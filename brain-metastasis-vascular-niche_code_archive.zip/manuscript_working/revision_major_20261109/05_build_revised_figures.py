from pathlib import Path
import json, os, sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
REV = ROOT / "manuscript_working" / "revision_major_20261109" / "outputs"
SRC = ROOT / "manuscript_working" / "figures_v1" / "source_data"
OUT = ROOT / "manuscript_working" / "revision_major_20261109" / "formal_main_figures"
PDF, PNG, SVG, TIFF, QA = [OUT / x for x in ("pdf", "png", "svg", "tiff", "qa")]
for d in (PDF, PNG, SVG, TIFF, QA):
    d.mkdir(parents=True, exist_ok=True)

skill_scripts = Path(os.environ.get(
    "NATURE_FIGURE_SCRIPTS",
    str(Path.home() / ".codex" / "skills" / "nature-figure" / "scripts"),
))
sys.path.insert(0, str(skill_scripts))
from audit_panel_alignment import require_matplotlib_panel_alignment

plt.rcParams.update({
    "font.family": "sans-serif", "font.sans-serif": ["Arial", "DejaVu Sans"],
    "font.size": 7, "axes.titlesize": 7.4, "axes.labelsize": 7,
    "xtick.labelsize": 6.2, "ytick.labelsize": 6.2, "legend.fontsize": 6,
    "axes.linewidth": .65, "axes.spines.top": False, "axes.spines.right": False,
    "pdf.fonttype": 42, "svg.fonttype": "none",
})

INK = "#222222"; MUTED = "#6F7377"; GRID = "#E5E7E9"
BLUE = "#3B6FB6"; TEAL = "#238B80"; ORANGE = "#D87842"
PURPLE = "#7764A8"; RED = "#C74F50"; GRAY = "#9AA0A4"; PALE = "#F4F6F7"

def rr(name):
    return pd.read_csv(REV / name)

def rs(name, **kwargs):
    return pd.read_csv(SRC / name, **kwargs)

def style(ax, grid="y"):
    ax.spines["left"].set_color(GRAY)
    ax.spines["bottom"].set_color(GRAY)
    if grid:
        ax.grid(axis=grid, color=GRID, lw=.5, zorder=0)

def panel(ax, text):
    ax.text(-.11, 1.04, text, transform=ax.transAxes, weight="bold",
            fontsize=8, va="bottom")

def jit(n, seed, width=.06):
    return np.random.default_rng(seed).uniform(-width, width, n)

def median(ax, x, values, color=INK, width=.22):
    if len(values):
        ax.hlines(np.median(values), x-width, x+width, color=color, lw=1.35, zorder=4)

def export(fig, stem, axes, ids, rows=None, exemptions=None):
    fig.canvas.draw()
    require_matplotlib_panel_alignment(
        fig, axes=axes, panel_ids=ids, row_groups=rows or [],
        exemptions=exemptions or [], require_panel_labels=False,
        json_out=str(QA / f"{stem}.alignment.json"),
        overlay_svg=str(QA / f"{stem}.alignment.svg"),
        tolerance_pt=1.5, gutter_tolerance_pt=1.5, strict=True,
    )
    fig.savefig(PDF / f"{stem}.pdf", bbox_inches="tight", facecolor="white")
    fig.savefig(SVG / f"{stem}.svg", bbox_inches="tight", facecolor="white")
    fig.savefig(PNG / f"{stem}.png", dpi=300, bbox_inches="tight", facecolor="white")
    fig.savefig(TIFF / f"{stem}.tiff", dpi=600, bbox_inches="tight", facecolor="white")
    plt.close(fig)

def figure1():
    fig = plt.figure(figsize=(7.2, 6.35), layout="constrained")
    gs = fig.add_gridspec(3, 2, height_ratios=[.95, 1.0, 1.75],
                          wspace=.20, hspace=.18)
    axa = fig.add_subplot(gs[0, 0])
    census = rr("internal_patient_specimen_census.csv")
    rows = ["scRNA tumour", "scRNA field", "spatial tumour", "spatial field"]
    cols = census.paper_patient_id.tolist()
    for j, r in census.iterrows():
        values = [pd.notna(r.scRNA_tumor), pd.notna(r.scRNA_adjacent),
                  pd.notna(r.ST_tumor), pd.notna(r.ST_adjacent)]
        role = r.manuscript_role
        color = BLUE if "Confirmed" in role else (PURPLE if "Provisional" in role else GRAY)
        for i, present in enumerate(values):
            axa.scatter(j, 3-i, s=38, marker="s",
                        facecolor=color if present else "white", edgecolor=color, lw=.8)
    axa.set_xticks(range(len(cols)), cols, rotation=90, ha="center")
    axa.set_yticks(range(4), rows[::-1]); axa.tick_params(length=0)
    axa.set_xlim(-.6, len(cols)-.4); axa.set_ylim(-.6, 3.6)
    [s.set_visible(False) for s in axa.spines.values()]
    axa.set_title("Internal cohort and assay coverage", loc="left")
    panel(axa, "a")

    axb = fig.add_subplot(gs[0, 1])
    u = rs("FocusedFig1B_frozen_UMAP.csv.gz")
    counts = u["lineage_l1"].value_counts()
    stromal_name = counts.index[np.argmin(np.abs(counts.to_numpy() - 711))]
    endothelial_name = counts.index[np.argmin(np.abs(counts.to_numpy() - 593))]
    stromal = u["lineage_l1"].eq(stromal_name)
    endothelial = u["lineage_l1"].eq(endothelial_name)
    background = ~(stromal | endothelial)
    axb.scatter(u.loc[background, "UMAP_1"], u.loc[background, "UMAP_2"],
                s=.10, c="#E8E8E8", lw=0, rasterized=True)
    for mask, color, label in ((stromal, PURPLE, f"Stromal ({stromal.sum():,})"),
                               (endothelial, RED, f"Endothelial ({endothelial.sum():,})")):
        axb.scatter(u.loc[mask, "UMAP_1"], u.loc[mask, "UMAP_2"],
                    s=.75, c=color, lw=0, rasterized=True, label=label)
    axb.set_xticks([]); axb.set_yticks([]); axb.set_aspect("equal")
    [s.set_visible(False) for s in axb.spines.values()]
    axb.set_title("Vascular cells in the single-cell atlas", loc="left")
    axb.legend(loc="lower right", markerscale=3, handletextpad=.25)
    panel(axb, "b")

    axc = fig.add_subplot(gs[1, :])
    det = rs("FocusedFig1C_marker_detection.csv", index_col=0)
    mean = rs("FocusedFig1C_marker_mean_logCP10K.csv", index_col=0)
    z = (mean - mean.min()) / (mean.max() - mean.min()).replace(0, 1)
    for i, idx in enumerate(det.index):
        axc.scatter(np.arange(det.shape[1]), np.full(det.shape[1], i),
                    s=7 + 35*det.loc[idx].to_numpy(),
                    c=z.loc[idx].to_numpy(), cmap="Blues", vmin=0, vmax=1,
                    edgecolor="white", lw=.2)
    axc.set_xticks(range(det.shape[1]), det.columns, rotation=35, ha="right",
                   fontstyle="italic")
    state_labels = ["Pericyte 1", "Pericyte 2", "Fibroblast 1", "Fibroblast 2",
                    "Fibroblast 3", "Fibroblast 4", "Barrier EC 1", "Barrier EC 2",
                    "Barrier EC 3", "Venous EC"]
    axc.set_yticks(range(det.shape[0]), state_labels)
    axc.set_ylim(det.shape[0]-.5, -.5); axc.tick_params(length=0)
    [s.set_visible(False) for s in axc.spines.values()]
    axc.set_title("Marker evidence resolves mural and endothelial identities", loc="left")
    panel(axc, "c")

    mapspec = gs[2, :].subgridspec(2, 4, wspace=.06, hspace=.07)
    slide_names = ["S1_T", "Toct6", "Toct5", "Toct4"]
    display_names = ["LUAD-1", "LUAD-3*", "PCNSL-1†", "PCNSL-3"]
    map_axes = []
    for row, score_name in enumerate(("EC_score", "mural_score")):
        for col, (slide, display) in enumerate(zip(slide_names, display_names)):
            ax = fig.add_subplot(mapspec[row, col]); map_axes.append(ax)
            d = rs(f"FocusedFig1D_{slide}_scores.csv")
            vals = d[score_name].to_numpy(); order = np.argsort(vals)
            ax.scatter(d["px"].to_numpy()[order], -d["py"].to_numpy()[order],
                       c=vals[order], s=1.5, cmap="magma", vmin=-.1, vmax=.6,
                       lw=0, rasterized=True)
            ax.set_aspect("equal"); ax.set_xticks([]); ax.set_yticks([])
            [s.set_visible(False) for s in ax.spines.values()]
            if row == 0: ax.set_title(display, fontsize=6.7, pad=2)
            if col == 0:
                ax.set_ylabel("EC score" if row == 0 else "Mural score", labelpad=4)
    panel(map_axes[0], "d")
    export(fig, "Main_Fig1", [axa, axb, axc, map_axes[0]], ["a", "b", "c", "d"],
           rows=[["a", "b"]],
           exemptions=[{"panels": ["c"], "checks": ["column", "panel-label"],
                        "reason": "The marker panel spans the full figure width; the spatial image plate is excluded from comparable-axis alignment."}])

def figure2():
    fig = plt.figure(figsize=(7.2, 6.15), layout="constrained")
    gs = fig.add_gridspec(2, 6, height_ratios=[1.0, 1.08], wspace=.42, hspace=.48)
    data = rr("slideseq_spatial_stratified_null.csv")
    ec_mural = data[data.pair.eq("EC-mural")]

    axa = fig.add_subplot(gs[0, 0:3])
    xen = rr("xenium_section_level_descriptive.csv")
    for sample, q in xen[xen.pair.str.contains("EC") & xen.pair.str.contains("壁")].groupby("sample"):
        q = q.sort_values("radius_um")
        axa.plot(q.radius_um, q.obs_over_null, "-o", color=TEAL, alpha=.72, lw=1, ms=3)
    axa.axhline(1, color=GRAY, ls="--", lw=.75)
    axa.set_yscale("log"); axa.set_yticks([1, 2, 5, 10], ["1", "2", "5", "10"])
    axa.minorticks_off(); axa.set_xticks([15, 30, 60])
    axa.set_xlabel("Radius (µm)"); axa.set_ylabel("Observed / permutation null")
    axa.set_title("Xenium near-field enrichment decays with radius", loc="left")
    style(axa); panel(axa, "a")

    axb = fig.add_subplot(gs[0, 3:6])
    for (_, site), q in ec_mural.groupby(["patient", "site"]):
        q = q.sort_values("radius_multiplier")
        axb.plot(q.radius_multiplier, q.log2_enrichment, "-o",
                 color=BLUE if site == "BM" else GRAY, alpha=.72, lw=.9, ms=3)
    axb.axhline(0, color=GRAY, ls="--", lw=.75)
    axb.set_xticks([2, 5, 10], ["2×", "5×", "10×"])
    axb.set_xlabel("Radius / section median nearest-neighbour distance")
    axb.set_ylabel("")
    axb.set_title("Slide-seq log2 enrichment across scaled radii\nblue, BrM; grey, primary lung",
                  loc="left", fontsize=6.6)
    style(axb); panel(axb, "b")

    axc = fig.add_subplot(gs[1, 0:2])
    nearest = ec_mural[ec_mural.radius_multiplier.eq(2)]
    for i, (site, color) in enumerate((("BM", BLUE), ("PT", GRAY))):
        values = nearest.loc[nearest.site.eq(site), "log2_enrichment"].to_numpy()
        axc.scatter(i+jit(len(values), 30+i), values, s=24, c=color,
                    edgecolor="white", lw=.4)
        median(axc, i, values)
    test = rr("slideseq_patient_group_test.csv").iloc[0]
    axc.axhline(0, color=GRAY, ls="--", lw=.75)
    axc.set_xticks([0, 1], ["BrM\nn=6", "Primary lung\nn=7"])
    axc.set_ylabel("Nearest-radius log2 enrichment")
    axc.set_title(f"Patient-level contrast\nΔ={test.median_difference:.2f} "
                  f"[{test.bootstrap95_low:.2f}, {test.bootstrap95_high:.2f}]\n"
                  f"exact P={test.p_exact_patient_label_permutation:.3f}",
                  loc="left", fontsize=6.6)
    style(axc); panel(axc, "c")

    axd = fig.add_subplot(gs[1, 2:4])
    xe = rs("RevisedFig2E_Xenium_pair_specificity.csv")
    for i, (pair_name, q) in enumerate(xe.groupby("pair", sort=False)):
        values = np.log2(q.obs_over_null.to_numpy())
        color = (TEAL, PURPLE, RED)[i]
        axd.scatter(i+jit(len(values), 70+i), values, s=21, c=color,
                    edgecolor="white", lw=.35)
        median(axd, i, values)
    axd.axhline(0, color=GRAY, ls="--", lw=.75)
    axd.set_xticks(range(3), ["EC–mural", "Mural–tumour", "EC–tumour"],
                   rotation=25, ha="right")
    axd.set_ylabel("")
    axd.set_title("Xenium pair specificity (15-µm log2)\nsection-level descriptive", loc="left", fontsize=6.6)
    style(axd); panel(axd, "d")

    axe = fig.add_subplot(gs[1, 4:6])
    pairs = ["EC-mural", "mural-tumour", "EC-tumour"]
    for i, pair_name in enumerate(pairs):
        for site, off, color in (("BM", -.10, BLUE), ("PT", .10, GRAY)):
            values = data[(data.pair.eq(pair_name)) &
                          (data.radius_multiplier.eq(2)) &
                          (data.site.eq(site))].log2_enrichment.to_numpy()
            axe.scatter(i+off+jit(len(values), 90+i+(site == "PT"), .025),
                        values, s=14, c=color, alpha=.82)
            median(axe, i+off, values, color, .07)
    axe.axhline(0, color=GRAY, ls="--", lw=.75)
    axe.set_xticks(range(3), ["EC–mural", "Mural–tumour", "EC–tumour"],
                   rotation=25, ha="right")
    axe.set_ylabel("")
    axe.set_title("Slide-seq pair specificity (log2)\nblue, BrM; grey, primary", loc="left", fontsize=6.6)
    axe.yaxis.tick_right()
    axe.tick_params(axis="y", labelright=True, labelleft=False)
    style(axe); panel(axe, "e")

    export(fig, "Main_Fig2", [axa, axb, axc, axd, axe],
           ["a", "b", "c", "d", "e"], rows=[["a", "b"], ["c", "d", "e"]],
           exemptions=[{"panels": ["c", "d", "e"], "checks": ["horizontal-gutter"],
                        "reason": "The lower panels use intentionally different categorical label widths."},
                       {"panels": ["a", "c"], "checks": ["panel-label"],
                        "reason": "The upper half-width trajectory and lower one-third contrast begin on different grid spans."}])

def figure3():
    fig = plt.figure(figsize=(7.2, 5.45), layout="constrained")
    gs = fig.add_gridspec(2, 2, height_ratios=[1, 1.05], wspace=.28, hspace=.28)
    stats = rr("programme_reanalysis_statistics.csv")
    paired = rr("internal_programme_paired_standardized.csv")
    axa = fig.add_subplot(gs[0, 0])
    internal = stats[stats.dataset.str.startswith("Internal")].copy()
    for i, programme in enumerate(["T_transport", "M_matrix"]):
        color = BLUE if programme == "T_transport" else ORANGE
        values = paired.loc[paired.programme.eq(programme), "paired_delta_z"].to_numpy()
        axa.scatter(i + jit(len(values), 800+i, .055), values, s=30, c=color,
                    edgecolor="white", lw=.45, zorder=3)
        row = internal.loc[internal.programme.eq(programme)].iloc[0]
        axa.plot([i, i], [row.ci95_low, row.ci95_high], color=color, lw=1.5, zorder=2)
        axa.scatter(i, row.effect, marker="D", s=38, c="white", edgecolor=color,
                    lw=1.3, zorder=4)
    axa.axhline(0, color=GRAY, ls="--", lw=.8)
    axa.set_xticks([0, 1], ["Transport", "Matrix"])
    axa.set_ylabel("Tumour minus field\nstandardized programme score")
    axa.set_title("Internal paired tumour–field effects\nn=3 patients", loc="left")
    style(axa); panel(axa, "a")

    def donor_panel(ax, frame, group_order, group_labels, title, seed):
        xpos = [0, 1, 3, 4]
        k = 0
        for j, programme in enumerate(("T_transport", "M_matrix")):
            for group, label, color in zip(group_order, group_labels, (TEAL, GRAY)):
                vals = frame[(frame.programme.eq(programme)) &
                             (frame.group.eq(group))].score_z.to_numpy()
                x = xpos[k]; k += 1
                ax.scatter(x + jit(len(vals), seed+k, .07), vals, s=24,
                           c=color, edgecolor="white", lw=.4, zorder=3)
                median(ax, x, vals)
        ax.axvline(2, color=GRID, lw=.8)
        ax.set_xticks(xpos, [group_labels[0] + "\nT", group_labels[1] + "\nT",
                            group_labels[0] + "\nM", group_labels[1] + "\nM"])
        ax.set_ylabel("Cohort-standardized programme score")
        ax.set_title(title, loc="left")
        style(ax)

    axb = fig.add_subplot(gs[0, 1])
    donor_panel(axb, rr("kim_programme_standardized.csv"),
                ("BrM", "Primary lung"), ("BrM", "Lung"),
                "Kim patient-level distributions", 900)
    panel(axb, "b")

    axc = fig.add_subplot(gs[1, 0])
    donor_panel(axc, rr("walchli_programme_standardized.csv"),
                ("BrM", "Temporal lobe"), ("Met", "Brain"),
                "Wälchli donor-level distributions", 950)
    panel(axc, "c")

    axd = fig.add_subplot(gs[1, 1])
    external = stats[~stats.dataset.str.startswith("Internal")].copy()
    labels = [f"{r.dataset}: {'T transport' if r.programme == 'T_transport' else 'M matrix'}"
              for _, r in external.iterrows()]
    y = np.arange(len(external))[::-1]; axd.axvline(0, color=GRAY, ls="--", lw=.8)
    for yi, (_, row) in zip(y, external.iterrows()):
        color = BLUE if row.programme == "T_transport" else ORANGE
        axd.plot([row.ci95_low, row.ci95_high], [yi, yi], color=color, lw=1.5)
        axd.scatter(row.effect, yi, s=30, c=color, edgecolor="white", lw=.4)
    axd.set_yticks(y, labels)
    axd.set_xlabel("BrM minus reference\ncohort-standardized median difference")
    axd.set_title("External effect summary", loc="left")
    style(axd, "x"); panel(axd, "d")
    export(fig, "Main_Fig3", [axa, axb, axc, axd],
           ["a", "b", "c", "d"], rows=[["a", "b"], ["c", "d"]],
           exemptions=[{"panels": ["c", "d"], "checks": ["horizontal-gutter"],
                        "reason": "The donor distribution and forest summary require different y-label widths."}])

def figure4():
    fig = plt.figure(figsize=(7.2, 7.85), layout="constrained")
    gs = fig.add_gridspec(3, 6, height_ratios=[1, 1.05, .92],
                          wspace=.52, hspace=.52)
    order = ["EC_cycle", "tip_guidance", "activation_fenestration",
             "ECM_associated", "BBB_transport", "junction"]
    labels = ["Cycle", "Tip/guidance", "Activation", "ECM", "BBB transport", "Junction"]

    axa = fig.add_subplot(gs[0, 0:2])
    tests = rs("RevisedFig4B_EC_donor_tests.csv").set_index("module").loc[order].reset_index()
    y = np.arange(6)[::-1]; axa.axvline(0, color=GRAY, ls="--", lw=.75)
    for yi, (_, row) in zip(y, tests.iterrows()):
        color = RED if row.median_diff > 0 else BLUE
        axa.plot([row.median_bootstrap95_low, row.median_bootstrap95_high],
                 [yi, yi], color=color, lw=1.4)
        axa.scatter(row.median_diff, yi, c=color, s=27, edgecolor="white", lw=.4)
    axa.set_yticks(y, labels)
    axa.set_xlabel("BrM minus temporal lobe\ndonor-level median score")
    axa.set_title("Endothelial programme remodelling", loc="left", pad=7)
    axa.set_xlim(-6.2, 8.5); axa.set_xticks([-5, 0, 5])
    style(axa, "x"); panel(axa, "a")

    axb = fig.add_subplot(gs[0, 2:4])
    foot = rs("RevisedFig4C_VEGF_footprint_scores.csv")
    for i, (group, color, label) in enumerate((("BM", TEAL, "BrM\nn=5"),
                                               ("TL", GRAY, "Temporal lobe\nn=9"),
                                               ("GBM", PURPLE, "GBM\nn=7"))):
        vals = foot.loc[foot.group.eq(group), "score"].to_numpy()
        axb.scatter(i+jit(len(vals), 1000+i, .06), vals, s=22, c=color,
                    edgecolor="white", lw=.4, zorder=3)
        median(axb, i, vals)
    axb.axhline(0, color=GRAY, ls="--", lw=.75)
    axb.set_xticks(range(3), ["BrM\nn=5", "Temporal lobe\nn=9", "GBM\nn=7"])
    axb.set_ylabel("")
    axb.set_title("3D VEGF footprint score", loc="left", pad=7)
    style(axb); panel(axb, "b")

    axc = fig.add_subplot(gs[0, 4:6])
    pert = rs("RevisedFig4D_3D_VEGF_panel_tests.csv").set_index("panel").loc[order].reset_index()
    y = np.arange(6)[::-1]; axc.axvline(0, color=GRAY, ls="--", lw=.75)
    for yi, (_, row) in zip(y, pert.iterrows()):
        color = TEAL if row.delta_z > 0 else GRAY
        axc.plot([row.bootstrap_95lo, row.bootstrap_95hi], [yi, yi], color=color, lw=1.4)
        axc.scatter(row.delta_z, yi, c=color, s=27, edgecolor="white", lw=.4)
    axc.set_yticks(y, labels)
    axc.set_xlabel("VEGF minus control\nstandardized score")
    axc.set_title("VEGF-response calibration", loc="left", pad=7)
    axc.set_xlim(-.7, 2.2); axc.set_xticks([0, 1, 2])
    axc.yaxis.tick_right()
    axc.tick_params(axis="y", labelright=True, labelleft=False)
    style(axc, "x"); panel(axc, "c")

    imc_raw = rs("RevisedFig4E_F_IMC_patient_metrics.csv")
    axd = fig.add_subplot(gs[1, 0:3])
    for i, (group, color) in enumerate((("Brain Metastasis", ORANGE), ("Glioblastoma", GRAY))):
        vals = imc_raw.loc[imc_raw.group.eq(group), "EC_per_mm2_mean_ROI"].dropna().to_numpy()
        axd.scatter(i+jit(len(vals), 1100+i, .07), vals, s=10, c=color,
                    alpha=.72, edgecolor="white", lw=.2, zorder=3)
        median(axd, i, vals)
    axd.set_yscale("log"); axd.set_yticks([10, 100], ["10", "100"]); axd.minorticks_off()
    axd.set_xticks([0, 1], ["BrM\nn=46", "GBM\nn=118"])
    axd.set_ylabel("Patient mean EC density / mm²")
    axd.set_title("Patient-level endothelial density", loc="left")
    style(axd); panel(axd, "d")

    axe = fig.add_subplot(gs[1, 3:6])
    for i, (group, color) in enumerate((("Brain Metastasis", ORANGE), ("Glioblastoma", GRAY))):
        vals = imc_raw.loc[imc_raw.group.eq(group), "cancer_median_dist_um_mean_ROI"].dropna().to_numpy()
        axe.scatter(i+jit(len(vals), 1150+i, .07), vals, s=10, c=color,
                    alpha=.72, edgecolor="white", lw=.2, zorder=3)
        median(axe, i, vals)
    axe.set_xticks([0, 1], ["BrM\nn=46", "GBM\nn=117"])
    axe.set_ylabel("")
    axe.set_title("Patient mean nearest-EC distance (µm)", loc="left")
    style(axe); panel(axe, "e")

    axf = fig.add_subplot(gs[2, :])
    imc = rr("imc_clustered_regression_models.csv")
    ilabels = ["Nearest-EC distance\n+ density + region",
               "Nearest-EC distance\n+ density + region + age + sex",
               "EC density\n+ region"]
    y = np.arange(3)[::-1]; axf.axvline(1, color=GRAY, ls="--", lw=.75)
    for yi, (_, row) in zip(y, imc.iterrows()):
        color = ORANGE if row.group_ratio > 1 else BLUE
        axf.plot([row.ci95_low_ratio, row.ci95_high_ratio], [yi, yi],
                 color=color, lw=1.7)
        axf.scatter(row.group_ratio, yi, s=34, c=color,
                    edgecolor="white", lw=.4, zorder=3)
    axf.set_yticks(y, ilabels)
    axf.set_xlabel("Adjusted BrM / GBM ratio (patient-clustered 95% CI)")
    axf.set_title("IMC geometry remains altered after density and region adjustment", loc="left")
    axf.set_xlim(.25, 1.5); axf.set_xticks([.4, .6, .8, 1.0, 1.2, 1.4])
    style(axf, "x"); panel(axf, "f")

    export(fig, "Main_Fig4", [axa, axb, axc, axd, axe, axf],
           ["a", "b", "c", "d", "e", "f"],
           rows=[["a", "b", "c"], ["d", "e"]],
           exemptions=[{"panels": ["a", "b", "c"], "checks": ["horizontal-gutter"],
                        "reason": "The top-row forest and donor panels have different y-label requirements."},
                       {"panels": ["a", "d"], "checks": ["panel-label"],
                        "reason": "Top one-third and middle one-half panels begin on different grid spans."},
                       {"panels": ["f"], "checks": ["column", "panel-label"],
                        "reason": "The adjusted IMC forest spans the full figure width."}])

def main():
    figure1(); figure2(); figure3(); figure4()
    contracts = {
        "Fig1": {"conclusion": "Cohort roles and biological units are explicit."},
        "Fig2": {"conclusion": "EC–mural proximity is cross-platform, while the BrM–lung contrast is directional but not significant."},
        "Fig3": {"conclusion": "Mural matrix programme increases externally; transport direction is cohort-dependent."},
        "Fig4": {"conclusion": "Activated EC states coexist with density-adjusted altered geometry; VEGF is calibration only."},
    }
    (OUT / "figure_contracts.json").write_text(json.dumps(contracts, indent=2), encoding="utf-8")
    print(json.dumps({"outputs": [str(PDF / f"Main_Fig{i}.pdf")
                                  for i in range(1, 5)]}, indent=2))

if __name__ == "__main__":
    main()
