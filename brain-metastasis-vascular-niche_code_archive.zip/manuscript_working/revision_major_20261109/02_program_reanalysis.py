from pathlib import Path
import itertools
import json

import numpy as np
import pandas as pd
from scipy.stats import rankdata
from statsmodels.stats.multitest import multipletests


ROOT = Path(__file__).resolve().parents[2]
H = ROOT / "FINAL_HANDOFF_20260922"
OUT = ROOT / "manuscript_working" / "revision_major_20261109" / "outputs"
OUT.mkdir(parents=True, exist_ok=True)
RNG = np.random.default_rng(20261109)


def exact_rank_sum(x, y):
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    z = np.r_[x, y]
    ranks = rankdata(z, method="average")
    nx = len(x)
    observed = abs(ranks[:nx].sum() - nx * (len(z) + 1) / 2)
    combos = np.array(list(itertools.combinations(range(len(z)), nx)), dtype=int)
    null = np.abs(ranks[combos].sum(axis=1) - nx * (len(z) + 1) / 2)
    p = float(np.mean(null >= observed - 1e-12))
    u = ranks[:nx].sum() - nx * (nx + 1) / 2
    rbc = float(2 * u / (len(x) * len(y)) - 1)
    return p, len(null), rbc


def bootstrap_median_difference(x, y, n_boot=20000):
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    vals = np.empty(n_boot, float)
    for i in range(n_boot):
        vals[i] = np.median(RNG.choice(x, len(x), replace=True)) - np.median(RNG.choice(y, len(y), replace=True))
    return float(np.quantile(vals, 0.025)), float(np.quantile(vals, 0.975))


def paired_signflip(delta):
    delta = np.asarray(delta, float)
    obs = abs(float(np.mean(delta)))
    signs = np.array(list(itertools.product([-1.0, 1.0], repeat=len(delta))))
    null = np.abs((signs * delta).mean(axis=1))
    return float(np.mean(null >= obs - 1e-12)), len(null)


def bootstrap_paired_mean(delta, n_boot=20000):
    delta = np.asarray(delta, float)
    vals = np.empty(n_boot, float)
    for i in range(n_boot):
        vals[i] = np.mean(RNG.choice(delta, len(delta), replace=True))
    return float(np.quantile(vals, 0.025)), float(np.quantile(vals, 0.975))


# Internal analysis: confirmed lung-origin BrM patients only; each programme is tested within itself.
cols = ["patient_id", "tissue_role", "pericyte_clean", "T_transport", "M_matrix", "T_transport_ndet", "M_matrix_ndet", "total_counts", "n_genes"]
cells = pd.read_csv(H / "results/spatial_distance_and_state_validation/internal_cell_states.csv.gz", usecols=cols)
cells = cells[cells.pericyte_clean & cells.patient_id.isin(["P1", "P3", "P5"])].copy()
means = (
    cells.groupby(["patient_id", "tissue_role"])
    .agg(
        n_cells=("T_transport", "size"),
        T_transport=("T_transport", "mean"),
        M_matrix=("M_matrix", "mean"),
        T_genes_detected=("T_transport_ndet", "mean"),
        M_genes_detected=("M_matrix_ndet", "mean"),
        median_UMI=("total_counts", "median"),
        median_genes=("n_genes", "median"),
    )
    .reset_index()
)
paired = means[means.n_cells >= 10].pivot(index="patient_id", columns="tissue_role")
paired = paired.dropna(subset=[("T_transport", "tumor"), ("T_transport", "adjacent_or_field"), ("M_matrix", "tumor"), ("M_matrix", "adjacent_or_field")])
internal_rows = []
internal_scores = []
for metric in ["T_transport", "M_matrix"]:
    ref = paired[(metric, "adjacent_or_field")].to_numpy(float)
    scale = float(np.std(ref, ddof=1))
    if not np.isfinite(scale) or scale == 0:
        scale = 1.0
    center = float(np.mean(ref))
    tumor_z = (paired[(metric, "tumor")].to_numpy(float) - center) / scale
    field_z = (ref - center) / scale
    delta = tumor_z - field_z
    p, nperm = paired_signflip(delta)
    lo, hi = bootstrap_paired_mean(delta)
    internal_rows.append({
        "dataset": "Internal confirmed BrM",
        "programme": metric,
        "comparison": "tumour vs adjacent/field",
        "n_BrM_pairs": len(delta),
        "n_reference": len(delta),
        "effect": float(np.mean(delta)),
        "effect_definition": "mean paired difference in reference-standardized programme score",
        "ci95_low": lo,
        "ci95_high": hi,
        "p_exact": p,
        "n_permutations": nperm,
        "replicate_unit": "patient",
    })
    for pid, tz, fz, dz in zip(paired.index, tumor_z, field_z, delta):
        internal_scores.append({"patient": pid, "programme": metric, "tumour_z": tz, "field_z": fz, "paired_delta_z": dz})

internal_stats = pd.DataFrame(internal_rows)
internal_stats["q_BH_within_internal"] = multipletests(internal_stats.p_exact, method="fdr_bh")[1]
pd.DataFrame(internal_scores).to_csv(OUT / "internal_programme_paired_standardized.csv", index=False)

# Kim cohort: sample and patient IDs are one-to-one in the retained strict-gate subset.
kim = pd.read_csv(H / "results/spatial_distance_and_state_validation/kim_pericyte_sample_scores.csv")
kim = kim[(kim.gate == "pericyte_clean") & (kim.n_cells >= 10) & kim.origin.isin(["mBrain", "tLung"])].copy()
kim_meta = pd.read_csv(H / "results/nutrition/kim_author_sample_metadata.csv")
kim = kim.merge(kim_meta[["patient", "sample"]], on="sample", how="left", validate="1:1")
external_stats = []
kim_long = []
for metric, label in [("T_mean", "T_transport"), ("M_mean", "M_matrix")]:
    pooled = kim[metric].to_numpy(float)
    center, scale = float(np.mean(pooled)), float(np.std(pooled, ddof=1))
    kim[f"{label}_z"] = (kim[metric] - center) / scale
    x = kim.loc[kim.origin.eq("mBrain"), f"{label}_z"].to_numpy(float)
    y = kim.loc[kim.origin.eq("tLung"), f"{label}_z"].to_numpy(float)
    p, nperm, rbc = exact_rank_sum(x, y)
    lo, hi = bootstrap_median_difference(x, y)
    external_stats.append({
        "dataset": "Kim",
        "programme": label,
        "comparison": "brain metastasis vs primary lung",
        "n_BrM": len(x),
        "n_reference": len(y),
        "effect": float(np.median(x) - np.median(y)),
        "effect_definition": "median difference in cohort-standardized programme score",
        "ci95_low": lo,
        "ci95_high": hi,
        "rank_biserial": rbc,
        "p_exact": p,
        "n_permutations": nperm,
        "replicate_unit": "patient/sample (one retained sample per patient)",
    })
    kim_long.extend({"patient": r.patient, "sample": r.sample, "group": "BrM" if r.origin == "mBrain" else "Primary lung", "programme": label, "score_z": r[f"{label}_z"], "n_cells": r.n_cells} for _, r in kim.iterrows())

pd.DataFrame(kim_long).to_csv(OUT / "kim_programme_standardized.csv", index=False)

# Walchli cohort: donor aggregation was performed before testing.
wal = pd.read_csv(H / "results/pericyte_differentiation/pericyte_donor_scores.csv")
wal = wal[(wal.dataset == "Walchli") & (wal.gate == "clean") & wal.group.isin(["MET", "TL"]) & (wal.n_cells >= 10)].copy()
wal_long = []
for metric in ["T_transport", "M_matrix"]:
    pooled = wal[metric].to_numpy(float)
    center, scale = float(np.mean(pooled)), float(np.std(pooled, ddof=1))
    wal[f"{metric}_z"] = (wal[metric] - center) / scale
    x = wal.loc[wal.group.eq("MET"), f"{metric}_z"].to_numpy(float)
    y = wal.loc[wal.group.eq("TL"), f"{metric}_z"].to_numpy(float)
    p, nperm, rbc = exact_rank_sum(x, y)
    lo, hi = bootstrap_median_difference(x, y)
    external_stats.append({
        "dataset": "Walchli",
        "programme": metric,
        "comparison": "brain metastasis vs temporal lobe",
        "n_BrM": len(x),
        "n_reference": len(y),
        "effect": float(np.median(x) - np.median(y)),
        "effect_definition": "median difference in cohort-standardized programme score",
        "ci95_low": lo,
        "ci95_high": hi,
        "rank_biserial": rbc,
        "p_exact": p,
        "n_permutations": nperm,
        "replicate_unit": "donor",
    })
    wal_long.extend({"donor": r.donor, "group": "BrM" if r.group == "MET" else "Temporal lobe", "programme": metric, "score_z": r[f"{metric}_z"], "n_cells": r.n_cells, "n_samples": r.n_samples} for _, r in wal.iterrows())

pd.DataFrame(wal_long).to_csv(OUT / "walchli_programme_standardized.csv", index=False)
external_stats = pd.DataFrame(external_stats)
external_stats["q_BH_external4"] = multipletests(external_stats.p_exact, method="fdr_bh")[1]
stats = pd.concat([internal_stats, external_stats], ignore_index=True, sort=False)
stats.to_csv(OUT / "programme_reanalysis_statistics.csv", index=False)

# Coverage and scoring audit. The fixed gene lists are explicit; internal detected-gene counts quantify depth dependence.
gene_sets = json.loads((H / "results/pericyte_differentiation/gene_sets.json").read_text(encoding="utf-8"))["gene_sets"]
coverage = means.copy()
coverage["T_gene_set_size"] = len(gene_sets["T_transport"])
coverage["M_gene_set_size"] = len(gene_sets["M_matrix"])
coverage["T_detected_fraction"] = coverage.T_genes_detected / coverage.T_gene_set_size
coverage["M_detected_fraction"] = coverage.M_genes_detected / coverage.M_gene_set_size
coverage.to_csv(OUT / "internal_programme_gene_coverage.csv", index=False)
pd.DataFrame([
    {"programme": "T_transport", "genes": ";".join(gene_sets["T_transport"]), "n_genes": len(gene_sets["T_transport"])},
    {"programme": "M_matrix", "genes": ";".join(gene_sets["M_matrix"]), "n_genes": len(gene_sets["M_matrix"])},
]).to_csv(OUT / "mural_programme_gene_lists.csv", index=False)

summary = {
    "primary_change": "raw cross-programme M>T comparison removed",
    "internal_pairs": int(len(paired)),
    "external_tests": external_stats.to_dict(orient="records"),
    "interpretation": "Programme-specific standardized effects only; internal evidence is paired but underpowered.",
}
(OUT / "programme_reanalysis_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
print(stats.to_string(index=False))
