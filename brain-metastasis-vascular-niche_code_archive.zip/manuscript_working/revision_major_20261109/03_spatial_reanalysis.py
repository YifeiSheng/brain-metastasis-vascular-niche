from pathlib import Path
import itertools
import json

import numpy as np
import pandas as pd
from sklearn.neighbors import NearestNeighbors, radius_neighbors_graph


ROOT = Path(__file__).resolve().parents[2]
H = ROOT / "FINAL_HANDOFF_20260922"
OUT = ROOT / "manuscript_working" / "revision_major_20261109" / "outputs"
OUT.mkdir(parents=True, exist_ok=True)
RNG = np.random.default_rng(20261109)
PX_UM = 0.65
N_PERM = 999

SITE = {
    "PA019": "BM", "PA025": "BM", "PA054": "BM", "PA056": "BM", "STK_14": "BM", "STK_18": "BM",
    "N254": "PT", "N586": "PT", "STK_15": "PT", "STK_20": "PT", "STK22dot2": "PT", "KRAS_10": "PT", "KRAS_12": "PT",
}


def spatial_strata(xy, n_bins=4):
    x_edges = np.unique(np.quantile(xy[:, 0], np.linspace(0, 1, n_bins + 1)))
    y_edges = np.unique(np.quantile(xy[:, 1], np.linspace(0, 1, n_bins + 1)))
    xb = np.clip(np.digitize(xy[:, 0], x_edges[1:-1]), 0, n_bins - 1)
    yb = np.clip(np.digitize(xy[:, 1], y_edges[1:-1]), 0, n_bins - 1)
    return xb * n_bins + yb


def permute_within_strata(mask, strata):
    out = np.zeros(len(mask), dtype=np.int8)
    for s in np.unique(strata):
        idx = np.flatnonzero(strata == s)
        n_pos = int(mask[idx].sum())
        if n_pos:
            out[RNG.choice(idx, size=n_pos, replace=False)] = 1
    return out


def bootstrap_median_difference(x, y, n_boot=20000):
    vals = np.empty(n_boot, float)
    for i in range(n_boot):
        vals[i] = np.median(RNG.choice(x, len(x), replace=True)) - np.median(RNG.choice(y, len(y), replace=True))
    return float(np.quantile(vals, 0.025)), float(np.quantile(vals, 0.975))


def exact_group_permutation(x, y):
    z = np.r_[x, y]
    nx = len(x)
    obs = abs(float(np.median(x) - np.median(y)))
    stats = []
    for idx in itertools.combinations(range(len(z)), nx):
        idx = np.asarray(idx)
        keep = np.ones(len(z), bool)
        keep[idx] = False
        stats.append(abs(float(np.median(z[idx]) - np.median(z[keep]))))
    stats = np.asarray(stats)
    return float(np.mean(stats >= obs - 1e-12)), len(stats)


pair_defs = [
    ("EC", "mural", "EC-mural"),
    ("mural", "tumour", "mural-tumour"),
    ("EC", "tumour", "EC-tumour"),
]
rows = []
bead_dir = H / "results/vascular_niche/V1"
for path in sorted(bead_dir.glob("beads_*.csv.gz")):
    pid = path.name.removeprefix("beads_").removesuffix(".csv.gz")
    if pid not in SITE:
        continue
    d = pd.read_csv(path)
    xy = d[["x", "y"]].to_numpy(float)
    labels = {
        "EC": d["EC"].astype(bool).to_numpy(),
        "mural": d["周细胞"].astype(bool).to_numpy(),
        "tumour": d["肿瘤"].astype(bool).to_numpy(),
    }
    strata = spatial_strata(xy, n_bins=4)
    nn = NearestNeighbors(n_neighbors=2).fit(xy)
    distances, _ = nn.kneighbors(xy)
    median_nn = float(np.median(distances[:, 1]))
    radii_mult = [2, 5, 10]
    graphs = {m: radius_neighbors_graph(xy, median_nn * m, mode="connectivity", include_self=False).tocsr() for m in radii_mult}
    for a_name, b_name, pair_name in pair_defs:
        a_idx = np.flatnonzero(labels[a_name])
        b_mask = labels[b_name]
        if len(a_idx) < 20 or b_mask.sum() < 20:
            continue
        obs = {}
        null = {m: np.empty(N_PERM, float) for m in radii_mult}
        degree = {}
        for m in radii_mult:
            ga = graphs[m][a_idx]
            degree[m] = np.asarray(ga.sum(axis=1)).ravel()
            obs[m] = float((ga @ b_mask.astype(np.int8) > 0).mean())
        for i in range(N_PERM):
            pm = permute_within_strata(b_mask, strata)
            for m in radii_mult:
                null[m][i] = float((graphs[m][a_idx] @ pm > 0).mean())
        for m in radii_mult:
            n = null[m]
            ratio = obs[m] / max(float(n.mean()), 1e-12)
            rows.append({
                "patient": pid,
                "site": SITE[pid],
                "pair": pair_name,
                "radius_multiplier": m,
                "radius_um": median_nn * m * PX_UM,
                "n_anchor": len(a_idx),
                "n_target": int(b_mask.sum()),
                "observed_fraction": obs[m],
                "null_mean_fraction": float(n.mean()),
                "obs_over_null": ratio,
                "log2_enrichment": float(np.log2(ratio)),
                "null_sd": float(n.std(ddof=1)),
                "p_upper_MC": float((1 + np.sum(n >= obs[m])) / (N_PERM + 1)),
                "n_permutations": N_PERM,
                "median_anchor_degree": float(np.median(degree[m])),
                "fraction_anchor_zero_degree": float(np.mean(degree[m] == 0)),
                "spatial_strata": "4x4 coordinate-quantile bins",
            })

spatial = pd.DataFrame(rows)
spatial.to_csv(OUT / "slideseq_spatial_stratified_null.csv", index=False)

nearest = spatial[(spatial.pair == "EC-mural") & (spatial.radius_multiplier == 2)].copy()
x = nearest.loc[nearest.site.eq("BM"), "log2_enrichment"].to_numpy(float)
y = nearest.loc[nearest.site.eq("PT"), "log2_enrichment"].to_numpy(float)
p, n_perm_group = exact_group_permutation(x, y)
lo, hi = bootstrap_median_difference(x, y)
group_test = pd.DataFrame([{
    "comparison": "Brain metastasis vs primary lung",
    "pair": "EC-mural",
    "radius_rule": "2 x within-section median nearest-neighbour distance",
    "n_BrM_patients": len(x),
    "n_primary_lung_patients": len(y),
    "median_BrM_log2_enrichment": float(np.median(x)),
    "median_primary_log2_enrichment": float(np.median(y)),
    "median_difference": float(np.median(x) - np.median(y)),
    "bootstrap95_low": lo,
    "bootstrap95_high": hi,
    "p_exact_patient_label_permutation": p,
    "n_exact_allocations": n_perm_group,
    "replicate_unit": "patient",
}])
group_test.to_csv(OUT / "slideseq_patient_group_test.csv", index=False)

# Xenium remains section-level descriptive evidence because donor IDs are not explicit and raw
# classified cells needed for a revised compartment-stratified null are not retained in the handoff.
xen = pd.read_csv(ROOT / "manuscript_working/figures_v1/source_data/RevisedFig2B_Xenium_EC_mural_radius.csv")
xen["biological_unit"] = "section/specimen; donor identity not explicit"
xen["inferential_role"] = "descriptive cross-platform replication only"
xen.to_csv(OUT / "xenium_section_level_descriptive.csv", index=False)

methods = {
    "SlideSeq": {
        "input": "retained bead coordinate and marker-class tables after duplicate-upload removal",
        "patients": {"Brain_metastasis": len(x), "Primary_lung": len(y)},
        "radii": "2, 5 and 10 times each section's median nearest-neighbour bead distance; physical scale uses 0.65 um/pixel",
        "anchor_target_pairs": [p[2] for p in pair_defs],
        "null": "target labels permuted within 4x4 coordinate-quantile strata; target count preserved within each stratum; coordinates, anchor labels and tissue geometry fixed",
        "edge_handling": "fixed anchor coordinates and fixed radius graph preserve each anchor's boundary-limited opportunity count; zero-degree fractions and median degrees are reported",
        "permutations_per_section_pair": N_PERM,
        "group_test": "exact patient-label permutation of the nearest-radius median difference; all allocations",
        "multiplicity": "EC-mural at nearest radius is primary; other radii and pairs are prespecified sensitivity analyses",
    },
    "Xenium": {
        "sections": int(xen["sample"].nunique()),
        "donor_identity": "not explicit in retained metadata",
        "role": "descriptive section-level radius decay; no disease or donor-level inference",
        "legacy_null_disclosure": "target count preserved under 50 global label permutations in the original export; no compartment-stratified rerun possible from retained classified-cell files",
    },
}
(OUT / "spatial_methods_revision.json").write_text(json.dumps(methods, indent=2), encoding="utf-8")
print(group_test.to_string(index=False))
