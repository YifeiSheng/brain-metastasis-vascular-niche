from pathlib import Path
import json

import numpy as np
import pandas as pd
import scipy.io as sio
from scipy.spatial import cKDTree
from scipy.stats import mannwhitneyu
import statsmodels.formula.api as smf


ROOT = Path(__file__).resolve().parents[2]
H = ROOT / "FINAL_HANDOFF_20260922"
BASE = H / "results/verified_vascular_geometry"
DATA = H / "data/external/imc/Karimi2023/data/BrainData"
OUT = ROOT / "manuscript_working" / "revision_major_20261109" / "outputs"
OUT.mkdir(parents=True, exist_ok=True)
RNG = np.random.default_rng(20261109)
N_NULL = 499


def bootstrap_median_difference(x, y, n_boot=20000):
    vals = np.empty(n_boot, float)
    for i in range(n_boot):
        vals[i] = np.median(RNG.choice(x, len(x), replace=True)) - np.median(RNG.choice(y, len(y), replace=True))
    return float(np.quantile(vals, 0.025)), float(np.quantile(vals, 0.975))


mapping = pd.read_csv(BASE / "ALL_ROI_MAPPING_OFFICIAL_VERIFIED.csv")
roi_metrics = pd.read_csv(BASE / "IMC_official_ROI_metrics.csv")
mapping_cols = [
    "official_roi", "Patient ID", "Tumor Type", "Primary Site of Brain Metastasis",
    "Tissue Region", "Age", "Sex", "Post-Surgical Treatment",
]
roi = roi_metrics.merge(mapping[mapping_cols], on=["official_roi", "Patient ID", "Tumor Type", "Tissue Region"], how="left", validate="1:1")
roi = roi[roi["Tumor Type"].isin(["Brain Metastasis", "Glioblastoma"])].copy()

completeness = []
for col in ["Primary Site of Brain Metastasis", "Tissue Region", "Age", "Sex", "Post-Surgical Treatment"]:
    for group, g in roi.groupby("Tumor Type"):
        v = g[col].astype(str)
        missing = g[col].isna() | v.str.lower().isin(["nan", "unknown", "na", "n/a", ""])
        completeness.append({
            "field": col,
            "group": group,
            "n_ROIs": len(g),
            "n_patients": g["Patient ID"].nunique(),
            "n_missing_ROIs": int(missing.sum()),
            "fraction_missing_ROIs": float(missing.mean()),
        })
pd.DataFrame(completeness).to_csv(OUT / "imc_covariate_completeness.csv", index=False)

# ROI-level regression with patient-clustered covariance.
roi["group_BrM"] = (roi["Tumor Type"] == "Brain Metastasis").astype(int)
roi["log_distance"] = np.log(roi["cancer_median_dist_um"])
roi["log_EC_density"] = np.log1p(roi["EC_per_mm2"])
roi["age_numeric"] = pd.to_numeric(roi["Age"], errors="coerce")
roi["sex_clean"] = roi["Sex"].where(roi["Sex"].isin(["M", "F"]))
roi["treatment_clean"] = roi["Post-Surgical Treatment"].where(~roi["Post-Surgical Treatment"].astype(str).str.lower().eq("unknown"))

model_rows = []
primary = roi.dropna(subset=["log_distance", "log_EC_density", "Tissue Region"]).copy()
m1 = smf.ols("log_distance ~ group_BrM + log_EC_density + C(Q('Tissue Region'))", data=primary).fit(cov_type="cluster", cov_kwds={"groups": primary["Patient ID"]})
for name, model, data, label in [("distance_primary", m1, primary, "group + EC density + tissue region")]:
    term = "group_BrM"
    model_rows.append({
        "model": name,
        "outcome": "log cancer-to-nearest-EC distance",
        "adjustment": label,
        "n_ROIs": len(data),
        "n_patients": data["Patient ID"].nunique(),
        "group_log_coefficient": float(model.params[term]),
        "group_ratio": float(np.exp(model.params[term])),
        "ci95_low_ratio": float(np.exp(model.conf_int().loc[term, 0])),
        "ci95_high_ratio": float(np.exp(model.conf_int().loc[term, 1])),
        "p_cluster_robust": float(model.pvalues[term]),
    })

complete = roi.dropna(subset=["log_distance", "log_EC_density", "Tissue Region", "age_numeric", "sex_clean"]).copy()
if complete["Patient ID"].nunique() >= 20:
    m2 = smf.ols("log_distance ~ group_BrM + log_EC_density + C(Q('Tissue Region')) + age_numeric + C(sex_clean)", data=complete).fit(cov_type="cluster", cov_kwds={"groups": complete["Patient ID"]})
    term = "group_BrM"
    model_rows.append({
        "model": "distance_clinical_sensitivity",
        "outcome": "log cancer-to-nearest-EC distance",
        "adjustment": "group + EC density + tissue region + age + sex",
        "n_ROIs": len(complete),
        "n_patients": complete["Patient ID"].nunique(),
        "group_log_coefficient": float(m2.params[term]),
        "group_ratio": float(np.exp(m2.params[term])),
        "ci95_low_ratio": float(np.exp(m2.conf_int().loc[term, 0])),
        "ci95_high_ratio": float(np.exp(m2.conf_int().loc[term, 1])),
        "p_cluster_robust": float(m2.pvalues[term]),
    })

density = roi.dropna(subset=["log_EC_density", "Tissue Region"]).copy()
md = smf.ols("log_EC_density ~ group_BrM + C(Q('Tissue Region'))", data=density).fit(cov_type="cluster", cov_kwds={"groups": density["Patient ID"]})
term = "group_BrM"
model_rows.append({
    "model": "density_primary",
    "outcome": "log1p EC density",
    "adjustment": "group + tissue region",
    "n_ROIs": len(density),
    "n_patients": density["Patient ID"].nunique(),
    "group_log_coefficient": float(md.params[term]),
    "group_ratio": float(np.exp(md.params[term])),
    "ci95_low_ratio": float(np.exp(md.conf_int().loc[term, 0])),
    "ci95_high_ratio": float(np.exp(md.conf_int().loc[term, 1])),
    "p_cluster_robust": float(md.pvalues[term]),
})
models = pd.DataFrame(model_rows)
models.to_csv(OUT / "imc_clustered_regression_models.csv", index=False)

# Geometry-preserving null: keep EC positions and ROI geometry fixed; sample the observed number
# of cancer cells from all eligible non-EC cell centroids. This conditions directly on EC abundance.
null_rows = []
missing_geometry_inputs = []
mapping_sub = mapping[mapping["Tumor Type"].isin(["Brain Metastasis", "Glioblastoma"])]
for _, r in mapping_sub.iterrows():
    roi_id, old = r.official_roi, r.legacy_roi
    cf = BASE / "official_updated/CellType" / f"{roi_id}.mat"
    sf = BASE / "official_updated/Segmentation" / roi_id
    if not sf.exists():
        sf = DATA / "BRAIN_IMC_Segmentation" / old
    if not cf.exists() or not (sf / "allRegionIndices.mat").exists() or not (sf / "nuclei_multiscale.mat").exists():
        missing_geometry_inputs.append(roi_id)
        continue
    sm = sio.loadmat(sf / "allRegionIndices.mat")
    nm = sio.loadmat(sf / "nuclei_multiscale.mat")
    m = sio.loadmat(cf)
    ct = np.array([str(x[0]) if len(x) else "NONE" for x in m["cellTypes"].ravel()])
    seg = sm["allRegInds"].ravel()
    h, w = nm["nucleiImage"].shape
    xy = np.array([
        [np.mean((np.asarray(i).ravel().astype(np.int64) - 1) // h), np.mean((np.asarray(i).ravel().astype(np.int64) - 1) % h)] if np.size(i) else [np.nan, np.nan]
        for i in seg
    ])
    ok = np.isfinite(xy).all(axis=1)
    xy, ct = xy[ok], ct[ok]
    ec = ct == "Endothelial cell"
    ca = ct == "Cancer"
    eligible = ~ec
    if ec.sum() < 5 or ca.sum() < 20 or eligible.sum() < ca.sum():
        continue
    distances = cKDTree(xy[ec]).query(xy[eligible])[0]
    cancer_in_eligible = ca[eligible]
    observed = float(np.median(distances[cancer_in_eligible]))
    null = np.empty(N_NULL, float)
    for i in range(N_NULL):
        null[i] = float(np.median(RNG.choice(distances, size=int(ca.sum()), replace=False)))
    null_mean = float(np.mean(null))
    null_rows.append({
        "official_roi": roi_id,
        "Patient ID": r["Patient ID"],
        "Tumor Type": r["Tumor Type"],
        "Tissue Region": r["Tissue Region"],
        "n_EC": int(ec.sum()),
        "n_cancer": int(ca.sum()),
        "n_eligible_non_EC": int(eligible.sum()),
        "observed_median_distance_um": observed,
        "null_mean_median_distance_um": null_mean,
        "observed_over_null": observed / null_mean,
        "observed_minus_null_um": observed - null_mean,
        "null_z": (observed - null_mean) / float(np.std(null, ddof=1)),
        "p_upper_MC": float((1 + np.sum(null >= observed)) / (N_NULL + 1)),
        "n_permutations": N_NULL,
    })

null_roi = pd.DataFrame(null_rows)
null_roi.to_csv(OUT / "imc_roi_geometry_preserving_null.csv", index=False)
if len(null_roi):
    null_patient = (
        null_roi.groupby(["Patient ID", "Tumor Type"])
        .agg(
            n_ROIs=("official_roi", "size"),
            observed_over_null=("observed_over_null", "mean"),
            observed_minus_null_um=("observed_minus_null_um", "mean"),
        )
        .reset_index()
    )
    x = null_patient.loc[null_patient["Tumor Type"].eq("Brain Metastasis"), "observed_over_null"].to_numpy(float)
    y = null_patient.loc[null_patient["Tumor Type"].eq("Glioblastoma"), "observed_over_null"].to_numpy(float)
    u = mannwhitneyu(x, y, alternative="two-sided", method="asymptotic")
    lo, hi = bootstrap_median_difference(x, y)
    null_test = pd.DataFrame([{
        "comparison": "Brain metastasis vs glioblastoma",
        "metric": "patient mean observed/null nearest-EC distance",
        "n_BrM": len(x),
        "n_GBM": len(y),
        "BrM_median": float(np.median(x)),
        "GBM_median": float(np.median(y)),
        "median_difference": float(np.median(x) - np.median(y)),
        "bootstrap95_low": lo,
        "bootstrap95_high": hi,
        "rank_biserial": float(2 * u.statistic / (len(x) * len(y)) - 1),
        "p_MWU": float(u.pvalue),
        "replicate_unit": "patient",
        "status": "completed",
    }])
else:
    null_patient = pd.DataFrame(columns=["Patient ID", "Tumor Type", "n_ROIs", "observed_over_null", "observed_minus_null_um"])
    null_test = pd.DataFrame([{
        "comparison": "Brain metastasis vs glioblastoma",
        "metric": "geometry-preserving null",
        "status": "not regenerated: underlying centroid segmentation files are absent from the retained handoff",
        "n_missing_ROIs": len(missing_geometry_inputs),
    }])
null_patient.to_csv(OUT / "imc_patient_geometry_preserving_null.csv", index=False)
null_test.to_csv(OUT / "imc_geometry_null_group_test.csv", index=False)

methods = {
    "regression": "ROI-level OLS with patient-clustered covariance; primary distance model adjusts group, log1p EC density and tissue region; clinical-covariate model is sensitivity only.",
    "treatment_covariate": "The available field is post-surgical treatment, which occurs after tissue acquisition and was therefore summarized but not adjusted as a pre-exposure confounder.",
    "geometry_null": "Specified as fixed EC positions and ROI geometry with the observed number of cancer cells sampled from non-EC centroids, but not regenerated because the underlying centroid segmentation files are absent from the retained handoff. The density-conditioned regression is the primary reviewer-requested analysis.",
    "missing_geometry_ROIs": len(missing_geometry_inputs),
    "interpretation": "Endpoints are detected-cell density and 2D centroid geometry, not vessel number, perfusion or sprouting.",
}
(OUT / "imc_conditional_methods.json").write_text(json.dumps(methods, indent=2), encoding="utf-8")
print(models.to_string(index=False))
print(null_test.to_string(index=False))
