from pathlib import Path
import json
import re

import pandas as pd


ROOT = Path(__file__).resolve().parents[2]
H = ROOT / "FINAL_HANDOFF_20260922"
OUT = ROOT / "manuscript_working" / "revision_major_20261109" / "outputs"
OUT.mkdir(parents=True, exist_ok=True)


def parse_sex_age(value):
    value = "" if pd.isna(value) else str(value)
    m = re.fullmatch(r"([MF])/(\d+)", value)
    if not m:
        return pd.Series({"sex": pd.NA, "age": pd.NA})
    return pd.Series({"sex": m.group(1), "age": int(m.group(2))})


registry = pd.read_csv(H / "data/metadata/patient_registry_verified.csv")
sex_age = registry["sex_age"].apply(parse_sex_age)
internal = pd.concat([registry, sex_age], axis=1)
internal["intracranial_diagnosis"] = internal["disease_category"].map({
    "Brain metastasis": "Intracranial brain metastasis",
    "CNS lymphoma": "Primary CNS lymphoma",
})
internal["primary_origin"] = internal["disease"].map({
    "Lung adenocarcinoma": "Lung",
    "High-grade neuroendocrine carcinoma": "Lung, high-grade neuroendocrine/SCLC-like",
    "DLBCL": "Not applicable",
    "B-cell lymphoma (DLBCL-like)": "Not applicable",
    "B-cell lymphoma": "Not applicable",
})
internal["manuscript_role"] = "Intracranial disease reference only"
internal.loc[internal.patient_id.isin(["P1", "P3", "P5"]), "manuscript_role"] = "Confirmed lung-origin BrM descriptive atlas"
internal.loc[internal.patient_id.eq("P8"), "manuscript_role"] = "Provisional spatial-only BrM specimen"
internal["primary_inference"] = internal.patient_id.isin(["P1", "P3", "P5"])
internal["primary_exclusion_reason"] = "PCNSL is not part of the BrM cohort"
internal.loc[internal.patient_id.isin(["P1", "P3", "P5"]), "primary_exclusion_reason"] = ""
internal.loc[internal.patient_id.eq("P8"), "primary_exclusion_reason"] = "Donor identity remains provisional"
for col in ["treatment_history", "tissue_location", "collection_procedure", "ethics_approval", "consent"]:
    internal[col] = "REQUIRES_HOSPITAL_VERIFICATION"

internal_cols = [
    "patient_id", "paper_patient_id", "intracranial_diagnosis", "disease", "primary_origin",
    "sex", "age", "pathology_no", "scRNA_tumor", "scRNA_adjacent", "ST_tumor", "ST_adjacent",
    "paper_identity_status", "manuscript_role", "primary_inference", "primary_exclusion_reason",
    "treatment_history", "tissue_location", "collection_procedure", "ethics_approval", "consent",
    "paper_provenance_note",
]
internal[internal_cols].to_csv(OUT / "internal_patient_specimen_census.csv", index=False)


def read_tsv_no_header(path):
    return pd.read_csv(path, sep="\t", header=None, names=["accession", "title", "metadata"])


rows = []

# Slide-seq: titles provide explicit patient IDs. KRAS_11 is a duplicate upload of PA056 and is not
# present in the locked analysis table.
slide_meta = read_tsv_no_header(H / "code/external_reconstruction/specifications/spatial__GSE223501__sample_meta.tsv")
slide_used = pd.read_csv(ROOT / "manuscript_working/figures_v1/source_data/RevisedFig2D_SlideSeq_smallest_radius.csv")
for _, r in slide_used.iterrows():
    meta = slide_meta[slide_meta.title.str.contains(r.pid, regex=False)]
    accession = meta.accession.iloc[0] if len(meta) else pd.NA
    rows.append({
        "resource": "GSE223501 Slide-seq",
        "accession": accession,
        "unit_id": r.pid,
        "group": "Brain metastasis" if r.site == "BM" else "Primary lung",
        "physical_unit": "Slide-seq section",
        "biological_unit": "Patient",
        "unit_confidence": "Explicit patient ID in source metadata",
        "primary_use": True,
        "notes": "One retained section per patient; duplicated KRAS_11 upload excluded as PA056 duplicate.",
    })

# Xenium: unique specimen accessions are explicit, but donor IDs are not present in the retained metadata.
xen_meta = read_tsv_no_header(H / "code/external_reconstruction/specifications/scrna__GSE325935__sample_meta.tsv")
for _, r in xen_meta.iterrows():
    specimen = re.search(r"(\d{2}-\d{4})", r.title)
    rows.append({
        "resource": "GSE325935 Xenium",
        "accession": r.accession,
        "unit_id": specimen.group(1) if specimen else r.title,
        "group": "Breast-cancer brain metastasis",
        "physical_unit": "Xenium specimen/section",
        "biological_unit": "Specimen; donor identity not explicit",
        "unit_confidence": "Unique specimen accession, no explicit patient field",
        "primary_use": False,
        "notes": "Use as four section-level descriptive replications; do not call four independent donors.",
    })

# Kim: source metadata gives patient IDs. Only strict-gate samples with >=10 cells enter the figure.
kim_scores = pd.read_csv(H / "results/spatial_distance_and_state_validation/kim_pericyte_sample_scores.csv")
kim_scores = kim_scores[(kim_scores.gate == "pericyte_clean") & (kim_scores.n_cells >= 10) & kim_scores.origin.isin(["mBrain", "tLung"])]
kim_meta = pd.read_csv(H / "results/nutrition/kim_author_sample_metadata.csv")
kim = kim_scores.merge(kim_meta[["patient", "sample", "site"]], on="sample", how="left", validate="1:1")
for _, r in kim.iterrows():
    rows.append({
        "resource": "Kim single-cell cohort",
        "accession": "See public-resource table",
        "unit_id": r.patient,
        "group": "Brain metastasis" if r.origin == "mBrain" else "Primary lung",
        "physical_unit": r.sample,
        "biological_unit": "Patient",
        "unit_confidence": "Explicit patient ID in author metadata",
        "primary_use": True,
        "notes": f"Strict clean mural gate; n_cells={int(r.n_cells)}.",
    })

# Walchli: aggregate to donor; repeated temporal-lobe specimens already share donor IDs.
wal = pd.read_csv(H / "results/pericyte_differentiation/pericyte_donor_scores.csv")
wal = wal[(wal.dataset == "Walchli") & (wal.gate == "clean") & wal.group.isin(["MET", "TL"]) & (wal.n_cells >= 10)]
for _, r in wal.iterrows():
    rows.append({
        "resource": "Walchli vascular cohort",
        "accession": "GSE173278",
        "unit_id": r.donor,
        "group": "Brain metastasis" if r.group == "MET" else "Temporal lobe",
        "physical_unit": f"{int(r.n_samples)} specimen(s)",
        "biological_unit": "Donor",
        "unit_confidence": "Explicit donor field; repeated specimens aggregated",
        "primary_use": True,
        "notes": f"Clean mural gate; n_cells={int(r.n_cells)}.",
    })

# Sorted endothelial transcriptomes.
ec = pd.read_csv(H / "results/endothelial_response/EC_donor_manifest.csv")
for _, r in ec.iterrows():
    group = r.get("group", r.get("Group", ""))
    donor = r.get("donor", r.get("Donor", ""))
    rows.append({
        "resource": "GSE256493 sorted endothelial",
        "accession": "GSE256493",
        "unit_id": donor,
        "group": group,
        "physical_unit": "Collapsed donor libraries",
        "biological_unit": "Donor",
        "unit_confidence": "Donor manifest",
        "primary_use": True,
        "notes": "Replicate libraries collapsed before testing.",
    })

# IMC: patient-level aggregation of ROIs.
imc = pd.read_csv(H / "results/verified_vascular_geometry/IMC_official_patient_metrics.csv")
imc = imc[(imc.scope == "all_regions") & imc.group.isin(["Brain Metastasis", "Glioblastoma"])]
for _, r in imc.iterrows():
    rows.append({
        "resource": "Public IMC",
        "accession": "Karimi et al. brain IMC resource",
        "unit_id": r.patient,
        "group": r.group,
        "physical_unit": f"{int(r.n_ROIs)} ROI(s)",
        "biological_unit": "Patient",
        "unit_confidence": "Official patient-ROI mapping",
        "primary_use": True,
        "notes": "ROIs aggregated to patient before unadjusted group testing.",
    })

external = pd.DataFrame(rows)
external.to_csv(OUT / "external_biological_unit_census.csv", index=False)

summary = (
    external.groupby(["resource", "group", "biological_unit"], dropna=False)
    .agg(n_rows=("unit_id", "size"), n_unique_units=("unit_id", "nunique"))
    .reset_index()
)
summary.to_csv(OUT / "external_unit_summary.csv", index=False)

unresolved = pd.DataFrame([
    ("Internal cohort", "Ethics committee, approval number and approval scope", "Hospital record"),
    ("Internal cohort", "Consent procedure or waiver", "Hospital record"),
    ("Internal cohort", "Treatment history before tissue acquisition", "Clinical record"),
    ("Internal cohort", "Anatomical tissue location and collection/processing procedure", "Pathology/surgery record"),
    ("Internal cohort", "P8 donor identity", "Sample registry/source documents"),
    ("Xenium", "Whether four specimens correspond to four independent patients", "Source article or author metadata"),
    ("GSE227549", "Whether five libraries per condition are biological or technical replicates", "Source article or author confirmation"),
    ("Repository", "Permanent DOI/accession for scripts and processed source data", "Study team repository account"),
], columns=["scope", "unresolved_item", "required_source"])
unresolved.to_csv(OUT / "unresolved_team_inputs.csv", index=False)

report = {
    "confirmed_internal_BrM_patients": internal.loc[internal.primary_inference, "patient_id"].tolist(),
    "provisional_internal_specimens": internal.loc[internal.patient_id.eq("P8"), "patient_id"].tolist(),
    "PCNSL_role": "intracranial disease reference only; excluded from principal BrM inference",
    "SlideSeq": {"BrM_patients": int((slide_used.site == "BM").sum()), "primary_lung_patients": int((slide_used.site == "PT").sum())},
    "Xenium": {"sections": len(xen_meta), "explicit_donor_ids": False},
    "outputs": ["internal_patient_specimen_census.csv", "external_biological_unit_census.csv", "external_unit_summary.csv", "unresolved_team_inputs.csv"],
}
(OUT / "cohort_audit_summary.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
print(json.dumps(report, indent=2))
