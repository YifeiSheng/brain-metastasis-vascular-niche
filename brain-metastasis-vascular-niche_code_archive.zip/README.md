# Brain metastasis vascular niche

Code archive for **A matrix-remodelled mural programme and altered vascular geometry define the human brain-metastatic niche**.

## Contents

- `manuscript_working/revision_major_20261109/01` through `05`: final cohort audit, mural programme reanalysis, spatial permutation analysis, clustered IMC models and main-figure builder.
- `FINAL_HANDOFF_20260922/code/`: original analysis, annotation, integration, data preparation and external-data reconstruction scripts. Earlier exploratory analyses and legacy figures remain here for provenance; the final manuscript uses the five revision entry points above.
- `aggregate_results/`: non-identifying group-level statistics and programme definitions. These summaries are not raw clinical data.
- `MANIFEST.json`: SHA-256 hashes and provenance of public files.

## Data availability

Raw internal human single-cell and spatial-transcriptomic data are not publicly available because of patient privacy protections and institutional restrictions. De-identified supporting data are available from Tieying Hou (sz_houtieying@yeah.net) upon reasonable request, subject to applicable institutional and ethics requirements. Requests should describe the proposed research and required data. Release is subject to the data custodian's authorization; this repository does not itself authorize patient-data sharing.

Public datasets: GSE131907 (Kim), GSE256493 (vascular atlas), GSE223501 (Slide-seq), GSE325935 (Xenium), GSE227549 (VEGF calibration), and Zenodo record 7884599 (IMC). See `docs/PUBLIC_DATA.md` and the original reconstruction instructions.

## Reproduction

Use Python 3.12 or a compatible environment and install `requirements.txt`. R scripts require the packages listed in their library calls; original instructions describe the Seurat and reconstruction steps. Retain the repository directory structure: entry points resolve paths relative to it. Restore authorized inputs under `FINAL_HANDOFF_20260922/data` and the intermediate tables under `FINAL_HANDOFF_20260922/results`, following the reconstruction guide, then run revision scripts 01–05 in order. The figure builder also needs its referenced earlier figure-source tables and the Nature figure alignment helper; see `docs/REPRODUCIBILITY.md`.

This is an archive of the original source code with privacy-related tube-label substitutions and a generic home-directory alias. Original patient raw data, patient-level internal matrices, registry tables, name/code keys, clinical records, ethics scans and specimen submission forms are excluded. Restoring inputs requires authorized access; a clean-clone end-to-end analysis cannot run using this public code archive alone.

## Authors

Yifei Sheng and Shiying Li: formal analysis and original draft. Yifei Sheng: manuscript revision. Libin Wang: data acquisition and curation. Libin Wang and Tieying Hou: project administration, supervision and funding acquisition. Yifei Sheng and Shiying Li contributed equally. Libin Wang and Tieying Hou are co-corresponding authors.

## Citation and reuse

The manuscript is being prepared for submission; no publication DOI is assigned. Cite this repository and the exact commit used. Third-party datasets retain their original access conditions. No additional license grant is made by this archival deposit.
