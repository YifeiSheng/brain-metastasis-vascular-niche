# Reproduction and privacy boundaries

## Final entry points

1. `01_cohort_audit.py`: requires the restricted patient registry and public sample annotations. Its clinical census output must remain local.
2. `02_program_reanalysis.py`: requires the internal per-cell state table, external programme summaries and programme definitions. Internal donor-level outputs remain controlled.
3. `03_spatial_reanalysis.py`: requires the classified public Slide-seq coordinate tables and Xenium export. Slide-seq uses 999 stratified permutations; the retained Xenium export uses 50 global permutations.
4. `04_imc_conditional_geometry.py`: requires the public IMC region geometry and metadata plus the previously prepared region table. Models use patient-clustered covariance.
5. `05_build_revised_figures.py`: requires the revision outputs and `manuscript_working/figures_v1/source_data`. It imports `audit_panel_alignment.py` from the Nature figure skill. Set `NATURE_FIGURE_SCRIPTS` to the helper directory; its public source is separately available from the figure skill used by the authors. The exact helper is not redistributed as original research code.

Only source-code syntax and archive integrity were checked at deposit. No claim of a fresh clean-clone, full-data rerun is made. Package versions in requirements are intentionally unpinned because a fully verified lockfile was not supplied; installation and analysis should be performed in an isolated environment. Restore data according to the original code and reconstruction documentation before execution.

## Clinical information

No internal patient-level data table is published in this repository. Tube-label mnemonics were replaced consistently in the public code; authorized data must use the same aliases. The identity mapping remains with the clinical data custodian. Clinical dates, ages, pathology numbers, signed consent, scans, filenames containing patient names and source forms are excluded. Pseudonymisation alone does not make genomic data anonymous or authorize unrestricted release.

## Included summaries

The aggregate summaries retain effect sizes, intervals, P values and effective sample counts. They contain no internal participant identifier, individual clinical attribute, single-cell expression vector or spatial coordinate. These summaries support inspection of reported statistics; full recalculation requires authorized inputs.
