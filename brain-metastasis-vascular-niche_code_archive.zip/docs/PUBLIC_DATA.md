# Public input sources

| Resource | Source |
|---|---|
| Kim single-cell cohort | https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE131907 |
| Vascular atlas | https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE256493 |
| Slide-seq | https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE223501 |
| Xenium | https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE325935 |
| VEGF calibration | https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE227549 |
| IMC | https://zenodo.org/records/7884599 |

Retrieve each dataset directly from its original repository under its terms. This archive does not redistribute third-party raw data. The external reconstruction scripts refer to download rosters from the original handoff; recreate those rosters from the public records when they are absent. See the dataset-specific reconstruction guide for exact author matrix and annotation names.
