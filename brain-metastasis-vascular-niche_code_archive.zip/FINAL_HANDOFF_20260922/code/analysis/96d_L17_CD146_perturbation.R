# Current scientific analysis; package-relative paths.
handoff_arg <- grep("^--file=", commandArgs(), value=TRUE)
handoff_file <- sub("^--file=", "", handoff_arg[1])
HANDOFF_ROOT <- Sys.getenv("SAFEPOSTER_HANDOFF_ROOT", unset=normalizePath(file.path(dirname(handoff_file), "../.."), mustWork=TRUE))
#!/usr/bin/env Rscript
suppressPackageStartupMessages(library(limma))
root <- file.path(HANDOFF_ROOT, "")
out <- file.path(root,"results/tumor_VEGFA_perturbation")
dat <- read.delim(gzfile(file.path(out,"GSE248935_gene_fpkm.txt.gz")), check.names=FALSE)
meta <- read.csv(file.path(out,"GSE248935_sample_mapping.csv"), stringsAsFactors=FALSE)
stopifnot(!anyDuplicated(dat$gene_id),identical(meta$column,paste0("sample",1:6)),all(meta$condition==c(rep("shNC",3),rep("shCD146",3))))
x <- as.matrix(dat[,meta$column]); storage.mode(x)<-"double"
stopifnot(all(is.finite(x)),all(x>=0))
rownames(x)<-dat$gene_id
group<-factor(meta$condition,levels=c("shNC","shCD146"))
design<-model.matrix(~group)
# Filter depends only on expression, not on differential effect or desired direction.
keep<-rowSums(x>=1)>=3
primary <- NULL
sens<-list()
for (pseudo in c(0.5,0.1,1)) {
  z<-log2(x[keep,,drop=FALSE]+pseudo)
  fit<-eBayes(lmFit(z,design),trend=TRUE,robust=TRUE)
  tab<-topTable(fit,coef=2,number=Inf,sort.by="none",adjust.method="BH",confint=TRUE)
  tab$gene_id<-rownames(tab)
  tab$gene_name<-dat$gene_name[match(tab$gene_id,dat$gene_id)]
  tab$mean_shNC_FPKM<-rowMeans(x[keep,1:3,drop=FALSE])
  tab$mean_shCD146_FPKM<-rowMeans(x[keep,4:6,drop=FALSE])
  tab$ratio_of_arithmetic_means<-tab$mean_shCD146_FPKM/tab$mean_shNC_FPKM
  tab$pseudocount<-pseudo
  tab<-tab[,c("gene_id","gene_name","logFC","CI.L","CI.R","AveExpr","t","P.Value","adj.P.Val","mean_shNC_FPKM","mean_shCD146_FPKM","ratio_of_arithmetic_means","pseudocount")]
  sens[[as.character(pseudo)]]<-tab
  if(pseudo==0.5)primary<-tab
}
write.csv(primary[order(primary$adj.P.Val),],gzfile(file.path(out,"GSE248935_all_gene_limma_trend.csv.gz")),row.names=FALSE)
panel<-c("MCAM","VEGFA","VEGFB","VEGFC","PGF","ANGPT1","ANGPT2","FGF2","PDGFA","PDGFB","TGFB1","LCN2","GAS6","AXL","JUN","FOS","CD44","ABCG2","CSPG4","PDGFRB","KDR","NRP1","NRP2","AKR1B10")
write.csv(do.call(rbind,lapply(sens,function(z)z[z$gene_name%in%panel,])),file.path(out,"GSE248935_targeted_genes_sensitivity.csv"),row.names=FALSE)
expression<-dat[dat$gene_name%in%panel,c("gene_id","gene_name",meta$column)]
expression$passes_filter<-keep[dat$gene_name%in%panel]
write.csv(expression,file.path(out,"GSE248935_targeted_gene_expression.csv"),row.names=FALSE)
summary<-data.frame(total_genes=nrow(x),tested_genes=sum(keep),BH05_up=sum(primary$adj.P.Val<0.05&primary$logFC>0),BH05_down=sum(primary$adj.P.Val<0.05&primary$logFC<0),MCAM_ratio=primary$ratio_of_arithmetic_means[primary$gene_name=="MCAM"],VEGFA_ratio=primary$ratio_of_arithmetic_means[primary$gene_name=="VEGFA"])
write.csv(summary,file.path(out,"GSE248935_summary.csv"),row.names=FALSE)
z<-log2(x[keep,]+0.5)
pca<-prcomp(t(z),scale.=FALSE)
write.csv(data.frame(meta,PC1=pca$x[,1],PC2=pca$x[,2]),file.path(out,"GSE248935_PCA_samples.csv"),row.names=FALSE)
plotit<-function(){
  par(mfrow=c(1,3),mar=c(5,4,4,1),las=1)
  for(g in c("MCAM","VEGFA")){
    yy<-x[dat$gene_name==g,]
    plot(c(0.9,1,1.1,1.9,2,2.1),yy,xlim=c(0.5,2.5),ylim=c(0,max(yy)*1.2),pch=21,bg=rep(c("#2166AC","#B2182B"),each=3),xlab="",ylab="FPKM",xaxt="n",main=g)
    axis(1,at=1:2,labels=c("shNC","shCD146"))
    segments(c(0.8,1.8),c(mean(yy[1:3]),mean(yy[4:6])),c(1.2,2.2),c(mean(yy[1:3]),mean(yy[4:6])),lwd=2)
    tt<-primary[primary$gene_name==g,]
    mtext(sprintf("KD/control %.3f; global BH q=%.2g",tt$ratio_of_arithmetic_means,tt$adj.P.Val),3,line=0.4,cex=.75)
  }
  vv<-summary(pca)$importance[2,1:2]*100
  plot(pca$x[,1],pca$x[,2],pch=21,bg=rep(c("#2166AC","#B2182B"),each=3),xlim=range(pca$x[,1])+c(-15,15),ylim=range(pca$x[,2])+c(-10,10),xlab=sprintf("PC1 (%.1f%%)",vv[1]),ylab=sprintf("PC2 (%.1f%%)",vv[2]),main="All filtered genes")
  text(pca$x[,1],pca$x[,2],meta$column,pos=c(3,2,3,1,3,2),cex=.7)
  legend("bottomright",legend=c("shNC","shCD146"),pch=21,pt.bg=c("#2166AC","#B2182B"),bty="n",cex=.7)
}
pdf(file.path(out,"GSE248935_perturbation_QC.pdf"),width=12,height=4);plotit();dev.off()
png(file.path(out,"GSE248935_perturbation_QC.png"),width=2100,height=700,res=175);plotit();dev.off()
capture.output(sessionInfo(),file=file.path(out,"R_sessionInfo.txt"))
print(summary);print(primary[primary$gene_name%in%c("MCAM","VEGFA","AKR1B10"),])

jack <- list()
for(g in c("MCAM","VEGFA")){
 yy<-log2(x[dat$gene_name==g,]+0.5)
 for(i in 1:6)jack[[length(jack)+1]]<-data.frame(gene=g,omitted_sample=meta$column[i],log2_mean_difference=mean(yy[setdiff(4:6,i)])-mean(yy[setdiff(1:3,i)]))
}
write.csv(do.call(rbind,jack),file.path(out,"GSE248935_leave_one_out_effects.csv"),row.names=FALSE)
