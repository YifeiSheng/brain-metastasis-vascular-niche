# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
"""L17: retrieve the public CD146 perturbation study and preserve sample identity."""
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
from pathlib import Path
from urllib.request import urlopen
import concurrent.futures, json, hashlib, re, datetime
ROOT = Path(str(_HANDOFF_ROOT / ''))
OUT = ROOT / 'results/tumor_VEGFA_perturbation'
OUT.mkdir(parents=True, exist_ok=True)
urls = {'geo248935.txt': 'https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE248935&targ=self&form=text&view=full', 'GSE248935_gene_fpkm.txt.gz': 'https://ftp.ncbi.nlm.nih.gov/geo/series/GSE248nnn/GSE248935/suppl/GSE248935_gene_fpkm.txt.gz', 'thno2026.txt': 'https://www.thno.org/v16p1905.htm', 'thnov16p1905s1.pdf': 'https://www.thno.org/v16/p1905/thnov16p1905s1.pdf'}
urls.update({f'{s}.txt': f'https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc={s}&targ=self&form=text&view=full' for s in ['GSM7923254', 'GSM7923255', 'GSM7923256', 'GSM7923257', 'GSM7923258', 'GSM7923259']})
urls.update({p + '.xml': 'https://www.ebi.ac.uk/europepmc/webservices/rest/' + p + '/fullTextXML' for p in ['PMC12727695', 'PMC11534324', 'PMC5678093']})
urls.update({p + '.xml': 'https://www.ebi.ac.uk/ena/browser/api/xml/' + p for p in ['SRX22684420', 'SRX22684423']})

def retrieve(item):
    (name, url) = item
    p = OUT / name
    if not p.exists():
        p.write_bytes(urlopen(url, timeout=60).read())
    data = p.read_bytes()
    return dict(file=name, url=url, bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
records = list(concurrent.futures.ThreadPoolExecutor(max_workers=3).map(retrieve, urls.items()))
samples = []
for p in sorted(OUT.glob('GSM*.txt')):
    txt = p.read_text()
    title = re.search('!Sample_title = (.+)', txt).group(1).strip()
    matched = re.fullmatch('(shNC|shCD146) (\\d)', title)
    assert matched, title
    (group, number) = matched.groups()
    genotype = re.search('!Sample_characteristics_ch1 = genotype: (.+)', txt).group(1).strip()
    assert ('knockdown' in genotype) == (group == 'shCD146')
    samples.append(dict(column='sample' + number, geo_accession=p.stem, title=title, condition=group, genotype=genotype, mapping_basis='explicit numeric suffix in GSM title matched to matrix sample number; not GSM display order'))
samples = sorted(samples, key=lambda x: x['column'])
assert [s['column'] for s in samples] == ['sample' + str(i) for i in range(1, 7)]
import csv
with (OUT / 'GSE248935_sample_mapping.csv').open('w') as f:
    w = csv.DictWriter(f, fieldnames=list(samples[0]))
    w.writeheader()
    w.writerows(samples)
(OUT / 'PROVENANCE_DOWNLOADS.json').write_text(json.dumps(dict(retrieved_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), inputs=records, notes=['FPKM column-to-GSM mapping uses the explicitly numbered GSM titles; deposition does not provide a separate sample key.', 'Series overall_design mentions AKR1B10, inconsistent with title, summary, six GSM genotypes, and associated article; retain this discrepancy.', 'Processed FPKM reanalysis is not raw-read reprocessing. No private data sent to remote resources.']), indent=2))
print(json.dumps(samples, indent=2))
