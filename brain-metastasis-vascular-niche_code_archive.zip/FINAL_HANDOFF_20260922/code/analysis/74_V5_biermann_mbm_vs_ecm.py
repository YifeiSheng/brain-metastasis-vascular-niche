# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os, re, glob, gzip, time, numpy as np, pandas as pd, scanpy as sc, scipy.io, scipy.sparse as sp
from sklearn.neighbors import NearestNeighbors, KDTree, radius_neighbors_graph
from scipy.stats import mannwhitneyu
B = str(_HANDOFF_ROOT / '')
E = f'{B}/data/external/scrna/GSE185386/raw'
O = f'{B}/results/vascular_niche/V5'
os.makedirs(O, exist_ok=True)
L = open(f'{O}/progress.txt', 'a', buffering=1)
log = lambda *a: L.write(time.strftime('[%H:%M:%S] ') + ' '.join(map(str, a)) + '\n')
rng = np.random.default_rng(0)
PX_UM = 0.65
meta = pd.read_csv(f'{B}/data/external/scrna/GSE185386/sample_meta.tsv', sep='\t', header=None, names=['gsm', 'title', 'ch'])
meta['site'] = np.where(meta.ch.str.contains('site: MBM'), 'MBM', 'ECM')
PERI = ['CSPG4', 'NOTCH3', 'RGS5', 'PDGFRB', 'KCNJ8', 'HIGD1B', 'NDUFA4L2', 'ACTA2', 'TAGLN']
FIB = ['DCN', 'LUM', 'COL1A1', 'COL1A2', 'COL3A1', 'FBLN1', 'PRRX1']
LIN = {'EC': ['PECAM1', 'CDH5', 'CLDN5', 'VWF', 'FLT1'], 'stroma': ['PDGFRB', 'RGS5', 'COL1A2', 'DCN', 'LUM', 'ACTA2', 'NOTCH3'], 'myeloid': ['PTPRC', 'CD68', 'CD163', 'C1QA', 'AIF1', 'CSF1R'], 'lymphoid': ['CD3E', 'CD2', 'NKG7', 'MS4A1', 'CD79A'], 'tumor': ['MLANA', 'PMEL', 'MITF', 'SOX10', 'DCT', 'TYR', 'PRAME'], 'CNS': ['GFAP', 'AQP4', 'PLP1', 'MBP', 'SNAP25', 'MOBP']}

def det(a, g):
    return np.asarray((a[:, g].X > 0).sum(axis=1)).ravel().astype(int) if g in a.var_names else np.zeros(a.n_obs, int)

def mean_of(a, gs):
    gs = [g for g in gs if g in a.var_names]
    return np.asarray(a[:, gs].X.mean(axis=1)).ravel() if gs else np.zeros(a.n_obs)
SKIP_SN = os.path.exists(f'{O}/V5_snrna_composition.csv')
rows = []
for (_, m) in (meta[meta.title.str.endswith('_sn')] if not SKIP_SN else meta.iloc[0:0]).iterrows():
    pre = glob.glob(f'{E}/{m.gsm}_*_sn_matrix.mtx.gz')
    if not pre:
        log('缺', m.title)
        continue
    pre = pre[0].replace('_matrix.mtx.gz', '')
    M = scipy.io.mmread(pre + '_matrix.mtx.gz').tocsr().T.astype(np.float32)
    bc = pd.read_csv(pre + '_barcodes.tsv.gz', header=None)[0].values
    ft = pd.read_csv(pre + '_features.tsv.gz', header=None, sep='\t')
    a = sc.AnnData(M, obs=pd.DataFrame(index=bc), var=pd.DataFrame(index=(ft[1] if ft.shape[1] > 1 else ft[0]).values))
    a.var_names_make_unique()
    sc.pp.filter_cells(a, min_genes=300)
    a.var['mt'] = a.var_names.str.startswith('MT-')
    sc.pp.calculate_qc_metrics(a, qc_vars=['mt'], inplace=True)
    a = a[a.obs.pct_counts_mt < 10].copy()
    sc.pp.filter_genes(a, min_cells=3)
    sc.pp.normalize_total(a, target_sum=10000.0)
    sc.pp.log1p(a)
    LS = pd.DataFrame({k: mean_of(a, v) for (k, v) in LIN.items()}, index=a.obs_names)
    gate = LS.idxmax(axis=1).where(LS.max(axis=1) > 0.3, 'other').values
    st = gate == 'stroma'
    ec = gate == 'EC'
    my = gate == 'myeloid'
    for (nm, gs) in [('peri', PERI), ('fib', FIB)]:
        gg = [g for g in gs if g in a.var_names]
        sc.tl.score_genes(a, gg, score_name=nm, ctrl_size=50, n_bins=25, random_state=0)
        a.obs[nm + '_ndet'] = np.asarray((a[:, gg].X > 0).sum(axis=1)).ravel()
    peri = (a.obs.peri > 0.15) & (a.obs.peri_ndet >= 4)
    fib = (a.obs.fib > 0.15) & (a.obs.fib_ndet >= 4)
    r = dict(sample=m.title, site=m.site, n_cells=a.n_obs, n_stroma=int(st.sum()), n_EC=int(ec.sum()), n_myeloid=int(my.sum()), n_tumor=int((gate == 'tumor').sum()), stroma_frac_of_all=round(float(st.mean()), 4), EC_frac_of_all=round(float(ec.mean()), 4), peri_frac_of_stroma=round(float(peri[st].mean()) if st.sum() else np.nan, 4), fib_frac_of_stroma=round(float(fib[st].mean()) if st.sum() else np.nan, 4), peri_over_peri_fib=round(float(peri[st].sum() / max((peri[st] | fib[st]).sum(), 1)) if st.sum() else np.nan, 4), NOTCH3_in_stroma=round(float(det(a, 'NOTCH3')[st].mean()) if st.sum() else np.nan, 4), RGS5_in_stroma=round(float(det(a, 'RGS5')[st].mean()) if st.sum() else np.nan, 4), ABCB1_in_EC=round(float(det(a, 'ABCB1')[ec].mean()) if ec.sum() else np.nan, 4), ANGPT2_in_EC=round(float(det(a, 'ANGPT2')[ec].mean()) if ec.sum() else np.nan, 4), PLVAP_in_EC=round(float(det(a, 'PLVAP')[ec].mean()) if ec.sum() else np.nan, 4), ABCB1_and_ANGPT2_in_EC=round(float(((det(a, 'ABCB1') == 1) & (det(a, 'ANGPT2') == 1))[ec].mean()) if ec.sum() else np.nan, 4), MFSD2A_in_EC=round(float(det(a, 'MFSD2A')[ec].mean()) if ec.sum() else np.nan, 4), BAM_in_myeloid=round(float((det(a, 'F13A1') + det(a, 'LYVE1') + det(a, 'CD209') + det(a, 'COLEC12') >= 2)[my].mean()) if my.sum() else np.nan, 4))
    rows.append(r)
    log(m.title, m.site, a.n_obs, '核; 间质', int(st.sum()), '内皮', int(ec.sum()))
res = pd.DataFrame(rows) if not SKIP_SN else pd.read_csv(f'{O}/V5_snrna_composition.csv')
res.to_csv(f'{O}/V5_snrna_composition.csv', index=False)
out = []
for col in [c for c in res.columns if c not in ('sample', 'site')]:
    sub = res[res.n_stroma >= 20] if 'stroma' in col or 'peri' in col or 'fib' in col or ('NOTCH3' in col) or ('RGS5' in col) else res[res.n_EC >= 20] if 'EC' in col else res[res.n_myeloid >= 20] if 'myeloid' in col else res
    x = sub[sub.site == 'MBM'][col].dropna()
    y = sub[sub.site == 'ECM'][col].dropna()
    if len(x) >= 3 and len(y) >= 3:
        out.append(dict(metric=col, MBM_median=round(x.median(), 4), ECM_median=round(y.median(), 4), n_MBM=len(x), n_ECM=len(y), mwu_p=mannwhitneyu(x, y).pvalue))
pd.DataFrame(out).sort_values('mwu_p').to_csv(f'{O}/V5_snrna_mbm_vs_ecm.csv', index=False)
log('snRNA 完成')
SETS = {'EC': ['PECAM1', 'CLDN5', 'VWF', 'CDH5', 'FLT1'], '周细胞': ['RGS5', 'NOTCH3', 'HIGD1B', 'PDGFRB', 'KCNJ8', 'NDUFA4L2', 'CSPG4'], '成纤维': ['DCN', 'LUM', 'COL1A1', 'COL1A2', 'COL3A1'], 'BAM': ['F13A1', 'LYVE1', 'CD209', 'COLEC12', 'SIGLEC1'], 'PDGFB': ['PDGFB'], 'PDGFRB': ['PDGFRB'], 'JAG1': ['JAG1'], 'DLL4': ['DLL4'], 'NOTCH3': ['NOTCH3'], 'ABCB1': ['ABCB1'], 'ANGPT2': ['ANGPT2']}
GENES = sorted({g for v in SETS.values() for g in v})
PAIRS = [('EC', '周细胞'), ('周细胞', '肿瘤'), ('EC', '肿瘤'), ('BAM', '周细胞'), ('成纤维', '周细胞'), ('PDGFB', 'PDGFRB'), ('JAG1', 'NOTCH3'), ('DLL4', 'NOTCH3')]
srows = []
scomp = []
for f in sorted(glob.glob(f'{E}/*_slide_spatial_info.csv.gz')):
    pre = f.replace('_spatial_info.csv.gz', '')
    name = os.path.basename(pre).split('_', 1)[1].replace('_slide', '')
    site = 'MBM' if name.startswith('MBM') else 'ECM'
    info = pd.read_csv(f, index_col=0)
    with gzip.open(pre + '_raw_counts.csv.gz', 'rt') as fh:
        header = fh.readline().rstrip('\n').split(',')
        beads = [h.strip('"') for h in header[1:]]
        tot = np.full(len(beads), np.inf)
        rows_ = {}
        for line in fh:
            i = line.index(',')
            g = line[:i].strip('"')
            if g in GENES:
                rows_[g] = np.fromstring(line[i + 1:], sep=',', dtype=np.float32)
    M = pd.DataFrame(rows_, index=beads)
    info = info.reindex(beads)
    keep = (tot >= 50) & info.xcoord.notna().values
    M = M[keep]
    info = info[keep]
    xy = info[['xcoord', 'ycoord']].values.astype(float)
    n = len(xy)
    lab = info.rctd_cell_type.astype(str).values
    nn = NearestNeighbors(n_neighbors=2).fit(xy)
    (d, _) = nn.kneighbors(xy)
    NN = float(np.median(d[:, 1]))
    tree = KDTree(xy)
    pos = {k: M[[g for g in v if g in M]].sum(axis=1).values >= 1 if any((g in M for g in v)) else np.zeros(n, bool) for (k, v) in SETS.items()}
    pos['肿瘤'] = lab == 'Tumor cells'
    pos['EC_rctd'] = lab == 'Endothelial cells'
    pos['间质_rctd'] = lab == 'Stromal cells'
    st = pos['间质_rctd']
    scomp.append(dict(slide=name, site=site, n_beads=n, n_stroma_rctd=int(st.sum()), n_EC_rctd=int(pos['EC_rctd'].sum()), peri_marker_in_stroma=round(float(pos['周细胞'][st].mean()) if st.sum() else np.nan, 4), fib_marker_in_stroma=round(float(pos['成纤维'][st].mean()) if st.sum() else np.nan, 4), peri_over_peri_fib_stroma=round(float(pos['周细胞'][st].sum() / max((pos['周细胞'][st] | pos['成纤维'][st]).sum(), 1)) if st.sum() else np.nan, 4), ABCB1_in_EC=round(float(pos['ABCB1'][pos['EC_rctd']].mean()) if pos['EC_rctd'].sum() else np.nan, 4), ANGPT2_in_EC=round(float(pos['ANGPT2'][pos['EC_rctd']].mean()) if pos['EC_rctd'].sum() else np.nan, 4)))
    GR = {mult: radius_neighbors_graph(xy, NN * mult, mode='connectivity', include_self=False).tocsr() for mult in [2, 5]}
    for (a_, b_) in PAIRS:
        A = np.where(pos[a_])[0]
        nb = int(pos[b_].sum())
        if len(A) < 20 or nb < 20:
            continue
        Bv = pos[b_].astype(np.int32)
        perms = []
        for _ in range(100):
            pm = np.zeros(n, np.int32)
            pm[rng.choice(n, nb, replace=False)] = 1
            perms.append(pm)
        for mult in [2, 5]:
            r = NN * mult
            GA = GR[mult][A]
            obs = float((GA @ Bv > 0).mean())
            null = np.array([float((GA @ pm > 0).mean()) for pm in perms])
            srows.append(dict(slide=name, site=site, pair=f'{a_}-{b_}', radius_mult=mult, radius_um=round(r * PX_UM, 1), n_A=len(A), n_B=nb, obs_frac=round(obs, 4), null_frac=round(float(null.mean()), 4), obs_over_null=round(obs / max(null.mean(), 1e-06), 3), z=round(float((obs - null.mean()) / (null.std() + 1e-09)), 2)))
    log('slide', name, site, n, 'beads; RCTD:', dict(pd.Series(lab).value_counts().head(5)))
pd.DataFrame(srows).to_csv(f'{O}/V5_slideseq_neighbor.csv', index=False)
pd.DataFrame(scomp).to_csv(f'{O}/V5_slideseq_composition.csv', index=False)
log('全部完成')
