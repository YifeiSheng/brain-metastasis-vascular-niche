# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
"""NicheNet leave-one-BM-donor sensitivity. Fixed primary background; no new target cutoffs."""
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os
for k in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS']:
    os.environ[k] = '2'
from pathlib import Path
import pandas as pd, numpy as np, json
from scipy.stats import ttest_ind
from sklearn.metrics import average_precision_score
B = Path(str(_HANDOFF_ROOT / ''))
O = B / 'results/ligand_response'
R = O / 'resources'
counts = pd.read_csv(O / 'EC_main_pseudobulk_counts.csv.gz', index_col=0)
log = np.log2(1 + counts.div(counts.sum(1), axis=0) * 1000000.0)
bg = pd.read_csv(O / 'EC_main_donor_DE.csv')
targets = (R / 'nichenet_targets.txt').read_text().splitlines()
ligs = (R / 'nichenet_ligands.txt').read_text().splitlines()
tix = {g: i for (i, g) in enumerate(targets)}
bg = bg[bg.gene.isin(tix) & bg.t.notna()].gene.tolist()
mat = np.memmap(R / 'nichenet_ligand_target_float32.bin', dtype='<f4', mode='r', shape=(len(targets), len(ligs)), order='F')
v = np.asarray(mat[[tix[g] for g in bg], :])
bm = log.index.str.startswith('MET')
tl = log.index.str.startswith('TL')
c = pd.read_csv(O / 'internal_NicheNet_LR_compatibility.csv')
tum = set(c.loc[c.is_tumor, 'ligand'])
rows = []
for donor in log.index[bm]:
    sel = bm & (log.index != donor)
    ts = ttest_ind(log.loc[sel, bg], log.loc[tl, bg], equal_var=False, axis=0).statistic
    target = np.argsort(-ts)[:200]
    gold = np.zeros(len(bg))
    gold[target] = 1
    ap = np.array([average_precision_score(gold, v[:, j]) if v[:, j].std() > 0 else np.nan for j in range(len(ligs))])
    rank = pd.Series(ap, index=ligs).rank(ascending=False, method='min')
    trank = pd.Series(ap, index=ligs).where(pd.Index(ligs).isin(tum)).rank(ascending=False, method='min')
    for lig in ['VEGFA', 'FGF2', 'TGFB1', 'PGF']:
        j = ligs.index(lig)
        rows.append(dict(omitted_BM_donor=donor, n_BM=4, n_TL=9, ligand=lig, rank_all=rank[lig], rank_tumor=trank[lig], auprc=ap[j]))
    print(donor, rows[-4], flush=True)
pd.DataFrame(rows).to_csv(O / 'NicheNet_leave_one_BM_out.csv', index=False)
