# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
"""L18: endothelial abundance and tumour-to-EC geometry using official named clinical linkage."""
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os
for k in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS']:
    os.environ[k] = '2'
from pathlib import Path
import json, hashlib, scipy.io as sio, numpy as np, pandas as pd
from scipy.spatial import cKDTree
from scipy.stats import mannwhitneyu, rankdata, wilcoxon
from statsmodels.stats.multitest import multipletests
B = Path(str(_HANDOFF_ROOT / ''))
O = B / 'results/verified_vascular_geometry'
D = B / 'data/external/imc/Karimi2023/data/BrainData'
mp = pd.read_csv(O / 'ALL_ROI_MAPPING_OFFICIAL_VERIFIED.csv')
rows = []
manifest = []
for (_, r) in mp.iterrows():
    (roi, old) = (r.official_roi, r.legacy_roi)
    cf = O / 'official_updated/CellType' / f'{roi}.mat'
    sf = O / 'official_updated/Segmentation' / roi
    if not sf.exists():
        sf = D / 'BRAIN_IMC_Segmentation' / old
    sm = sio.loadmat(sf / 'allRegionIndices.mat')
    nm = sio.loadmat(sf / 'nuclei_multiscale.mat')
    m = sio.loadmat(cf)
    ct = np.array([str(x[0]) if len(x) else 'NONE' for x in m['cellTypes'].ravel()])
    seg = sm['allRegInds'].ravel()
    (H, W) = nm['nucleiImage'].shape
    assert len(seg) == len(ct)
    xy = np.array([[np.mean((np.asarray(i).ravel().astype(np.int64) - 1) // H), np.mean((np.asarray(i).ravel().astype(np.int64) - 1) % H)] if np.size(i) else [np.nan, np.nan] for i in seg])
    area = np.array([np.size(i) for i in seg])
    ok = np.isfinite(xy).all(axis=1)
    xy = xy[ok]
    ct = ct[ok]
    area = area[ok]
    ec = ct == 'Endothelial cell'
    ca = ct == 'Cancer'
    A = H * W / 1000000.0
    row = {'official_roi': roi, 'legacy_roi': old, 'Patient ID': r['Patient ID'], 'Tumor Type': r['Tumor Type'], 'Tissue Region': r['Tissue Region'], 'n_cells': len(ct), 'n_EC': int(ec.sum()), 'n_cancer': int(ca.sum()), 'image_H': H, 'image_W': W, 'area_mm2': A, 'EC_per_mm2': ec.sum() / A, 'EC_cell_fraction': ec.mean(), 'EC_nuclear_footprint_fraction': area[ec].sum() / (H * W), 'EC_nuclear_area_median_um2': float(np.median(area[ec])) if ec.any() else np.nan}
    if ec.sum() >= 5 and ca.sum() >= 20:
        dd = cKDTree(xy[ec]).query(xy[ca])[0]
        row.update(cancer_median_dist_um=float(np.median(dd)), cancer_within20um=float(np.mean(dd <= 20)), cancer_within100um=float(np.mean(dd <= 100)))
    rows.append(row)
    for f in [cf, sf / 'allRegionIndices.mat', sf / 'nuclei_multiscale.mat']:
        manifest.append({'path': str(f.relative_to(B)), 'size': f.stat().st_size, 'sha256': hashlib.sha256(f.read_bytes()).hexdigest()})
d = pd.DataFrame(rows)
d.to_csv(O / 'IMC_official_ROI_metrics.csv', index=False)
pts = []
for (scope, z) in [('all_regions', d), ('tumor_core', d[d['Tissue Region'].astype(str).str.contains('Core')])]:
    for (pid, g) in z.groupby('Patient ID'):
        assert g['Tumor Type'].nunique() == 1
        pts.append({'patient': pid, 'group': g['Tumor Type'].iloc[0], 'scope': scope, 'n_ROIs': len(g), 'n_EC': int(g.n_EC.sum()), 'n_cells': int(g.n_cells.sum()), 'area_mm2': g.area_mm2.sum(), 'EC_per_mm2_mean_ROI': g.EC_per_mm2.mean(), 'EC_per_mm2_area_weighted': g.n_EC.sum() / g.area_mm2.sum(), 'EC_fraction_mean_ROI': g.EC_cell_fraction.mean(), 'EC_nuclear_footprint_mean_ROI': g.EC_nuclear_footprint_fraction.mean(), 'cancer_median_dist_um_mean_ROI': g.cancer_median_dist_um.mean(), 'cancer_median_dist_um_median_ROI': g.cancer_median_dist_um.median()})
p = pd.DataFrame(pts)
p.to_csv(O / 'IMC_official_patient_metrics.csv', index=False)
tests = []
metrics = ['EC_per_mm2_mean_ROI', 'EC_per_mm2_area_weighted', 'cancer_median_dist_um_mean_ROI', 'cancer_median_dist_um_median_ROI']
for (scope, z) in p.groupby('scope'):
    for (comp, groups) in [('BrM_vs_GBM', ['Glioblastoma']), ('BrM_vs_all_glioma', ['Glioblastoma', 'Astrocytoma'])]:
        for metric in metrics:
            a = z[z.group == 'Brain Metastasis'][metric].dropna().values
            b = z[z.group.isin(groups)][metric].dropna().values
            if min(len(a), len(b)) < 3:
                continue
            u = mannwhitneyu(a, b, alternative='two-sided', method='asymptotic')
            tests.append({'scope': scope, 'comparison': comp, 'metric': metric, 'n_BrM': len(a), 'n_ref': len(b), 'BrM_median': float(np.median(a)), 'reference_median': float(np.median(b)), 'p_donor_MWU': float(u.pvalue), 'rank_biserial': float(2 * u.statistic / (len(a) * len(b)) - 1)})
t = pd.DataFrame(tests)
t['q_BH_16'] = multipletests(t.p_donor_MWU, method='fdr_bh')[1]
t.to_csv(O / 'IMC_donor_group_tests.csv', index=False)
bm = d[d['Tumor Type'] == 'Brain Metastasis']
paired = []
for (pid, g) in bm.groupby('Patient ID'):
    a = g[g['Tissue Region'] == 'Tumor Core']
    b = g[g['Tissue Region'] == 'Tumor Margin']
    if len(a) and len(b):
        for metric in ['EC_per_mm2', 'cancer_median_dist_um', 'EC_cell_fraction', 'EC_nuclear_footprint_fraction']:
            av = a[metric].mean()
            bv = b[metric].mean()
            paired.append({'patient': pid, 'metric': metric, 'core': av, 'margin': bv, 'core_minus_margin': av - bv, 'n_core_ROI': len(a), 'n_margin_ROI': len(b)})
pair = pd.DataFrame(paired)
pair.to_csv(O / 'IMC_BrM_paired_core_margin.csv', index=False)
ptests = []
for (metric, g) in pair.groupby('metric'):
    g = g.dropna(subset=['core', 'margin'])
    z = g.core_minus_margin.values
    w = wilcoxon(z, zero_method='wilcox', method='approx', alternative='two-sided')
    ptests.append({'metric': metric, 'n_paired_donors': len(g), 'core_median': g.core.median(), 'margin_median': g.margin.median(), 'median_paired_difference': np.median(z), 'n_core_lower': int((z < 0).sum()), 'n_core_higher': int((z > 0).sum()), 'p_paired_Wilcoxon': w.pvalue})
pt = pd.DataFrame(ptests)
pt['q_BH_4'] = multipletests(pt.p_paired_Wilcoxon, method='fdr_bh')[1]
pt.to_csv(O / 'IMC_paired_core_margin_tests.csv', index=False)
old = pd.read_csv(B / 'results/vascular_niche/V6/V6_imc_vessel_metrics_by_roi.csv')
cmp = d.merge(old[['roi', 'n_cells', 'n_EC', 'EC_per_mm2', 'cancer_median_dist_um']], left_on='legacy_roi', right_on='roi', suffixes=('_new', '_legacy'), validate='1:1')
for metric in ['n_cells', 'n_EC', 'EC_per_mm2', 'cancer_median_dist_um']:
    cmp[metric + '_difference_after_legacy_rounding'] = cmp[metric + '_new'].round(1 if metric in ['EC_per_mm2', 'cancer_median_dist_um'] else 0) - cmp[metric + '_legacy']
cmp.to_csv(O / 'IMC_legacy_ROI_numerical_impact.csv', index=False)
legacy = pd.read_csv(B / 'results/vascular_niche/V6/V6_imc_vessel_metrics_by_patient.csv')
impact = p[p.scope == 'all_regions'].merge(legacy, left_on='patient', right_on='Patient ID', suffixes=('_new', '_legacy'))
impact['density_new_minus_legacy'] = impact.EC_per_mm2_mean_ROI - impact.EC_per_mm2
impact['distance_new_minus_legacy'] = impact.cancer_median_dist_um_mean_ROI - impact.cancer_median_dist_um
impact.to_csv(O / 'IMC_legacy_patient_numerical_impact.csv', index=False)
(O / 'IMC_INPUT_MANIFEST.json').write_text(json.dumps(manifest, indent=2))
print('MAIN', t.query("scope=='all_regions' and comparison=='BrM_vs_GBM'").to_string(index=False), flush=True)
print('PAIRED', pt.to_string(index=False), flush=True)
print('IMPACT', cmp.filter(like='difference').abs().max().to_dict(), flush=True)
