# Current scientific analysis; package-relative paths.
handoff_arg <- grep("^--file=", commandArgs(), value=TRUE)
handoff_file <- sub("^--file=", "", handoff_arg[1])
HANDOFF_ROOT <- Sys.getenv("SAFEPOSTER_HANDOFF_ROOT", unset=normalizePath(file.path(dirname(handoff_file), "../.."), mustWork=TRUE))
# 注: GEO 的 .rds.gz 是双重 gzip (gzip 里面还是 gzip 的 RDS), 先 zcat 一层再 readRDS
# L13 D4: GSE131907 raw UMI rds → 只保留 mBrain (脑转移) + tLung (原发肺肿瘤) 样本, 写 mtx 供 python 打分
Sys.setenv(OPENBLAS_NUM_THREADS="8",OMP_NUM_THREADS="8")
suppressPackageStartupMessages({library(Matrix)})
E<-file.path(HANDOFF_ROOT, "data/external/scrna/GSE131907"); O<-file.path(HANDOFF_ROOT, "results/external_replication/D4")
PROG<-file.path(O,"progress.txt"); log<-function(...){con<-file(PROG,open="a");writeLines(paste0(format(Sys.time(),"[%H:%M:%S] "),paste0(...,collapse="")),con);close(con)}
ann<-read.delim(gzfile(file.path(E,"GSE131907_Lung_Cancer_cell_annotation.txt.gz")),stringsAsFactors=FALSE)
log("注释 ",nrow(ann)," 细胞; 列: ",paste(colnames(ann),collapse=","))
print(table(ann$Sample_Origin)); print(head(table(ann$Cell_type)))
keep<-ann[ann$Sample_Origin %in% c("mBrain","tLung","nLung"),]
log("保留 mBrain/tLung/nLung ",nrow(keep))
rds1<-file.path(E,"GSE131907_raw_UMI_matrix.rds"); if(!file.exists(rds1)) system(paste0("zcat ",file.path(E,"GSE131907_Lung_Cancer_raw_UMI_matrix.rds.gz")," > ",rds1)); m<-readRDS(rds1)
log("矩阵 ",class(m)[1]," ",nrow(m)," x ",ncol(m))
m<-m[,intersect(colnames(m),keep$Index)]
if(!inherits(m,"sparseMatrix")) m<-Matrix(as.matrix(m),sparse=TRUE)
writeMM(m,file.path(O,"matrix.mtx")); writeLines(rownames(m),file.path(O,"features.tsv")); writeLines(colnames(m),file.path(O,"barcodes.tsv"))
write.csv(keep[match(colnames(m),keep$Index),],file.path(O,"cell_annotation_subset.csv"),row.names=FALSE)
log("写出 ",nrow(m)," x ",ncol(m)," 完成")
