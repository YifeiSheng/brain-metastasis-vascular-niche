# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os, glob, json, time, numpy as np, pandas as pd, scanpy as sc
from scipy.stats import mannwhitneyu
B = str(_HANDOFF_ROOT / '')
R = f'{B}/results/external_replication'
D = f'{R}/D8'
E = f'{B}/data/external/scrna/GSE223499'
L = open(f'{D}/progress.txt', 'a', buffering=1)
log = lambda *a: L.write(time.strftime('[%H:%M:%S] ') + ' '.join(map(str, a)) + '\n')
J = json.load(open(f'{R}/D2/signatures_used.json'))
SIG = J['signatures']
SIG2LIN = J['lineage']
LIN = {'髓系': ['PTPRC', 'CD68', 'CD14', 'AIF1', 'CSF1R', 'C1QA', 'LYZ', 'TYROBP', 'FCER1G'], 'T/NK': ['CD3E', 'CD3D', 'CD2', 'NKG7', 'GNLY', 'TRAC', 'CD8A', 'IL7R'], '基质/血管': ['PDGFRB', 'RGS5', 'COL1A2', 'DCN', 'CLDN5', 'VWF', 'PECAM1', 'ACTA2'], '上皮/肿瘤': ['EPCAM', 'KRT8', 'KRT18', 'KRT19'], 'B': ['MS4A1', 'CD79A', 'CD79B', 'CD19']}
meta = pd.read_csv(f'{E}/sample_meta.csv')
meta['genotype'] = np.where(meta['stk11 mutation'].str.contains('STK11', na=False), 'STK11突变', np.where(meta['kras mutation status'].str.contains('KRAS G|KRAS Q', na=False), 'KRAS突变_STK11野生', '未注明'))
meta['site'] = meta['metastatic site']
meta.to_csv(f'{D}/sample_groups.csv', index=False)
rows = []
cells = []
for (_, m) in meta.iterrows():
    h5 = glob.glob(f'{E}/raw/{m.gsm}_*_sn_raw_feature_bc_matrix.h5')
    if not h5:
        log('缺文件', m.gsm)
        continue
    a = sc.read_10x_h5(h5[0])
    a.var_names_make_unique()
    sc.pp.filter_cells(a, min_counts=500)
    sc.pp.filter_cells(a, min_genes=300)
    a.var['mt'] = a.var_names.str.startswith('MT-')
    sc.pp.calculate_qc_metrics(a, qc_vars=['mt'], inplace=True)
    a = a[a.obs.pct_counts_mt < 10].copy()
    if a.n_obs > 30000:
        a = a[np.argsort(-a.obs.total_counts.values)[:30000]].copy()
    sc.pp.filter_genes(a, min_cells=3)
    sc.pp.normalize_total(a, target_sum=10000.0)
    sc.pp.log1p(a)
    LS = pd.DataFrame(index=a.obs_names)
    for (l, g) in LIN.items():
        gg = [x for x in g if x in a.var_names]
        LS[l] = np.asarray(a[:, gg].X.mean(axis=1)).ravel()
    lin = LS.idxmax(axis=1).where(LS.max(axis=1) > 0.3, '其他')
    a.obs['lineage_gate'] = lin.values
    pc = pd.DataFrame(index=a.obs_names)
    pc['sample'] = m.title
    pc['lineage_gate'] = lin.values
    for (c, g) in SIG.items():
        gg = [x for x in g if x in a.var_names]
        if len(gg) < 3:
            continue
        sc.tl.score_genes(a, gg, score_name='_s', ctrl_size=50, n_bins=25, random_state=0)
        s = a.obs['_s'].values
        det = np.asarray((a[:, gg].X > 0).sum(axis=1)).ravel()
        pos = (s > 0.15) & (det >= max(2, len(gg) // 2))
        pc[c] = pos
        pc[c + '_score'] = s
        l = SIG2LIN[c]
        den = (lin == l).values if l in LIN else np.ones(len(lin), bool)
        rows.append(dict(sample=m.title, gsm=m.gsm, patient=m['patient id'], site=m.site, genotype=m.genotype, signature=c, lineage=l, n_genes=len(gg), n_cells=a.n_obs, n_lineage_cells=int(den.sum()), n_positive=int((pos & den).sum()), frac_of_lineage=round(float((pos & den).sum() / max(den.sum(), 1)), 4), frac_of_all=round(float(pos.mean()), 4), mean_score_lineage=round(float(s[den].mean()) if den.sum() else np.nan, 4)))
    cells.append(pc)
    log(m.title, m.site, m.genotype, a.n_obs, '核; 门控:', lin.value_counts().to_dict())
res = pd.DataFrame(rows)
res.to_csv(f'{D}/D8_signature_frequency_by_sample.csv', index=False)
pd.concat(cells).to_csv(f'{D}/D8_percell.csv.gz', compression='gzip')
cmp = []
for (c, sub) in res.groupby('signature'):
    sub = sub[sub.n_lineage_cells >= 20]
    for (col, g1, g2) in [('site', 'BM', 'PT'), ('genotype', 'STK11突变', 'KRAS突变_STK11野生'), ('genotype', 'STK11突变', '未注明')]:
        x = sub[sub[col] == g1].frac_of_lineage
        y = sub[sub[col] == g2].frac_of_lineage
        if len(x) >= 3 and len(y) >= 3:
            p = mannwhitneyu(x, y, alternative='two-sided').pvalue
            cmp.append(dict(signature=c, lineage=sub.lineage.iloc[0], contrast=col, group1=g1, group2=g2, n1=len(x), n2=len(y), median1=round(x.median(), 4), median2=round(y.median(), 4), mwu_p=p))
pd.DataFrame(cmp).sort_values('mwu_p').to_csv(f'{D}/D8_group_comparison.csv', index=False)
log('全部完成')
