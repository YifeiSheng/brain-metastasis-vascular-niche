# Current scientific analysis; package-relative paths.
handoff_arg <- grep("^--file=", commandArgs(), value=TRUE)
handoff_file <- sub("^--file=", "", handoff_arg[1])
HANDOFF_ROOT <- Sys.getenv("SAFEPOSTER_HANDOFF_ROOT", unset=normalizePath(file.path(dirname(handoff_file), "../.."), mustWork=TRUE))
# Public experiment state contrasts; limma-trend on deposited normalized-expression values.
suppressPackageStartupMessages(library(limma))
B <- file.path(HANDOFF_ROOT, "results/pericyte_differentiation/GSE237317")
x <- as.matrix(read.csv(file.path(B,"author_expression_matrix.csv"),row.names=1,check.names=FALSE))
map <- read.csv(file.path(B,"ensembl_symbol_map.csv"),stringsAsFactors=FALSE)
group <- factor(c("CSC","CSC","Cdpericyte","Cdpericyte","PdCSC","PdCSC"),levels=c("CSC","Cdpericyte","PdCSC"))
stopifnot(grepl("^CSC",colnames(x)[1]),grepl("^Cdpericyte",colnames(x)[3]),grepl("^pdCSC",colnames(x)[5]))
design <- model.matrix(~0+group);colnames(design)<-levels(group)
contr <- makeContrasts(Cdpericyte_vs_CSC=Cdpericyte-CSC,PdCSC_vs_Cdpericyte=PdCSC-Cdpericyte,PdCSC_vs_CSC=PdCSC-CSC,levels=design)
keep <- rowSums(x>=1)>=2
all <- list()
for (mode in c("author_values","library_scaled")){
 y <- if(mode=="author_values") log2(x[keep,,drop=FALSE]+1) else log2(t(t(x[keep,,drop=FALSE])/colSums(x))*1e6+1)
 fit <- eBayes(contrasts.fit(lmFit(y,design),contr),trend=TRUE)
 for (co in colnames(contr)){
  z<-topTable(fit,coef=co,number=Inf,sort.by="none",confint=TRUE);z$gene_id<-rownames(z);z$symbol<-map$symbol[match(z$gene_id,map$gene_id)];z$contrast<-co;z$normalization<-mode;all[[length(all)+1]]<-z
 }
}
res<-do.call(rbind,all);res$q_all_contrasts<-ave(res$P.Value,res$normalization,FUN=function(p)p.adjust(p,"BH"))
write.csv(res,gzfile(file.path(B,"all_gene_state_contrasts.csv.gz")),row.names=FALSE)
markers<-c("MCAM","CD44","ABCG2","PDGFRB","CSPG4","RGS5","HIGD1B","ABCC9","KCNJ8","ADGRA2","VEGFA","SLC6A1","SLC1A3","SLC12A7","SLC20A2","COL4A1","COL4A2","COL4A3","COL4A4","ADAMTS1","LAMA4")
panel<-res[res$symbol%in%markers,];panel$q_BH_marker63<-ave(panel$P.Value,panel$normalization,FUN=function(p)p.adjust(p,"BH"))
write.csv(panel,file.path(B,"marker_state_contrasts.csv"),row.names=FALSE)
xx<-data.frame(gene_id=rownames(x),symbol=map$symbol[match(rownames(x),map$gene_id)],x,check.names=FALSE)
write.csv(xx[xx$symbol%in%markers,],file.path(B,"marker_author_expression.csv"),row.names=FALSE)
capture.output(sessionInfo(),file=file.path(B,"R_sessionInfo.txt"))
cat("COMPLETE",nrow(x),"deposited genes",sum(keep),"tested genes\n")
