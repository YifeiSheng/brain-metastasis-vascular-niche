# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
"""L16 extra mural-gate sensitivity. Strict exclusions are deliberately conservative,
because contractile/ECM programs can be genuine pericyte biology."""
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
from pathlib import Path
import pandas as pd
B = Path(str(_HANDOFF_ROOT / ''))
O = B / 'results/spatial_distance_and_state_validation'
rows = []
for name in ['internal_cell_states.csv.gz', 'kim_stromal_marker_states.csv.gz']:
    d = pd.read_csv(O / name)
    for gate in ['screened', 'low_contractile_fibro']:
        z = d[d.pericyte_clean].copy()
        if gate == 'low_contractile_fibro':
            z = z[(z.SMC_contractile_ndet < 3) & (z.fibroblast_ndet < 3)]
        key = 'patient_id' if name.startswith('internal') else 'Sample'
        for (ident, q) in z.groupby(key):
            rows.append(dict(dataset='internal' if name.startswith('internal') else 'Kim2020', unit=ident, origin='' if name.startswith('internal') else q.Sample_Origin.iloc[0], gate=gate, n=len(q), T_n=int(q.T_supported.sum()), M_n=int(q.M_supported.sum()), both_n=int((q.T_supported & q.M_supported).sum())))
pd.DataFrame(rows).to_csv(O / 'mural_identity_exclusion_sensitivity.csv', index=False)
a = pd.read_csv(O / 'pericyte_legacy_vs_marker_audit.csv.gz')
a[a.pericyte_clean].groupby(['patient_id', 'legacy_label', 'functional_support']).size().rename('n').to_csv(O / 'legacy_classifier_marker_crosscheck.csv')
print('COMPLETE')
