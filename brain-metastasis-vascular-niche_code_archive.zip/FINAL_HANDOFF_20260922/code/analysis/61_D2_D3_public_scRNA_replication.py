# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import numpy as np, os, glob, gzip, json, numpy as np, pandas as pd, scanpy as sc, scipy.sparse as sp, time, re
E = str(_HANDOFF_ROOT / 'data/external/scrna')
DL = str(_HANDOFF_ROOT / 'data/integrated')
R = str(_HANDOFF_ROOT / 'results/external_replication')
L = open(f'{R}/D2/progress.txt', 'a', buffering=1)
log = lambda *a: L.write(time.strftime('[%H:%M:%S] ') + ' '.join(map(str, a)) + '\n')
mk = pd.read_csv(f'{DL}/output/rare_cell_markers.csv')
cand = pd.read_csv(f'{DL}/output/rare_cell_candidates.csv')
SIG = {}
for (c, sub) in mk.groupby('candidate'):
    s = sub[(sub.pct_in > 0.5) & (sub.pct_out < 0.05)].sort_values('diff', ascending=False).gene.tolist()
    if len(s) < 3:
        s = sub[(sub.pct_in > 0.4) & (sub.pct_out < 0.1)].sort_values('diff', ascending=False).gene.tolist()[:6]
    if len(s) >= 3:
        SIG[c] = s[:10]
LIN = {'髓系': ['PTPRC', 'CD68', 'CD14', 'AIF1', 'CSF1R', 'C1QA', 'LYZ', 'TYROBP', 'FCER1G'], 'T/NK': ['CD3E', 'CD3D', 'CD2', 'NKG7', 'GNLY', 'TRAC', 'CD8A', 'IL7R'], '基质/血管': ['PDGFRB', 'RGS5', 'COL1A2', 'DCN', 'CLDN5', 'VWF', 'PECAM1', 'ACTA2'], '上皮/肿瘤': ['EPCAM', 'KRT8', 'KRT18', 'KRT19'], 'B': ['MS4A1', 'CD79A', 'CD79B', 'CD19']}
SIG2LIN = {c: '髓系' if any((k in c for k in ['巨噬', '小胶质', '单核', '树突', 'pDC', '肥大', 'ADAMDEC1'])) else 'T/NK' if any((k in c for k in ['T 细胞', 'NK', 'γδ', 'Treg', 'T(', '增殖 T'])) else '基质/血管' if any((k in c for k in ['周细胞', '内皮', '成纤维'])) else '上皮/肿瘤' if any((k in c for k in ['肿瘤', '上皮', 'EMT', '黏液', '神经内分泌', 'OPC'])) else 'B' if 'B 细胞' in c else '其他' for c in SIG}
json.dump({'signatures': SIG, 'lineage': SIG2LIN}, open(f'{R}/D2/signatures_used.json', 'w'), ensure_ascii=False, indent=1)

def process(adata, sample, dataset, author_ct=None):
    sc.pp.filter_genes(adata, min_cells=3)
    sc.pp.filter_cells(adata, min_genes=200)
    sc.pp.normalize_total(adata, target_sum=10000.0)
    sc.pp.log1p(adata)
    LS = pd.DataFrame(index=adata.obs_names)
    for (l, g) in LIN.items():
        gg = [x for x in g if x in adata.var_names]
        LS[l] = np.asarray(adata[:, gg].X.mean(axis=1)).ravel() if gg else 0
    lin = LS.idxmax(axis=1).where(LS.max(axis=1) > 0.3, '其他')
    adata.obs['lineage_gate'] = lin.values
    rows = []
    percell = pd.DataFrame(index=adata.obs_names)
    percell['lineage_gate'] = lin.values
    for (c, g) in SIG.items():
        gg = [x for x in g if x in adata.var_names]
        if len(gg) < 3:
            continue
        sc.tl.score_genes(adata, gg, score_name='_s', ctrl_size=50, n_bins=25, random_state=0)
        s = adata.obs['_s'].values
        det = np.asarray((adata[:, gg].X > 0).sum(axis=1)).ravel()
        pos = (s > 0.15) & (det >= max(2, len(gg) // 2))
        percell[c] = pos
        l = SIG2LIN[c]
        den = (lin == l).values if l in LIN else np.ones(len(lin), bool)
        rows.append(dict(dataset=dataset, sample=sample, signature=c, lineage=l, n_genes=len(gg), n_lineage_cells=int(den.sum()), n_positive=int((pos & den).sum()), frac_of_lineage=round(float((pos & den).sum() / max(den.sum(), 1)), 4), frac_of_all=round(float(pos.mean()), 4)))
    ct = pd.Series(adata.obs['author_ct']) if 'author_ct' in adata.obs else None
    return (pd.DataFrame(rows), percell, LS)
allrows = []
ctrows = []
for mtx in sorted(glob.glob(f'{E}/GSE186344/raw/*_matrix.mtx.gz')):
    pre = mtx.replace('_matrix.mtx.gz', '')
    sample = os.path.basename(pre).split('_', 1)[1]
    if 'Mouse' in sample:
        continue
    try:
        a = sc.read_10x_mtx(os.path.dirname(mtx), prefix=os.path.basename(pre) + '_', cache=False)
    except Exception as e:
        import scipy.io
        M = scipy.io.mmread(mtx).tocsr().T
        bc = pd.read_csv(pre + '_barcodes.tsv.gz', header=None)[0].values
        ft = pd.read_csv(pre + '_features.tsv.gz', header=None, sep='\t')
        a = sc.AnnData(M, obs=pd.DataFrame(index=bc), var=pd.DataFrame(index=ft[1].values if ft.shape[1] > 1 else ft[0].values))
    a.var_names_make_unique()
    import re
    annf = pre + '_Cell_Types_Annotations.csv.gz'
    key = lambda i: re.sub('.*?([ACGT]{16})(-\\d+)?$', '\\1', str(i))
    if os.path.exists(annf):
        ann = pd.read_csv(annf, index_col=0)
        ann.index = [key(i) for i in ann.index]
        ann = ann[~ann.index.duplicated()]
        a.obs['author_ct'] = ann['Cell_Type'].reindex([key(i) for i in a.obs_names]).values
    else:
        a.obs['author_ct'] = np.nan
    (df, percell, LS) = process(a, sample, 'GSE186344')
    allrows.append(df)
    if a.obs.author_ct.notna().any():
        ct = pd.crosstab(a.obs.author_ct, a.obs.lineage_gate)
        ct['sample'] = sample
        ctrows.append(ct.reset_index())
    percell.to_csv(f'{R}/D2/percell_{sample}.csv.gz', compression='gzip')
    log('GSE186344', sample, a.n_obs, '细胞; 作者注释覆盖', int(a.obs.author_ct.notna().sum()))
for h5 in sorted(glob.glob(f'{E}/GSE203552/raw/*biopsy*_rna.h5')):
    sample = re.search('(p\\d+_biopsy\\d*)', h5).group(1)
    a = sc.read_10x_h5(h5)
    a.var_names_make_unique()
    (df, percell, LS) = process(a, sample, 'GSE203552_PCNSL')
    allrows.append(df)
    percell.to_csv(f'{R}/D3/percell_{sample}.csv.gz', compression='gzip')
    log('GSE203552', sample, a.n_obs)
res = pd.concat(allrows)
res.to_csv(f'{R}/D2/D2_D3_signature_frequency_by_sample.csv', index=False)
if ctrows:
    pd.concat(ctrows).to_csv(f'{R}/D2/D2_author_celltype_vs_our_gate.csv', index=False)
log('全部完成')
