# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os, json, urllib.request, urllib.parse, numpy as np, pandas as pd, time
from scipy.stats import mannwhitneyu
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
font_manager.fontManager.addfont(str(_HANDOFF_ROOT / 'environment/NotoSansCJKsc-Regular.otf'))
plt.rcParams['font.family'] = ['Noto Sans CJK SC', 'DejaVu Sans']
B = str(_HANDOFF_ROOT / '')
EY = f'{B}/data/external/bulk/Yang2026_BrM_zenodo'
ET = f'{B}/data/external/bulk/TCGA-LUAD'
O = f'{B}/results/immune_glial_lymphoma/I4_BULK'
os.makedirs(O, exist_ok=True)
AX = {'T轴': ['CD3E', 'CD8A', 'CXCL13', 'FOXP3', 'TNFRSF9', 'PDCD1', 'CD2'], '中性粒轴': ['CSF3R', 'S100A8', 'S100A9', 'FCGR3B', 'CXCR2', 'G0S2'], '髓系轴': ['CD163', 'CD68', 'C1QA', 'MRC1', 'MS4A7', 'AIF1'], '干扰素轴': ['CXCL9', 'CXCL10', 'GBP5', 'GBP4', 'IDO1', 'STAT1'], '血管龛轴': ['PDGFRB', 'NOTCH3', 'RGS5', 'HIGD1B', 'NDUFA4L2', 'KCNJ8'], 'BAM轴': ['F13A1', 'LYVE1', 'CD209', 'COLEC12', 'SIGLEC1', 'FOLR2'], '肥大细胞轴': ['TPSAB1', 'CPA3', 'MS4A2', 'HDC'], '肺来源代理': ['NAPSA', 'NKX2-1', 'SFTPB', 'SFTPA2']}
GENES = ['STK11', 'KRAS', 'EGFR', 'TP53', 'KEAP1']
NONSIL = {'Missense_Mutation', 'Frame_Shift_Del', 'Frame_Shift_Ins', 'Nonsense_Mutation', 'In_Frame_Del', 'In_Frame_Ins', 'Nonstop_Mutation', 'Splice_Site', 'Translation_Start_Site'}

def zscore_axes(logexpr):
    S = {}
    for (k, g) in AX.items():
        gg = [x for x in g if x in logexpr.index]
        z = logexpr.loc[gg].sub(logexpr.loc[gg].mean(1), axis=0).div(logexpr.loc[gg].std(1) + 1e-09, axis=0)
        S[k] = z.mean(0)
    return pd.DataFrame(S)

def compare(S, mut, label):
    out = []
    for g in GENES:
        if g not in mut:
            continue
        for ax in AX:
            x = S.loc[mut.index[mut[g] == 1], ax].dropna()
            y = S.loc[mut.index[mut[g] == 0], ax].dropna()
            out.append(dict(cohort=label, gene=g, axis=ax, n_mut=len(x), n_wt=len(y), median_mut=round(x.median(), 3) if len(x) else np.nan, median_wt=round(y.median(), 3) if len(y) else np.nan, mwu_p=mannwhitneyu(x, y).pvalue if len(x) >= 3 and len(y) >= 3 else np.nan))
    if 'KRAS' in mut and 'STK11' in mut:
        a = mut.index[(mut.KRAS == 1) & (mut.STK11 == 1)]
        b = mut.index[(mut.KRAS == 1) & (mut.STK11 == 0)]
        for ax in AX:
            x = S.loc[a, ax].dropna()
            y = S.loc[b, ax].dropna()
            out.append(dict(cohort=label, gene='KRAS+STK11 vs KRAS单突变', axis=ax, n_mut=len(x), n_wt=len(y), median_mut=round(x.median(), 3) if len(x) else np.nan, median_wt=round(y.median(), 3) if len(y) else np.nan, mwu_p=mannwhitneyu(x, y).pvalue if len(x) >= 3 and len(y) >= 3 else np.nan))
    return pd.DataFrame(out)
res = []
m = pd.read_excel(f'{EY}/Mutation.xlsx')
m = m[m.Variant_Classification.isin(NONSIL)]
mut = pd.crosstab(m.Tumor_Sample_Barcode, m.Hugo_Symbol).clip(upper=1)
mut = mut.reindex(columns=GENES).fillna(0).astype(int)
mut = mut.reindex(m.Tumor_Sample_Barcode.unique()).fillna(0).astype(int)
c = pd.read_csv(f'{EY}/discovery.counts.csv', index_col=0)
c = c[~c.index.duplicated()]
cpm = np.log2(c / c.sum() * 1000000.0 + 1)
S = zscore_axes(cpm)
common = [s for s in S.index if s in mut.index]
print('Yang discovery 130 例, 有突变表:', len(common))
Sy = S.loc[common]
my = mut.loc[common]
Sy['lung_proxy'] = (Sy['肺来源代理'] > 0.3).astype(int)
print('肺来源代理阳性:', int(Sy.lung_proxy.sum()))
print('突变数:', my.sum().to_dict())
Sy.join(my.add_prefix('mut_')).to_csv(f'{O}/I4_yang2026_axes_genotype.csv')
res.append(compare(Sy, my, 'Yang2026 脑转移 bulk (全部有突变表)'))
res.append(compare(Sy[Sy.lung_proxy == 1], my.loc[Sy.index[Sy.lung_proxy == 1]], 'Yang2026 脑转移 bulk (肺来源代理阳性)'))
S.to_csv(f'{O}/I4_yang2026_axes_all130.csv')
API = 'https://www.cbioportal.org/api'

def post(path, body, params=None):
    u = API + path + ('?' + urllib.parse.urlencode(params) if params else '')
    req = urllib.request.Request(u, data=json.dumps(body).encode(), headers={'Content-Type': 'application/json', 'Accept': 'application/json'})
    return json.load(urllib.request.urlopen(req, timeout=300))

def get(path):
    req = urllib.request.Request(API + path, headers={'Accept': 'application/json'})
    return json.load(urllib.request.urlopen(req, timeout=120))
ENT = {'KRAS': 3845, 'STK11': 6794, 'TP53': 7157, 'KEAP1': 9817, 'EGFR': 1956}
st = 'luad_tcga_pan_can_atlas_2018'
mt = post(f'/molecular-profiles/{st}_mutations/mutations/fetch', {'sampleListId': f'{st}_all', 'entrezGeneIds': list(ENT.values())}, {'projection': 'SUMMARY'})
md = pd.DataFrame(mt)
md['gene'] = md.entrezGeneId.map({v: k for (k, v) in ENT.items()})
md = md[md.mutationType.astype(str) != 'Silent']
mm = pd.crosstab(md.sampleId, md.gene).clip(upper=1)
allsamples = get(f'/sample-lists/{st}_all')['sampleIds']
mm = mm.reindex(allsamples).fillna(0).astype(int).reindex(columns=GENES).fillna(0).astype(int)
fp = pd.read_csv(f'{ET}/TCGA-LUAD.star_fpkm.tsv.gz', sep='\t', index_col=0)
pm = pd.read_csv(f'{ET}/gencode.v36.annotation.gtf.gene.probemap', sep='\t')
id2g = dict(zip(pm.id, pm.gene))
fp.index = [id2g.get(i, i) for i in fp.index]
fp = fp[~fp.index.duplicated()]
prim = [s for s in fp.columns if s[13:15] == '01']
fp = fp[prim]
fp.columns = [s[:15] for s in fp.columns]
fp = fp.loc[:, ~fp.columns.duplicated()]
St = zscore_axes(fp)
common = [s for s in St.index if s in mm.index]
St = St.loc[common]
mt_ = mm.loc[common]
print('TCGA-LUAD 原发 有表达+突变:', len(common), '突变数:', mt_.sum().to_dict())
St.join(mt_.add_prefix('mut_')).to_csv(f'{O}/I4_tcga_luad_axes_genotype.csv')
res.append(compare(St, mt_, 'TCGA-LUAD 原发 bulk'))
R = pd.concat(res)
R.to_csv(f'{O}/I4_genotype_vs_immune_axes.csv', index=False)
pd.set_option('display.width', 250)
print(R[R.gene.isin(['STK11', 'KRAS', 'KRAS+STK11 vs KRAS单突变'])].to_string(index=False))
(fig, axes) = plt.subplots(2, 5, figsize=(20, 7))
for (row, (lab, S_, M_)) in enumerate([('TCGA-LUAD 原发', St, mt_), ('Yang2026 脑转移', Sy, my)]):
    for (ax, axis) in zip(axes[row], ['T轴', '中性粒轴', '髓系轴', '干扰素轴', '血管龛轴']):
        groups = [('STK11野生/KRAS野生', (M_.STK11 == 0) & (M_.KRAS == 0)), ('KRAS突变', (M_.KRAS == 1) & (M_.STK11 == 0)), ('STK11突变', M_.STK11 == 1)]
        data = [S_.loc[M_.index[mk], axis].dropna() for (_, mk) in groups]
        ax.boxplot(data, showfliers=False)
        ax.set_xticks([1, 2, 3])
        ax.set_xticklabels([f'{g}\nn={len(d)}' for ((g, _), d) in zip(groups, data)], fontsize=7)
        for (i, dv) in enumerate(data):
            ax.scatter(np.random.normal(i + 1, 0.05, len(dv)), dv, s=5, alpha=0.5)
        ax.set_title(f'{lab}: {axis}', fontsize=9)
fig.tight_layout()
fig.savefig(f'{O}/I4_axes_by_genotype.png', dpi=110)
plt.close(fig)
print('完成')
