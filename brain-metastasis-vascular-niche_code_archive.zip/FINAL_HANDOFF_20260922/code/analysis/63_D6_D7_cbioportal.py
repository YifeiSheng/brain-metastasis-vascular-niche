# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import json, urllib.request, urllib.parse, pandas as pd, numpy as np, time
API = 'https://www.cbioportal.org/api'
O = str(_HANDOFF_ROOT / 'results/external_replication/D6')
X12 = str(_HANDOFF_ROOT / 'results/internal_programs_and_CNV')

def get(path, params=None):
    u = API + path + ('?' + urllib.parse.urlencode(params) if params else '')
    req = urllib.request.Request(u, headers={'Accept': 'application/json'})
    return json.load(urllib.request.urlopen(req, timeout=120))

def post(path, body, params=None):
    u = API + path + ('?' + urllib.parse.urlencode(params) if params else '')
    req = urllib.request.Request(u, data=json.dumps(body).encode(), headers={'Content-Type': 'application/json', 'Accept': 'application/json'})
    return json.load(urllib.request.urlopen(req, timeout=300))
GENES = {'MYC': 4609, 'RB1': 5925, 'NKX2-1': 7080, 'EGFR': 1956, 'MET': 4233, 'CDK6': 1021, 'AURKA': 6790, 'PTEN': 5728, 'CDKN2A': 1029, 'TNFAIP3': 7128, 'ESR1': 2099, 'CCND1': 595, 'MDM2': 4193, 'CDK4': 1019, 'ERBB2': 2064, 'TERT': 7015, 'SMAD4': 4089, 'KRAS': 3845, 'STK11': 6794, 'TP53': 7157, 'KEAP1': 9817, 'SMARCA4': 6597, 'BRAF': 673, 'PIK3CA': 5290, 'NF1': 4763, 'SETD2': 29072, 'ALK': 238}
study = 'msk_met_2021'
cd = post(f'/studies/{study}/clinical-data/fetch', {'attributeIds': ['CANCER_TYPE_DETAILED', 'SAMPLE_TYPE', 'METASTATIC_SITE', 'PRIMARY_SITE', 'ORGAN_SYSTEM', 'SUBTYPE', 'METASTATIC_SITE_BILLING', 'MET_SITE_BRAIN', 'DMETS_DX_BRAIN', 'MSI_TYPE', 'FGA', 'TMB_NONSYNONYMOUS']}, {'clinicalDataType': 'SAMPLE', 'projection': 'SUMMARY'})
cdf = pd.DataFrame(cd)
tab = cdf.pivot_table(index='sampleId', columns='clinicalAttributeId', values='value', aggfunc='first')
print('MSK-MET 样本数', len(tab))
print(tab.columns.tolist())
luad = tab[tab.get('CANCER_TYPE_DETAILED', '').astype(str).str.contains('Lung Adenocarcinoma', na=False)].copy()
print('肺腺癌样本', len(luad))
print(luad.SAMPLE_TYPE.value_counts().to_dict() if 'SAMPLE_TYPE' in luad else '')
site_col = [c for c in luad.columns if 'METASTATIC_SITE' in c][:1]
if site_col:
    print(luad[site_col[0]].value_counts().head(12).to_dict())
brain = luad[(luad.SAMPLE_TYPE == 'Metastasis') & luad[site_col[0]].astype(str).str.contains('CNS|Brain', case=False, na=False)] if site_col else luad.iloc[0:0]
prim = luad[luad.SAMPLE_TYPE == 'Primary']
other_met = luad[(luad.SAMPLE_TYPE == 'Metastasis') & ~luad.index.isin(brain.index)]
print('脑转移样本', len(brain), '原发', len(prim), '其他部位转移', len(other_met))
prof = f'{study}_cna'
ids = list(GENES.values())

def cna(samples):
    out = []
    for i in range(0, len(samples), 2000):
        r = post(f'/molecular-profiles/{prof}/discrete-copy-number/fetch', {'sampleIds': samples[i:i + 2000], 'entrezGeneIds': ids}, {'discreteCopyNumberEventType': 'ALL', 'projection': 'SUMMARY'})
        out += r
        time.sleep(0.3)
    d = pd.DataFrame(out)
    return d
rows = []
for (name, S) in [('brain_met', brain), ('primary', prim), ('other_met', other_met)]:
    if len(S) == 0:
        continue
    d = cna(list(S.index))
    d['gene'] = d.entrezGeneId.map({v: k for (k, v) in GENES.items()})
    for g in GENES:
        sub = d[d.gene == g]
        n = len(S)
        amp = sub[sub.alteration == 2].sampleId.nunique()
        gain = sub[sub.alteration >= 1].sampleId.nunique()
        dele = sub[sub.alteration == -2].sampleId.nunique()
        loss = sub[sub.alteration <= -1].sampleId.nunique()
        rows.append(dict(group=name, gene=g, n_samples=n, amp2=amp, frac_amp2=round(amp / n, 4), gain_ge1=gain, frac_gain=round(gain / n, 4), deepdel=dele, frac_deepdel=round(dele / n, 4), loss_le_minus1=loss, frac_loss=round(loss / n, 4)))
res = pd.DataFrame(rows)
res.to_csv(f'{O}/D6_mskmet_luad_cna_by_site.csv', index=False)
piv = res.pivot(index='gene', columns='group', values=['frac_amp2', 'frac_deepdel'])
pd.set_option('display.width', 250)
print(piv.round(3).to_string())
from scipy.stats import fisher_exact
frows = []
for g in GENES:
    b = res[(res.group == 'brain_met') & (res.gene == g)]
    p = res[(res.group == 'primary') & (res.gene == g)]
    if len(b) and len(p):
        for (ev, col, cnt) in [('amp2', 'frac_amp2', 'amp2'), ('deepdel', 'frac_deepdel', 'deepdel')]:
            bb = int(b[cnt].iloc[0])
            nb = int(b.n_samples.iloc[0])
            pp = int(p[cnt].iloc[0])
            npp = int(p.n_samples.iloc[0])
            (orr, pv) = fisher_exact([[bb, nb - bb], [pp, npp - pp]])
            frows.append(dict(gene=g, event=ev, brain_frac=round(bb / nb, 4), primary_frac=round(pp / npp, 4), OR=round(orr, 2), fisher_p=pv))
fe = pd.DataFrame(frows).sort_values('fisher_p')
fe.to_csv(f'{O}/D6_brain_vs_primary_fisher.csv', index=False)
print(fe.head(20).to_string(index=False))
st = 'luad_tcga_pan_can_atlas_2018'
mprof = f'{st}_mutations'
mg = {g: GENES[g] for g in ['KRAS', 'EGFR', 'STK11', 'TP53', 'KEAP1', 'NKX2-1', 'SMARCA4', 'BRAF', 'PIK3CA', 'NF1', 'SETD2', 'ALK']}
mut = post(f'/molecular-profiles/{mprof}/mutations/fetch', {'sampleListId': f'{st}_all', 'entrezGeneIds': list(mg.values())}, {'projection': 'SUMMARY'})
md = pd.DataFrame(mut)
md['gene'] = md.entrezGeneId.map({v: k for (k, v) in mg.items()})
md = md[md.mutationType.astype(str) != 'Silent']
mm = pd.crosstab(md.sampleId, md.gene).clip(upper=1)
sl = get(f'/sample-lists/{st}_all')
allsamples = sl['sampleIds']
mm = mm.reindex(allsamples).fillna(0).astype(int)
sc_ = pd.read_csv(f'{X12}/M3_TCGA_LUAD_signature_scores.csv', index_col=0)
sc_.index = [i[:15] for i in sc_.index]
sc_ = sc_[~sc_.index.duplicated()]
j = mm.join(sc_['黏液分泌型肿瘤'], how='inner')
print('\nTCGA-LUAD 突变×黏液签名 样本数', len(j))
j['mucinous_group'] = pd.qcut(j['黏液分泌型肿瘤'], 3, labels=['低', '中', '高'])
out = []
for g in mg:
    if g not in j:
        continue
    t = j.groupby('mucinous_group', observed=True)[g].mean().round(3)
    hi = j[j.mucinous_group == '高'][g]
    lo = j[j.mucinous_group == '低'][g]
    (orr, pv) = fisher_exact([[int(hi.sum()), len(hi) - int(hi.sum())], [int(lo.sum()), len(lo) - int(lo.sum())]])
    out.append(dict(gene=g, mut_rate_low=t.get('低'), mut_rate_mid=t.get('中'), mut_rate_high=t.get('高'), OR_high_vs_low=round(orr, 2), fisher_p=pv))
d7 = pd.DataFrame(out).sort_values('fisher_p')
d7.to_csv(f'{O}/D7_tcga_luad_mucinous_vs_mutations.csv', index=False)
print(d7.to_string(index=False))
