# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
from pathlib import Path
import requests, json, hashlib, gzip, tarfile, re, datetime
B = Path(str(_HANDOFF_ROOT / ''))
O = B / 'results/VEGF_sprouting_calibration'
O.mkdir(parents=True, exist_ok=True)
M = []

def get(url, p):
    if not p.exists():
        r = requests.get(url, timeout=90)
        r.raise_for_status()
        p.write_bytes(r.content)
    M.append({'url': url, 'path': str(p.relative_to(B)), 'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()})
    return p
for acc in ['GSE196776', 'GSE227549']:
    d = O / acc
    d.mkdir(exist_ok=True)
    x = get(f'https://ftp.ncbi.nlm.nih.gov/geo/series/{acc[:-3]}nnn/{acc}/soft/{acc}_family.soft.gz', d / f'{acc}_family.soft.gz')
    s = gzip.decompress(x.read_bytes()).decode()
    (d / 'metadata.soft.txt').write_text(s)
    x = get(f'https://ftp.ncbi.nlm.nih.gov/geo/series/{acc[:-3]}nnn/{acc}/suppl/{acc}_RAW.tar', d / f'{acc}_RAW.tar')
    with tarfile.open(x) as tf:
        for m in tf.getmembers():
            if m.isfile():
                target = d / Path(m.name).name
                if not target.exists():
                    target.write_bytes(tf.extractfile(m).read())
    samples = []
    for block in s.split('^SAMPLE = ')[1:]:
        gsm = block.splitlines()[0]
        obj = {'gsm': gsm}
        for line in block.splitlines()[1:]:
            if line.startswith('!Sample_') and ' = ' in line:
                (k, v) = line[8:].split(' = ', 1)
                obj.setdefault(k, []).append(v)
        samples.append(obj)
    (d / 'samples.json').write_text(json.dumps(samples, indent=2))
    print(acc, [(x['gsm'], x.get('title'), x.get('characteristics_ch1')) for x in samples], flush=True)
    for sm in samples:
        print(sm['gsm'], sm.get('growth_protocol_ch1'), sm.get('treatment_protocol_ch1'), sm.get('description'), sm.get('data_processing'), flush=True)
paper = get('https://freidok.uni-freiburg.de/files/244070/melDObYIVeN4fBKo/1-s2.0-S0925443924000139-main.pdf', O / 'Rapp2024.pdf')
import sys
sys.path.insert(0, str(O / 'runtime'))
try:
    import pypdf
    (O / 'Rapp2024.txt').write_text('\n'.join((page.extract_text() for page in pypdf.PdfReader(paper).pages)))
except ImportError:
    print('Optional PDF text extraction requires pypdf in mechanism_sources/runtime; original PDF downloaded.')
(O / 'download_manifest.json').write_text(json.dumps(M, indent=2))
