# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os, gzip, time, numpy as np, pandas as pd, scipy.sparse as sp, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from sklearn.neighbors import NearestNeighbors, KDTree, radius_neighbors_graph
from scipy.stats import mannwhitneyu
font_manager.fontManager.addfont(str(_HANDOFF_ROOT / 'environment/NotoSansCJKsc-Regular.otf'))
plt.rcParams['font.family'] = ['Noto Sans CJK SC', 'DejaVu Sans']
B = str(_HANDOFF_ROOT / '')
E = f'{B}/data/external/spatial/GSE223501/raw'
O = f'{B}/results/vascular_niche/V1'
os.makedirs(O, exist_ok=True)
L = open(f'{O}/progress.txt', 'a', buffering=1)
log = lambda *a: L.write(time.strftime('[%H:%M:%S] ') + ' '.join(map(str, a)) + '\n')
rng = np.random.default_rng(0)
PX_UM = 0.65
meta = pd.read_csv(f'{B}/data/external/spatial/GSE223501/sample_meta.tsv', sep='\t', header=None, names=['gsm', 'title', 'ch'])
meta['site'] = np.where(meta.ch.str.contains('Brain Metastasis'), 'BM', 'PT')
meta['pid'] = meta.title.str.replace('NSCLC_', '').str.replace('_slideseq', '')
SETS = {'EC': ['PECAM1', 'CLDN5', 'VWF', 'CDH5', 'FLT1'], '周细胞': ['RGS5', 'NOTCH3', 'HIGD1B', 'PDGFRB', 'KCNJ8', 'NDUFA4L2', 'CSPG4'], '肿瘤': ['EPCAM', 'KRT8', 'KRT18', 'KRT19', 'KRT7', 'NAPSA', 'SFTPB', 'NKX2-1'], 'BAM': ['F13A1', 'LYVE1', 'CD209', 'COLEC12', 'SIGLEC1'], '成纤维': ['DCN', 'LUM', 'COL1A1', 'COL1A2', 'COL3A1'], '脑': ['GFAP', 'AQP4', 'PLP1', 'MBP', 'SNAP25', 'MOBP'], '巨噬': ['CD163', 'CD68', 'C1QA', 'C1QB', 'MS4A7'], 'PDGFB': ['PDGFB'], 'PDGFRB': ['PDGFRB'], 'JAG1': ['JAG1'], 'DLL4': ['DLL4'], 'NOTCH3': ['NOTCH3'], 'ABCB1': ['ABCB1'], 'ANGPT2': ['ANGPT2'], 'PLVAP': ['PLVAP'], 'CLDN5': ['CLDN5']}
GENES = sorted({g for v in SETS.values() for g in v})
PAIRS = [('EC', '周细胞'), ('周细胞', '肿瘤'), ('EC', '肿瘤'), ('BAM', '周细胞'), ('BAM', 'EC'), ('成纤维', '周细胞'), ('巨噬', '周细胞'), ('PDGFB', 'PDGFRB'), ('JAG1', 'NOTCH3'), ('DLL4', 'NOTCH3'), ('ABCB1', 'ANGPT2'), ('PLVAP', 'CLDN5'), ('脑', '周细胞')]

def read_slide(pre):
    with gzip.open(f'{E}/{pre}_counts.csv.gz', 'rt') as f:
        header = f.readline().rstrip('\n').split(',')
        beads = [h.strip('"').replace('.1', '-1') for h in header[1:]]
        tot = np.full(len(beads), np.inf)
        rows = {}
        for line in f:
            i = line.index(',')
            g = line[:i].strip('"')
            if g in GENES:
                rows[g] = np.fromstring(line[i + 1:], sep=',', dtype=np.float32)
    M = pd.DataFrame(rows, index=beads)
    co = pd.read_csv(f'{E}/{pre}_coords.csv.gz', index_col=0)
    co.index = [i.replace('.1', '-1') for i in co.index]
    co = co.reindex(beads)
    return (M, tot, co)
rows_pair = []
rows_dist = []
rows_comp = []
figs = []
SEEN = set()
for (_, m) in meta.iterrows():
    pre = f'{m.gsm}_{m.title}'
    (M, tot, co) = read_slide(pre)
    keep = (tot >= 50) & co.x.notna().values
    M = M[keep]
    co = co[keep]
    tot = tot[keep]
    xy = co[['x', 'y']].values.astype(float)
    n = len(xy)
    nn = NearestNeighbors(n_neighbors=2).fit(xy)
    (d, _) = nn.kneighbors(xy)
    NN = float(np.median(d[:, 1]))
    pos = {k: M[[g for g in v if g in M]].sum(axis=1).values >= 1 if any((g in M for g in v)) else np.zeros(n, bool) for (k, v) in SETS.items()}
    pos['肿瘤'] = (M[[g for g in SETS['肿瘤'] if g in M]] > 0).sum(axis=1).values >= 2
    sig = (n, int(pos['EC'].sum()), int(pos['周细胞'].sum()), round(float(xy[:, 0].sum()), 1))
    if sig in SEEN:
        log(m.pid, m.site, '与已处理切片字节级重复 (GEO 重复上传: KRAS_11 = PA056), 跳过')
        continue
    SEEN.add(sig)
    pd.DataFrame({k: pos[k] for k in ['EC', '周细胞', '肿瘤', 'BAM', '成纤维', '脑', '巨噬']}, index=co.index).assign(x=xy[:, 0], y=xy[:, 1]).to_csv(f'{O}/beads_{m.pid}.csv.gz', compression='gzip')
    tree = KDTree(xy)
    log(m.pid, m.site, n, 'beads, NN 中位', round(NN, 1), 'px ≈', round(NN * PX_UM, 1), 'µm; 阳性 bead:', {k: int(pos[k].sum()) for k in ['EC', '周细胞', '肿瘤', 'BAM', '成纤维', '脑']})
    GR = {mult: radius_neighbors_graph(xy, NN * mult, mode='connectivity', include_self=False).tocsr() for mult in [2, 5, 10]}
    for (a, b) in PAIRS:
        A = np.where(pos[a])[0]
        nb = int(pos[b].sum())
        if len(A) < 20 or nb < 20:
            rows_pair.append(dict(pid=m.pid, site=m.site, pair=f'{a}-{b}', n_A=len(A), n_B=nb, note='阳性 bead<20'))
            continue
        Bv = pos[b].astype(np.int32)
        perms = []
        for _ in range(100):
            pm = np.zeros(n, np.int32)
            pm[rng.choice(n, nb, replace=False)] = 1
            perms.append(pm)
        for mult in [2, 5, 10]:
            r = NN * mult
            GA = GR[mult][A]
            obs = float((GA @ Bv > 0).mean())
            null = np.array([float((GA @ pm > 0).mean()) for pm in perms])
            z = (obs - null.mean()) / (null.std() + 1e-09)
            rows_pair.append(dict(pid=m.pid, site=m.site, pair=f'{a}-{b}', radius_mult=mult, radius_um=round(r * PX_UM, 1), n_A=len(A), n_B=nb, obs_frac=round(obs, 4), null_frac=round(float(null.mean()), 4), obs_over_null=round(obs / max(null.mean(), 1e-06), 3), z=round(float(z), 2), p_perm=float(((null >= obs).sum() + 1) / (len(null) + 1))))
    T = np.where(pos['肿瘤'])[0]
    if len(T) >= 50:
        tt = KDTree(xy[T])
        for k in ['周细胞', 'EC', '成纤维', 'BAM', '巨噬', '脑']:
            idx = np.where(pos[k])[0]
            if len(idx) < 20:
                continue
            (dd, _) = tt.query(xy[idx], k=1)
            dd = dd[:, 0] * PX_UM
            rows_dist.append(dict(pid=m.pid, site=m.site, cls=k, n=len(idx), median_um=round(float(np.median(dd)), 1), frac_within_30um=round(float((dd <= 30).mean()), 4), frac_within_100um=round(float((dd <= 100).mean()), 4)))
    rows_comp.append(dict(pid=m.pid, site=m.site, n_beads=n, peri=int(pos['周细胞'].sum()), fib=int(pos['成纤维'].sum()), ec=int(pos['EC'].sum()), tumor=int(pos['肿瘤'].sum()), bam=int(pos['BAM'].sum()), peri_over_peri_fib=round(pos['周细胞'].sum() / max(pos['周细胞'].sum() + pos['成纤维'].sum(), 1), 4), peri_per_1k=round(1000 * pos['周细胞'].mean(), 2), ec_per_1k=round(1000 * pos['EC'].mean(), 2), abcb1_in_ec=round(float(pos['ABCB1'][pos['EC']].mean()) if pos['EC'].sum() else np.nan, 4), angpt2_in_ec=round(float(pos['ANGPT2'][pos['EC']].mean()) if pos['EC'].sum() else np.nan, 4), plvap_in_ec=round(float(pos['PLVAP'][pos['EC']].mean()) if pos['EC'].sum() else np.nan, 4)))
    (fig, ax) = plt.subplots(figsize=(6, 6))
    ax.scatter(xy[:, 0], xy[:, 1], s=1, c='#dddddd')
    for (k, c) in [('肿瘤', '#f4a582'), ('EC', '#2166ac'), ('周细胞', '#d6604d'), ('BAM', '#4dac26')]:
        ax.scatter(xy[pos[k], 0], xy[pos[k], 1], s=2, c=c, label=f'{k} {int(pos[k].sum())}')
    ax.set_title(f'{m.pid} ({m.site}) Slide-seq bead 级 marker 检出')
    ax.legend(markerscale=5, fontsize=8)
    ax.set_aspect('equal')
    ax.axis('off')
    plt.tight_layout()
    plt.savefig(f'{O}/beads_{m.pid}.png', dpi=110)
    plt.close()
pair = pd.DataFrame(rows_pair)
pair.to_csv(f'{O}/V1_slideseq_neighbor_enrichment.csv', index=False)
dist = pd.DataFrame(rows_dist)
dist.to_csv(f'{O}/V1_distance_to_tumor.csv', index=False)
comp = pd.DataFrame(rows_comp)
comp.to_csv(f'{O}/V1_composition.csv', index=False)
out = []
for col in ['peri_over_peri_fib', 'peri_per_1k', 'ec_per_1k', 'abcb1_in_ec', 'angpt2_in_ec', 'plvap_in_ec']:
    x = comp[comp.site == 'BM'][col].dropna()
    y = comp[comp.site == 'PT'][col].dropna()
    if len(x) >= 3 and len(y) >= 3:
        out.append(dict(metric=col, BM_median=round(x.median(), 4), PT_median=round(y.median(), 4), n_BM=len(x), n_PT=len(y), mwu_p=mannwhitneyu(x, y).pvalue))
for pr in pair.pair.unique():
    sub = pair[(pair.pair == pr) & (pair.radius_mult == 2)]
    x = sub[sub.site == 'BM'].obs_over_null.dropna()
    y = sub[sub.site == 'PT'].obs_over_null.dropna()
    if len(x) >= 3 and len(y) >= 3:
        out.append(dict(metric=f'邻接富集(2NN) {pr}', BM_median=round(x.median(), 3), PT_median=round(y.median(), 3), n_BM=len(x), n_PT=len(y), mwu_p=mannwhitneyu(x, y).pvalue))
pd.DataFrame(out).to_csv(f'{O}/V1_BM_vs_PT.csv', index=False)
log('全部完成')
