# Current scientific analysis; package-relative paths.
handoff_arg <- grep("^--file=", commandArgs(), value=TRUE)
handoff_file <- sub("^--file=", "", handoff_arg[1])
HANDOFF_ROOT <- Sys.getenv("SAFEPOSTER_HANDOFF_ROOT", unset=normalizePath(file.path(dirname(handoff_file), "../.."), mustWork=TRUE))
# L17 export all author-labeled tumor cells from Kim raw RDS, preserving total library sizes.
suppressMessages(library(Matrix));suppressMessages(library(jsonlite))
B=file.path(HANDOFF_ROOT, "");O=file.path(B,"results/nutrition")
x=readRDS(file.path(B,"data/external/scrna/GSE131907/GSE131907_raw_UMI_matrix.rds"))
cat("RAW",class(x),dim(x),"\n")
a=read.delim(gzfile(file.path(B,"data/external/scrna/GSE131907/GSE131907_Lung_Cancer_cell_annotation.txt.gz")),check.names=FALSE,stringsAsFactors=FALSE)
cat("ANN",colnames(a),"\n")
a=a[match(colnames(x),a$Index),]
keep=a$Cell_subtype %in% c("Malignant cells","tS1","tS2","tS3")
keep=keep & a$Sample_Origin %in% c("mBrain","tLung","tL/B","mLN","PE")
a=a[keep,];x=x[,keep,drop=FALSE]
cat("TUMOR",dim(x),"\n");print(table(a$Sample_Origin))
S=fromJSON(file.path(O,"gene_sets.json"))$sets;gs=sort(unique(unlist(S)))
rawgs=gs;rawgs[gs=="ATP5F1A" & !("ATP5F1A"%in%rownames(x))]="ATP5A1";rawgs[gs=="ATP5F1B" & !("ATP5F1B"%in%rownames(x))]="ATP5B"
ok=rawgs %in% rownames(x);cnt=x[rawgs[ok],,drop=FALSE];rownames(cnt)=gs[ok]
a$total_umi=as.numeric(Matrix::colSums(x));a$Index=colnames(x)
writeMM(Matrix(as.matrix(cnt),sparse=TRUE),file.path(O,"kim_full_tumor_selected_counts.mtx"))
writeLines(rownames(cnt),file.path(O,"kim_full_tumor_selected_genes.tsv"))
write.csv(a,file.path(O,"kim_full_tumor_annotation.csv"),row.names=FALSE)
cat("COMPLETE\n")
