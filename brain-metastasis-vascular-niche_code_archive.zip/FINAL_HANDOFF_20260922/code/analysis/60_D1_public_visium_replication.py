# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os, json, glob, gzip, numpy as np, pandas as pd, scanpy as sc, scipy.sparse as sp, time
from sklearn.neighbors import NearestNeighbors
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
font_manager.fontManager.addfont(str(_HANDOFF_ROOT / 'environment/NotoSansCJKsc-Regular.otf'))
plt.rcParams['font.family'] = ['Noto Sans CJK SC', 'DejaVu Sans']
E = str(_HANDOFF_ROOT / 'data/external/spatial')
X8 = str(_HANDOFF_ROOT / 'results/internal_spatial_validation')
X12 = str(_HANDOFF_ROOT / 'results/internal_programs_and_CNV')
O = str(_HANDOFF_ROOT / 'results/external_replication/D1')
os.makedirs(O, exist_ok=True)
L = open(f'{O}/progress.txt', 'a', buffering=1)
log = lambda *a: L.write(time.strftime('[%H:%M:%S] ') + ' '.join(map(str, a)) + '\n')
rng = np.random.default_rng(0)
SLIDES = {'GSE179572_pt15': dict(h5=f'{E}/GSE179572/raw/GSM5420749_filtered_feature_bc_matrix.h5', pos=f'{E}/GSE179572/raw/GSM5420749/spatial/tissue_positions_list.csv', cancer='肺腺癌'), 'GSE179572_pt19': dict(h5=f'{E}/GSE179572/raw/GSM5420751_filtered_feature_bc_matrix.h5', pos=f'{E}/GSE179572/raw/GSM5420751/spatial/tissue_positions_list.csv', cancer='肺腺癌'), 'GSE179572_pt27': dict(h5=f'{E}/GSE179572/raw/GSM5420754_filtered_feature_bc_matrix.h5', pos=f'{E}/GSE179572/raw/GSM5420754/spatial/tissue_positions_list.csv', cancer='肺腺癌'), 'GSE179572_pt16_melanoma': dict(h5=f'{E}/GSE179572/raw/GSM5420750_filtered_feature_bc_matrix.h5', pos=f'{E}/GSE179572/raw/GSM5420750/spatial/tissue_positions_list.csv', cancer='黑色素瘤'), 'GSE179572_pt24_RCC': dict(h5=f'{E}/GSE179572/raw/GSM5420752_filtered_feature_bc_matrix.h5', pos=f'{E}/GSE179572/raw/GSM5420752/spatial/tissue_positions_list.csv', cancer='肾透明细胞癌'), 'GSE179572_pt26_breast': dict(h5=f'{E}/GSE179572/raw/GSM5420753_filtered_feature_bc_matrix.h5', pos=f'{E}/GSE179572/raw/GSM5420753/spatial/tissue_positions_list.csv', cancer='乳腺癌'), 'GSE320505_LBM_RIH_2': dict(h5=f'{E}/GSE320505/raw/GSM9544606_LBM_RIH_2_HPT_filtered_feature_bc_matrix.h5', pos=f'{E}/GSE320505/raw/GSM9544606_LBM_RIH_2_HPT_tissue_positions.csv.gz', cancer='肺腺癌'), 'GSE320505_LBM_RIH_3': dict(h5=f'{E}/GSE320505/raw/GSM9544607_LBM_RIH_3_HPT_filtered_feature_bc_matrix.h5', pos=f'{E}/GSE320505/raw/GSM9544607_LBM_RIH_3_HPT_tissue_positions.csv.gz', cancer='肺腺癌'), 'GSE320505_LBM_USC_2_1_LCNEC': dict(h5=f'{E}/GSE320505/raw/GSM9544608_LBM_USC_2_1_HPT_filtered_feature_bc_matrix.h5', pos=f'{E}/GSE320505/raw/GSM9544608_LBM_USC_2_1_HPT_tissue_positions.csv.gz', cancer='肺大细胞神经内分泌癌'), 'GSE320505_BBM_USC_5_1_breast': dict(h5=f'{E}/GSE320505/raw/GSM9544605_BBM_USC_5_1_HPT_filtered_feature_bc_matrix.h5', pos=f'{E}/GSE320505/raw/GSM9544605_BBM_USC_5_1_HPT_tissue_positions.csv.gz', cancer='乳腺癌')}
TUMOR = {'肺腺癌': ['EPCAM', 'KRT8', 'KRT18', 'KRT7', 'SFTPB', 'NAPSA', 'NKX2-1', 'MUC1'], '黑色素瘤': ['MLANA', 'PMEL', 'MITF', 'TYR', 'DCT', 'S100B', 'SOX10', 'PRAME'], '肾透明细胞癌': ['CA9', 'PAX8', 'KRT18', 'EPCAM', 'NDUFA4L2', 'CRYAB', 'VEGFA', 'KRT8'], '乳腺癌': ['EPCAM', 'KRT8', 'KRT18', 'KRT19', 'ESR1', 'ERBB2', 'GATA3', 'KRT7'], '肺大细胞神经内分泌癌': ['EPCAM', 'KRT8', 'KRT18', 'INSM1', 'CHGA', 'SYP', 'ASCL1', 'NEUROD1']}
BRAIN = ['GFAP', 'AQP4', 'PLP1', 'MBP', 'MOBP', 'MOG', 'SNAP25', 'SYT1', 'GJA1', 'SLC1A2']
SIG = json.load(open(f'{X8}/signatures_used.json'))['signatures']
KEYSIG = ['肺腺癌上皮', '星形胶质(sc缺失)', '反应性星形胶质', '少突胶质成熟', '神经元(sc缺失)', 'T细胞', '中性粒', 'TLS(三级淋巴结构)', '淋巴瘤B', '边界相关巨噬 BAM(LYVE1/CD209/COLEC12/F13A1+)', '脂质相关肿瘤相关巨噬(SPP1+/GPNMB+/TREM2+/PLIN2+)', '干扰素反应巨噬(GBP4/5+/CXCL9/10+/IFI44L+)', '稳态小胶质(P2RY12+/CX3CR1+/SALL1+)', '活化小胶质(IL1B+/CCL3+/CCL4+/ATF3+)', '血管周细胞/平滑肌(CSPG4+/NOTCH3+/RGS5+/KCNJ8+)', '内皮细胞(CDH5+/KDR+/CD34+/ABCB1+ 血脑屏障型)', '成纤维细胞(DCN+/LUM+/COL1A2+/PDGFRB+)', '活化调节性 T 细胞(FOXP3+/TNFRSF9+/LAYN+/IL2RA+)', 'CXCL13+ 耗竭样 CD8 T(TNFRSF9+/ENTPD1+/MIR155HG+)', '黏液/分泌型肺腺癌细胞(MUC5B+/TFF3+/AGR2+/CEACAM5+)', '经典单核细胞(FCN1+/S100A12+/SELL+/TREM1+)', '肥大细胞', '浆细胞样树突状细胞 pDC', '成熟调节型树突状细胞 mregDC', 'γδ 型/细胞毒 T 细胞(CD3+/TRGC2+/CD8A+ 活化)']
GENES = ['EPCAM', 'SFTPB', 'NAPSA', 'NKX2-1', 'AGR2', 'MUC5B', 'TFF3', 'LCN2', 'CEACAM5', 'CEACAM6', 'MS4A1', 'CD79A', 'CD3E', 'CD8A', 'CXCL13', 'FOXP3', 'TNFRSF9', 'TNFRSF4', 'LAMP3', 'CCR7', 'CCL19', 'TPSAB1', 'CPA3', 'KIT', 'LILRA4', 'CD163', 'MRC1', 'F13A1', 'COLEC12', 'SIGLEC1', 'LYVE1', 'CD209', 'SPP1', 'GPNMB', 'TREM2', 'APOE', 'CXCL9', 'CXCL10', 'GBP5', 'P2RY12', 'TMEM119', 'CX3CR1', 'IL1B', 'CCL3', 'S100A8', 'S100A9', 'CSF3R', 'FCGR3B', 'NOTCH3', 'RGS5', 'HIGD1B', 'NDUFA4L2', 'PDGFRB', 'PDGFB', 'ACTA2', 'CLDN5', 'VWF', 'DCN', 'COL1A1', 'POSTN', 'GFAP', 'AQP4', 'SERPINA3', 'CD44', 'CHI3L1', 'PLP1', 'MBP', 'BCAS1', 'OLIG2', 'SNAP25', 'JCHAIN', 'MZB1', 'NDRG1', 'VEGFA', 'LOX', 'MLANA', 'PMEL', 'CA9', 'ESR1', 'ERBB2', 'INSM1', 'CHGA']
PAIRS = [('RGS5', 'HIGD1B', 'NDUFA4L2'), ('NOTCH3', 'HIGD1B', 'CLDN5'), ('PDGFB', 'PDGFRB'), ('F13A1', 'NOTCH3'), ('COLEC12', 'F13A1', 'SIGLEC1'), ('LYVE1', 'CD209', 'F13A1'), ('APOE', 'TREM2'), ('SPP1', 'GPNMB', 'TREM2'), ('TPSAB1', 'CPA3'), ('CXCL13', 'CD3E'), ('CXCL13', 'CCL19', 'MS4A1'), ('MUC5B', 'TFF3', 'AGR2'), ('GFAP', 'SERPINA3', 'CD44'), ('P2RY12', 'TMEM119'), ('CXCL9', 'CXCR3'), ('GAS6', 'AXL'), ('LGALS9', 'HAVCR2'), ('CCL19', 'PDGFRB'), ('CCL19', 'LAMP3')]
cent = pd.read_csv(f'{X12}/M4_CN_centroids_z.csv', index_col=0)
cent.index = [f'CN{i}' for i in cent.index]
CNNAME = {'CN0': '肿瘤核心', 'CN1': '血管-间质-免疫龛', 'CN2': '淋巴瘤B核心', 'CN3': '界面胶质带', 'CN4': '脑实质/白质', 'CN5': '血管龛', 'CN6': '轻度反应性星形胶质', 'CN7': '中性粒样'}
featmap = {f: f.split('(')[0].strip() for f in SIG}

def read_positions(p):
    if p.endswith('.gz'):
        d = pd.read_csv(p)
        d.columns = ['barcode', 'in_tissue', 'row', 'col', 'py', 'px']
    else:
        d = pd.read_csv(p, header=None)
        if isinstance(d.iloc[0, 0], str) and d.iloc[0, 0] == 'barcode':
            d = pd.read_csv(p)
        d.columns = ['barcode', 'in_tissue', 'row', 'col', 'py', 'px']
    return d.set_index('barcode')

def score_sig(v, genes, n_null=40):
    g = [x for x in genes if x in v.var_names]
    if len(g) < 2:
        return (None, None, len(g))
    sc.tl.score_genes(v, g, score_name='_s', ctrl_size=50, n_bins=25, random_state=0)
    s = v.obs['_s'].values.copy()
    mean = np.asarray(v.X.mean(axis=0)).ravel()
    bins = pd.qcut(pd.Series(mean).rank(method='first'), 25, labels=False).values
    gb = [bins[v.var_names.get_loc(x)] for x in g]
    pool = {b: np.where(bins == b)[0] for b in set(gb)}
    null = []
    for k in range(n_null):
        rg = [v.var_names[rng.choice(pool[b])] for b in gb]
        sc.tl.score_genes(v, rg, score_name='_n', ctrl_size=50, n_bins=25, random_state=k)
        null.append(v.obs['_n'].values.copy())
    return (s, float(np.quantile(np.vstack(null), 0.99)), len(g))
rows_sig = []
rows_gene = []
rows_pair = []
rows_cn = []
rows_arch = []
for (sl, cfg) in SLIDES.items():
    v = sc.read_10x_h5(cfg['h5'])
    v.var_names_make_unique()
    pos = read_positions(cfg['pos']).reindex(v.obs_names)
    v = v[pos.in_tissue.fillna(0).astype(int) == 1].copy()
    pos = pos.reindex(v.obs_names)
    xy = pos[['px', 'py']].values.astype(float)
    sc.pp.filter_genes(v, min_cells=3)
    v.layers['counts'] = v.X.copy()
    tot = np.asarray(v.X.sum(axis=1)).ravel()
    sc.pp.normalize_total(v, target_sum=10000.0)
    sc.pp.log1p(v)
    tp = [g for g in TUMOR[cfg['cancer']] if g in v.var_names]
    bp = [g for g in BRAIN if g in v.var_names]
    t = np.asarray(v[:, tp].X.mean(axis=1)).ravel()
    b = np.asarray(v[:, bp].X.mean(axis=1)).ravel()
    lab = np.array(['other'] * v.n_obs, dtype=object)
    lab[(t >= 0.5) & (b < 0.5)] = 'tumor'
    lab[(b >= 0.5) & (t < 0.5)] = 'brain'
    lab[(t >= 0.5) & (b >= 0.5)] = 'interface'
    nn = NearestNeighbors(n_neighbors=7).fit(xy)
    (dist, idx) = nn.kneighbors(xy)
    dmin = np.median(dist[:, 1])
    neigh = [[j for (j, dd) in zip(idx[i, 1:], dist[i, 1:]) if dd < dmin * 1.3] for i in range(v.n_obs)]
    lab2 = lab.copy()
    for i in range(v.n_obs):
        if lab[i] == 'tumor' and any((lab[j] == 'brain' for j in neigh[i])):
            lab2[i] = 'interface'
        elif lab[i] == 'brain' and any((lab[j] == 'tumor' for j in neigh[i])):
            lab2[i] = 'interface'
    v.obs['band'] = lab2
    bandcnt = pd.Series(lab2).value_counts().to_dict()
    log(sl, v.n_obs, 'spots', bandcnt)
    ss = pd.DataFrame(index=v.obs_names)
    for name in KEYSIG:
        (s, thr, ng) = score_sig(v, SIG[name])
        if s is None:
            continue
        ss[featmap[name]] = s
        pos_ = s > thr
        r = dict(slide=sl, cancer=cfg['cancer'], signature=name, n_genes=ng, n_spots=v.n_obs, pos_frac_all=round(pos_.mean(), 4), mean_all=round(float(s.mean()), 4))
        for bd in ['tumor', 'interface', 'brain']:
            m = lab2 == bd
            r[f'n_{bd}'] = int(m.sum())
            r[f'pos_frac_{bd}'] = round(pos_[m].mean(), 4) if m.sum() else np.nan
            r[f'mean_{bd}'] = round(float(s[m].mean()), 4) if m.sum() else np.nan
        rows_sig.append(r)
    C = v.layers['counts'].tocsc()
    gi = {g: i for (i, g) in enumerate(v.var_names)}
    for g in GENES:
        if g not in gi:
            continue
        c = C[:, gi[g]].toarray().ravel()
        d = dict(slide=sl, cancer=cfg['cancer'], gene=g, det_all=round((c > 0).mean(), 3))
        for bd in ['tumor', 'interface', 'brain']:
            m = lab2 == bd
            d[f'det_{bd}'] = round((c[m] > 0).mean(), 3) if m.sum() >= 20 else np.nan
        rows_gene.append(d)
    A = sp.lil_matrix((v.n_obs, v.n_obs))
    for i in range(v.n_obs):
        for j in neigh[i]:
            A[i, j] = 1
    A = A.tocsr() + sp.eye(v.n_obs, format='csr')

    def high(g):
        c = C[:, gi[g]].toarray().ravel() / np.maximum(tot, 1) * 10000.0
        p = c[c > 0]
        if len(p) < 20:
            return (None, float((c > 0).mean()))
        return ((c >= np.quantile(p, 0.75)).astype(float), float((c > 0).mean()))
    for pr in PAIRS:
        if any((g not in gi for g in pr)):
            continue
        hs = [high(g) for g in pr]
        if any((h[0] is None for h in hs)):
            rows_pair.append(dict(slide=sl, cancer=cfg['cancer'], pair='-'.join(pr), note='阳性spot<20', dets=';'.join((f'{h[1]:.3f}' for h in hs))))
            continue
        Lh = hs[0][0]
        Rs = [h[0] for h in hs[1:]]
        obs = float((Lh * np.prod([A @ R > 0 for R in Rs], axis=0)).sum())
        null = np.array([float((Lh * np.prod([A @ rng.permutation(R) > 0 for R in Rs], axis=0)).sum()) for _ in range(200)])
        z = (obs - null.mean()) / (null.std() + 1e-09)
        p = (np.sum(null >= obs) + 1) / 201
        rows_pair.append(dict(slide=sl, cancer=cfg['cancer'], pair='-'.join(pr), dets=';'.join((f'{h[1]:.3f}' for h in hs)), obs=obs, null_mean=round(null.mean(), 1), obs_over_null=round(obs / max(null.mean(), 1), 2), z=round(z, 2), p=round(p, 4)))
    F = ss.reindex(columns=[c for c in cent.columns if not c.startswith('邻居:')]).fillna(0)
    Nb = np.vstack([F.values[neigh[i]].mean(axis=0) if neigh[i] else F.values[i] for i in range(v.n_obs)])
    Z = pd.DataFrame(np.hstack([F.values, Nb]), index=v.obs_names, columns=list(F.columns) + ['邻居:' + c for c in F.columns])
    Z = (Z - Z.mean()) / (Z.std() + 1e-09)
    Zc = Z.reindex(columns=cent.columns).fillna(0)
    dmat = ((Zc.values[:, None, :] - cent.values[None, :, :]) ** 2).sum(-1)
    cn = cent.index[dmat.argmin(1)]
    v.obs['CN'] = cn
    comp = pd.Series(cn).value_counts(normalize=True) * 100
    r = dict(slide=sl, cancer=cfg['cancer'])
    r.update({CNNAME[k]: round(float(comp.get(k, 0)), 1) for k in cent.index})
    m = lab2 == 'tumor'
    compt = pd.Series(cn[m]).value_counts(normalize=True) * 100 if m.sum() else pd.Series(dtype=float)
    r.update({'肿瘤带_' + CNNAME[k]: round(float(compt.get(k, 0)), 1) for k in cent.index})
    rows_cn.append(r)
    mm = (lab2 == 'tumor') | (lab2 == 'interface')
    det = lambda g: float((C[:, gi[g]].toarray().ravel()[mm] > 0).mean()) if g in gi and mm.sum() else np.nan
    d = dict(slide=sl, cancer=cfg['cancer'], CD3E=det('CD3E'), CXCL13=det('CXCL13'), FOXP3=det('FOXP3'), CSF3R=det('CSF3R'), S100A8=det('S100A8'), FCGR3B=det('FCGR3B'), CD163=det('CD163'), F13A1=det('F13A1'), NOTCH3=det('NOTCH3'), TPSAB1=det('TPSAB1'), MS4A1=det('MS4A1'), CXCL9=det('CXCL9'))
    T_rich = d['CD3E'] >= 0.1 and d['CXCL13'] >= 0.08
    neut = d['CSF3R'] >= 0.15 and d['S100A8'] >= 0.4
    d['archetype'] = 'T富集型(CXCL13+)' if T_rich else '中性粒主导型' if neut else '髓系型(CD163+)' if d['CD163'] >= 0.3 else '免疫荒漠型'
    rows_arch.append(d)
    ss['band'] = lab2
    ss['CN'] = cn
    ss['px'] = xy[:, 0]
    ss['py'] = xy[:, 1]
    ss.to_csv(f'{O}/spot_table_{sl}.csv.gz', compression='gzip')
    keys = ['band', 'CN', '肺腺癌上皮', '反应性星形胶质', '血管周细胞/平滑肌', '边界相关巨噬 BAM', '干扰素反应巨噬', 'CXCL13+ 耗竭样 CD8 T', '黏液/分泌型肺腺癌细胞', '肥大细胞', '中性粒', '活化小胶质']
    (fig, axes) = plt.subplots(2, 6, figsize=(26, 8))
    for (ax, k) in zip(axes.ravel(), keys):
        if k == 'band':
            col = {'tumor': '#d62728', 'interface': '#ff7f0e', 'brain': '#1f77b4', 'other': '#cccccc'}
            ax.scatter(xy[:, 0], -xy[:, 1], s=5, c=[col[x] for x in lab2], linewidths=0)
            ax.set_title(f"三带 T{bandcnt.get('tumor', 0)}/I{bandcnt.get('interface', 0)}/B{bandcnt.get('brain', 0)}", fontsize=9)
        elif k == 'CN':
            cm = plt.get_cmap('tab10')
            ax.scatter(xy[:, 0], -xy[:, 1], s=5, c=[cm(int(x[2:])) for x in cn], linewidths=0)
            ax.set_title('CN 投射（我们的 8 个邻域）', fontsize=9)
        elif k in ss.columns:
            s = ss[k].values
            ax.scatter(xy[:, 0], -xy[:, 1], s=5, c=s, cmap='magma', vmin=np.quantile(s, 0.02), vmax=max(np.quantile(s, 0.98), 1e-06), linewidths=0)
            ax.set_title(k[:22], fontsize=9)
        ax.set_xticks([])
        ax.set_yticks([])
        ax.set_aspect('equal')
    fig.suptitle(f"{sl} {cfg['cancer']}", fontsize=12)
    fig.savefig(f'{O}/spatial_{sl}.png', dpi=100, bbox_inches='tight')
    plt.close(fig)
    log(sl, '完成')
pd.DataFrame(rows_sig).to_csv(f'{O}/D1_signature_by_slide.csv', index=False)
pd.DataFrame(rows_gene).to_csv(f'{O}/D1_key_gene_detection.csv', index=False)
pd.DataFrame(rows_pair).to_csv(f'{O}/D1_marker_cooccurrence.csv', index=False)
pd.DataFrame(rows_cn).to_csv(f'{O}/D1_CN_composition.csv', index=False)
pd.DataFrame(rows_arch).to_csv(f'{O}/D1_archetype_call.csv', index=False)
log('全部完成')
