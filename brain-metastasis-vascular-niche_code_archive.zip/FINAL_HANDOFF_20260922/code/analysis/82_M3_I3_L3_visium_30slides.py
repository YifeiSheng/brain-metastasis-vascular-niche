# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os, json, glob, gzip, re, numpy as np, pandas as pd, scanpy as sc, scipy.sparse as sp, scipy.io, time
from sklearn.neighbors import NearestNeighbors
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
font_manager.fontManager.addfont(str(_HANDOFF_ROOT / 'environment/NotoSansCJKsc-Regular.otf'))
plt.rcParams['font.family'] = ['Noto Sans CJK SC', 'DejaVu Sans']
B = str(_HANDOFF_ROOT / '')
E = f'{B}/data/external/spatial'
ES = f'{B}/data/external/scrna'
X8 = f'{B}/results/internal_spatial_validation'
O = f'{B}/results/immune_glial_lymphoma/M3_I3_L3_VISIUM'
os.makedirs(O, exist_ok=True)
L = open(f'{O}/progress.txt', 'a', buffering=1)
log = lambda *a: L.write(time.strftime('[%H:%M:%S] ') + ' '.join(map(str, a)) + '\n')
rng = np.random.default_rng(0)
SLIDES = {'GSE179572_pt15': dict(h5=f'{E}/GSE179572/raw/GSM5420749_filtered_feature_bc_matrix.h5', pos=f'{E}/GSE179572/raw/GSM5420749/spatial/tissue_positions_list.csv', cancer='肺腺癌', dataset='GSE179572'), 'GSE179572_pt19': dict(h5=f'{E}/GSE179572/raw/GSM5420751_filtered_feature_bc_matrix.h5', pos=f'{E}/GSE179572/raw/GSM5420751/spatial/tissue_positions_list.csv', cancer='肺腺癌', dataset='GSE179572'), 'GSE179572_pt27': dict(h5=f'{E}/GSE179572/raw/GSM5420754_filtered_feature_bc_matrix.h5', pos=f'{E}/GSE179572/raw/GSM5420754/spatial/tissue_positions_list.csv', cancer='肺腺癌', dataset='GSE179572'), 'GSE179572_pt16_melanoma': dict(h5=f'{E}/GSE179572/raw/GSM5420750_filtered_feature_bc_matrix.h5', pos=f'{E}/GSE179572/raw/GSM5420750/spatial/tissue_positions_list.csv', cancer='黑色素瘤', dataset='GSE179572'), 'GSE179572_pt24_RCC': dict(h5=f'{E}/GSE179572/raw/GSM5420752_filtered_feature_bc_matrix.h5', pos=f'{E}/GSE179572/raw/GSM5420752/spatial/tissue_positions_list.csv', cancer='肾透明细胞癌', dataset='GSE179572'), 'GSE179572_pt26_breast': dict(h5=f'{E}/GSE179572/raw/GSM5420753_filtered_feature_bc_matrix.h5', pos=f'{E}/GSE179572/raw/GSM5420753/spatial/tissue_positions_list.csv', cancer='乳腺癌', dataset='GSE179572'), 'GSE320505_LBM_RIH_2': dict(h5=f'{E}/GSE320505/raw/GSM9544606_LBM_RIH_2_HPT_filtered_feature_bc_matrix.h5', pos=f'{E}/GSE320505/raw/GSM9544606_LBM_RIH_2_HPT_tissue_positions.csv.gz', cancer='肺腺癌', dataset='GSE320505'), 'GSE320505_LBM_RIH_3': dict(h5=f'{E}/GSE320505/raw/GSM9544607_LBM_RIH_3_HPT_filtered_feature_bc_matrix.h5', pos=f'{E}/GSE320505/raw/GSM9544607_LBM_RIH_3_HPT_tissue_positions.csv.gz', cancer='肺腺癌', dataset='GSE320505'), 'GSE320505_LBM_USC_2_1_LCNEC': dict(h5=f'{E}/GSE320505/raw/GSM9544608_LBM_USC_2_1_HPT_filtered_feature_bc_matrix.h5', pos=f'{E}/GSE320505/raw/GSM9544608_LBM_USC_2_1_HPT_tissue_positions.csv.gz', cancer='肺大细胞神经内分泌癌', dataset='GSE320505'), 'GSE320505_BBM_USC_5_1_breast': dict(h5=f'{E}/GSE320505/raw/GSM9544605_BBM_USC_5_1_HPT_filtered_feature_bc_matrix.h5', pos=f'{E}/GSE320505/raw/GSM9544605_BBM_USC_5_1_HPT_tissue_positions.csv.gz', cancer='乳腺癌', dataset='GSE320505'), 'GSE203552_PCNSL_p1': dict(h5=f'{ES}/GSE203552/raw/GSM6176208_filtered_feature_bc_matrix_p1_visium.h5', pos=f'{ES}/GSE203552/raw/GSM6176208_tissue_positions_list_p1_visium.csv.gz', cancer='原发中枢神经系统淋巴瘤', dataset='GSE203552'), 'GSE203552_PCNSL_p2': dict(h5=f'{ES}/GSE203552/raw/GSM6176213_filtered_feature_bc_matrix_p2_visium.h5', pos=f'{ES}/GSE203552/raw/GSM6176213_tissue_positions_list_p2_visium.csv.gz', cancer='原发中枢神经系统淋巴瘤', dataset='GSE203552'), 'GSE203552_PCNSL_p3': dict(h5=f'{ES}/GSE203552/raw/GSM6176214_filtered_feature_bc_matrix_p3_visium.h5', pos=f'{ES}/GSE203552/raw/GSM6176214_tissue_positions_list_p3_visium.csv.gz', cancer='原发中枢神经系统淋巴瘤', dataset='GSE203552'), 'GSE203552_PCNSL_p7': dict(h5=f'{ES}/GSE203552/raw/GSM6176215_filtered_feature_bc_matrix_p7_visium.h5', pos=f'{ES}/GSE203552/raw/GSM6176215_tissue_positions_list_p7_visium.csv.gz', cancer='原发中枢神经系统淋巴瘤', dataset='GSE203552'), 'GSE230207_PCNSL_hot': dict(h5=f'{E}/GSE230207/raw/GSM7192449_hot.h5', pos=f'{E}/GSE230207/raw/GSM7192449_tissue_positions_list.csv.gz', cancer='原发中枢神经系统淋巴瘤', dataset='GSE230207'), 'GSE230207_PCNSL_cold': dict(h5=f'{E}/GSE230207/raw/GSM7192450_cold.h5', pos=f'{E}/GSE230207/raw/GSM7192450_tissue_positions_list.csv.gz', cancer='原发中枢神经系统淋巴瘤', dataset='GSE230207'), 'GSE230207_PCNSL_IME': dict(h5=f'{E}/GSE230207/raw/GSM7192451_IME.h5', pos=f'{E}/GSE230207/raw/GSM7192451_tissue_positions_list.csv.gz', cancer='原发中枢神经系统淋巴瘤', dataset='GSE230207'), 'GSE230207_PCNSL_IMS': dict(h5=f'{E}/GSE230207/raw/GSM7192453_IMS.h5', pos=f'{E}/GSE230207/raw/GSM7192453_tissue_positions_list.csv.gz', cancer='原发中枢神经系统淋巴瘤', dataset='GSE230207')}
meta = pd.read_csv(f'{ES}/GSE325196/sample_meta.tsv', sep='\t', header=None, names=['gsm', 'title', 'ch'])
meta = meta[meta.title.str.startswith('Visium')]
CMAP = {'NSCLC': '非小细胞肺癌', 'SCLC': '小细胞肺癌', 'Melanoma': '黑色素瘤', 'Sarcoma': '肉瘤'}
for (_, m) in meta.iterrows():
    pre = glob.glob(f'{ES}/GSE325196/raw/{m.gsm}_V_*_matrix.mtx.gz')
    if not pre:
        continue
    c = re.search('cell type: ([^;]+)', m.ch).group(1).strip()
    cancer = '乳腺癌' if 'BC' in c else CMAP.get(c, c)
    spec = re.search('(\\d{2}-\\d{4})', m.title).group(1)
    kind = 'FFPE' if 'FFPE' in m.title else 'frozen'
    SLIDES[f'GSE325196_{spec}_{kind}'] = dict(pre=pre[0].replace('_matrix.mtx.gz', ''), pos=pre[0].replace('_matrix.mtx.gz', '_tissue_positions_list.csv.gz'), cancer=cancer, dataset='GSE325196')
import sys
if len(sys.argv) > 1 and sys.argv[1] == 'yang':
    O = f'{B}/results/immune_glial_lymphoma/M3_I3_L3_VISIUM_YANG'
    os.makedirs(O, exist_ok=True)
    L = open(f'{O}/progress.txt', 'a', buffering=1)
    log = lambda *a: L.write(time.strftime('[%H:%M:%S] ') + ' '.join(map(str, a)) + '\n')
    SLIDES = {}
    for d in sorted(glob.glob(f'{B}/data/external/bulk/Yang2026_BrM_zenodo/spatial_export/*/')):
        nm = os.path.basename(d.rstrip('/'))
        SLIDES[f'Yang2026_{nm}'] = dict(pre=d + 'x', pos=d + 'tissue_positions_list.csv', cancer='泛癌原发' if 'Primary' in nm else '泛癌脑转移', dataset='Yang2026_ST', plain=True)
TUMOR = {'泛癌脑转移': ['EPCAM', 'KRT8', 'KRT18', 'KRT19', 'KRT7', 'MLANA', 'PMEL', 'MITF'], '泛癌原发': ['EPCAM', 'KRT8', 'KRT18', 'KRT19', 'KRT7', 'MLANA', 'PMEL', 'MITF'], '肺腺癌': ['EPCAM', 'KRT8', 'KRT18', 'KRT7', 'SFTPB', 'NAPSA', 'NKX2-1', 'MUC1'], '非小细胞肺癌': ['EPCAM', 'KRT8', 'KRT18', 'KRT7', 'SFTPB', 'NAPSA', 'NKX2-1', 'MUC1'], '黑色素瘤': ['MLANA', 'PMEL', 'MITF', 'TYR', 'DCT', 'S100B', 'SOX10', 'PRAME'], '肾透明细胞癌': ['CA9', 'PAX8', 'KRT18', 'EPCAM', 'NDUFA4L2', 'CRYAB', 'VEGFA', 'KRT8'], '乳腺癌': ['EPCAM', 'KRT8', 'KRT18', 'KRT19', 'ESR1', 'ERBB2', 'GATA3', 'KRT7'], '肺大细胞神经内分泌癌': ['EPCAM', 'KRT8', 'KRT18', 'INSM1', 'CHGA', 'SYP', 'ASCL1', 'NEUROD1'], '原发中枢神经系统淋巴瘤': ['MS4A1', 'CD79A', 'CD79B', 'CD19', 'PAX5', 'BANK1', 'IRF4', 'MEF2B'], '肉瘤': ['VIM', 'MKI67', 'TOP2A', 'COL1A1', 'CD99']}
BRAIN = ['GFAP', 'AQP4', 'PLP1', 'MBP', 'MOBP', 'MOG', 'SNAP25', 'SYT1', 'GJA1', 'SLC1A2']
SIG = json.load(open(f'{X8}/signatures_used.json'))['signatures']
KEYSIG = ['反应性星形胶质', '活化小胶质(IL1B+/CCL3+/CCL4+/ATF3+)', '星形胶质(sc缺失)', 'T细胞', '中性粒', 'TLS(三级淋巴结构)', '少突胶质成熟']
GENES = ['GFAP', 'AQP4', 'SERPINA3', 'CD44', 'CHI3L1', 'C3', 'VIM', 'P2RY12', 'TMEM119', 'CX3CR1', 'GPR34', 'IL1B', 'CCL3', 'CCL4', 'CD74', 'PLP1', 'MBP', 'BCAS1', 'SNAP25', 'CD3E', 'CD8A', 'CD4', 'GZMB', 'PDCD1', 'CXCL13', 'TNFRSF9', 'FOXP3', 'IL2RA', 'MS4A1', 'CR2', 'CXCR5', 'CCL19', 'CCL21', 'LAMP3', 'CCR7', 'JCHAIN', 'CXCL9', 'CXCL10', 'GBP5', 'CD163', 'CD68', 'F13A1', 'LYVE1', 'CD209', 'SPP1', 'GPNMB', 'TREM2', 'APOE', 'CSF3R', 'S100A8', 'S100A9', 'FCGR3B', 'TPSAB1', 'CPA3', 'PECAM1', 'VWF', 'CLDN5', 'CDH5', 'ABCB1', 'MFSD2A', 'ANGPT2', 'PLVAP', 'ESM1', 'NOTCH3', 'RGS5', 'PDGFRB', 'HIGD1B', 'NDUFA4L2', 'KCNJ8', 'ABCC9', 'SLC6A1', 'SLC20A2', 'ACTA2', 'MYH11', 'DCN', 'COL1A1', 'LUM', 'EPCAM', 'KRT8']
PAIRS = [('GFAP', 'SERPINA3', 'CD44'), ('IL1B', 'CCL3', 'CCL4'), ('GFAP', 'P2RY12'), ('SERPINA3', 'P2RY12'), ('CD44', 'CHI3L1', 'GFAP'), ('GFAP', 'CD74'), ('CXCL13', 'CD3E'), ('CXCL13', 'CCL19', 'MS4A1'), ('MS4A1', 'CR2'), ('CXCL13', 'FOXP3'), ('TNFRSF9', 'CXCL13'), ('CXCL9', 'CXCR3'), ('CXCL9', 'CXCL10', 'GBP5'), ('PECAM1', 'NOTCH3'), ('CLDN5', 'NOTCH3'), ('VWF', 'RGS5'), ('PECAM1', 'PDGFRB'), ('CLDN5', 'SLC6A1'), ('PECAM1', 'ABCC9'), ('PECAM1', 'ACTA2'), ('LYVE1', 'CD209', 'F13A1'), ('SPP1', 'GPNMB', 'TREM2'), ('APOE', 'TREM2')]

def opn(p):
    return gzip.open(p, 'rt') if open(p, 'rb').read(2) == b'\x1f\x8b' else open(p, 'rt')

def read_trio(pre):
    if pre.endswith('/x'):
        d = pre[:-1]
        M = scipy.io.mmread(d + 'matrix.mtx').tocsr().T.astype(np.float32)
        bc = [l.strip() for l in open(d + 'barcodes.tsv') if l.strip()]
        ft = [l.strip().split('\t') for l in open(d + 'features.tsv') if l.strip()]
        genes = [f[1] if len(f) > 1 else f[0] for f in ft]
        a = sc.AnnData(M, obs=pd.DataFrame(index=bc), var=pd.DataFrame(index=genes))
        a.var_names_make_unique()
        return a
    M = scipy.io.mmread(pre + '_matrix.mtx.gz').tocsr().T.astype(np.float32)
    bc = [l.strip() for l in opn(pre + '_barcodes.tsv.gz') if l.strip()]
    ft = [l.strip().split('\t') for l in opn(pre + '_features.tsv.gz') if l.strip()]
    genes = [f[1] if len(f) > 1 else f[0] for f in ft]
    a = sc.AnnData(M, obs=pd.DataFrame(index=bc), var=pd.DataFrame(index=genes))
    a.var_names_make_unique()
    return a

def read_positions(p):
    d = pd.read_csv(p, header=None)
    if str(d.iloc[0, 0]).strip() == 'barcode':
        d = pd.read_csv(p)
    d.columns = ['barcode', 'in_tissue', 'row', 'col', 'py', 'px']
    return d.set_index('barcode')

def score_sig(v, genes, n_null=40):
    g = [x for x in genes if x in v.var_names]
    if len(g) < 2:
        return (None, None, len(g))
    sc.tl.score_genes(v, g, score_name='_s', ctrl_size=50, n_bins=25, random_state=0)
    s = v.obs['_s'].values.copy()
    mean = np.asarray(v.X.mean(axis=0)).ravel()
    bins = pd.qcut(pd.Series(mean).rank(method='first'), 25, labels=False).values
    gb = [bins[v.var_names.get_loc(x)] for x in g]
    pool = {b: np.where(bins == b)[0] for b in set(gb)}
    null = []
    for k in range(n_null):
        rg = [v.var_names[rng.choice(pool[b])] for b in gb]
        sc.tl.score_genes(v, rg, score_name='_n', ctrl_size=50, n_bins=25, random_state=k)
        null.append(v.obs['_n'].values.copy())
    return (s, float(np.quantile(np.vstack(null), 0.99)), len(g))
rows_band = []
rows_gene = []
rows_pair = []
rows_arch = []
rows_ves = []
for (sl, cfg) in SLIDES.items():
    try:
        v = sc.read_10x_h5(cfg['h5']) if 'h5' in cfg else read_trio(cfg['pre'])
        v.var_names_make_unique()
        pos = read_positions(cfg['pos']).reindex(v.obs_names)
    except Exception as e:
        log('读取失败', sl, str(e)[:120])
        continue
    v = v[pos.in_tissue.fillna(0).astype(int) == 1].copy()
    pos = pos.reindex(v.obs_names)
    xy = pos[['px', 'py']].values.astype(float)
    if v.n_obs < 100:
        log('spot 太少', sl, v.n_obs)
        continue
    sc.pp.filter_genes(v, min_cells=3)
    v.layers['counts'] = v.X.copy()
    tot = np.asarray(v.X.sum(axis=1)).ravel()
    sc.pp.normalize_total(v, target_sum=10000.0)
    sc.pp.log1p(v)
    tp = [g for g in TUMOR[cfg['cancer']] if g in v.var_names]
    bp = [g for g in BRAIN if g in v.var_names]
    t = np.asarray(v[:, tp].X.mean(axis=1)).ravel()
    b = np.asarray(v[:, bp].X.mean(axis=1)).ravel()
    lab = np.array(['other'] * v.n_obs, dtype=object)
    lab[(t >= 0.5) & (b < 0.5)] = 'tumor'
    lab[(b >= 0.5) & (t < 0.5)] = 'brain'
    lab[(t >= 0.5) & (b >= 0.5)] = 'interface'
    nn = NearestNeighbors(n_neighbors=7).fit(xy)
    (dist, idx) = nn.kneighbors(xy)
    dmin = np.median(dist[:, 1])
    neigh = [[j for (j, dd) in zip(idx[i, 1:], dist[i, 1:]) if dd < dmin * 1.3] for i in range(v.n_obs)]
    lab2 = lab.copy()
    for i in range(v.n_obs):
        if lab[i] == 'tumor' and any((lab[j] == 'brain' for j in neigh[i])):
            lab2[i] = 'interface'
        elif lab[i] == 'brain' and any((lab[j] == 'tumor' for j in neigh[i])):
            lab2[i] = 'interface'
    bandcnt = pd.Series(lab2).value_counts().to_dict()
    log(sl, cfg['cancer'], v.n_obs, 'spots', bandcnt)
    base = dict(slide=sl, dataset=cfg['dataset'], cancer=cfg['cancer'], group='淋巴瘤' if '淋巴瘤' in cfg['cancer'] else '脑转移', n_spots=v.n_obs, median_umi=float(np.median(tot)))
    for bd in ['tumor', 'interface', 'brain', 'other']:
        base[f'n_{bd}'] = int(bandcnt.get(bd, 0))
    ss = pd.DataFrame(index=v.obs_names)
    r = dict(base)
    for name in KEYSIG:
        (s, thr, ng) = score_sig(v, SIG[name])
        if s is None:
            continue
        short = name.split('(')[0]
        ss[short] = s
        pos_ = s > thr
        r[f'{short}_pos_all'] = round(float(pos_.mean()), 4)
        for bd in ['tumor', 'interface', 'brain']:
            m = lab2 == bd
            r[f'{short}_pos_{bd}'] = round(float(pos_[m].mean()), 4) if m.sum() >= 20 else np.nan
    rows_band.append(r)
    C = v.layers['counts'].tocsc()
    gi = {g: i for (i, g) in enumerate(v.var_names)}

    def cnt(g):
        return C[:, gi[g]].toarray().ravel() if g in gi else np.zeros(v.n_obs)
    for g in GENES:
        if g not in gi:
            continue
        c = cnt(g)
        d = dict(base)
        d.update(gene=g, det_all=round(float((c > 0).mean()), 4))
        for bd in ['tumor', 'interface', 'brain']:
            m = lab2 == bd
            d[f'det_{bd}'] = round(float((c[m] > 0).mean()), 4) if m.sum() >= 20 else np.nan
        rows_gene.append(d)
    A = sp.lil_matrix((v.n_obs, v.n_obs))
    for i in range(v.n_obs):
        for j in neigh[i]:
            A[i, j] = 1
    A = A.tocsr() + sp.eye(v.n_obs, format='csr')

    def high(g):
        c = cnt(g) / np.maximum(tot, 1) * 10000.0
        p = c[c > 0]
        if len(p) < 20:
            return (None, float((c > 0).mean()))
        return ((c >= np.quantile(p, 0.75)).astype(float), float((c > 0).mean()))
    for pr in PAIRS:
        if any((g not in gi for g in pr)):
            rows_pair.append(dict(base, pair='-'.join(pr), note='基因缺失'))
            continue
        hs = [high(g) for g in pr]
        if any((h[0] is None for h in hs)):
            rows_pair.append(dict(base, pair='-'.join(pr), note='阳性spot<20', dets=';'.join((f'{h[1]:.3f}' for h in hs))))
            continue
        Lh = hs[0][0]
        Rs = [h[0] for h in hs[1:]]
        obs = float((Lh * np.prod([A @ R > 0 for R in Rs], axis=0)).sum())
        null = np.array([float((Lh * np.prod([A @ rng.permutation(R) > 0 for R in Rs], axis=0)).sum()) for _ in range(200)])
        z = (obs - null.mean()) / (null.std() + 1e-09)
        p = (np.sum(null >= obs) + 1) / 201
        rows_pair.append(dict(base, pair='-'.join(pr), dets=';'.join((f'{h[1]:.3f}' for h in hs)), obs=obs, null_mean=round(null.mean(), 1), obs_over_null=round(obs / max(null.mean(), 1), 2), z=round(z, 2), p=round(p, 4)))
    mm = (lab2 == 'tumor') | (lab2 == 'interface')
    if mm.sum() < 20:
        mm = np.ones(v.n_obs, bool)
    det = lambda g: float((cnt(g)[mm] > 0).mean()) if g in gi else np.nan
    d = dict(base, n_eval=int(mm.sum()))
    for g in ['CD3E', 'CD8A', 'CXCL13', 'FOXP3', 'TNFRSF9', 'PDCD1', 'CSF3R', 'S100A8', 'FCGR3B', 'CD163', 'F13A1', 'NOTCH3', 'TPSAB1', 'MS4A1', 'CR2', 'CXCR5', 'CCL19', 'LAMP3', 'CXCL9', 'JCHAIN']:
        d[g] = round(det(g), 4)
    T_rich = d['CD3E'] >= 0.1 and d['CXCL13'] >= 0.08
    neut = d['CSF3R'] >= 0.15 and d['S100A8'] >= 0.4
    d['archetype'] = 'T富集型(CXCL13+)' if T_rich else '中性粒主导型' if neut else '髓系型(CD163+)' if d['CD163'] >= 0.3 else '免疫荒漠型'
    d['CXCL13_without_TLS'] = bool(d['CXCL13'] >= 0.08 and d['MS4A1'] < 0.05)
    d['TLS_like'] = bool(d['MS4A1'] >= 0.05 and d['CXCL13'] >= 0.08 and (d['CCL19'] >= 0.05))
    rows_arch.append(d)
    ves = (cnt('PECAM1') > 0) | (cnt('VWF') > 0) | (cnt('CLDN5') > 0)
    mural = (cnt('NOTCH3') > 0) | (cnt('RGS5') > 0) | (cnt('PDGFRB') > 0)
    n3 = cnt('NOTCH3') > 0
    rg = cnt('RGS5') > 0
    tper = (cnt('SLC6A1') > 0) | (cnt('SLC20A2') > 0) | (cnt('ABCC9') > 0) | (cnt('KCNJ8') > 0)
    smc = (cnt('ACTA2') > 0) | (cnt('MYH11') > 0)
    hi = tot >= np.median(tot)
    ec_strict = cnt('PECAM1') + cnt('VWF') + cnt('CLDN5') >= 3
    r = dict(base)
    for bd in ['all', 'tumor', 'interface', 'brain']:
        m = np.ones(v.n_obs, bool) if bd == 'all' else lab2 == bd
        if m.sum() < 20:
            continue
        r[f'{bd}_n'] = int(m.sum())
        r[f'{bd}_vessel_frac'] = round(float(ves[m].mean()), 4)
        r[f'{bd}_vessel_strict_frac'] = round(float(ec_strict[m].mean()), 4)
        vm = m & ves
        if vm.sum() >= 20:
            r[f'{bd}_cov_mural'] = round(float(mural[vm].mean()), 4)
            r[f'{bd}_cov_NOTCH3'] = round(float(n3[vm].mean()), 4)
            r[f'{bd}_cov_RGS5'] = round(float(rg[vm].mean()), 4)
            r[f'{bd}_cov_Tperi'] = round(float(tper[vm].mean()), 4)
            r[f'{bd}_cov_SMC'] = round(float(smc[vm].mean()), 4)
            r[f'{bd}_bg_mural_nonvessel'] = round(float(mural[m & ~ves].mean()), 4) if (m & ~ves).sum() >= 20 else np.nan
            r[f'{bd}_cov_mural_hidepth'] = round(float(mural[vm & hi].mean()), 4) if (vm & hi).sum() >= 20 else np.nan
            r[f'{bd}_cov_NOTCH3_hidepth'] = round(float(n3[vm & hi].mean()), 4) if (vm & hi).sum() >= 20 else np.nan
            r[f'{bd}_cov_mural_strict'] = round(float(mural[m & ec_strict].mean()), 4) if (m & ec_strict).sum() >= 20 else np.nan
    rows_ves.append(r)
    ss['band'] = lab2
    ss['px'] = xy[:, 0]
    ss['py'] = xy[:, 1]
    ss['umi'] = tot
    for g in ['GFAP', 'SERPINA3', 'CD44', 'P2RY12', 'CXCL13', 'CD3E', 'MS4A1', 'PECAM1', 'VWF', 'CLDN5', 'NOTCH3', 'RGS5', 'PDGFRB', 'CSF3R', 'S100A8', 'CD163']:
        ss[f'det_{g}'] = (cnt(g) > 0).astype(int)
    ss.to_csv(f'{O}/spot_table_{sl}.csv.gz', compression='gzip')
    (fig, axes) = plt.subplots(2, 4, figsize=(18, 8))
    keys = ['band', '反应性星形胶质', '活化小胶质', 'det_CXCL13', 'det_CD3E', 'det_MS4A1', 'vessel', 'det_NOTCH3']
    col = {'tumor': '#d62728', 'interface': '#ff7f0e', 'brain': '#1f77b4', 'other': '#cccccc'}
    for (ax, k) in zip(axes.ravel(), keys):
        if k == 'band':
            ax.scatter(xy[:, 0], -xy[:, 1], s=5, c=[col[x] for x in lab2], linewidths=0)
            ax.set_title(f"三带 T{bandcnt.get('tumor', 0)}/I{bandcnt.get('interface', 0)}/B{bandcnt.get('brain', 0)}", fontsize=9)
        elif k == 'vessel':
            ax.scatter(xy[:, 0], -xy[:, 1], s=5, c=np.where(ves & mural, 2, np.where(ves, 1, 0)), cmap='viridis', linewidths=0)
            ax.set_title('血管 spot (黄=含壁细胞 marker)', fontsize=9)
        elif k in ss.columns:
            s = ss[k].values.astype(float)
            ax.scatter(xy[:, 0], -xy[:, 1], s=5, c=s, cmap='magma', vmin=np.quantile(s, 0.02), vmax=max(np.quantile(s, 0.98), 1e-06), linewidths=0)
            ax.set_title(k, fontsize=9)
        ax.set_xticks([])
        ax.set_yticks([])
        ax.set_aspect('equal')
    fig.suptitle(f"{sl} {cfg['cancer']}", fontsize=12)
    fig.savefig(f'{O}/spatial_{sl}.png', dpi=90, bbox_inches='tight')
    plt.close(fig)
    pd.DataFrame(rows_band).to_csv(f'{O}/M3_interface_by_slide.csv', index=False)
    pd.DataFrame(rows_gene).to_csv(f'{O}/M3_gene_detection_by_band.csv', index=False)
    pd.DataFrame(rows_pair).to_csv(f'{O}/M3_I3_L3_cooccurrence.csv', index=False)
    pd.DataFrame(rows_arch).to_csv(f'{O}/I3_archetype_30slides.csv', index=False)
    pd.DataFrame(rows_ves).to_csv(f'{O}/L3_vessel_coverage_by_slide.csv', index=False)
log('全部完成', len(rows_band), '张')
