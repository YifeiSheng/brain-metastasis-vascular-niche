# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os, re, glob, numpy as np, pandas as pd, scipy.io, time
from sklearn.neighbors import KDTree
from scipy.stats import mannwhitneyu, kruskal, wilcoxon
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
font_manager.fontManager.addfont(str(_HANDOFF_ROOT / 'environment/NotoSansCJKsc-Regular.otf'))
plt.rcParams['font.family'] = ['Noto Sans CJK SC', 'DejaVu Sans']
B = str(_HANDOFF_ROOT / '')
D = f'{B}/data/external/imc/Karimi2023/data/BrainData'
O = f'{B}/results/immune_glial_lymphoma/M1_I1_IMC'
os.makedirs(O, exist_ok=True)
L = open(f'{O}/progress.txt', 'a', buffering=1)
log = lambda *a: L.write(time.strftime('[%H:%M:%S] ') + ' '.join(map(str, a)) + '\n')
clin = pd.read_excel(f'{D}/Clinical Data GBM BrM.xlsx', sheet_name='Sheet1')
clin.columns = [c.strip() for c in clin.columns]
clin = clin.set_index('Image ID')
TYPES = ['Cancer', 'Endothelial cell', 'Astrocytes', 'Cl BMDM', 'Alt BMDM', 'Cl MG', 'Alt MG', 'Macrophages other', 'Cl Mo', 'Int Mo', 'Non-Cl Mo', 'Neutrophils', 'Mast cell', 'DCs cell', 'B cell', 'NK cell', 'Tc', 'Th', 'Treg', 'T other']
IMM = ['Cl BMDM', 'Alt BMDM', 'Cl MG', 'Alt MG', 'Macrophages other', 'Cl Mo', 'Int Mo', 'Non-Cl Mo', 'Neutrophils', 'Mast cell', 'DCs cell', 'B cell', 'NK cell', 'Tc', 'Th', 'Treg', 'T other']
MAC = ['Cl BMDM', 'Alt BMDM', 'Cl MG', 'Alt MG', 'Macrophages other']
MONO = ['Cl Mo', 'Int Mo', 'Non-Cl Mo']
TC = ['Tc', 'Th', 'Treg', 'T other']

def metrics(cnt, area):
    n_all = sum(cnt.values())
    n_imm = sum((cnt[t] for t in IMM))
    r = dict(n_cells=n_all, n_immune=n_imm, area_mm2=round(area, 3))
    for t in TYPES:
        r[f'n_{t}'] = cnt[t]
    for t in IMM:
        r[f'immfrac_{t}'] = round(cnt[t] / max(n_imm, 1), 4)
        r[f'dens_{t}'] = round(cnt[t] / area, 2)
    r['frac_all_immune'] = round(n_imm / max(n_all, 1), 4)
    r['frac_all_T'] = round(sum((cnt[t] for t in TC)) / max(n_all, 1), 4)
    r['frac_all_Tc'] = round(cnt['Tc'] / max(n_all, 1), 4)
    r['frac_all_Treg'] = round(cnt['Treg'] / max(n_all, 1), 4)
    r['frac_all_Neut'] = round(cnt['Neutrophils'] / max(n_all, 1), 4)
    r['frac_all_myeloid'] = round(sum((cnt[t] for t in MAC + MONO)) / max(n_all, 1), 4)
    r['frac_all_astro'] = round(cnt['Astrocytes'] / max(n_all, 1), 4)
    r['frac_all_cancer'] = round(cnt['Cancer'] / max(n_all, 1), 4)
    r['frac_all_EC'] = round(cnt['Endothelial cell'] / max(n_all, 1), 4)
    bm = cnt['Cl BMDM'] + cnt['Alt BMDM']
    mg = cnt['Cl MG'] + cnt['Alt MG']
    r['BMDM_over_MG'] = round(bm / max(mg, 1), 3)
    r['MG_frac_of_mac'] = round(mg / max(bm + mg, 1), 4)
    r['Alt_frac_of_BMDM'] = round(cnt['Alt BMDM'] / max(bm, 1), 4)
    r['Treg_frac_of_T'] = round(cnt['Treg'] / max(sum((cnt[t] for t in TC)), 1), 4)
    r['Tc_frac_of_T'] = round(cnt['Tc'] / max(sum((cnt[t] for t in TC)), 1), 4)
    T_rich = r['frac_all_T'] >= 0.05 and r['frac_all_Tc'] >= 0.02
    neut = r['frac_all_Neut'] >= 0.05
    mye = r['frac_all_myeloid'] >= 0.2
    r['archetype'] = 'T富集型' if T_rich else '中性粒主导型' if neut else '髓系型' if mye else '免疫荒漠型'
    return r
rows = []
cells = {}
for f in sorted(glob.glob(f'{D}/BRAIN_IMC_CellType/*.mat')):
    roi = os.path.basename(f)[:-4]
    try:
        m = scipy.io.loadmat(f)
        ct = np.array([str(x[0]) if len(x) else 'NONE' for x in m['cellTypes'].ravel()])
        seg = scipy.io.loadmat(f'{D}/BRAIN_IMC_Segmentation/{roi}/allRegionIndices.mat')['allRegInds'].ravel()
        nuc = scipy.io.loadmat(f'{D}/BRAIN_IMC_Segmentation/{roi}/nuclei_multiscale.mat')
        (H, W) = nuc['nucleiImage'].shape
    except Exception as e:
        log('跳过', roi, str(e)[:80])
        continue
    if len(seg) != len(ct):
        log('长度不一致', roi)
        continue
    cent = np.array([[np.mean((np.asarray(idx).ravel() - 1) // H), np.mean((np.asarray(idx).ravel() - 1) % H)] if np.size(idx) else [np.nan, np.nan] for idx in seg])
    ok = ~np.isnan(cent[:, 0]) & (ct != 'NONE')
    cent = cent[ok]
    ct = ct[ok]
    area = H * W / 1000000.0
    cnt = {t: int((ct == t).sum()) for t in TYPES}
    r = dict(roi=roi)
    r.update(metrics(cnt, area))
    cells[roi] = cnt
    canc = ct == 'Cancer'
    if canc.sum() >= 20:
        tree = KDTree(cent[canc])
        for k in ['Astrocytes', 'Cl MG', 'Alt MG', 'Cl BMDM', 'Alt BMDM', 'Tc', 'Neutrophils', 'Endothelial cell']:
            idx = ct == k
            if idx.sum() >= 10:
                (d, _) = tree.query(cent[idx], k=1)
                r[f'med_dist_to_cancer_{k}'] = round(float(np.median(d)), 1)
                r[f'within20_cancer_{k}'] = round(float((d[:, 0] <= 20).mean()), 4)
        (d, _) = tree.query(cent[~canc], k=1)
        r['within20_cancer_all_noncancer'] = round(float((d[:, 0] <= 20).mean()), 4)
    rows.append(r)
res = pd.DataFrame(rows).set_index('roi')
brm = clin[clin['Tumor Type'].astype(str).str.contains('Metas')].copy()
brm.index = [f'BrM_001C{k}' for k in range(1, len(brm) + 1)]
clin2 = pd.concat([clin[~clin['Tumor Type'].astype(str).str.contains('Metas')], brm])
res = res.join(clin2, how='left')
res['group'] = np.where(res['Tumor Type'].astype(str).str.contains('Metas'), '脑转移', '胶质瘤')
res['primary'] = res['Primary Site of Brain Metastasis'].astype(str).str.strip()
res['region'] = res['Tissue Region'].astype(str).str.strip()
res.to_csv(f'{O}/M1_imc_immune_by_roi.csv')
log('ROI', len(res), dict(res.group.value_counts()), dict(res.region.value_counts()))
prow = []
for ((pid, reg), sub) in res.groupby(['Patient ID', 'region']):
    cnt = {t: int(sub[f'n_{t}'].sum()) for t in TYPES}
    area = float(sub.area_mm2.sum())
    r = dict(patient=pid, region=reg, n_roi=len(sub))
    r.update(metrics(cnt, area))
    for c in [c for c in res.columns if c.startswith(('med_dist_', 'within20_'))]:
        r[c] = round(float(sub[c].mean()), 4) if sub[c].notna().any() else np.nan
    r['archetype_vote'] = sub.archetype.value_counts().idxmax()
    first = sub.iloc[0]
    for c in ['group', 'Tumor Type', 'primary', 'Age', 'Sex', 'OS event (days post surgery)', 'Post-Surgical Treatment', 'IDH status (wildtype = wt, mutant = mut)']:
        r[c] = first[c]
    prow.append(r)
pt = pd.DataFrame(prow)
pt.to_csv(f'{O}/M1_imc_immune_by_patient_region.csv', index=False)
core = pt[pt.region == 'Tumor Core'].set_index('patient')
log('病人 Core:', dict(core.group.value_counts()), '脑转移原发:', dict(core[core.group == '脑转移'].primary.value_counts()))
MET = ['frac_all_immune', 'frac_all_T', 'frac_all_Tc', 'frac_all_Treg', 'frac_all_Neut', 'frac_all_myeloid', 'frac_all_astro', 'frac_all_EC', 'BMDM_over_MG', 'MG_frac_of_mac', 'Alt_frac_of_BMDM', 'Treg_frac_of_T'] + [f'immfrac_{t}' for t in IMM] + [f'dens_{t}' for t in ['Mast cell', 'DCs cell', 'Neutrophils', 'B cell', 'Tc', 'Treg', 'Cl BMDM', 'Alt BMDM', 'Cl MG', 'Alt MG']] + [c for c in core.columns if c.startswith(('med_dist_', 'within20_'))]
cmp = []
bm = core[core.group == '脑转移']
gl = core[core.group == '胶质瘤']
bm['primary3'] = bm.primary.where(bm.primary.isin(['Lung', 'Breast', 'Melanoma']), '其他')
for c in MET:
    x = bm[c].dropna()
    y = gl[c].dropna()
    g = bm.groupby('primary3')[c].median().round(4).to_dict()
    kp = np.nan
    grp = [bm[bm.primary3 == k][c].dropna() for k in ['Lung', 'Breast', 'Melanoma']]
    if all((len(v) >= 3 for v in grp)):
        try:
            kp = kruskal(*grp).pvalue
        except Exception:
            kp = np.nan
    cmp.append(dict(metric=c, BrM_median=round(x.median(), 4) if len(x) else np.nan, BrM_n=len(x), glioma_median=round(y.median(), 4) if len(y) else np.nan, glioma_n=len(y), mwu_p=mannwhitneyu(x, y).pvalue if len(x) >= 3 and len(y) >= 3 else np.nan, by_primary_median=g, kruskal_p_primary=kp))
pd.DataFrame(cmp).to_csv(f'{O}/M1_BrM_vs_glioma_by_primary.csv', index=False)
reg = []
for grp_name in ['脑转移', '胶质瘤']:
    P = pt[pt.group == grp_name]
    for c in ['frac_all_astro', 'frac_all_T', 'frac_all_Tc', 'frac_all_Neut', 'frac_all_myeloid', 'frac_all_immune', 'MG_frac_of_mac', 'BMDM_over_MG', 'immfrac_Cl MG', 'immfrac_Alt MG', 'immfrac_Cl BMDM', 'immfrac_Mast cell', 'immfrac_DCs cell', 'frac_all_cancer', 'med_dist_to_cancer_Astrocytes', 'med_dist_to_cancer_Cl MG', 'within20_cancer_Astrocytes', 'within20_cancer_Cl MG', 'within20_cancer_Cl BMDM']:
        w = P.pivot(index='patient', columns='region', values=c)
        r = dict(group=grp_name, metric=c)
        for k in ['Tumor Core', 'Tumor Margin', 'Adjacent Normal']:
            if k in w:
                r[f'median_{k}'] = round(float(w[k].median()), 4) if w[k].notna().any() else np.nan
                r[f'n_{k}'] = int(w[k].notna().sum())
        if 'Tumor Core' in w and 'Tumor Margin' in w:
            d = w[['Tumor Core', 'Tumor Margin']].dropna()
            if len(d) >= 5:
                try:
                    r['paired_wilcoxon_p_core_vs_margin'] = wilcoxon(d['Tumor Core'], d['Tumor Margin']).pvalue
                except Exception:
                    r['paired_wilcoxon_p_core_vs_margin'] = np.nan
                r['n_paired'] = len(d)
                r['median_margin_minus_core'] = round(float((d['Tumor Margin'] - d['Tumor Core']).median()), 4)
        R = res[res.group == grp_name]
        x = R[R.region == 'Tumor Core'][c].dropna()
        y = R[R.region == 'Tumor Margin'][c].dropna()
        r['roi_mwu_p_core_vs_margin'] = mannwhitneyu(x, y).pvalue if len(x) >= 3 and len(y) >= 3 else np.nan
        reg.append(r)
pd.DataFrame(reg).to_csv(f'{O}/M1_core_margin_normal.csv', index=False)
arch = pd.crosstab([core.group, core.primary.where(core.group == '脑转移', '-')], core.archetype)
arch.to_csv(f'{O}/I1_archetype_by_group_primary.csv')
arch_vote = pd.crosstab([core.group, core.primary.where(core.group == '脑转移', '-')], core.archetype_vote)
arch_vote.to_csv(f'{O}/I1_archetype_vote_by_group_primary.csv')
roi_arch = pd.crosstab([res.group, res.region], res.archetype)
roi_arch.to_csv(f'{O}/I1_archetype_by_roi_region.csv')
log('原型(病人 Core 合并):', arch.to_dict())

def parse_os(v):
    mm = re.search('([A-Za-z ]+)\\s*\\((\\d+)', str(v))
    return (mm.group(1).strip().lower(), float(mm.group(2))) if mm else (None, np.nan)
(core['os_status'], core['os_days']) = zip(*core['OS event (days post surgery)'].map(parse_os))
core['event'] = core.os_status.str.contains('death|dead|deceased', na=False).astype(int)
core['lung'] = (core.primary == 'Lung').astype(int)
core['T_rich'] = (core.archetype == 'T富集型').astype(int)
core['desert'] = (core.archetype == '免疫荒漠型').astype(int)
bmo = core[(core.group == '脑转移') & core.os_days.notna()].copy()
log('脑转移有 OS:', len(bmo), '事件', int(bmo.event.sum()))
out = []
try:
    from lifelines import CoxPHFitter, KaplanMeierFitter
    from lifelines.statistics import logrank_test
    for c in ['frac_all_T', 'frac_all_Tc', 'frac_all_Treg', 'frac_all_Neut', 'frac_all_myeloid', 'frac_all_immune', 'BMDM_over_MG', 'MG_frac_of_mac', 'immfrac_Mast cell', 'immfrac_DCs cell', 'immfrac_B cell', 'dens_Tc', 'dens_Neutrophils', 'T_rich', 'desert', 'within20_cancer_Tc', 'within20_cancer_Cl BMDM']:
        if c not in bmo:
            continue
        for (nm, dd) in [('全部脑转移(按肺/非肺分层)', bmo), ('肺癌来源', bmo[bmo.lung == 1])]:
            d = dd[[c, 'os_days', 'event', 'lung']].dropna().copy()
            if c not in ['T_rich', 'desert']:
                d[c] = (d[c] - d[c].mean()) / (d[c].std() + 1e-09)
            if len(d) < 15 or d.event.sum() < 8 or d[c].nunique() < 2:
                continue
            try:
                cph = CoxPHFitter().fit(d[[c, 'os_days', 'event'] + (['lung'] if nm.startswith('全部') else [])], 'os_days', 'event', strata=['lung'] if nm.startswith('全部') else None)
                s = cph.summary.loc[c]
                out.append(dict(metric=c, cohort=nm, n=len(d), events=int(d.event.sum()), HR=round(float(np.exp(s['coef'])), 3), ci_low=round(float(np.exp(s['coef lower 95%'])), 3), ci_high=round(float(np.exp(s['coef upper 95%'])), 3), p=float(s['p']), unit='二值' if c in ['T_rich', 'desert'] else 'per SD'))
            except Exception as e:
                log('Cox 失败', c, nm, str(e)[:100])
    pd.DataFrame(out).to_csv(f'{O}/I1_cox_os.csv', index=False)
    (fig, ax) = plt.subplots(figsize=(5, 4))
    km = KaplanMeierFitter()
    for (lab, m) in [('T富集型', bmo.T_rich == 1), ('其他原型', bmo.T_rich == 0)]:
        if m.sum() >= 3:
            km.fit(bmo.os_days[m], bmo.event[m], label=f'{lab} (n={int(m.sum())})')
            km.plot_survival_function(ax=ax, ci_show=False)
    if (bmo.T_rich == 1).sum() >= 3 and (bmo.T_rich == 0).sum() >= 3:
        lr = logrank_test(bmo.os_days[bmo.T_rich == 1], bmo.os_days[bmo.T_rich == 0], bmo.event[bmo.T_rich == 1], bmo.event[bmo.T_rich == 0])
        ax.set_title(f'脑转移 OS: T富集型 vs 其他 logrank p={lr.p_value:.3f}', fontsize=10)
    ax.set_xlabel('术后天数')
    ax.set_ylabel('生存比例')
    fig.savefig(f'{O}/I1_KM_Trich.png', dpi=120, bbox_inches='tight')
    plt.close(fig)
except Exception as e:
    log('lifelines 失败', str(e)[:200])
core.to_csv(f'{O}/I1_imc_patient_core_table.csv')
m4 = []
for (grp_name, reg_name) in [('脑转移', 'Tumor Core'), ('脑转移', 'Tumor Margin'), ('脑转移', 'Adjacent Normal'), ('胶质瘤', 'Tumor Core'), ('胶质瘤', 'Tumor Margin'), ('胶质瘤', 'Adjacent Normal')]:
    R = res[(res.group == grp_name) & (res.region == reg_name)]
    if not len(R):
        continue
    r = dict(group=grp_name, region=reg_name, n_roi=len(R), n_patients=R['Patient ID'].nunique())
    for t in ['Mast cell', 'DCs cell', 'B cell', 'NK cell', 'Neutrophils']:
        r[f'dens_{t}_median'] = round(float(R[f'dens_{t}'].median()), 2)
        r[f'immfrac_{t}_median'] = round(float(R[f'immfrac_{t}'].median()), 4)
        r[f'roi_frac_with_any_{t}'] = round(float((R[f'n_{t}'] > 0).mean()), 3)
        r[f'total_{t}'] = int(R[f'n_{t}'].sum())
    m4.append(r)
pd.DataFrame(m4).to_csv(f'{O}/M4_mast_dc_summary.csv', index=False)
bmc = core[core.group == '脑转移'].copy()
bmc['primary3'] = bmc.primary.where(bmc.primary.isin(['Lung', 'Breast', 'Melanoma']), '其他')
bmc = bmc.sort_values(['primary3', 'frac_all_T'])
(fig, ax) = plt.subplots(figsize=(max(8, 0.3 * len(bmc)), 4))
cols = IMM
bottom = np.zeros(len(bmc))
cm = plt.get_cmap('tab20')
for (i, t) in enumerate(cols):
    v = bmc[f'immfrac_{t}'].values
    ax.bar(range(len(bmc)), v, bottom=bottom, color=cm(i % 20), label=t, width=0.85)
    bottom += v
ax.set_xticks(range(len(bmc)))
ax.set_xticklabels([f'{p[:4]}|{a[:1]}' for (p, a) in zip(bmc.primary3, bmc.archetype)], rotation=90, fontsize=6)
ax.set_ylabel('占免疫细胞比例')
ax.set_title('脑转移病人 Tumor Core 免疫组成 (成像质谱; 标签=原发|原型首字)', fontsize=10)
ax.legend(fontsize=6, ncol=2, bbox_to_anchor=(1, 1))
fig.savefig(f'{O}/M1_immune_composition_BrM_patients.png', dpi=120, bbox_inches='tight')
plt.close(fig)
keys = ['frac_all_T', 'frac_all_Neut', 'frac_all_myeloid', 'BMDM_over_MG', 'immfrac_Mast cell', 'immfrac_DCs cell', 'frac_all_astro', 'frac_all_immune']
(fig, axes) = plt.subplots(2, 4, figsize=(14, 6))
for (ax, c) in zip(axes.ravel(), keys):
    data = [gl[c].dropna(), bm[bm.primary3 == 'Lung'][c].dropna(), bm[bm.primary3 == 'Breast'][c].dropna(), bm[bm.primary3 == 'Melanoma'][c].dropna(), bm[bm.primary3 == '其他'][c].dropna()]
    ax.boxplot(data, labels=['胶质瘤', '肺', '乳腺', '黑色素瘤', '其他'], showfliers=False)
    for (i, dv) in enumerate(data):
        ax.scatter(np.random.normal(i + 1, 0.05, len(dv)), dv, s=6, alpha=0.6)
    ax.set_title(c, fontsize=9)
    ax.tick_params(axis='x', labelsize=7)
fig.suptitle('病人级 Tumor Core: 胶质瘤 vs 脑转移(按原发)', fontsize=11)
fig.savefig(f'{O}/M1_BrM_vs_glioma_box.png', dpi=120, bbox_inches='tight')
plt.close(fig)
(fig, axes) = plt.subplots(1, 4, figsize=(14, 3.5))
for (ax, c) in zip(axes, ['frac_all_astro', 'MG_frac_of_mac', 'frac_all_T', 'within20_cancer_Astrocytes']):
    w = pt[pt.group == '脑转移'].pivot(index='patient', columns='region', values=c)
    if 'Tumor Core' in w and 'Tumor Margin' in w:
        d = w[['Tumor Core', 'Tumor Margin']].dropna()
        for (_, rr) in d.iterrows():
            ax.plot([0, 1], [rr['Tumor Core'], rr['Tumor Margin']], '-o', color='gray', alpha=0.6, ms=3)
        ax.set_xticks([0, 1])
        ax.set_xticklabels(['Core', 'Margin'])
        ax.set_title(f'{c} (n={len(d)})', fontsize=9)
fig.suptitle('脑转移病人 Core vs Margin (成像质谱)', fontsize=11)
fig.savefig(f'{O}/M1_core_margin_paired.png', dpi=120, bbox_inches='tight')
plt.close(fig)
log('全部完成')
