# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
"""L17 donor EC pseudobulk and internal sender/receiver expression. No input changes."""
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os
for k in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS']:
    os.environ[k] = '2'
from pathlib import Path
import pandas as pd, numpy as np, scipy.sparse as sp, scipy.io as sio, json, re, time
from threadpoolctl import threadpool_limits
threadpool_limits(2)
B = Path(str(_HANDOFF_ROOT / ''))
O = B / 'results/ligand_response'
O.mkdir(exist_ok=True, parents=True)
LIN = {'EC': ['PECAM1', 'CDH5', 'CLDN5', 'VWF'], 'mural': ['PDGFRB', 'RGS5', 'NOTCH3', 'ACTA2', 'MYH11'], 'fibroblast': ['DCN', 'LUM', 'COL1A2', 'PDGFRA'], 'immune': ['PTPRC'], 'myeloid': ['CD68', 'CD163', 'C1QA', 'AIF1'], 'tumor_epi': ['EPCAM', 'KRT8', 'KRT18', 'KRT19'], 'oligo': ['PLP1', 'MBP', 'MOG'], 'astro': ['AQP4', 'GFAP', 'ALDH1L1']}
rows = []
sums = {}
detn = {}
ncell = {}
for (fn, raw) in [('download_list.txt', 'raw'), ('download_list_other.txt', 'raw_other')]:
    for line in (B / 'data/external/scrna/GSE256493' / fn).read_text().splitlines():
        (gsm, pre, name, *rest) = line.split()
        if '_EC' not in name or not name.startswith(('MET_', 'TL_')):
            continue
        donor = '_'.join(name.split('_')[:2])
        group = 'BM' if name.startswith('MET_') else 'TL'
        p = B / 'data/external/scrna/GSE256493' / raw
        print('READ', name, flush=True)
        X = sio.mmread(p / (pre + '_matrix.mtx.gz')).tocsr().T.tocsr().astype(np.float32)
        gf = p / (pre + '_features.tsv.gz')
        if not gf.exists():
            gf = p / (pre + '_genes.tsv.gz')
        ft = pd.read_csv(gf, sep='\t', header=None)
        genes = ft.iloc[:, 1 if ft.shape[1] > 1 else 0].astype(str).values
        ix = {g: i for (i, g) in reversed(list(enumerate(genes)))}
        total = np.asarray(X.sum(1)).ravel()
        ng = np.diff(X.indptr)
        mt = np.char.startswith(genes.astype(str), 'MT-')
        mtfrac = np.asarray(X[:, mt].sum(1)).ravel() / np.maximum(total, 1)
        qc = (ng >= 300) & (mtfrac < 0.2)
        req = list(dict.fromkeys(sum(LIN.values(), []) + ['PTPRC', 'CD3D', 'TYROBP', 'LYZ']))
        rc = np.column_stack([X[:, ix[g]].toarray().ravel() if g in ix else np.zeros(len(total)) for g in req])
        C = pd.DataFrame(rc, columns=req)
        E = np.log1p(C.div(np.maximum(total, 1), axis=0) * 10000.0)
        lm = pd.DataFrame({k: E[gs].mean(1) for (k, gs) in LIN.items()})
        gate_legacy = qc & (lm.idxmax(1).values == 'EC') & (lm.max(1).values > 0.3)
        gate_strict = qc & ((C[LIN['EC']] > 0).sum(1).values >= 2) & ((C[LIN['tumor_epi']] > 0).sum(1).values < 2) & ((C[['PTPRC', 'CD3D', 'TYROBP', 'LYZ']] > 0).sum(1).values < 2)
        for (gate, sel) in [('main', gate_legacy), ('strict', gate_strict)]:
            n = int(sel.sum())
            r = dict(sample=name, gsm=gsm, donor=donor, group=group, gate=gate, n_qc=int(qc.sum()), n_EC=n, raw_prefix=str(p / pre))
            rows.append(r)
            if n < 20:
                continue
            key = (gate, donor, group)
            v = pd.Series(np.asarray(X[sel].sum(0)).ravel(), index=genes).groupby(level=0).sum()
            d = pd.Series(np.asarray((X[sel] > 0).sum(0)).ravel(), index=genes).groupby(level=0).max()
            sums[key] = sums.get(key, pd.Series(dtype=float)).add(v, fill_value=0)
            detn[key] = detn.get(key, pd.Series(dtype=float)).add(d, fill_value=0)
            ncell[key] = ncell.get(key, 0) + n
        print('DONE', name, rows[-2]['n_EC'], rows[-1]['n_EC'], flush=True)
pd.DataFrame(rows).to_csv(O / 'EC_library_manifest.csv', index=False)
meta = []
for gate in ['main', 'strict']:
    keys = [k for k in sums if k[0] == gate]
    frame = pd.DataFrame({k[1]: sums[k] for k in keys}).T.fillna(0)
    frame.to_csv(O / f'EC_{gate}_pseudobulk_counts.csv.gz', compression='gzip')
    det = pd.DataFrame({k[1]: detn[k] / ncell[k] for k in keys}).T.fillna(0)
    det.to_csv(O / f'EC_{gate}_detection.csv.gz', compression='gzip')
    for k in keys:
        meta.append(dict(gate=gate, donor=k[1], group=k[2], n_EC=ncell[k]))
pd.DataFrame(meta).to_csv(O / 'EC_donor_manifest.csv', index=False)
import anndata as ad
a = ad.read_h5ad(B / 'data/integrated/final_integrated_annotated.h5ad')
pc = pd.read_csv(B / 'data/integrated/per_cell_labels.csv', index_col='cell').reindex(a.obs_names)
x = a.X.tocsr().astype(np.float32)
total = np.asarray(x.sum(1)).ravel()
ex = x.multiply(10000.0 / np.maximum(total[:, None], 1)).tocsr()
ex.data = np.log1p(ex.data)
means = {}
dets = {}
counts = {}
meta = []
for ((pat, lin), ii) in pc.groupby(['patient_id', 'lineage_l1'], observed=True).indices.items():
    if pat not in ['P1', 'P3', 'P5']:
        continue
    key = pat + '|' + lin
    ii = np.asarray(ii)
    n = len(ii)
    means[key] = np.asarray(ex[ii].mean(0)).ravel()
    dets[key] = np.asarray((x[ii] > 0).mean(0)).ravel()
    counts[key] = np.asarray(x[ii].sum(0)).ravel()
    meta.append(dict(key=key, patient=pat, lineage=lin, n_cells=n))
for (name, d) in [('mean_logCP10k', means), ('detection', dets), ('counts', counts)]:
    pd.DataFrame(d, index=a.var_names).T.to_csv(O / f'internal_lineage_{name}.csv.gz', compression='gzip')
pd.DataFrame(meta).to_csv(O / 'internal_lineage_manifest.csv', index=False)
print('COMPLETE', flush=True)
