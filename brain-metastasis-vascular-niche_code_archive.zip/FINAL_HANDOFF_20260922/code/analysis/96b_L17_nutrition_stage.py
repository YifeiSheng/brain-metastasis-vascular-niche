# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
"""Stage-aware fixed follow-up contrasts using all public Kim2020 malignant cells.
The complete source was used to avoid relying only on early primary lung controls.
"""
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os
for k in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS']:
    os.environ[k] = '2'
from pathlib import Path
import numpy as np, pandas as pd, scipy.io, json, itertools, math, hashlib, time
from scipy.stats import rankdata
from statsmodels.stats.multitest import multipletests
B = Path(str(_HANDOFF_ROOT / ''))
O = B / 'results/nutrition'
S = json.load(open(O / 'gene_sets.json'))['sets']
genes = pd.read_csv(O / 'kim_full_tumor_selected_genes.tsv', header=None)[0].tolist()
c = scipy.io.mmread(O / 'kim_full_tumor_selected_counts.mtx').T.toarray()
a = pd.read_csv(O / 'kim_full_tumor_annotation.csv')
m = pd.read_csv(O / 'kim_author_sample_metadata.csv')
a = a.merge(m, how='left', left_on='Sample', right_on='sample', validate='many_to_one', sort=False)
assert len(a) == len(c) and a.patient.notna().all()
a['group'] = a.Sample_Origin.map({'mBrain': 'Brain', 'tLung': 'Early_primary', 'tL/B': 'Advanced_primary', 'mLN': 'Extracranial_metastasis', 'PE': 'Extracranial_metastasis'})
tot = a.total_umi.values
expr = np.log1p(c / np.maximum(tot[:, None], 1) * 10000.0)
rows = []
gene_rows = []
roster = []
for ((group, patient), ii) in a.groupby(['group', 'patient']).indices.items():
    counts = c[ii].sum(axis=0)
    lib = tot[ii].sum()
    logcp = np.log2(1 + counts / lib * 1000000.0)
    meta = dict(patient=patient, group=group, n_cells=len(ii), samples=';'.join(sorted(a.iloc[ii].Sample.unique())), sites=';'.join(sorted(a.iloc[ii].Sample_Origin.unique())), stages=';'.join(sorted(a.iloc[ii].stage.astype(str).unique())), total_umi=float(lib))
    roster.append(meta)
    for (k, gs) in S.items():
        jj = [genes.index(g) for g in gs if g in genes]
        rows.append(dict(**meta, pathway=k, n_genes=len(jj), pseudobulk_log2cpm_mean=float(logcp[jj].mean()), cell_log1pcp10k_mean=float(expr[ii][:, jj].mean())))
    for (j, g) in enumerate(genes):
        gene_rows.append(dict(**meta, gene=g, counts=float(counts[j]), cpm=float(counts[j] / lib * 1000000.0), fraction_detected=float((c[ii, j] > 0).mean())))
r = pd.DataFrame(rows)
r.to_csv(O / 'kim_stage_aware_patient_pathways.csv', index=False)
pd.DataFrame(roster).to_csv(O / 'kim_stage_aware_patient_roster.csv', index=False)
pd.DataFrame(gene_rows).to_csv(O / 'kim_stage_aware_patient_genes.csv', index=False)
tests = []
rng = np.random.default_rng(20260922)
for comp in ['Early_primary', 'Advanced_primary', 'Extracranial_metastasis']:
    z = r[(r.n_cells >= 50) & r.group.isin(['Brain', comp])]
    wide = z.pivot(index=['group', 'patient'], columns='pathway', values='pseudobulk_log2cpm_mean').dropna()
    vv = wide.values
    grp = wide.index.get_level_values('group') == 'Brain'
    n1 = int(grp.sum())
    n2 = len(grp) - n1
    assert min(n1, n2) >= 3
    ranks = np.column_stack([rankdata(vv[:, j]) for j in range(vv.shape[1])])
    obs = ranks[grp].sum(axis=0)
    center = n1 * (len(grp) + 1) / 2
    nc = math.comb(len(grp), n1)
    nr = nc if nc <= 500000 else 100000
    cnt = np.zeros(vv.shape[1], int)
    it = itertools.combinations(range(len(grp)), n1) if nc <= 500000 else (rng.choice(len(grp), n1, replace=False) for _ in range(nr))
    for start in range(0, nr, 10000):
        ix = np.array(list(itertools.islice(it, min(10000, nr - start))))
        perm = ranks[ix].sum(axis=1)
        cnt += (np.abs(perm - center) >= np.abs(obs - center) - 1e-10).sum(axis=0)
    ps = cnt / nr if nc <= 500000 else (cnt + 1) / (nr + 1)
    for (j, k) in enumerate(wide.columns):
        v1 = vv[grp, j]
        v2 = vv[~grp, j]
        u = obs[j] - n1 * (n1 + 1) / 2
        boot = np.median(rng.choice(v1, (5000, n1)), axis=1) - np.median(rng.choice(v2, (5000, n2)), axis=1)
        tests.append(dict(comparison='Brain_vs_' + comp, pathway=k, n_brain=n1, n_comparator=n2, median_brain=float(np.median(v1)), median_comparator=float(np.median(v2)), median_difference=float(np.median(v1) - np.median(v2)), rank_biserial=float(2 * u / (n1 * n2) - 1), bootstrap_ci_low=float(np.quantile(boot, 0.025)), bootstrap_ci_high=float(np.quantile(boot, 0.975)), p=float(ps[j]), exact=nc <= 500000, n_permutations=nr))
t = pd.DataFrame(tests)
t['q_BH_all36'] = multipletests(t.p, method='fdr_bh')[1]
for (comp, ii) in t.groupby('comparison').groups.items():
    t.loc[ii, 'q_BH_contrast12'] = multipletests(t.loc[ii, 'p'], method='fdr_bh')[1]
t.to_csv(O / 'kim_stage_aware_tests.csv', index=False)
inputs = []
for p in [O / 'kim_full_tumor_selected_counts.mtx', O / 'kim_full_tumor_selected_genes.tsv', O / 'kim_full_tumor_annotation.csv', O / 'kim_author_sample_metadata.csv', next((B / 'data/external/scrna/GSE131907').rglob('GSE131907_raw_UMI_matrix.rds'), None), next((B / 'data/external/scrna/GSE131907').rglob('GSE131907_Lung_Cancer_cell_annotation.txt.gz'), None)]:
    if p is None:
        continue
    h = hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda : f.read(8388608), b''):
            h.update(chunk)
    inputs.append(dict(path=str(p), size=p.stat().st_size, sha256=h.hexdigest()))
(O / 'STAGE_PROVENANCE.json').write_text(json.dumps({'inputs': inputs, 'public_raw_archive_policy': 'Original public archives are optional provenance sources; this analysis uses the four bundled derived inputs. Absence does not alter the numerical model.', 'script': str(Path(__file__).resolve()), 'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'seed': 20260922, 'contrasts_fixed_before_reading_full_matrix_results': ['Early_primary', 'Advanced_primary', 'Extracranial_metastasis'], 'patient_pooling': 'mLN and PE pooled within author patient id, so repeat sites are not independent'}, indent=2))
print(t.to_string(index=False))
print('COMPLETE')
