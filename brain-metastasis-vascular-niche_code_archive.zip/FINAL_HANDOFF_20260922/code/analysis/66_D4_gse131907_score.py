# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os, json, time, numpy as np, pandas as pd, scanpy as sc, scipy.io, scipy.sparse as sp
from scipy.stats import mannwhitneyu
B = str(_HANDOFF_ROOT / '')
R = f'{B}/results/external_replication'
D = f'{R}/D4'
L = open(f'{D}/progress.txt', 'a', buffering=1)
log = lambda *a: L.write(time.strftime('[%H:%M:%S] ') + ' '.join(map(str, a)) + '\n')
J = json.load(open(f'{R}/D2/signatures_used.json'))
SIG = J['signatures']
SIG2LIN = J['lineage']
LIN = {'髓系': ['PTPRC', 'CD68', 'CD14', 'AIF1', 'CSF1R', 'C1QA', 'LYZ', 'TYROBP', 'FCER1G'], 'T/NK': ['CD3E', 'CD3D', 'CD2', 'NKG7', 'GNLY', 'TRAC', 'CD8A', 'IL7R'], '基质/血管': ['PDGFRB', 'RGS5', 'COL1A2', 'DCN', 'CLDN5', 'VWF', 'PECAM1', 'ACTA2'], '上皮/肿瘤': ['EPCAM', 'KRT8', 'KRT18', 'KRT19'], 'B': ['MS4A1', 'CD79A', 'CD79B', 'CD19']}
log('读取 mtx ...')
M = scipy.io.mmread(f'{D}/matrix.mtx').tocsr().T.astype(np.float32)
genes = pd.read_csv(f'{D}/features.tsv', header=None, sep='\t')[0].values
bcs = pd.read_csv(f'{D}/barcodes.tsv', header=None, sep='\t')[0].values
ann = pd.read_csv(f'{D}/cell_annotation_subset.csv')
ann.index = ann['Index'].values
ann = ann.reindex(bcs)
a = sc.AnnData(M, obs=ann, var=pd.DataFrame(index=genes))
a.var_names_make_unique()
log('AnnData', a.shape, a.obs.Sample_Origin.value_counts().to_dict())
sc.pp.filter_genes(a, min_cells=3)
sc.pp.normalize_total(a, target_sum=10000.0)
sc.pp.log1p(a)
LS = pd.DataFrame(index=a.obs_names)
for (l, g) in LIN.items():
    gg = [x for x in g if x in a.var_names]
    LS[l] = np.asarray(a[:, gg].X.mean(axis=1)).ravel()
lin = LS.idxmax(axis=1).where(LS.max(axis=1) > 0.3, '其他')
a.obs['lineage_gate'] = lin.values
percell = a.obs[['Sample', 'Sample_Origin', 'Cell_type', 'Cell_subtype', 'lineage_gate']].copy()
rows = []
for (c, g) in SIG.items():
    gg = [x for x in g if x in a.var_names]
    if len(gg) < 3:
        continue
    sc.tl.score_genes(a, gg, score_name='_s', ctrl_size=50, n_bins=25, random_state=0)
    s = a.obs['_s'].values
    det = np.asarray((a[:, gg].X > 0).sum(axis=1)).ravel()
    pos = (s > 0.15) & (det >= max(2, len(gg) // 2))
    percell[c] = pos
    percell[c + '_score'] = s
    l = SIG2LIN[c]
    den = (lin == l).values if l in LIN else np.ones(len(lin), bool)
    for (smp, idx) in a.obs.groupby('Sample').indices.items():
        d = den[idx]
        p = pos[idx]
        rows.append(dict(sample=smp, origin=a.obs.Sample_Origin.iloc[idx[0]], signature=c, lineage=l, n_genes=len(gg), n_cells=len(idx), n_lineage_cells=int(d.sum()), n_positive=int((p & d).sum()), frac_of_lineage=round(float((p & d).sum() / max(d.sum(), 1)), 4), frac_of_all=round(float(p.mean()), 4), mean_score_lineage=round(float(s[idx][d].mean()) if d.sum() else np.nan, 4)))
    log(c, '完成')
res = pd.DataFrame(rows)
res.to_csv(f'{D}/D4_signature_frequency_by_sample.csv', index=False)
percell.to_csv(f'{D}/D4_percell.csv.gz', compression='gzip')
cmp = []
for (c, sub) in res.groupby('signature'):
    sub = sub[sub.n_lineage_cells >= 20]
    for (o1, o2) in [('mBrain', 'tLung'), ('mBrain', 'nLung'), ('tLung', 'nLung')]:
        x = sub[sub.origin == o1].frac_of_lineage
        y = sub[sub.origin == o2].frac_of_lineage
        if len(x) >= 3 and len(y) >= 3:
            p = mannwhitneyu(x, y, alternative='two-sided').pvalue
            cmp.append(dict(signature=c, lineage=sub.lineage.iloc[0], group1=o1, group2=o2, n1=len(x), n2=len(y), median1=round(x.median(), 4), median2=round(y.median(), 4), mean1=round(x.mean(), 4), mean2=round(y.mean(), 4), mwu_p=p))
cmp = pd.DataFrame(cmp).sort_values('mwu_p')
cmp.to_csv(f'{D}/D4_group_comparison.csv', index=False)
ct = pd.crosstab(a.obs.Cell_type, a.obs.lineage_gate)
ct.to_csv(f'{D}/D4_author_celltype_vs_our_gate.csv')
enr = []
for c in SIG:
    if c not in percell:
        continue
    t = percell.groupby('Cell_subtype')[c].agg(['mean', 'sum', 'size']).sort_values('mean', ascending=False)
    for (st, r) in t.head(3).iterrows():
        enr.append(dict(signature=c, author_subtype=st, frac_positive=round(r['mean'], 4), n_positive=int(r['sum']), n_subtype=int(r['size'])))
pd.DataFrame(enr).to_csv(f'{D}/D4_signature_top_author_subtypes.csv', index=False)
log('全部完成')
