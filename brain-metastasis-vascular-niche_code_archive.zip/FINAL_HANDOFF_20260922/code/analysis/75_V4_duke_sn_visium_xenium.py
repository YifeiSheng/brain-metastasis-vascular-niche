# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os, re, glob, gzip, time, json, numpy as np, pandas as pd, scanpy as sc, scipy.io, scipy.sparse as sp
from sklearn.neighbors import NearestNeighbors, KDTree, radius_neighbors_graph
from scipy.stats import mannwhitneyu
B = str(_HANDOFF_ROOT / '')
E = f'{B}/data/external/scrna/GSE325196/raw'
EX = f'{B}/data/external/spatial/GSE325935/raw'
O = f'{B}/results/vascular_niche/V4'
os.makedirs(O, exist_ok=True)
L = open(f'{O}/progress.txt', 'a', buffering=1)
log = lambda *a: L.write(time.strftime('[%H:%M:%S] ') + ' '.join(map(str, a)) + '\n')
rng = np.random.default_rng(0)
meta = pd.read_csv(f'{B}/data/external/scrna/GSE325196/sample_meta.tsv', sep='\t', header=None, names=['gsm', 'title', 'ch'])
meta['cancer'] = meta.ch.str.extract('cell type: ([^;]+)')[0].str.strip()
meta['spec'] = meta.title.str.extract('(\\d{2}-\\d{4})')[0]
meta['kind'] = np.where(meta.title.str.startswith('Visium'), 'visium', 'sn')

def opn(p):
    return gzip.open(p, 'rt') if open(p, 'rb').read(2) == b'\x1f\x8b' else open(p, 'rt')

def read_trio(pre):
    M = scipy.io.mmread(pre + '_matrix.mtx.gz').tocsr().T.astype(np.float32)
    bc = [l.strip() for l in opn(pre + '_barcodes.tsv.gz') if l.strip()]
    ft = [l.strip().split('\t') for l in opn(pre + '_features.tsv.gz') if l.strip()]
    genes = [f[1] if len(f) > 1 else f[0] for f in ft]
    a = sc.AnnData(M, obs=pd.DataFrame(index=bc), var=pd.DataFrame(index=genes))
    a.var_names_make_unique()
    return a
PERI = ['CSPG4', 'NOTCH3', 'RGS5', 'PDGFRB', 'KCNJ8', 'HIGD1B', 'NDUFA4L2', 'ACTA2', 'TAGLN']
FIB = ['DCN', 'LUM', 'COL1A1', 'COL1A2', 'COL3A1', 'FBLN1', 'PRRX1']
TUMOR = {'NSCLC': ['EPCAM', 'KRT8', 'KRT18', 'KRT7', 'NAPSA', 'NKX2-1', 'SFTPB', 'MUC1'], 'SCLC': ['EPCAM', 'KRT8', 'KRT18', 'INSM1', 'CHGA', 'SYP', 'ASCL1', 'NEUROD1'], 'BC': ['EPCAM', 'KRT8', 'KRT18', 'KRT19', 'ESR1', 'ERBB2', 'GATA3', 'KRT7'], 'Melanoma': ['MLANA', 'PMEL', 'MITF', 'TYR', 'DCT', 'S100B', 'SOX10', 'PRAME'], 'Sarcoma': ['VIM', 'MKI67', 'TOP2A', 'COL1A1', 'CD99']}

def tkey(c):
    return 'BC' if 'BC' in str(c) else str(c)
LIN = {'EC': ['PECAM1', 'CDH5', 'CLDN5', 'VWF', 'FLT1'], 'stroma': ['PDGFRB', 'RGS5', 'COL1A2', 'DCN', 'LUM', 'ACTA2', 'NOTCH3'], 'myeloid': ['PTPRC', 'CD68', 'CD163', 'C1QA', 'AIF1', 'CSF1R'], 'lymphoid': ['CD3E', 'CD2', 'NKG7', 'MS4A1', 'CD79A'], 'CNS': ['GFAP', 'AQP4', 'PLP1', 'MBP', 'SNAP25', 'MOBP']}

def det(a, g):
    return np.asarray((a[:, g].X > 0).sum(axis=1)).ravel().astype(int) if g in a.var_names else np.zeros(a.n_obs, int)

def mean_of(a, gs):
    gs = [g for g in gs if g in a.var_names]
    return np.asarray(a[:, gs].X.mean(axis=1)).ravel() if gs else np.zeros(a.n_obs)
rows = []
pcs = []
for (_, m) in meta[meta.kind == 'sn'].iterrows():
    pre = glob.glob(f'{E}/{m.gsm}_S_*_matrix.mtx.gz')
    if not pre:
        log('缺', m.title)
        continue
    a = read_trio(pre[0].replace('_matrix.mtx.gz', ''))
    sc.pp.filter_cells(a, min_genes=300)
    a.var['mt'] = a.var_names.str.startswith('MT-')
    sc.pp.calculate_qc_metrics(a, qc_vars=['mt'], inplace=True)
    a = a[a.obs.pct_counts_mt < 10].copy()
    sc.pp.filter_genes(a, min_cells=3)
    sc.pp.normalize_total(a, target_sum=10000.0)
    sc.pp.log1p(a)
    lin = dict(LIN)
    lin['tumor'] = TUMOR[tkey(m.cancer)]
    LS = pd.DataFrame({k: mean_of(a, v) for (k, v) in lin.items()}, index=a.obs_names)
    gate = LS.idxmax(axis=1).where(LS.max(axis=1) > 0.3, 'other').values
    st = gate == 'stroma'
    ec = gate == 'EC'
    my = gate == 'myeloid'
    for (nm, gs) in [('peri', PERI), ('fib', FIB)]:
        gg = [g for g in gs if g in a.var_names]
        sc.tl.score_genes(a, gg, score_name=nm, ctrl_size=50, n_bins=25, random_state=0)
        a.obs[nm + '_ndet'] = np.asarray((a[:, gg].X > 0).sum(axis=1)).ravel()
    peri = (a.obs.peri > 0.15) & (a.obs.peri_ndet >= 4)
    fib = (a.obs.fib > 0.15) & (a.obs.fib_ndet >= 4)
    pd_ = sum((det(a, g) for g in ['NOTCH3', 'RGS5', 'KCNJ8', 'HIGD1B', 'PDGFRB', 'CSPG4', 'NDUFA4L2']))
    fd_ = sum((det(a, g) for g in ['DCN', 'LUM', 'COL1A2', 'COL1A1', 'FBLN1', 'PRRX1', 'COL3A1']))
    peri2 = (pd_ >= 2) & (pd_ > fd_)
    fib2 = (fd_ >= 2) & (fd_ > pd_)
    pc = pd.DataFrame({'sample': m.spec, 'cancer': m.cancer, 'gate': gate, 'peri_ndet': pd_, 'fib_ndet': fd_, 'ABCB1': det(a, 'ABCB1'), 'ANGPT2': det(a, 'ANGPT2'), 'PLVAP': det(a, 'PLVAP'), 'NOTCH3': det(a, 'NOTCH3')}, index=a.obs_names)
    pcs.append(pc[np.isin(gate, ['stroma', 'EC'])])
    rows.append(dict(sample=m.spec, cancer=m.cancer, n_cells=a.n_obs, n_stroma=int(st.sum()), n_EC=int(ec.sum()), n_myeloid=int(my.sum()), n_tumor=int((gate == 'tumor').sum()), peri2_frac_of_stroma=round(float(peri2[st].mean()) if st.sum() else np.nan, 4), fib2_frac_of_stroma=round(float(fib2[st].mean()) if st.sum() else np.nan, 4), peri2_over_peri2_fib2=round(float(peri2[st].sum() / max((peri2[st] | fib2[st]).sum(), 1)) if st.sum() else np.nan, 4), peri_frac_of_stroma=round(float(peri[st].mean()) if st.sum() else np.nan, 4), fib_frac_of_stroma=round(float(fib[st].mean()) if st.sum() else np.nan, 4), peri_over_peri_fib=round(float(peri[st].sum() / max((peri[st] | fib[st]).sum(), 1)) if st.sum() else np.nan, 4), NOTCH3_in_stroma=round(float(det(a, 'NOTCH3')[st].mean()) if st.sum() else np.nan, 4), ABCB1_in_EC=round(float(det(a, 'ABCB1')[ec].mean()) if ec.sum() else np.nan, 4), ANGPT2_in_EC=round(float(det(a, 'ANGPT2')[ec].mean()) if ec.sum() else np.nan, 4), ABCB1_and_ANGPT2_in_EC=round(float(((det(a, 'ABCB1') == 1) & (det(a, 'ANGPT2') == 1))[ec].mean()) if ec.sum() else np.nan, 4), PLVAP_in_EC=round(float(det(a, 'PLVAP')[ec].mean()) if ec.sum() else np.nan, 4), BAM_in_myeloid=round(float((det(a, 'F13A1') + det(a, 'LYVE1') + det(a, 'CD209') + det(a, 'COLEC12') >= 2)[my].mean()) if my.sum() else np.nan, 4)))
    log('sn', m.spec, m.cancer, a.n_obs, '核; 间质', int(st.sum()), '内皮', int(ec.sum()))
sn = pd.DataFrame(rows)
sn.to_csv(f'{O}/V4_snrna_composition.csv', index=False)
pd.concat(pcs).to_csv(f'{O}/V4_snrna_percell_stroma_EC.csv.gz', compression='gzip')
log('snRNA 完成')
import sys
if os.path.exists(f'{O}/V4_xenium_neighbor.csv'):
    log('Visium/Xenium 已有结果, 跳过')
    sys.exit(0)

def read_positions(p):
    d = pd.read_csv(p, header=None if 'list' in p else 0)
    if d.shape[1] == 6 and (not str(d.iloc[0, 0]).startswith('barcode')):
        d.columns = ['barcode', 'in_tissue', 'row', 'col', 'py', 'px']
    else:
        d.columns = ['barcode', 'in_tissue', 'row', 'col', 'py', 'px']
    return d.set_index('barcode')
vrows = []
vpair = []
TRI = [('NOTCH3', 'HIGD1B', 'CLDN5'), ('RGS5', 'HIGD1B', 'NDUFA4L2'), ('PDGFB', 'PDGFRB'), ('F13A1', 'NOTCH3'), ('LYVE1', 'CD209', 'F13A1'), ('ABCB1', 'ANGPT2'), ('JAG1', 'NOTCH3'), ('DLL4', 'NOTCH3')]
for (_, m) in meta[meta.kind == 'visium'].iterrows():
    pre = glob.glob(f'{E}/{m.gsm}_V_*_matrix.mtx.gz')
    if not pre:
        log('缺 Visium', m.title)
        continue
    pre = pre[0].replace('_matrix.mtx.gz', '')
    v = read_trio(pre)
    pos = read_positions(pre + '_tissue_positions_list.csv.gz').reindex(v.obs_names)
    v = v[pos.in_tissue.fillna(0).astype(int) == 1].copy()
    pos = pos.reindex(v.obs_names)
    xy = pos[['px', 'py']].values.astype(float)
    sc.pp.filter_genes(v, min_cells=3)
    sc.pp.normalize_total(v, target_sum=10000.0)
    sc.pp.log1p(v)
    tp = [g for g in TUMOR[tkey(m.cancer)] if g in v.var_names]
    bp = [g for g in ['GFAP', 'AQP4', 'PLP1', 'MBP', 'MOBP', 'MOG', 'SNAP25', 'SYT1', 'GJA1', 'SLC1A2'] if g in v.var_names]
    t = mean_of(v, tp)
    b = mean_of(v, bp)
    band = np.where((t >= 0.5) & (b < 0.5), 'tumor', np.where((b >= 0.5) & (t < 0.5), 'brain', np.where((t >= 0.5) & (b >= 0.5), 'interface', 'other')))
    D = {g: det(v, g) for g in ['NOTCH3', 'RGS5', 'HIGD1B', 'PDGFRB', 'CLDN5', 'PDGFB', 'ABCB1', 'ANGPT2', 'PLVAP', 'F13A1', 'LYVE1', 'CD209', 'JAG1', 'DLL4', 'NDUFA4L2']}
    r = dict(sample=m.spec, cancer=m.cancer, n_spots=v.n_obs, frac_tumor=round(float((band == 'tumor').mean()), 3), frac_brain=round(float((band == 'brain').mean()), 3))
    for g in ['NOTCH3', 'RGS5', 'PDGFRB', 'CLDN5', 'ABCB1', 'ANGPT2', 'PLVAP', 'F13A1']:
        r[f'det_{g}'] = round(float(D[g].mean()), 4)
        r[f'det_{g}_tumorband'] = round(float(D[g][band == 'tumor'].mean()) if (band == 'tumor').sum() >= 20 else np.nan, 4)
    vrows.append(r)
    for tri in TRI:
        hi = []
        for g in tri:
            if g not in v.var_names or D[g].sum() < 20:
                hi = None
                break
            x = np.asarray(v[:, g].X.todense()).ravel()
            thr = np.quantile(x[x > 0], 0.75)
            hi.append(x >= thr)
        if hi is None:
            vpair.append(dict(sample=m.spec, cancer=m.cancer, pair='-'.join(tri), note='阳性 spot<20'))
            continue
        obs = int(np.all(hi, axis=0).sum())
        null = []
        for _ in range(200):
            null.append(int(np.all([rng.permutation(h) for h in hi], axis=0).sum()))
        null = np.array(null)
        vpair.append(dict(sample=m.spec, cancer=m.cancer, pair='-'.join(tri), n_high=[int(h.sum()) for h in hi], obs=obs, null_mean=round(float(null.mean()), 2), obs_over_null=round(obs / max(null.mean(), 1e-06), 2), z=round(float((obs - null.mean()) / (null.std() + 1e-09)), 2), p=float(((null >= obs).sum() + 1) / (len(null) + 1))))
    log('visium', m.spec, m.cancer, v.n_obs, 'spots; 带:', dict(pd.Series(band).value_counts()))
pd.DataFrame(vrows).to_csv(f'{O}/V4_visium_detection.csv', index=False)
pd.DataFrame(vpair).to_csv(f'{O}/V4_visium_cooccurrence.csv', index=False)
log('Visium 完成')
xrows = []
xpair = []
for h5 in sorted(glob.glob(f'{EX}/*cell_feature_matrix.h5')):
    pre = h5.replace('_cell_feature_matrix.h5', '')
    name = os.path.basename(pre).split('_', 1)[1]
    a = sc.read_10x_h5(h5, gex_only=False)
    a = a[:, a.var.feature_types == 'Gene Expression'].copy()
    a.var_names_make_unique()
    pq = pre + '_cells.parquet'
    if not os.path.exists(pq):
        os.system(f'zcat {pre}_cells.parquet.gz > {pq}')
    cells = pd.read_parquet(pq)
    cells.index = cells.cell_id.astype(str)
    a.obs = a.obs.join(cells[['x_centroid', 'y_centroid', 'transcript_counts', 'cell_area']], how='left')
    a = a[(a.obs.transcript_counts >= 20) & a.obs.x_centroid.notna()].copy()
    X = a.X.tocsr()

    def cnt(g):
        return np.asarray(X[:, list(a.var_names).index(g)].todense()).ravel() if g in a.var_names else np.zeros(a.n_obs)
    ec = cnt('PECAM1') + cnt('VWF') >= 3
    mural = cnt('PDGFRB') + cnt('ACTA2') + cnt('MYH11') >= 3
    tumor = cnt('EPCAM') + cnt('KRT8') >= 5
    mac = cnt('CD163') + cnt('MRC1') >= 3
    tcell = cnt('CD3E') >= 2
    mural = mural & ~ec & ~tumor
    ec = ec & ~tumor
    xy = a.obs[['x_centroid', 'y_centroid']].values.astype(float)
    tree = KDTree(xy)
    n = a.n_obs
    GR = {r: radius_neighbors_graph(xy, r, mode='connectivity', include_self=False).tocsr() for r in [15, 30, 60]}

    def neigh_frac(A, Bm, r):
        return float((GR[r][A] @ Bm.astype(np.int32) > 0).mean())
    for (a_, Am, b_, Bm) in [('壁细胞', mural, 'EC', ec), ('EC', ec, '壁细胞', mural), ('壁细胞', mural, '肿瘤', tumor), ('EC', ec, '肿瘤', tumor), ('巨噬', mac, '壁细胞', mural), ('T', tcell, 'EC', ec)]:
        A = np.where(Am)[0]
        nb = int(Bm.sum())
        if len(A) < 50 or nb < 50:
            continue
        for r in [15, 30, 60]:
            obs = neigh_frac(A, Bm, r)
            null = []
            for _ in range(50):
                pm = np.zeros(n, bool)
                pm[rng.choice(n, nb, replace=False)] = True
                null.append(neigh_frac(A, pm, r))
            null = np.array(null)
            xpair.append(dict(sample=name, pair=f'{a_}-{b_}', radius_um=r, n_A=len(A), n_B=nb, obs_frac=round(obs, 4), null_frac=round(float(null.mean()), 4), obs_over_null=round(obs / max(null.mean(), 1e-06), 3), z=round(float((obs - null.mean()) / (null.std() + 1e-09)), 2)))
    T = np.where(tumor)[0]
    E_ = np.where(ec)[0]
    if len(T) >= 100 and len(E_) >= 100:
        (dd, _) = KDTree(xy[T]).query(xy[E_], k=1)
        dd = dd[:, 0]
        near = E_[dd <= 30]
        far = E_[dd > 100]
        xrows.append(dict(sample=name, n_cells=n, n_EC=len(E_), n_mural=int(mural.sum()), n_tumor=len(T), mural_over_mural_plus_fib=np.nan, EC_near_tumor=len(near), EC_far=len(far), ANGPT2_EC_near=round(float((cnt('ANGPT2')[near] > 0).mean()) if len(near) else np.nan, 4), ANGPT2_EC_far=round(float((cnt('ANGPT2')[far] > 0).mean()) if len(far) else np.nan, 4), ESM1_EC_near=round(float((cnt('ESM1')[near] > 0).mean()) if len(near) else np.nan, 4), ESM1_EC_far=round(float((cnt('ESM1')[far] > 0).mean()) if len(far) else np.nan, 4), mural_per_EC=round(float(mural.sum() / max(ec.sum(), 1)), 3), frac_EC_with_mural_15um=round(neigh_frac(E_, mural, 15), 4)))
    log('xenium', name, n, '细胞; EC', int(ec.sum()), '壁细胞', int(mural.sum()), '肿瘤', int(tumor.sum()))
pd.DataFrame(xrows).to_csv(f'{O}/V4_xenium_summary.csv', index=False)
pd.DataFrame(xpair).to_csv(f'{O}/V4_xenium_neighbor.csv', index=False)
log('全部完成')
