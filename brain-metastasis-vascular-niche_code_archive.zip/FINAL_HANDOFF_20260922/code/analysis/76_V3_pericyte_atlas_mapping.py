# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os, glob, re, time, numpy as np, pandas as pd, scanpy as sc, anndata as ad, scipy.io, celltypist, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
font_manager.fontManager.addfont(str(_HANDOFF_ROOT / 'environment/NotoSansCJKsc-Regular.otf'))
plt.rcParams['font.family'] = ['Noto Sans CJK SC', 'DejaVu Sans']
os.environ['OMP_NUM_THREADS'] = '8'
sc.settings.n_jobs = 8
B = str(_HANDOFF_ROOT / '')
Y = f'{B}/data/external/scrna/GSE163577/raw'
O = f'{B}/results/vascular_niche/V3'
os.makedirs(O, exist_ok=True)
L = open(f'{O}/progress.txt', 'a', buffering=1)
log = lambda *a: L.write(time.strftime('[%H:%M:%S] ') + ' '.join(map(str, a)) + '\n')
meta = pd.read_csv(f'{B}/data/external/scrna/GSE163577/sample_meta.tsv', sep='\t', header=None, names=['gsm', 'title', 'ch'])
dirs = {os.path.basename(t).split('_')[0]: f'{Y}/' + os.path.basename(t)[len(os.path.basename(t).split('_')[0]) + 1:].replace('.tar.gz', '') for t in glob.glob(f'{Y}/GSM*_filtered_feature_bc_matrix.tar.gz')}
meta['dir'] = meta.gsm.map(dirs)
meta['disease'] = meta.ch.str.extract('disease: ([^;]+)')[0].str.strip()
meta['region'] = meta.ch.str.extract('brain region: ([^;]+)')[0].str.strip()
ctrl = meta[(meta.disease == 'Control') & meta.dir.notna()]
log('Control 样本', len(ctrl), ctrl.region.value_counts().to_dict())
ads = []
for (_, m) in ctrl.iterrows():
    a = sc.read_10x_mtx(m.dir)
    a.var_names_make_unique()
    a.obs['sample'] = m.gsm
    a.obs['region'] = m.region
    a.obs_names = [f'{m.gsm}_{x}' for x in a.obs_names]
    ads.append(a)
ref = ad.concat(ads, join='inner')
ref.var_names_make_unique()
sc.pp.filter_cells(ref, min_genes=500)
ref.var['mt'] = ref.var_names.str.startswith('MT-')
sc.pp.calculate_qc_metrics(ref, qc_vars=['mt'], inplace=True)
ref = ref[ref.obs.pct_counts_mt < 5].copy()
sc.pp.filter_genes(ref, min_cells=10)
ref.layers['counts'] = ref.X.copy()
sc.pp.normalize_total(ref, target_sum=10000.0)
sc.pp.log1p(ref)
log('参考核数', ref.n_obs, '基因', ref.n_vars)

def mean_of(a, gs):
    gs = [g for g in gs if g in a.var_names]
    return np.asarray(a[:, gs].X.mean(axis=1)).ravel() if gs else np.zeros(a.n_obs)
G = {'mural': ['PDGFRB', 'RGS5', 'NOTCH3', 'KCNJ8', 'ABCC9', 'ACTA2', 'MYH11', 'TAGLN'], 'EC': ['CLDN5', 'FLT1', 'PECAM1', 'VWF', 'ABCB1', 'MFSD2A'], 'fibro': ['DCN', 'LUM', 'ABCA10', 'LAMA2', 'FBLN1', 'COL1A2', 'CEMIP'], 'astro': ['AQP4', 'GFAP', 'SLC1A2', 'ALDH1L1'], 'oligo': ['PLP1', 'MBP', 'MOBP', 'ST18'], 'micro': ['P2RY12', 'CX3CR1', 'CSF1R', 'PTPRC'], 'neuron': ['RBFOX3', 'SYT1', 'SNAP25', 'GAD1']}
LS = pd.DataFrame({k: mean_of(ref, v) for (k, v) in G.items()}, index=ref.obs_names)
ref.obs['compartment'] = LS.idxmax(axis=1).where(LS.max(axis=1) > 0.3, 'other').values
log('门控:', ref.obs.compartment.value_counts().to_dict())
vasc = ref[ref.obs.compartment.isin(['mural', 'EC', 'fibro'])].copy()

def subcluster(a, res=0.6):
    a = a.copy()
    sc.pp.highly_variable_genes(a, n_top_genes=2000, batch_key='sample')
    sc.pp.pca(a, n_comps=30, mask_var='highly_variable')
    sc.pp.neighbors(a, n_neighbors=15, method='gauss')
    sc.tl.leiden(a, resolution=res, key_added='sub', flavor='igraph', n_iterations=2, directed=False)
    return a
mur = subcluster(vasc[vasc.obs.compartment.isin(['mural', 'fibro'])])
ecs = subcluster(vasc[vasc.obs.compartment == 'EC'])
MK = {'平滑肌': ['ACTA2', 'MYH11', 'TAGLN', 'CNN1', 'MYL9', 'LMOD1'], '周细胞': ['PDGFRB', 'RGS5', 'KCNJ8', 'ABCC9', 'HIGD1B', 'NDUFA4L2', 'CSPG4'], '血管周成纤维': ['DCN', 'LUM', 'ABCA10', 'LAMA2', 'FBLN1', 'COL1A2', 'CEMIP', 'KCNMA1']}
EK = {'内皮_动脉': ['VEGFC', 'SEMA3G', 'HEY1', 'GJA5', 'BMX', 'FBLN5', 'IGFBP3'], '内皮_毛细血管': ['MFSD2A', 'SLC7A5', 'ABCB1', 'SLC2A1', 'CA4', 'SLC16A1', 'TFRC'], '内皮_静脉': ['ACKR1', 'NR2F2', 'IL1R1', 'VCAM1', 'SELE', 'SELP', 'CCL2']}

def annotate(a, MK, key='sub'):
    sc.tl.rank_genes_groups(a, key, method='wilcoxon', n_genes=100)
    lab = {}
    info = []
    scores = pd.DataFrame({k: mean_of(a, v) for (k, v) in MK.items()}, index=a.obs_names)
    for c in a.obs[key].cat.categories:
        idx = (a.obs[key] == c).values
        z = (scores[idx].mean() - scores.mean()) / (scores.std() + 1e-09)
        best = z.idxmax()
        lab[c] = best
        top = [g for g in pd.DataFrame(a.uns['rank_genes_groups']['names'])[c].tolist()[:60]]
        info.append(dict(cluster=c, n=int(idx.sum()), label=best, z=z.round(2).to_dict(), top_markers=','.join(top[:25]), n_SLC=sum((g.startswith('SLC') for g in top)), n_ECM=sum((bool(re.match('^(COL\\d|LAM[ABC]\\d|FN1|FBN|SPARC|LUM|DCN|ELN|VCAN|HSPG2|NID)', g)) for g in top))))
    return (lab, pd.DataFrame(info))
(labM, infoM) = annotate(mur, MK)
(labE, infoE) = annotate(ecs, EK)
for (i, r) in infoM.iterrows():
    if r.label == '周细胞':
        infoM.loc[i, 'label'] = '周细胞_T型' if r.n_SLC >= r.n_ECM else '周细胞_M型'
labM = {r.cluster: r.label for (_, r) in infoM.iterrows()}
mur.obs['label'] = mur.obs['sub'].map(labM).values
ecs.obs['label'] = ecs.obs['sub'].map(labE).values
infoM.to_csv(f'{O}/V3_reference_mural_clusters.csv', index=False)
infoE.to_csv(f'{O}/V3_reference_EC_clusters.csv', index=False)
log('壁细胞/成纤维 标签:', mur.obs.label.value_counts().to_dict())
log('内皮 标签:', ecs.obs.label.value_counts().to_dict())
refv = ad.concat([mur, ecs], join='inner')
refv.obs['label'] = refv.obs['label'].astype(str)
sc.tl.rank_genes_groups(refv, 'label', method='wilcoxon', n_genes=50)
pd.DataFrame(refv.uns['rank_genes_groups']['names']).to_csv(f'{O}/V3_reference_label_markers.csv', index=False)
model = celltypist.train(refv, labels='label', n_jobs=8, feature_selection=True, top_genes=300, check_expression=False, max_iter=200)
model.write(f'{O}/V3_yang2022_vascular_model.pkl')
log('模型训练完成')
sc.pp.highly_variable_genes(refv, n_top_genes=2000, batch_key='sample')
sc.pp.pca(refv, n_comps=30, mask_var='highly_variable')
sc.pl.pca(refv, color='label', show=False, legend_loc='on data', legend_fontsize=7, title='Yang 2022 正常脑血管参考 (Control, PCA)')
plt.savefig(f'{O}/V3_reference_pca.png', dpi=120, bbox_inches='tight')
plt.close()

def predict(a, source):
    sc.pp.normalize_total(a, target_sum=10000.0)
    sc.pp.log1p(a)
    p = celltypist.annotate(a, model=model, majority_voting=False)
    df = p.predicted_labels.copy()
    df['conf'] = p.probability_matrix.max(axis=1).values
    df['source'] = source
    return df
outs = []
lab = pd.read_csv(f'{B}/data/integrated/per_cell_labels.csv', usecols=['cell', 'patient_id', 'lineage_l1', 'proposed_label']).set_index('cell')
ours = sc.read_h5ad(f'{B}/data/integrated/final_integrated_annotated.h5ad')
keep = lab.index[lab.lineage_l1.isin(['基质', '内皮'])]
ours = ours[ours.obs_names.isin(keep)].copy()
ours.var_names_make_unique()
peri = [g for g in ['CSPG4', 'NOTCH3', 'RGS5', 'PDGFRB', 'KCNJ8', 'HIGD1B', 'NDUFA4L2'] if g in ours.var_names]
ours.obs['peri_ndet'] = np.asarray((ours[:, peri].X > 0).sum(axis=1)).ravel()
d = predict(ours, '我们_sc')
d['patient'] = lab.loc[d.index, 'patient_id'].values
d['lineage_l1'] = lab.loc[d.index, 'lineage_l1'].values
d['peri_ndet'] = ours.obs.loc[d.index, 'peri_ndet'].values
outs.append(d)
log('我们的细胞预测', len(d))
D4 = f'{B}/results/external_replication/D4'
ann = pd.read_csv(f'{D4}/cell_annotation_subset.csv')
ann.index = ann['Index'].values
bcs = pd.read_csv(f'{D4}/barcodes.tsv', header=None, sep='\t')[0].values
genes = pd.read_csv(f'{D4}/features.tsv', header=None, sep='\t')[0].values
sel = np.where(ann.reindex(bcs).Cell_type.isin(['Fibroblasts', 'Endothelial cells']).values)[0]
M = scipy.io.mmread(f'{D4}/matrix.mtx').tocsc()[:, sel].T.tocsr().astype(np.float32)
k = sc.AnnData(M, obs=ann.reindex(bcs[sel]), var=pd.DataFrame(index=genes))
k.var_names_make_unique()
d = predict(k, 'Kim2020')
d['origin'] = k.obs.Sample_Origin.values
d['author_subtype'] = k.obs.Cell_subtype.values
d['patient'] = k.obs.Sample.values
outs.append(d)
log('Kim 2020 预测', len(d))

def read_w(pre):
    M = scipy.io.mmread(f'{pre}_matrix.mtx.gz').tocsr().T.astype(np.float32)
    bc = pd.read_csv(f'{pre}_barcodes.tsv.gz', header=None)[0].values
    gf = f'{pre}_features.tsv.gz' if os.path.exists(f'{pre}_features.tsv.gz') else f'{pre}_genes.tsv.gz'
    ft = pd.read_csv(gf, header=None, sep='\t')
    a = sc.AnnData(M, obs=pd.DataFrame(index=bc), var=pd.DataFrame(index=(ft[1] if ft.shape[1] > 1 else ft[0]).values))
    a.var_names_make_unique()
    return a
W = f'{B}/data/external/scrna/GSE256493'
for (lst, root, src) in [('download_list.txt', 'raw', 'Wälchli_肺癌脑转移'), ('download_list_other.txt', 'raw_other', 'Wälchli_其他')]:
    for line in open(f'{W}/{lst}').read().splitlines():
        parts = line.split(' ', 3)
        (gsm, pre, name) = (parts[0], parts[1], parts[2])
        grp = parts[3] if len(parts) > 3 else '肺癌脑转移'
        if src == 'Wälchli_其他' and grp != '正常颞叶':
            continue
        a = read_w(f'{W}/{root}/{pre}')
        sc.pp.filter_cells(a, min_genes=300)
        a.var['mt'] = a.var_names.str.startswith('MT-')
        sc.pp.calculate_qc_metrics(a, qc_vars=['mt'], inplace=True)
        a = a[a.obs.pct_counts_mt < 20].copy()
        if a.n_obs < 50:
            continue
        d = predict(a, f'{src}_{grp}')
        d['patient'] = name
        d['sorted'] = 'EC_sorted' if name.endswith('_EC') else 'unsorted'
        outs.append(d)
        log('Wälchli', name, grp, len(d))
allp = pd.concat(outs)
allp.to_csv(f'{O}/V3_percell_predictions.csv.gz', compression='gzip')
allp['conf_ok'] = allp.conf >= 0.5
summ = allp.groupby(['source', 'predicted_labels']).size().unstack(fill_value=0)
summ.to_csv(f'{O}/V3_prediction_counts_by_source.csv')
summ_ok = allp[allp.conf_ok].groupby(['source', 'predicted_labels']).size().unstack(fill_value=0)
summ_ok.div(summ_ok.sum(axis=1), axis=0).round(3).to_csv(f'{O}/V3_prediction_fractions_conf50.csv')
log('全部完成')
