# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os, glob, numpy as np, pandas as pd, scanpy as sc, time
from sklearn.neighbors import KDTree, radius_neighbors_graph
B = str(_HANDOFF_ROOT / '')
EX = f'{B}/data/external/spatial/GSE325935/raw'
O = f'{B}/results/immune_glial_lymphoma/X_XENIUM_RARE'
os.makedirs(O, exist_ok=True)
L = open(f'{O}/progress.txt', 'a', buffering=1)
log = lambda *a: L.write(time.strftime('[%H:%M:%S] ') + ' '.join(map(str, a)) + '\n')
rng = np.random.default_rng(0)
rows = []
nb = []
for h5 in sorted(glob.glob(f'{EX}/*cell_feature_matrix.h5')):
    pre = h5.replace('_cell_feature_matrix.h5', '')
    name = os.path.basename(pre).split('_', 1)[1]
    a = sc.read_10x_h5(h5, gex_only=False)
    a = a[:, a.var.feature_types == 'Gene Expression'].copy()
    a.var_names_make_unique()
    pq = pre + '_cells.parquet'
    if not os.path.exists(pq):
        os.system(f'zcat {pre}_cells.parquet.gz > {pq}')
    cells = pd.read_parquet(pq)
    cells.index = cells.cell_id.astype(str)
    a.obs = a.obs.join(cells[['x_centroid', 'y_centroid', 'transcript_counts', 'cell_area']], how='left')
    a = a[(a.obs.transcript_counts >= 20) & a.obs.x_centroid.notna()].copy()
    X = a.X.tocsc()
    gi = {g: i for (i, g) in enumerate(a.var_names)}

    def cnt(g):
        return np.asarray(X[:, gi[g]].todense()).ravel() if g in gi else np.zeros(a.n_obs)
    ec = cnt('PECAM1') + cnt('VWF') >= 3
    tumor = cnt('EPCAM') + cnt('KRT8') >= 5
    tcell = cnt('CD3E') >= 2
    bcell = cnt('MS4A1') >= 2
    mast = (cnt('CPA3') >= 1) & (cnt('TPSAB1') >= 1) | (cnt('KIT') >= 2) & ((cnt('CPA3') >= 1) | (cnt('TPSAB1') >= 1))
    pdc = (cnt('LILRA4') >= 1) & (cnt('IL3RA') >= 1) & ~tumor
    cdc1 = (cnt('CLEC9A') >= 2) & ~tumor
    mreg = (cnt('CCR7') >= 2) & (cnt('CD83') >= 1) & ~tcell & ~bcell & ~tumor
    macro = cnt('CD163') + cnt('MRC1') >= 3
    brain = cnt('GFAP') + cnt('AQP4') + cnt('PLP1') + cnt('MBP') >= 4 if all((g in gi for g in ['GFAP', 'AQP4', 'PLP1', 'MBP'])) else np.zeros(a.n_obs, bool)
    xy = a.obs[['x_centroid', 'y_centroid']].values.astype(float)
    n = a.n_obs
    area = np.ptp(xy[:, 0]) * np.ptp(xy[:, 1]) / 1000000.0
    r = dict(sample=name, n_cells=n, n_EC=int(ec.sum()), n_tumor=int(tumor.sum()), n_T=int(tcell.sum()), n_mast=int(mast.sum()), n_pDC=int(pdc.sum()), n_cDC1=int(cdc1.sum()), n_mregDC=int(mreg.sum()), n_macro=int(macro.sum()), n_brain=int(brain.sum()), mast_per_10k=round(mast.sum() / n * 10000.0, 2), pDC_per_10k=round(pdc.sum() / n * 10000.0, 2), cDC1_per_10k=round(cdc1.sum() / n * 10000.0, 2), mregDC_per_10k=round(mreg.sum() / n * 10000.0, 2), T_per_10k=round(tcell.sum() / n * 10000.0, 1), macro_per_10k=round(macro.sum() / n * 10000.0, 1))
    GR = {rad: radius_neighbors_graph(xy, rad, mode='connectivity', include_self=False).tocsr() for rad in [15, 30]}
    for (lab, A) in [('mast', mast), ('pDC', pdc), ('cDC1', cdc1), ('mregDC', mreg), ('T', tcell), ('macro', macro)]:
        if A.sum() < 10:
            continue
        for (tgt, Bm) in [('EC', ec), ('tumor', tumor), ('brain', brain)]:
            if Bm.sum() < 50:
                continue
            for rad in [15, 30]:
                G = GR[rad]
                obs = float((G[A] @ Bm.astype(np.int32) > 0).mean())
                null = []
                for _ in range(50):
                    idx = rng.choice(np.where(~Bm)[0], A.sum(), replace=False)
                    null.append(float((G[idx] @ Bm.astype(np.int32) > 0).mean()))
                null = np.array(null)
                nb.append(dict(sample=name, cell=lab, target=tgt, radius_um=rad, n=int(A.sum()), obs_frac=round(obs, 4), null_frac=round(null.mean(), 4), enrich=round(obs / max(null.mean(), 1e-06), 2), z=round((obs - null.mean()) / (null.std() + 1e-09), 2)))
    rows.append(r)
    log(name, r)
    pd.DataFrame({'x': xy[:, 0], 'y': xy[:, 1], 'cls': np.select([mast, pdc, cdc1, mreg, ec, tumor, brain, tcell], ['mast', 'pDC', 'cDC1', 'mregDC', 'EC', 'tumor', 'brain', 'T'], 'other')}).to_csv(f'{O}/cells_{name}.csv.gz', index=False, compression='gzip')
pd.DataFrame(rows).to_csv(f'{O}/X_xenium_rare_counts.csv', index=False)
pd.DataFrame(nb).to_csv(f'{O}/X_xenium_rare_neighbor.csv', index=False)
log('完成')
