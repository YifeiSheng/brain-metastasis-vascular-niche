# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
"""L16 robustness and audit. Exact label-permutation at sample level; model specification sensitivity."""
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os
for k in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS']:
    os.environ[k] = '2'
from pathlib import Path
import itertools, math, json
import numpy as np, pandas as pd, statsmodels.api as sm, scanpy as sc
from scipy.stats import rankdata, spearmanr
from scipy.spatial import cKDTree
from statsmodels.stats.multitest import multipletests
B = Path(str(_HANDOFF_ROOT / ''))
O = B / 'results/spatial_distance_and_state_validation'
s = pd.read_csv(O / 'kim_pericyte_sample_scores.csv')
t = pd.read_csv(O / 'kim_pericyte_sample_tests.csv')
rng = np.random.default_rng(20260922)
for (i, r) in t.iterrows():
    z = s[(s.gate == r.gate) & (s.n_cells >= r.min_cells)]
    a = z[z.origin == 'mBrain'][r.metric].values
    b = z[z.origin == r.comparison.split()[-1]][r.metric].values
    ranks = rankdata(np.r_[a, b])
    n = len(a)
    N = len(ranks)
    expect = n * (N + 1) / 2
    obs = abs(ranks[:n].sum() - expect)
    nc = math.comb(N, n)
    if nc <= 100000:
        vals = np.array([abs(ranks[list(c)].sum() - expect) for c in itertools.combinations(range(N), n)])
        p = (vals >= obs - 1e-09).mean()
        method = 'exact all sample-label allocations'
    else:
        vals = np.array([abs(ranks[rng.choice(N, n, replace=False)].sum() - expect) for _ in range(19999)])
        p = ((vals >= obs - 1e-09).sum() + 1) / (len(vals) + 1)
        method = '19999 Monte Carlo allocations +1'
    t.loc[i, 'p_exact_or_MC'] = p
    t.loc[i, 'permutation_method'] = method
    t.loc[i, 'n_allocations'] = len(vals)
t['q_BH_permutation_all'] = multipletests(t.p_exact_or_MC, method='fdr_bh')[1]
t.to_csv(O / 'kim_pericyte_exact_tests.csv', index=False)
d = pd.read_csv(O / 'internal_cell_states.csv.gz', index_col='cell')
cols = ['VEGFA_det', 'PDGFB_det', 'VEGFA', 'PDGFB', 'PGF', 'FGF2', 'hypoxia', 'glycolysis', 'acetate', 'serine_synthesis', 'T_transport_ndet', 'M_matrix_ndet']
tb = d[d.tumor_scope != 'other']
cn = pd.read_csv(B / 'results/internal_programs_and_CNV/M7c_infercnv_multiref/M7c_luad_malignant_calls_hmm.csv').set_index('cell')
tb = tb.join(cn[['malignant_hmm']])
cnvs = []
for (p, z) in tb.groupby('patient_id'):
    for (scope, sel) in [('all', np.ones(len(z), bool)), ('tumor_tissue', z.tissue_role.eq('tumor').values), ('CNV_supported', z.malignant_hmm.eq(True).values)]:
        q = z[sel]
        if not len(q):
            continue
        cnvs.append(dict(patient=p, scope=scope, n=len(q), VEGFA_detection=float(q.VEGFA_det.mean()), PDGFB_detection=float(q.PDGFB_det.mean())))
pd.DataFrame(cnvs).to_csv(O / 'tumor_source_CNV_sensitivity.csv', index=False)
d.groupby(['patient_id', 'sample', 'tissue_role', 'lineage_l1'])[cols].mean().to_csv(O / 'internal_sample_lineage_checks.csv')
per = []
for k in [2, 3, 4]:
    for clean in [False, True]:
        z = d[(d.lineage_l1 == '基质') & (d.pericyte_identity_ndet >= k)]
        if clean:
            z = z[(z.epithelial_ndet < 2) & (z.endothelial_ndet < 2) & (z.astroglia_ndet < 2)]
        for (p, q) in z.groupby('patient_id'):
            for support in [1, 2]:
                T = q.T_transport_ndet >= support
                M = q.M_matrix_ndet >= support
                per.append(dict(patient=p, identity_min=k, screened=clean, support_min=support, n=len(q), T_n=int(T.sum()), M_n=int(M.sum()), both_n=int((T & M).sum())))
pd.DataFrame(per).to_csv(O / 'internal_pericyte_gate_sensitivity.csv', index=False)
rows = []
for h5 in sorted((B / 'data/external/spatial/GSE325935/raw').glob('*cell_feature_matrix.h5')):
    name = h5.name.split('_', 1)[1].replace('_cell_feature_matrix.h5', '')
    pre = str(h5).replace('_cell_feature_matrix.h5', '')
    a = sc.read_10x_h5(str(h5), gex_only=True)
    a.var_names_make_unique()
    c = pd.read_parquet(pre + '_cells.parquet')
    c.index = c.cell_id.astype(str)
    a.obs = a.obs.join(c[['x_centroid', 'y_centroid', 'transcript_counts', 'cell_area']])
    a = a[(a.obs.transcript_counts >= 20) & a.obs.x_centroid.notna()].copy()
    X = a.X.tocsc()
    gi = {g: i for (i, g) in enumerate(a.var_names)}

    def cnt(g):
        return X[:, gi[g]].toarray().ravel()
    er = cnt('PECAM1') + cnt('VWF') >= 3
    tr = cnt('EPCAM') + cnt('KRT8') >= 5
    ec = er & ~tr
    tu = tr & ~er
    xy = a.obs[['x_centroid', 'y_centroid']].values
    dist = cKDTree(xy[tu]).query(xy[ec])[0]
    tot = np.asarray(a.X.sum(axis=1)).ravel()
    base = pd.DataFrame({'y': np.log1p(cnt('ESM1')[ec] / np.maximum(tot[ec], 1) * 10000.0), 'logdist': np.log1p(dist), 'logdepth': np.log1p(tot[ec]), 'logarea': np.log1p(a.obs.cell_area.values[ec]), 'x': xy[ec, 0], 'ypos': xy[ec, 1]})
    groups = (base.x // 500).astype(int).astype(str) + '_' + (base.ypos // 500).astype(int).astype(str)
    tile = (base.x // 200).astype(int).astype(str) + '_' + (base.ypos // 200).astype(int).astype(str)
    for (spec, adj, fe) in [('unadjusted', False, False), ('depth_area', True, False), ('tile_FE', False, True), ('depth_area_tile_FE', True, True)]:
        cols = ['logdist'] + (['logdepth', 'logarea'] if adj else [])
        z = base[['y'] + cols].copy()
        if fe:
            z = z - z.groupby(tile).transform('mean')
        fit = sm.OLS(z.y, z[cols] if fe else sm.add_constant(z[cols])).fit(cov_type='cluster', cov_kwds={'groups': groups})
        rows.append(dict(slide=name, specification=spec, beta=float(fit.params.logdist), p=float(fit.pvalues.logdist), ci_low=float(fit.conf_int().loc['logdist', 0]), ci_high=float(fit.conf_int().loc['logdist', 1])))
    print('SENSITIVITY', name, flush=True)
r = pd.DataFrame(rows)
r['q_BH_16'] = multipletests(r.p, method='fdr_bh')[1]
r.to_csv(O / 'xenium_ESM1_model_sensitivity.csv', index=False)
print('EXACT KIM', t.query("gate=='pericyte_clean' and min_cells==20").to_string(index=False), flush=True)
print('COMPLETE', flush=True)
