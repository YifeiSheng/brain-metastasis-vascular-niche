# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
"""L17: full-transcriptome Slide-seq metabolism and distance to author-RCTD EC beads.
Sample-level results are descriptive; inferential unit is patient (replicate sections collapsed).
Distance is reported in source coordinate units: correlation/quantile contrasts do not require pixel scaling.
"""
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os
for k in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS']:
    os.environ[k] = '2'
from pathlib import Path
import numpy as np, pandas as pd, gzip, json, itertools, hashlib, re, time
from scipy.spatial import cKDTree
from scipy.stats import rankdata, wilcoxon
from statsmodels.stats.multitest import multipletests
B = Path(str(_HANDOFF_ROOT / ''))
O = B / 'results/nutrition'
E = B / 'data/external/scrna/GSE185386/raw'
S = json.load(open(O / 'gene_sets.json'))['sets']
GENES = sorted(set(sum(S.values(), [])))
rows = []
bins = []
cov = []
inputs = []
qc = []
for f in sorted(E.glob('*_slide_spatial_info.csv.gz')):
    name = f.name.split('_', 1)[1].replace('_slide_spatial_info.csv.gz', '')
    patient = name.split('_rep')[0]
    site = 'BM' if name.startswith('MBM') else 'ECM'
    counts = Path(str(f).replace('_spatial_info.csv.gz', '_raw_counts.csv.gz'))
    cache = O / (name + '_selected_counts.npz')
    info = pd.read_csv(f, index_col=0)
    if cache.exists():
        z = np.load(cache, allow_pickle=False)
        bc = z['barcodes']
        c = z['counts']
        tot = z['total']
        present = z['genes'].tolist()
    else:
        with gzip.open(counts, 'rt') as h:
            head = h.readline().rstrip().split(',')
            bc = np.array([x.strip('"') for x in head[1:]])
            tot = np.zeros(len(bc), float)
            select = {}
            for (j, line) in enumerate(h):
                split = line.find(',')
                g = line[:split].strip('"')
                v = np.fromstring(line[split + 1:], sep=',', dtype=np.float32)
                if len(v) != len(bc):
                    raise ValueError('Malformed count row ' + str(counts) + ' ' + g)
                tot += v
                g = {'ATP5A1': 'ATP5F1A', 'ATP5B': 'ATP5F1B'}.get(g, g)
                if g in GENES:
                    select[g] = v
        present = [g for g in GENES if g in select]
        c = np.column_stack([select[g] for g in present])
        np.savez_compressed(cache, barcodes=bc, counts=c, total=tot, genes=np.array(present))
    info = info.reindex(bc)
    xy = info[['xcoord', 'ycoord']].values
    valid = np.isfinite(xy).all(axis=1)
    labels = info.rctd_cell_type.astype(str).values
    ec = valid & (labels == 'Endothelial cells')
    tu = valid & (labels == 'Tumor cells')
    qc.append(dict(section=name, patient=patient, site=site, n_beads=len(bc), n_EC=int(ec.sum()), n_tumor=int(tu.sum()), n_panel_genes=len(present), n_expected=len(GENES)))
    if ec.sum() < 20 or tu.sum() < 200:
        print('SKIP', name, 'EC', ec.sum(), 'tumor', tu.sum(), flush=True)
        continue
    dist = np.full(len(bc), np.nan)
    dist[valid] = cKDTree(xy[ec]).query(xy[valid])[0]
    nnd = cKDTree(xy[valid]).query(xy[valid], k=2)[0][:, 1]
    nn = float(np.median(nnd[nnd > 0]))
    blockwidth = 20 * nn
    ex = np.log1p(c / np.maximum(tot[:, None], 1) * 10000.0)
    cs = pd.DataFrame({'cell': bc, 'section': name, 'patient': patient, 'site': site, 'author_type': labels, 'total_counts': tot, 'EC_distance_coordinate_units': dist, 'x': xy[:, 0], 'y': xy[:, 1]})
    for (k, gs) in S.items():
        jj = [present.index(g) for g in gs if g in present]
        cs[k] = ex[:, jj].mean(axis=1) if jj else np.full(len(ex), np.nan)
        cs[k + '_ndet'] = (c[:, jj] > 0).sum(axis=1)
    cs[tu].to_csv(O / (name + '_tumor_spatial_states.csv.gz'), index=False, compression='gzip')
    for (k, gs) in S.items():
        cov.append(dict(section=name, patient=patient, site=site, pathway=k, n_available=sum((g in present for g in gs)), n_expected=len(gs), available_genes=';'.join((g for g in gs if g in present)), missing_genes=';'.join((g for g in gs if g not in present))))
    for mincounts in [50, 100]:
        keep = tu & (tot >= mincounts)
        idx = np.where(keep)[0]
        if len(idx) < 200:
            continue
        di = dist[idx]
        dep = np.log1p(tot[idx])
        coord = xy[idx]
        bx = np.floor((coord - coord.min(axis=0)) / blockwidth).astype(int)
        block = pd.factorize(pd.Series([str(a) + '_' + str(b) for (a, b) in bx]))[0]
        near = di <= np.quantile(di, 0.25)
        far = di >= np.quantile(di, 0.75)
        for (k, gs) in S.items():
            jj = [present.index(g) for g in gs if g in present]
            yy = cs[k].values[idx]
            bins.append(dict(section=name, patient=patient, site=site, pathway=k, min_counts=mincounts, n_tumor=len(idx), n_EC=int(ec.sum()), n_genes=len(jj), distance_q25=float(np.quantile(di, 0.25)), distance_q75=float(np.quantile(di, 0.75)), near_mean=float(yy[near].mean()), far_mean=float(yy[far].mean()), far_minus_near=float(yy[far].mean() - yy[near].mean()), near_frac_any=float((c[idx][:, jj].sum(axis=1)[near] > 0).mean()), far_frac_any=float((c[idx][:, jj].sum(axis=1)[far] > 0).mean())))
            for method in ['depth_adjusted', 'depth_and_local_block']:
                z = np.column_stack([rankdata(di), rankdata(yy), dep])
                if method == 'depth_and_local_block':
                    zz = pd.DataFrame(z)
                    zz['block'] = block
                    z = z - zz.groupby('block')[[0, 1, 2]].transform('mean').values
                design = np.column_stack([np.ones(len(z)), z[:, 2]])
                res = z[:, :2] - design @ np.linalg.lstsq(design, z[:, :2], rcond=None)[0]
                r = float(np.corrcoef(res.T)[0, 1]) if np.isfinite(res).all() and np.min(np.std(res, axis=0)) > 1e-12 else np.nan
                rows.append(dict(section=name, patient=patient, site=site, pathway=k, min_counts=mincounts, method=method, n_tumor=len(idx), n_EC=int(ec.sum()), n_genes=len(jj), n_blocks=len(np.unique(block)), block_width_source_units=blockwidth, partial_rank_r=r))
    print('DONE', name, len(bc), 'EC', int(ec.sum()), 'tumor', int(tu.sum()), flush=True)
    for p in [f, counts]:
        h = hashlib.sha256(p.read_bytes()).hexdigest()
        inputs.append({'path': str(p), 'size': p.stat().st_size, 'sha256': h})
    pd.DataFrame(rows).to_csv(O / 'slideseq_section_distance_pathways.csv', index=False)
    pd.DataFrame(bins).to_csv(O / 'slideseq_section_distance_quartiles.csv', index=False)
pd.DataFrame(cov).to_csv(O / 'slideseq_module_gene_coverage.csv', index=False)
a = pd.DataFrame(rows)
b = pd.DataFrame(bins)
pd.DataFrame(qc).to_csv(O / 'slideseq_qc.csv', index=False)
pat = a.groupby(['site', 'patient', 'pathway', 'min_counts', 'method'], as_index=False).partial_rank_r.median()
pat.to_csv(O / 'slideseq_patient_distance_pathways.csv', index=False)
tests = []
for ((site, k, n, m), z) in pat.groupby(['site', 'pathway', 'min_counts', 'method']):
    v = z.partial_rank_r.values
    v = v[np.isfinite(v)]
    if len(v) < 3:
        tests.append(dict(site=site, pathway=k, min_counts=n, method=m, n_patients=len(v), median_partial_rank_r=np.nan, mean_partial_rank_r=np.nan, n_positive=int((v > 0).sum()), n_negative=int((v < 0).sum()), p_signflip=np.nan))
        continue
    obs = abs(v.mean())
    sgn = np.array(list(itertools.product([-1, 1], repeat=len(v))))
    null = np.abs((sgn * v).mean(axis=1))
    p = float((null >= obs - 1e-12).mean())
    tests.append(dict(site=site, pathway=k, min_counts=n, method=m, n_patients=len(v), median_partial_rank_r=float(np.median(v)), mean_partial_rank_r=float(v.mean()), n_positive=int((v > 0).sum()), n_negative=int((v < 0).sum()), p_signflip=p))
t = pd.DataFrame(tests)
t['q_BH_all'] = np.nan
ok = t.p_signflip.notna()
t.loc[ok, 'q_BH_all'] = multipletests(t.loc[ok, 'p_signflip'], method='fdr_bh')[1]
main = (t.site == 'BM') & (t.min_counts == 50) & (t.method == 'depth_and_local_block') & t.p_signflip.notna()
t.loc[main, 'q_BH_primary12'] = multipletests(t.loc[main, 'p_signflip'], method='fdr_bh')[1]
t.to_csv(O / 'slideseq_patient_distance_tests.csv', index=False)
(O / 'SLIDESEQ_PROVENANCE.json').write_text(json.dumps({'created_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'inputs': inputs, 'script': str(Path(__file__).resolve()), 'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'source': 'https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE185386', 'distance': 'nearest author-RCTD EC bead; coordinate units; no physical distance threshold'}, indent=2))
print(t[main].to_string(index=False))
print('COMPLETE', flush=True)
