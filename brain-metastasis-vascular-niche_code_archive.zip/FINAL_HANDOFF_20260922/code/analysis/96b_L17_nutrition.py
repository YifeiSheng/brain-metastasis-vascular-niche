# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
"""L17 nutrient adaptation: predeclared pathways, author-annotated Kim2020 malignant cells and internal tumor cells.
No integration, no per-cell significance tests; biological replication is sample/donor.
"""
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os
for k in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS']:
    os.environ[k] = '2'
from pathlib import Path
import json, hashlib, time, itertools, math
import numpy as np, pandas as pd, scipy.io, scipy.sparse as sp
from scipy.stats import rankdata, spearmanr
from statsmodels.stats.multitest import multipletests
B = Path(str(_HANDOFF_ROOT / ''))
O = B / 'results/nutrition'
O.mkdir(parents=True, exist_ok=True)
S = {'glycolysis': ['SLC2A1', 'HK2', 'PFKP', 'ALDOA', 'PGK1', 'ENO1', 'LDHA', 'PKM'], 'lactate_uptake_oxidation': ['SLC16A1', 'LDHB'], 'lactate_export': ['SLC16A3', 'LDHA'], 'glutamine_acquisition': ['SLC1A5', 'SLC38A1', 'SLC38A2', 'GLS', 'GLS2'], 'glutamine_synthesis': ['GLUL'], 'serine_synthesis': ['PHGDH', 'PSAT1', 'PSPH'], 'acetate_assimilation': ['ACSS1', 'ACSS2'], 'fatty_acid_synthesis': ['ACLY', 'ACACA', 'FASN', 'SCD', 'ELOVL6'], 'fatty_acid_uptake': ['CD36', 'SLC27A1', 'SLC27A4', 'FABP5', 'LPL'], 'oxidative_phosphorylation': ['NDUFS1', 'NDUFS2', 'NDUFV1', 'SDHA', 'SDHB', 'UQCRC1', 'UQCRC2', 'COX4I1', 'COX5A', 'ATP5F1A', 'ATP5F1B'], 'hypoxia_response': ['CA9', 'EGLN3', 'BNIP3', 'BNIP3L', 'NDRG1', 'PDK1', 'ADM', 'ANGPTL4'], 'autophagy_lysosome': ['ATG5', 'ATG7', 'BECN1', 'MAP1LC3B', 'LAMP1', 'LAMP2', 'CTSB', 'CTSD']}
(O / 'gene_sets.json').write_text(json.dumps({'sets': S, 'predeclared_before_results': True, 'notes': 'Literature-guided, compact mechanism panels, not canonical enrichment sets. Transporter expression is capacity not direction or flux. OXPHOS includes nuclear genes only.'}, indent=2))
inputs = []

def process(x, genes, meta, dataset):
    genes = np.array(genes)
    gi = {g: i for (i, g) in enumerate(genes)}
    for (new, old) in [('ATP5F1A', 'ATP5A1'), ('ATP5F1B', 'ATP5B')]:
        if new not in gi and old in gi:
            gi[new] = gi[old]
    allg = sorted(set(sum(S.values(), [])))
    present = [g for g in allg if g in gi]
    absent = sorted(set(allg) - set(present))
    print(dataset, x.shape, 'missing', absent, flush=True)
    x = x.tocsr()
    tot = np.asarray(x.sum(axis=1)).ravel()
    c = x[:, [gi[g] for g in present]].toarray()
    e = np.log1p(c / np.maximum(tot[:, None], 1) * 10000.0)
    meta = meta.reset_index(drop=True).copy()
    cr = meta.copy()
    cr['total_counts'] = tot
    for (k, gs) in S.items():
        idx = [present.index(g) for g in gs if g in present]
        cr[k] = e[:, idx].mean(axis=1)
        cr[k + '_ndet'] = (c[:, idx] > 0).sum(axis=1)
    cr.to_csv(O / (dataset + '_tumor_cell_states.csv.gz'), index=False, compression='gzip')
    rows = []
    grows = []
    comp = []
    for ((sample, site, patient), ii) in meta.groupby(['sample', 'site', 'patient']).indices.items():
        n = len(ii)
        counts = c[ii].sum(axis=0)
        lib = tot[ii].sum()
        lp = np.log2(1 + counts / max(lib, 1) * 1000000.0)
        meta0 = dict(dataset=dataset, sample=sample, patient=patient, site=site, n_cells=n, total_umi=float(lib), median_cell_umi=float(np.median(tot[ii])))
        for (k, gs) in S.items():
            idx = [present.index(g) for g in gs if g in present]
            rows.append(dict(**meta0, pathway=k, n_genes=len(idx), n_expected=len(gs), pseudobulk_log2cpm_mean=float(lp[idx].mean()), cell_log1pcp10k_mean=float(e[ii][:, idx].mean()), cell_fraction_any=float((c[ii][:, idx].sum(axis=1) > 0).mean()), cell_fraction_atleast2=float(((c[ii][:, idx] > 0).sum(axis=1) >= min(2, len(idx))).mean())))
        for (j, g) in enumerate(present):
            grows.append(dict(**meta0, gene=g, counts=float(counts[j]), cpm=float(counts[j] / max(lib, 1) * 1000000.0), mean_log1pcp10k=float(e[ii, j].mean()), fraction_detected=float((c[ii, j] > 0).mean())))
        for (key, g1, g2) in [('lactate_entry_and_conversion', 'SLC16A1', 'LDHB'), ('glutamine_entry_and_conversion', 'SLC1A5', 'GLS'), ('serine_first_two_enzymes', 'PHGDH', 'PSAT1')]:
            jj = [present.index(g) for g in [g1, g2] if g in present]
            comp.append(dict(**meta0, pair=key, genes=g1 + ';' + g2, fraction_coexpress=float(((c[ii][:, jj] > 0).sum(axis=1) == len(jj)).mean())))
    pd.DataFrame(rows).to_csv(O / (dataset + '_sample_pathways.csv'), index=False)
    pd.DataFrame(grows).to_csv(O / (dataset + '_sample_genes.csv'), index=False)
    pd.DataFrame(comp).to_csv(O / (dataset + '_sample_coexpression.csv'), index=False)
    return pd.DataFrame(rows)
D = B / 'results/external_replication/D4'
genes = pd.read_csv(D / 'features.tsv', header=None, sep='\t')[0].astype(str).values
bc = pd.read_csv(D / 'barcodes.tsv', header=None, sep='\t')[0].astype(str).values
ann = pd.read_csv(D / 'cell_annotation_subset.csv').set_index('Index').reindex(bc)
sel = (ann.Cell_subtype.isin(['Malignant cells', 'tS1', 'tS2', 'tS3']) & ann.Sample_Origin.isin(['mBrain', 'tLung'])).values
print('Reading Kim counts; selected malignant', sel.sum(), flush=True)
mat = scipy.io.mmread(D / 'matrix.mtx').tocsc()
x = mat[:, sel].T.tocsr()
del mat
m = ann.iloc[np.where(sel)[0]].copy()
m['cell'] = m.index
m = m.rename(columns={'Sample': 'sample', 'Sample_Origin': 'site'})
md = pd.read_csv(O / 'kim_author_sample_metadata.csv').set_index('sample')
m['patient'] = m['sample'].map(md.patient)
assert m.patient.notna().all()
kim = process(x, genes, m[['cell', 'sample', 'patient', 'site', 'Cell_subtype']], 'kim2020')
del x
tests = []
rng = np.random.default_rng(20260922)
for mincells in [50, 100]:
    for endpoint in ['pseudobulk_log2cpm_mean', 'cell_log1pcp10k_mean']:
        wide = kim[kim.n_cells >= mincells].pivot(index=['sample', 'site'], columns='pathway', values=endpoint).dropna()
        vv = wide.values
        grp = wide.index.get_level_values('site') == 'mBrain'
        n1 = int(grp.sum())
        n2 = len(grp) - n1
        assert min(n1, n2) >= 3, 'Insufficient biological replicates in one comparison arm'
        ranks = np.column_stack([rankdata(vv[:, j]) for j in range(vv.shape[1])])
        obs = ranks[grp].sum(axis=0)
        center = n1 * (len(grp) + 1) / 2
        extreme = np.abs(obs - center)
        ncomb = math.comb(len(grp), n1)
        nr = ncomb if ncomb <= 500000 else 100000
        cnt = np.zeros(vv.shape[1], dtype=int)
        it = itertools.combinations(range(len(grp)), n1) if ncomb <= 500000 else (rng.choice(len(grp), n1, replace=False) for _ in range(nr))
        for chunk_start in range(0, nr, 10000):
            idx = np.array(list(itertools.islice(it, min(10000, nr - chunk_start))))
            perm = ranks[idx].sum(axis=1)
            cnt += (np.abs(perm - center) >= extreme - 1e-10).sum(axis=0)
        ps = cnt / nr if ncomb <= 500000 else (cnt + 1) / (nr + 1)
        for (j, k) in enumerate(wide.columns):
            a = vv[grp, j]
            b = vv[~grp, j]
            u = obs[j] - n1 * (n1 + 1) / 2
            boot = np.median(rng.choice(a, (5000, len(a)), replace=True), axis=1) - np.median(rng.choice(b, (5000, len(b)), replace=True), axis=1)
            tests.append(dict(dataset='kim2020', pathway=k, endpoint=endpoint, min_cells=mincells, n_brain=n1, n_primary=n2, median_brain=float(np.median(a)), median_primary=float(np.median(b)), median_difference=float(np.median(a) - np.median(b)), rank_biserial=float(2 * u / (n1 * n2) - 1), bootstrap_ci_low=float(np.quantile(boot, 0.025)), bootstrap_ci_high=float(np.quantile(boot, 0.975)), permutation_p=float(ps[j]), n_permutations=nr, exact=ncomb <= 500000))
t = pd.DataFrame(tests)
t['q_BH_all48'] = multipletests(t.permutation_p, method='fdr_bh')[1]
primary = (t.endpoint == 'pseudobulk_log2cpm_mean') & (t.min_cells == 50)
t.loc[primary, 'q_BH_primary12'] = multipletests(t.loc[primary, 'permutation_p'], method='fdr_bh')[1]
t.to_csv(O / 'kim2020_pathway_tests.csv', index=False)
print(t[primary].to_string(index=False), flush=True)
import anndata as ad
a = ad.read_h5ad(B / 'data/integrated/final_integrated_annotated.h5ad')
lab = pd.read_csv(B / 'data/integrated/per_cell_labels.csv').set_index('cell').reindex(a.obs_names)
sel = lab.lineage_l1.isin(['上皮/肺腺癌', '神经内分泌/SCLC']).values
print('Internal lineage candidates', int(sel.sum()), lab.lineage_l1.value_counts().to_dict(), flush=True)
sel = (lab.patient_id.isin(['P1', 'P5']) & lab.lineage_l1.eq('上皮/肺腺癌') | lab.patient_id.eq('P3') & lab.lineage_l1.eq('上皮/神经内分泌')).values
m = a.obs.iloc[np.where(sel)[0]].copy()
m['cell'] = m.index
m['sample'] = m['sample'].astype(str)
m['patient'] = m['patient_id'].astype(str)
m['site'] = m['tissue_role'].astype(str)
m['lineage'] = lab.iloc[np.where(sel)[0]].lineage_l1.values
process(a.X[sel], a.var_names, m[['cell', 'sample', 'patient', 'site', 'lineage']], 'internal')
for p in [D / 'matrix.mtx', D / 'cell_annotation_subset.csv', D / 'features.tsv', D / 'barcodes.tsv', O / 'kim_author_sample_metadata.csv', B / 'data/integrated/final_integrated_annotated.h5ad', B / 'data/integrated/per_cell_labels.csv']:
    h = hashlib.sha256()
    with p.open('rb') as f:
        for z in iter(lambda : f.read(8388608), b''):
            h.update(z)
    inputs.append(dict(path=str(p), size=p.stat().st_size, sha256=h.hexdigest()))
(O / 'PROVENANCE.json').write_text(json.dumps({'created_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'inputs': inputs, 'script': str(Path(__file__).resolve()), 'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'numpy': np.__version__, 'pandas': pd.__version__, 'random_seed': 20260922}, indent=2))
print('COMPLETE', flush=True)
