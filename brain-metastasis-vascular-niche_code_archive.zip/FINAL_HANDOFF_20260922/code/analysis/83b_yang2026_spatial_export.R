# Current scientific analysis; package-relative paths.
handoff_arg <- grep("^--file=", commandArgs(), value=TRUE)
handoff_file <- sub("^--file=", "", handoff_arg[1])
HANDOFF_ROOT <- Sys.getenv("SAFEPOSTER_HANDOFF_ROOT", unset=normalizePath(file.path(dirname(handoff_file), "../.."), mustWork=TRUE))
# L15: Yang 2026 sce.mergeSCT.rds (Seurat, 17 张 Visium: 脑转移 + 配对原发) -> 每张导出 Spatial counts (mtx) + 坐标 (tissue_positions_list 格式) + meta
suppressMessages({library(Seurat); library(Matrix)})
E=file.path(HANDOFF_ROOT, "data/external/bulk/Yang2026_BrM_zenodo"); OUT=file.path(E,"spatial_export")
s=readRDS(file.path(E,"sce.mergeSCT.rds")); DefaultAssay(s)="Spatial"
cnt=GetAssayData(s,assay="Spatial",layer="counts"); cat("counts dim:",dim(cnt),"\n")
md=s@meta.data; write.csv(md[,intersect(c("orig.ident","nCount_Spatial","nFeature_Spatial","Group","MolecularNiche","seurat_clusters"),colnames(md))],file.path(OUT,"spot_meta.csv"))
for (img in names(s@images)) {
  co=tryCatch(GetTissueCoordinates(s,image=img),error=function(e) NULL)
  if (is.null(co)) { cat("no coords",img,"\n"); next }
  cells=rownames(co); cells=cells[cells %in% colnames(cnt)]
  if (length(cells)<50) { cat("few cells",img,length(cells),"\n"); next }
  d=file.path(OUT,img); dir.create(d,showWarnings=FALSE)
  m=cnt[,cells,drop=FALSE]; writeMM(m,file.path(d,"matrix.mtx")); writeLines(cells,file.path(d,"barcodes.tsv")); writeLines(rownames(m),file.path(d,"features.tsv"))
  xcol=intersect(c("imagecol","x","col"),colnames(co))[1]; ycol=intersect(c("imagerow","y","row"),colnames(co))[1]
  pos=data.frame(barcode=cells,in_tissue=1,row=0,col=0,py=co[cells,ycol],px=co[cells,xcol]); write.csv(pos,file.path(d,"tissue_positions_list.csv"),row.names=FALSE,quote=FALSE)
  cat(img,length(cells),"spots; orig.ident:",paste(names(table(md[cells,"orig.ident"])),collapse=","),"\n")
}
cat("DONE\n")
