# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import numpy as np, pandas as pd, scanpy as sc, scipy.io, time, os
B = str(_HANDOFF_ROOT / '')
Y = f'{B}/data/external/bulk/Yang2026_BrM_zenodo/snRNA_mtx'
O = f'{B}/results/immune_glial_lymphoma/M2_I2_SNRNA'
os.makedirs(O, exist_ok=True)
LIN = {'髓系': ['PTPRC', 'CD68', 'CD14', 'AIF1', 'CSF1R', 'C1QA', 'LYZ', 'TYROBP', 'FCER1G'], 'T/NK': ['CD3E', 'CD3D', 'CD2', 'NKG7', 'GNLY', 'TRAC', 'CD8A', 'IL7R'], '基质/血管': ['PDGFRB', 'RGS5', 'COL1A2', 'DCN', 'CLDN5', 'VWF', 'PECAM1', 'ACTA2'], '上皮/肿瘤': ['EPCAM', 'KRT8', 'KRT18', 'KRT19'], 'B': ['MS4A1', 'CD79A', 'CD79B', 'CD19']}
M = scipy.io.mmread(f'{Y}/matrix.mtx').tocsr().T.astype(np.float32)
genes = [l.strip() for l in open(f'{Y}/genes.tsv')]
bcs = [l.strip() for l in open(f'{Y}/barcodes.tsv')]
meta = pd.read_csv(f'{Y}/meta.csv', index_col=0).reindex(bcs)
a = sc.AnnData(M, obs=meta, var=pd.DataFrame(index=genes))
a.var_names_make_unique()
sc.pp.filter_cells(a, min_genes=300)
sc.pp.filter_genes(a, min_cells=3)
sc.pp.normalize_total(a, target_sum=10000.0)
sc.pp.log1p(a)
LS = pd.DataFrame(index=a.obs_names)
DET = pd.DataFrame(index=a.obs_names)
for (l, g) in LIN.items():
    gg = [x for x in g if x in a.var_names]
    LS[l] = np.asarray(a[:, gg].X.mean(axis=1)).ravel()
    DET[l] = np.asarray((a[:, gg].X > 0).sum(axis=1)).ravel()
AUTH = {'Myeloid cells': '髓系', 'T cells': 'T/NK', 'B cells': 'B', 'Endothelia': '基质/血管', 'Fibroblasts': '基质/血管', 'MTCs': '上皮/肿瘤'}
au = a.obs['celltype'].map(AUTH)
rows = []
for thr in [0.1, 0.15, 0.2, 0.25, 0.3]:
    lin = LS.idxmax(axis=1).where(LS.max(axis=1) > thr, '其他')
    for l in ['髓系', 'T/NK', 'B', '基质/血管', '上皮/肿瘤']:
        tp = int(((lin == l) & (au == l)).sum())
        fp = int(((lin == l) & (au != l) & au.notna()).sum())
        fn = int(((lin != l) & (au == l)).sum())
        rows.append(dict(rule=f'mean>{thr}', lineage=l, n_author=int((au == l).sum()), n_gate=int((lin == l).sum()), recall=round(tp / max(tp + fn, 1), 3), precision=round(tp / max(tp + fp, 1), 3)))
Z = (LS - LS.mean()) / (LS.std() + 1e-09)
lin2 = Z.idxmax(axis=1).where((DET.max(axis=1) >= 2) & (Z.max(axis=1) > 0), '其他')
for l in ['髓系', 'T/NK', 'B', '基质/血管', '上皮/肿瘤']:
    tp = int(((lin2 == l) & (au == l)).sum())
    fp = int(((lin2 == l) & (au != l) & au.notna()).sum())
    fn = int(((lin2 != l) & (au == l)).sum())
    rows.append(dict(rule='z-argmax & det>=2', lineage=l, n_author=int((au == l).sum()), n_gate=int((lin2 == l).sum()), recall=round(tp / max(tp + fn, 1), 3), precision=round(tp / max(tp + fp, 1), 3)))
r = pd.DataFrame(rows)
r.to_csv(f'{O}/M2_gate_calibration_yang.csv', index=False)
print(r.to_string(index=False))
