# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
from pathlib import Path
import json, hashlib, datetime, re
import pandas as pd, numpy as np
B = Path(str(_HANDOFF_ROOT / ''))
O = B / 'results/VEGF_sprouting_calibration'
gs = B / 'data/analysis_definitions/vascular_gene_sets.json'
plan = {'frozen_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'gene_sets_sha256': hashlib.sha256(gs.read_bytes()).hexdigest(), 'inputs': ['GSE227549', 'GSE196776'], 'design': 'Separate VEGF vs matched-study basal conditions; unpaired sample-level design because GEO lacks donor/batch/pair IDs. No matching inferred from numeric suffix. Commercial HUVEC sample replicate inferential unit; donor independence unproven. Controls in GSE196776 added in 2023 after VEGF sample submission in 2022; deposition date is not experiment date, confounded batch cannot be excluded.', 'time': 'GSE227549 3D25ng/mL18h vs basal; GSE196776 2D25ng/mL24h vs basal. Not a time course; cannot attribute across-assay differences solely to dimensionality.', 'DE': 'edgeR TMM normalization; filterByExpr using actual group; limma voom with robust empirical Bayes, VEGF-Control; genome-wide BH within each study; no across-study pooled analysis. No genes selected from human brain patient outcomes.', 'panel_scoring': 'Use frozen6primary +1tipcore panels. Mean per-gene z transformed voom logCPM within each study, among filterByExpr-expressed finite variance genes; minimum2 and half genes available. Exact two-sided label permutation rank-sum per assay. BH6primary per assay, pooled12primary additionally; sensitivity q across14 tests. Missing and low-expression genes explicitly logged. Means/foldchanges of individual genes retained. No comparison of absolute scores betweenstudies.', 'limitations': 'RNA observed after18/24h cannot alone distinguish sprouting, leak, or matureperfused vessel count. Actual3D phenotype from originalstudy. Nonbrain HUVEC perturbation calibrates interpretation and independentlyderived response footprint, not braincausality.'}
p = O / 'PERTURBATION_ANALYSIS_PLAN.json'
if not p.exists():
    p.write_text(json.dumps(plan, indent=2))
else:
    plan = json.loads(p.read_text())
mapping = B / 'results/pericyte_differentiation/GSE237317/ensembl_symbol_map.csv'
mp = pd.read_csv(mapping).drop_duplicates('gene_id')
mp.to_csv(O / 'gene_id_symbol_annotation.csv', index=False)
roster = []
for acc in plan['inputs']:
    d = O / acc
    samples = json.loads((d / 'samples.json').read_text())
    selected = []
    for x in samples:
        title = x['title'][0]
        if re.fullmatch('(?:HUVEC_)?(?:VEGF|Control)_\\d+', title):
            selected.append(x)
    selected.sort(key=lambda x: ('VEGF' in x['title'][0], x['title'][0]))
    cols = []
    for sm in selected:
        gsm = sm['gsm']
        files = list(d.glob(gsm + '_*.txt.gz'))
        assert len(files) == 1, (gsm, files)
        f = pd.read_csv(files[0], sep='\t', index_col=0)
        assert f.shape[1] == 1 and f.index.is_unique
        arr = f.iloc[:, 0]
        assert np.isfinite(arr).all() and (arr >= 0).all() and np.allclose(arr, np.round(arr))
        arr.name = gsm
        cols.append(arr)
        row = {'study': acc, 'gsm': gsm, 'title': sm['title'][0], 'group': 'VEGF' if 'VEGF' in sm['title'][0] else 'Control', 'numeric_suffix': sm['title'][0].split('_')[-1], 'submission_date': sm.get('submission_date', [''])[0], 'last_update_date': sm.get('last_update_date', [''])[0], 'batch': 'not reported', 'donor': 'not reported', 'pairing': 'not established', 'library_size': int(arr.sum()), 'source_count_file': str(files[0].relative_to(B))}
        roster.append(row)
    c = pd.concat(cols, axis=1)
    assert not c.isna().any().any()
    c.index = c.index.str.split('.').str[0]
    c = c.groupby(level=0, sort=False).sum()
    c.to_csv(d / 'counts_gene_id.csv.gz')
    pd.DataFrame([r for r in roster if r['study'] == acc]).to_csv(d / 'selected_samples.csv', index=False)
    print(acc, c.shape, 'minlib', c.sum().min(), 'maxlib', c.sum().max(), flush=True)
pd.DataFrame(roster).to_csv(O / 'perturbation_sample_roster.csv', index=False)
(O / 'annotation_provenance.json').write_text(json.dumps({'path': str(mapping.relative_to(B)), 'sha256': hashlib.sha256(mapping.read_bytes()).hexdigest(), 'origin': 'Ensembl-to-symbol annotation derived by 96c_reversible_differentiation.py from GSE256493 GSM8101557_metastasis_23-10-19_Ecs_features.tsv.gz; the map is stored under the GSE237317 analysis folder. Only the gene-ID dictionary is reused; no expression values from either source enter this step.'}, indent=2))
