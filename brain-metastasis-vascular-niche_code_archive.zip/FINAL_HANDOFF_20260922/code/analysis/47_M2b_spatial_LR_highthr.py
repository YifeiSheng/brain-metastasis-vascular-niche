# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import numpy as np, pandas as pd, scanpy as sc, scipy.sparse as sp
from sklearn.neighbors import NearestNeighbors
ST = str(_HANDOFF_ROOT / 'data/spatial')
O = str(_HANDOFF_ROOT / 'results/internal_programs_and_CNV')
SL = {'S1_T': 'batch_10562_2022_05_30', 'Toct6': 'batch_10562_2022_05_30', 'Toct4': 'batch_15551_2022_03_28', 'Toct5': 'batch_15551_2022_03_28', 'Coct4': 'batch_15551_2022_03_28', 'Coct6': 'batch_10562_2022_05_30'}
PAIRS = [('CCL19', 'CCR7'), ('CCL19', 'PDGFRB'), ('CCL19', 'LAMP3'), ('CCL19', 'ACTA2'), ('CCL19', 'MS4A1'), ('CCL21', 'CCR7'), ('CXCL13', 'CXCR5'), ('CXCL13', 'CD3E'), ('CXCL13', 'MS4A1'), ('DLL4', 'NOTCH3'), ('JAG1', 'NOTCH3'), ('PDGFB', 'PDGFRB'), ('GAS6', 'AXL'), ('CCL2', 'CCR2'), ('CXCL9', 'CXCR3'), ('CXCL10', 'CXCR3'), ('APOE', 'TREM2'), ('SPP1', 'CD44'), ('CSF1', 'CSF1R'), ('IL34', 'CSF1R'), ('ANGPT2', 'TEK'), ('VEGFA', 'KDR'), ('CD274', 'PDCD1'), ('LGALS9', 'HAVCR2'), ('TNFSF13B', 'TNFRSF13B'), ('CXCL12', 'CXCR4'), ('F13A1', 'NOTCH3'), ('LYVE1', 'PDGFRB'), ('CD163', 'NOTCH3'), ('P2RY12', 'GFAP')]
rng = np.random.default_rng(0)
rows = []
for (sl, b) in SL.items():
    v = sc.read_visium(f'{ST}/{b}/1.SpaceRanger/{sl}', count_file='filtered_feature_bc_matrix.h5', library_id=sl)
    v.var_names_make_unique()
    tot = np.asarray(v.X.sum(axis=1)).ravel()
    C = v.X.tocsc()
    xy = v.obsm['spatial'].astype(float)
    nn = NearestNeighbors(n_neighbors=7).fit(xy)
    (dist, idx) = nn.kneighbors(xy)
    dmin = np.median(dist[:, 1])
    A = sp.lil_matrix((v.n_obs, v.n_obs))
    for i in range(v.n_obs):
        for (j, dd) in zip(idx[i, 1:], dist[i, 1:]):
            if dd < dmin * 1.3:
                A[i, j] = 1
    A = A.tocsr() + sp.eye(v.n_obs, format='csr')
    gi = {g: i for (i, g) in enumerate(v.var_names)}

    def high(g):
        c = C[:, gi[g]].toarray().ravel() / tot * 10000.0
        pos = c[c > 0]
        if len(pos) < 20:
            return (None, float((c > 0).mean()))
        thr = np.quantile(pos, 0.75)
        return ((c >= thr).astype(float), float((c > 0).mean()))
    for (l, r) in PAIRS:
        if l not in gi or r not in gi:
            continue
        (Lh, ld) = high(l)
        (Rh, rd) = high(r)
        if Lh is None or Rh is None:
            rows.append(dict(slide=sl, ligand=l, receptor=r, lig_det=round(ld, 3), rec_det=round(rd, 3), note='阳性 spot<20'))
            continue
        obs = float((Lh * (A @ Rh > 0)).sum())
        null = np.array([float((Lh * (A @ rng.permutation(Rh) > 0)).sum()) for _ in range(200)])
        z = (obs - null.mean()) / (null.std() + 1e-09)
        p = (np.sum(null >= obs) + 1) / 201
        rows.append(dict(slide=sl, ligand=l, receptor=r, lig_det=round(ld, 3), rec_det=round(rd, 3), n_lig_high=int(Lh.sum()), n_rec_high=int(Rh.sum()), obs=obs, null_mean=round(null.mean(), 1), obs_over_null=round(obs / max(null.mean(), 1), 2), z=round(z, 2), p=round(p, 4)))
df = pd.DataFrame(rows)
df.to_csv(f'{O}/M2b_spatial_LR_high_threshold.csv', index=False)
pd.set_option('display.width', 260)
pd.set_option('display.max_rows', 300)
d = df.dropna(subset=['z']) if 'z' in df else df
print(d[['slide', 'ligand', 'receptor', 'lig_det', 'rec_det', 'n_lig_high', 'n_rec_high', 'obs', 'null_mean', 'obs_over_null', 'z', 'p']].sort_values(['ligand', 'receptor', 'slide']).to_string(index=False))
