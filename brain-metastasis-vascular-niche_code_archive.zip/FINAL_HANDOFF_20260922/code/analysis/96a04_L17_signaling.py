# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
"""L17 independent endothelial response footprints and NicheNet cross-cohort prioritization.
Observational receiver state, NOT an intervention in the human atlas and NOT causal inference.
"""
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os
for k in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS']:
    os.environ[k] = '2'
from pathlib import Path
import pandas as pd, numpy as np, json, itertools
from scipy.stats import ttest_ind, rankdata, pearsonr, spearmanr
from statsmodels.stats.multitest import multipletests
from sklearn.metrics import average_precision_score, roc_auc_score
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
B = Path(str(_HANDOFF_ROOT / ''))
O = B / 'results/ligand_response'
R = O / 'resources'
pr = pd.read_csv(R / 'progeny_human_full.csv')
meta = pd.read_csv(O / 'EC_donor_manifest.csv')
pathrows = []
pathlong = []
coverage = []
differentials = {}

def exact_rank_p(x, y):
    z = rankdata(np.r_[x, y])
    n = len(x)
    obs = abs(z[:n].sum() - n * (len(z) + 1) / 2)
    null = np.array([abs(z[list(ii)].sum() - n * (len(z) + 1) / 2) for ii in itertools.combinations(range(len(z)), n)])
    return float(np.mean(null >= obs - 1e-10))
for gate in ['main', 'strict']:
    counts = pd.read_csv(O / f'EC_{gate}_pseudobulk_counts.csv.gz', index_col=0)
    cpm = counts.div(counts.sum(1), axis=0) * 1000000.0
    log = np.log2(1 + cpm)
    m = meta[meta.gate == gate].set_index('donor').loc[counts.index]
    bm = m.group.eq('BM').values
    tl = ~bm
    expressed = (cpm >= 1).sum(0) >= min(bm.sum(), tl.sum())
    (stat, p) = ttest_ind(log.loc[bm, expressed], log.loc[tl, expressed], equal_var=False, axis=0)
    deg = pd.DataFrame(dict(gene=log.columns[expressed], t=stat, p=p, log2CPM_diff=log.loc[bm, expressed].mean(0).values - log.loc[tl, expressed].mean(0).values, log2FC=np.log2((cpm.loc[bm, expressed].mean(0).values + 0.1) / (cpm.loc[tl, expressed].mean(0).values + 0.1))))
    deg['q_BH'] = multipletests(deg.p.fillna(1), method='fdr_bh')[1]
    deg.sort_values('t', ascending=False).to_csv(O / f'EC_{gate}_donor_DE.csv', index=False)
    differentials[gate] = deg
    z = (log - log.mean(0)) / log.std(0, ddof=1).replace(0, np.nan)
    for top in [100, 500]:
        for (path, g) in pr.groupby('pathway'):
            net = g.sort_values('p.value').head(top).set_index('gene')
            gs = [x for x in net.index if x in z and z[x].notna().all()]
            w = net.loc[gs, 'weight'].values
            score = z[gs].values @ w / np.sqrt((w * w).sum())
            score = (score - score.mean()) / score.std(ddof=1)
            effect = float(np.median(score[bm]) - np.median(score[tl]))
            pval = exact_rank_p(score[bm], score[tl])
            pathrows.append(dict(gate=gate, top=top, pathway=path, n_BM=int(bm.sum()), n_TL=int(tl.sum()), genes_available=len(gs), median_BM=float(np.median(score[bm])), median_TL=float(np.median(score[tl])), median_diff=effect, p_exact=pval))
            coverage.append(dict(gate=gate, top=top, pathway=path, genes=';'.join(gs)))
            for (donor, v, grp) in zip(m.index, score, m.group):
                pathlong.append(dict(gate=gate, top=top, pathway=path, donor=donor, group=grp, score=float(v)))
res = pd.DataFrame(pathrows)
res['q_BH_all56'] = multipletests(res.p_exact, method='fdr_bh')[1]
main = (res.gate == 'main') & (res.top == 100)
res.loc[main, 'q_BH_main14'] = multipletests(res.loc[main, 'p_exact'], method='fdr_bh')[1]
res.to_csv(O / 'PROGENy_donor_tests.csv', index=False)
pd.DataFrame(pathlong).to_csv(O / 'PROGENy_donor_scores.csv', index=False)
pd.DataFrame(coverage).to_csv(O / 'PROGENy_coverage.csv', index=False)
targets = (R / 'nichenet_targets.txt').read_text().splitlines()
ligands = (R / 'nichenet_ligands.txt').read_text().splitlines()
mat = np.memmap(R / 'nichenet_ligand_target_float32.bin', dtype='<f4', mode='r', shape=(len(targets), len(ligands)), order='F')
lr = pd.read_csv(R / 'nichenet_lr.csv')[['from', 'to']].drop_duplicates()
idet = pd.read_csv(O / 'internal_lineage_detection.csv.gz', index_col=0)
imean = pd.read_csv(O / 'internal_lineage_mean_logCP10k.csv.gz', index_col=0)
imeta = pd.read_csv(O / 'internal_lineage_manifest.csv')
compat = []
for patient in ['P1', 'P3', 'P5']:
    ekey = patient + '|内皮'
    if ekey not in idet.index:
        continue
    recs = set(idet.columns[idet.loc[ekey] >= 0.1])
    for row in imeta[imeta.patient.eq(patient) & imeta.n_cells.ge(30)].itertuples():
        ls = set(idet.columns[idet.loc[row.key] >= 0.1])
        good = lr[lr['from'].isin(ls) & lr['to'].isin(recs)]
        for p in good.itertuples(index=False):
            (lig, rec) = p
            is_tumor = patient in ['P1', 'P5'] and row.lineage == '上皮/肺腺癌' or (patient == 'P3' and row.lineage == '上皮/神经内分泌')
            compat.append(dict(patient=patient, source=row.lineage, is_tumor=is_tumor, ligand=lig, receptor=rec, n_sender=row.n_cells, n_EC=int(imeta.set_index('key').loc[ekey, 'n_cells']), sender_det=float(idet.loc[row.key, lig]), receiver_det=float(idet.loc[ekey, rec]), sender_mean=float(imean.loc[row.key, lig]), receiver_mean=float(imean.loc[ekey, rec])))
compat = pd.DataFrame(compat)
compat.to_csv(O / 'internal_NicheNet_LR_compatibility.csv', index=False)
candidates = set(compat.ligand)
tumorcands = set(compat.loc[compat.is_tumor, 'ligand'])
target_ix = {t: i for (i, t) in enumerate(targets)}
lig_ix = {l: i for (i, l) in enumerate(ligands)}
rankrows = []
targetrows = []
for (gate, deg) in differentials.items():
    bg = deg[deg.gene.isin(target_ix) & deg.t.notna()].sort_values('t', ascending=False)
    bgix = np.array([target_ix[g] for g in bg.gene])
    v = np.array(mat[bgix, :])
    for top in [100, 200, 500]:
        wanted = list(bg[bg.t > 0].head(top).gene)
        gold = bg.gene.isin(wanted).values.astype(int)
        prev = gold.mean()
        table = []
        for (j, l) in enumerate(ligands):
            vals = v[:, j]
            if np.std(vals) == 0:
                continue
            r = pearsonr(vals, gold).statistic
            ap = average_precision_score(gold, vals)
            table.append(dict(gate=gate, top=top, ligand=l, n_targets=len(wanted), n_background=len(gold), pearson=float(r), auprc=float(ap), auprc_corrected=float((ap - prev) / (1 - prev)), roc_auc=float(roc_auc_score(gold, vals)), internal_LR_compatible=l in candidates, internal_tumor_LR_compatible=l in tumorcands))
        tab = pd.DataFrame(table).sort_values('auprc_corrected', ascending=False)
        tab['rank_all'] = np.arange(1, len(tab) + 1)
        tab['rank_compatible'] = tab.auprc_corrected.where(tab.internal_LR_compatible).rank(ascending=False, method='min')
        tab['rank_tumor'] = tab.auprc_corrected.where(tab.internal_tumor_LR_compatible).rank(ascending=False, method='min')
        rankrows.extend(tab.to_dict('records'))
        if gate == 'main' and top == 200:
            for l in ['VEGFA', 'TGFB1', 'FGF2', 'PGF', 'PDGFB', 'ANGPT1', 'ANGPT2', 'IGF1', 'IGF2']:
                if l not in lig_ix:
                    continue
                vv = pd.DataFrame(dict(gene=bg.gene.values, potential=v[:, lig_ix[l]], in_DE_top200=gold, t=bg.t.values, q=bg.q_BH.values)).sort_values('potential', ascending=False).head(100)
                vv['ligand'] = l
                targetrows.extend(vv.to_dict('records'))
pd.DataFrame(rankrows).to_csv(O / 'NicheNet_all_ligand_rankings.csv', index=False)
pd.DataFrame(targetrows).to_csv(O / 'NicheNet_candidate_targets.csv', index=False)
core = ['ESM1', 'ANGPT2', 'PLVAP', 'APLN', 'DLL4', 'KDR', 'FLT1', 'PDGFB', 'ABCB1', 'MFSD2A']
differentials['main'].set_index('gene').reindex(core).to_csv(O / 'EC_key_response_genes.csv')
ranks = pd.DataFrame(rankrows)
ranks[(ranks.gate == 'main') & (ranks.top == 200)].head(30).to_csv(O / 'NicheNet_main_top30.csv', index=False)
(fig, ax) = plt.subplots(1, 2, figsize=(12, 5))
zres = res[main].sort_values('median_diff')
ax[0].barh(zres.pathway, zres.median_diff, color=['#278e91' if q < 0.05 else '#a8b9bf' for q in zres.q_BH_main14])
ax[0].axvline(0, color='black', lw=0.7)
ax[0].set_xlabel('BM - temporal-lobe median footprint (SD)')
ax[0].set_title('EC donors: 5 brain metastases / 9 controls')
zr = ranks[(ranks.gate == 'main') & (ranks.top == 200) & ranks.internal_tumor_LR_compatible].head(15).sort_values('auprc_corrected')
ax[1].barh(zr.ligand, zr.auprc_corrected, color='#687fba')
ax[1].set_xlabel('NicheNet adjusted AUPRC')
ax[1].set_title('Top compatible tumor ligands / receiver DE')
fig.tight_layout()
fig.savefig(O / 'signaling_summary.png', dpi=180)
fig.savefig(O / 'signaling_summary.pdf')
plt.close(fig)
json.dump(dict(status='ANALYZED', primary_comparison='5 BM vs 9 independent temporal-lobe EC donors; CD31-enriched libraries only; duplicate libraries summed per donor', PROGENy='signed perturbation footprint weighting of donor-centered/standardized log2(1+CPM); 100 gene primary,500 sensitivity; score zscaled across donors', DE='exploratory Welch on donor log2(1+CPM),1CPM in >=5donors; gene-wise BH; no cell-level p', NicheNet='cross-cohort target compatibility, not causal attribution. All ligands ranked; positive EC-DE top100/200/500; no claims of ligand specificity', limits=['Control surgical temporal lobe/epilepsy tissue, not healthy-volunteer brain', 'Brain metastases include breast, not exclusively LUAD', 'small donor sample and disease/processing confounding', 'NicheNet target genes are from external EC atlas, not matched to internal tumor donors', 'internal P3 EC n14; LR detection is not secretion or receptor activation']), open(O / 'METHODS.json', 'w'), indent=2)
print(res[main][['pathway', 'median_diff', 'p_exact', 'q_BH_main14']].to_string(index=False), flush=True)
print(ranks[(ranks.gate == 'main') & (ranks.top == 200) & ranks.ligand.isin(['VEGFA', 'TGFB1', 'FGF2', 'PGF', 'PDGFB', 'ANGPT1', 'ANGPT2'])].to_string(index=False), flush=True)
print('COMPLETE', flush=True)
