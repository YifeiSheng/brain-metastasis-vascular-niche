# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
"""L16 Visium: spatially adjusted ligand/EC-state associations, not causal mediation."""
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os
for k in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS']:
    os.environ[k] = '2'
from pathlib import Path
import numpy as np, pandas as pd, scanpy as sc, json, statsmodels.api as sm
from scipy.spatial import cKDTree
from scipy.stats import rankdata, spearmanr
from statsmodels.stats.multitest import multipletests
B = Path(str(_HANDOFF_ROOT / ''))
O = B / 'results/spatial_distance_and_state_validation'
ST = Path(str(_HANDOFF_ROOT / 'data/spatial'))
SLIDES = {'S1_T': ('batch_10562_2022_05_30', 'P1', 'LUAD'), 'S2_C': ('batch_10562_2022_05_30', 'P5', 'LUAD'), 'Toct6': ('batch_10562_2022_05_30', 'P8', 'LUAD'), 'Coct6': ('batch_10562_2022_05_30', 'P8', 'LUAD'), 'Toct4': ('batch_15551_2022_03_28', 'P6', 'PCNSL'), 'Coct4': ('batch_15551_2022_03_28', 'P6', 'PCNSL'), 'Toct5': ('batch_15551_2022_03_28', 'P2', 'PCNSL'), 'Coct5': ('batch_15551_2022_03_28', 'P2', 'PCNSL')}
sets = json.load(open(O / 'gene_sets.json'))['gene_sets']
sets.update({'myeloid': ['LYZ', 'AIF1', 'LST1', 'CSF1R', 'CD68'], 'brain': ['GFAP', 'AQP4', 'PLP1', 'MBP', 'MOBP', 'SNAP25'], 'LUAD': ['EPCAM', 'KRT8', 'KRT18', 'KRT7', 'NAPSA', 'SFTPB'], 'PCNSL': ['MS4A1', 'CD79A', 'CD79B', 'CD19', 'PAX5']})
rows = []
scores = []
met = []
for (slide, (batch, patient, disease)) in SLIDES.items():
    root = ST / batch / '1.SpaceRanger' / slide
    a = sc.read_10x_h5(str(root / 'filtered_feature_bc_matrix.h5'))
    a.var_names_make_unique()
    pf = root / 'spatial/tissue_positions_list.csv'
    if pf.exists():
        pos = pd.read_csv(pf, header=None, names=['barcode', 'in_tissue', 'array_row', 'array_col', 'y', 'x']).set_index('barcode')
    else:
        pos = pd.read_csv(root / 'spatial/tissue_positions.csv').set_index('barcode')
        pos = pos.rename(columns={'pxl_row_in_fullres': 'y', 'pxl_col_in_fullres': 'x'})
    pos = pos.reindex(a.obs_names)
    keep = pos.in_tissue.eq(1).values
    a = a[keep].copy()
    pos = pos[keep]
    sf = json.load(open(root / 'spatial/scalefactors_json.json'))
    xy = pos[['x', 'y']].values * (55 / sf['spot_diameter_fullres'])
    tot = np.asarray(a.X.sum(axis=1)).ravel()
    sc.pp.normalize_total(a, target_sum=10000.0)
    sc.pp.log1p(a)
    x = a.X.tocsc()
    gi = {g: i for (i, g) in enumerate(a.var_names)}

    def val(g):
        return x[:, gi[g]].toarray().ravel() if g in gi else np.full(a.n_obs, np.nan)
    d = pd.DataFrame(index=a.obs_names)
    for (k, gs) in sets.items():
        gg = [g for g in gs if g in gi]
        d[k] = np.mean([val(g) for g in gg], axis=0) if gg else np.nan
    for g in ['VEGFA', 'PGF', 'FGF2', 'PDGFB', 'ANGPT2', 'ESM1', 'SLC2A1', 'CA9', 'ACSS2', 'PHGDH']:
        d[g] = val(g)
    d['log_depth'] = np.log1p(tot)
    d['tumor_score'] = d[disease]
    d['slide'] = slide
    d['patient'] = patient
    d['disease'] = disease
    d['x_um'] = xy[:, 0]
    d['y_um'] = xy[:, 1]
    d['block'] = (xy[:, 0] // 500).astype(int).astype(str) + np.char.add('_', (xy[:, 1] // 500).astype(int).astype(str))
    bands = pd.read_csv(B / f'results/internal_spatial_validation/spot_bands_{slide}.csv', index_col=0).reindex(d.index)
    d['band'] = bands.band
    nb = cKDTree(xy).query(xy, k=7)[1][:, 1:]
    for lig in ['VEGFA', 'PGF', 'FGF2']:
        d[lig + '_neighbor'] = d[lig].values[nb].mean(axis=1)
    for q in [0.5, 0.75, 0.9]:
        sel = d.endothelial >= d.endothelial.quantile(q)
        for hyp_adj in [False, True]:
            controls = ['log_depth', 'endothelial', 'tumor_score', 'myeloid', 'brain'] + (['hypoxia'] if hyp_adj else [])
            for lig in ['VEGFA', 'PGF', 'FGF2']:
                z = d.loc[sel, [lig + '_neighbor', 'EC_activation'] + controls + ['block']].dropna()
                n = len(z)
                if n < 50:
                    continue
                ranked = z[[lig + '_neighbor', 'EC_activation'] + controls].apply(rankdata)
                cov = sm.add_constant(ranked[controls])
                xr = sm.OLS(ranked[lig + '_neighbor'], cov).fit().resid
                yr = sm.OLS(ranked.EC_activation, cov).fit().resid
                xr = (xr - xr.mean()) / (xr.std() + 1e-12)
                yr = (yr - yr.mean()) / (yr.std() + 1e-12)
                fit = sm.OLS(yr, sm.add_constant(xr)).fit(cov_type='cluster', cov_kwds={'groups': z.block})
                ci = fit.conf_int().iloc[1]
                rows.append(dict(slide=slide, patient=patient, disease=disease, EC_quantile=q, hypoxia_adjusted=hyp_adj, ligand=lig, n_spots=n, n_blocks=z.block.nunique(), partial_r=float(fit.params.iloc[1]), ci_low=float(ci[0]), ci_high=float(ci[1]), p=float(fit.pvalues.iloc[1]), raw_rho=float(spearmanr(z[lig + '_neighbor'], z.EC_activation).statistic)))
    for (band, z) in d.groupby('band'):
        for k in ['hypoxia', 'glycolysis', 'acetate', 'serine_synthesis', 'glutamine', 'VEGFA', 'PDGFB']:
            met.append(dict(slide=slide, patient=patient, disease=disease, band=band, program=k, n_spots=len(z), mean=float(z[k].mean()), median=float(z[k].median())))
    d.to_csv(O / f'visium_spot_states_{slide}.csv.gz', compression='gzip')
    print('COMPLETE', slide, len(d), flush=True)
r = pd.DataFrame(rows)
r['q_BH_all_models'] = multipletests(r.p.fillna(1), method='fdr_bh')[1]
primary = (r.EC_quantile == 0.75) & ~r.hypoxia_adjusted
r.loc[primary, 'q_BH_primary_24'] = multipletests(r.loc[primary, 'p'].fillna(1), method='fdr_bh')[1]
r.to_csv(O / 'visium_ligand_EC_associations.csv', index=False)
pd.DataFrame(met).to_csv(O / 'visium_band_metabolic_programs.csv', index=False)
print(r[primary].to_string(index=False), flush=True)
