# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
from pathlib import Path
import json, datetime, hashlib, itertools
import numpy as np, pandas as pd
from scipy.stats import rankdata
from statsmodels.stats.multitest import multipletests
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
B = Path(str(_HANDOFF_ROOT / ''))
O = B / 'results/VEGF_sprouting_calibration'
gs = json.loads((B / 'data/analysis_definitions/vascular_gene_sets.json').read_text())
pan = {**gs['primary_panels'], **gs['sensitivity_panels']}
rows = []
cover = []
scores = []
rng = np.random.default_rng(180104)
for acc in ['GSE227549', 'GSE196776']:
    d = O / acc
    sm = pd.read_csv(d / 'selected_samples.csv')
    E = pd.read_csv(d / 'voom_logCPM.csv.gz').set_index('symbol')
    E = E.loc[E.index.notna()]
    assert not E.index[E.index.isin(sum(pan.values(), []))].duplicated().any()
    U = pd.read_csv(d / 'all_quantified_gene_universe.csv.gz')
    for (name, genes) in pan.items():
        av = [g for g in genes if g in E.index and E.loc[g, sm.gsm].std(ddof=1) > 1e-10]
        for g in genes:
            cover.append(dict(study=acc, panel=name, gene=g, measured=g in U.symbol.values, used=g in av, exclusion='' if g in av else 'not expressed by filterByExpr, unmapped, or zero variance'))
        if len(av) < max(2, int(np.ceil(len(genes) / 2))):
            rows.append(dict(study=acc, panel=name, n_available=len(av), p=np.nan, status='insufficient coverage'))
            continue
        mat = E.loc[av, sm.gsm].to_numpy(float)
        zz = (mat - mat.mean(1)[:, None]) / mat.std(1, ddof=1)[:, None]
        v = zz.mean(0)
        g = (sm.group == 'VEGF').to_numpy()
        a = v[g]
        b = v[~g]
        nr = len(a)
        nc = len(b)
        rk = rankdata(v)
        obs = abs(rk[g].sum() - nr * (len(v) + 1) / 2)
        null = np.array([abs(rk[list(ii)].sum() - nr * (len(v) + 1) / 2) for ii in itertools.combinations(range(len(v)), nr)])
        p = float(np.mean(null >= obs - 1e-10))
        u = rk[g].sum() - nr * (nr + 1) / 2
        rbc = 2 * u / (nr * nc) - 1
        ba = rng.choice(a, (10000, nr), replace=True).mean(1)
        bb = rng.choice(b, (10000, nc), replace=True).mean(1)
        ci = np.quantile(ba - bb, [0.025, 0.975])
        row = dict(study=acc, panel=name, primary=name in gs['primary_panels'], n_VEGF=nr, n_Control=nc, n_available=len(av), n_planned=len(genes), genes_used=';'.join(av), mean_VEGF=a.mean(), mean_Control=b.mean(), delta_z=a.mean() - b.mean(), bootstrap_95lo=ci[0], bootstrap_95hi=ci[1], rank_biserial=rbc, p=p, status='valid')
        row['mean_unweighted_gene_logCPM_difference'] = float(mat[:, g].mean() - mat[:, ~g].mean())
        rows.append(row)
        for (i, x) in sm.iterrows():
            scores.append(dict(study=acc, gsm=x.gsm, title=x.title, group=x.group, panel=name, score=v[i]))
res = pd.DataFrame(rows)
res['q_primary12'] = np.nan
mask = res.primary & res.p.notna()
res.loc[mask, 'q_primary12'] = multipletests(res.loc[mask, 'p'], method='fdr_bh')[1]
res['q_primary6_per_study'] = np.nan
for acc in res.study.unique():
    mask = (res.study == acc) & res.primary & res.p.notna()
    res.loc[mask, 'q_primary6_per_study'] = multipletests(res.loc[mask, 'p'], method='fdr_bh')[1]
mask = res.p.notna()
res.loc[mask, 'q_all14'] = multipletests(res.loc[mask, 'p'], method='fdr_bh')[1]
res.to_csv(O / 'VEGF_panel_tests.csv', index=False)
pd.DataFrame(scores).to_csv(O / 'VEGF_panel_sample_scores.csv', index=False)
pd.DataFrame(cover).to_csv(O / 'VEGF_panel_gene_coverage.csv', index=False)
pd.DataFrame(scores).pivot(index=['study', 'gsm', 'title', 'group'], columns='panel', values='score').to_csv(O / 'VEGF_panel_sample_scores_wide.csv')
(fig, ax) = plt.subplots(1, 2, figsize=(12, 5.4), sharex=True, sharey=True)
labels = ['EC cycle', 'Tip/guidance', 'Activation/fenestration', 'ECM associated', 'BBB transport', 'Junction']
for (a, acc, label) in zip(ax, ['GSE227549', 'GSE196776'], ['3D spheroid: VEGF vs basal (5 vs 5)', '2D monolayer: VEGF vs basal (3 vs 3)']):
    f = res[(res.study == acc) & res.primary].set_index('panel').loc[list(gs['primary_panels'])]
    for (i, (_, r)) in enumerate(f.iterrows()):
        a.errorbar(r.delta_z, i, xerr=[[r.delta_z - r.bootstrap_95lo], [r.bootstrap_95hi - r.delta_z]], fmt='o', color='#197b8a', capsize=4)
        a.text(2.98, i, f'q={r.q_primary12:.3f}', ha='right', va='center', fontsize=9)
    a.axvline(0, color='gray', lw=0.8)
    a.set_title(label, fontsize=11)
    a.set_xlabel('Within-assay mean gene-z difference\nVEGF − control (bootstrap 95% CI)')
    a.grid(axis='x', alpha=0.15)
ax[0].set_yticks(range(6), labels)
ax[0].invert_yaxis()
ax[0].set_xlim(-2.0, 3.15)
fig.suptitle('Public VEGF perturbations calibrate expression-panel interpretation', fontsize=14)
fig.text(0.5, 0.015, 'Separate experiments; 18 h (3D) and 24 h (2D). Pooled HUVECs; donor/pair IDs unavailable. 2D batch unresolved.\nq: BH across 12 primary tests; CI reflects samples, not independent human donors. RNA panels are not vessel morphology.', ha='center', fontsize=8.7)
fig.tight_layout(rect=[0, 0.085, 1, 0.95])
fig.savefig(O / 'VEGF_perturbation_calibration.png', dpi=180)
fig.savefig(O / 'VEGF_perturbation_calibration.pdf')
plt.close(fig)
print(res[['study', 'panel', 'n_available', 'delta_z', 'rank_biserial', 'p', 'q_primary12', 'q_all14']].to_string(index=False))
