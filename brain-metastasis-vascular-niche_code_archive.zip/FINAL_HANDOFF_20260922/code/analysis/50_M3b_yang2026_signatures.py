# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import pandas as pd, numpy as np
E = str(_HANDOFF_ROOT / 'data/external/bulk/Yang2026_BrM_zenodo')
O = str(_HANDOFF_ROOT / 'results/internal_programs_and_CNV')
SIG = {'NOTCH3+周细胞血管龛': ['PDGFRB', 'NOTCH3', 'RGS5', 'HIGD1B', 'NDUFA4L2', 'CSPG4', 'MCAM', 'KCNJ8'], 'BAM样巨噬': ['F13A1', 'COLEC12', 'SIGLEC1', 'CD209', 'FOLR2', 'LYVE1', 'MRC1', 'CD163'], '脂质TAM': ['SPP1', 'GPNMB', 'TREM2', 'PLIN2', 'LGALS3', 'CTSD', 'APOC1', 'APOE'], '干扰素巨噬': ['CXCL9', 'CXCL10', 'GBP4', 'GBP5', 'IFI44L', 'TNFSF10', 'CD163', 'IDO1'], '黏液分泌型肿瘤': ['MUC5B', 'TFF3', 'AGR2', 'LCN2', 'CEACAM5', 'MUC1', 'CEACAM6'], 'CXCL13+耗竭T': ['CXCL13', 'PDCD1', 'TNFRSF9', 'ENTPD1', 'LAG3', 'CTLA4', 'HAVCR2', 'CD8A'], '活化Treg': ['FOXP3', 'IL2RA', 'TNFRSF4', 'TNFRSF18', 'ICOS', 'CTLA4', 'TIGIT', 'CCR8'], '反应性星形胶质': ['GFAP', 'SERPINA3', 'CD44', 'C3', 'CHI3L1', 'VIM', 'AQP4'], '活化小胶质': ['P2RY12', 'GPR34', 'IL1B', 'CCL3', 'CCL4', 'ATF3', 'CX3CR1'], 'CCL19轴': ['CCL19', 'CCR7', 'CCL21'], '神经样(自定义)': ['NCAM1', 'L1CAM', 'GAP43', 'STMN2', 'DCX', 'TUBB3', 'ELAVL4', 'NRXN1', 'SYP', 'SNAP25', 'SYT1', 'NEFL', 'MAP2', 'UCHL1']}
MARK = {'BrMS1神经样(GFAP)': 'GFAP', 'BrMS2免疫浸润(IFI16)': 'IFI16', 'BrMS3代谢(ACSL5)': 'ACSL5', 'BrMS4增殖(TOP2A)': 'TOP2A'}
rows = []
for (name, f) in [('discovery', 'discovery.counts.csv'), ('validation', 'validation.counts.csv')]:
    c = pd.read_csv(f'{E}/{f}', index_col=0)
    c = c[~c.index.duplicated()]
    cpm = np.log2(c / c.sum() * 1000000.0 + 1)
    sc = {}
    for (k, g) in SIG.items():
        gg = [x for x in g if x in cpm.index]
        z = cpm.loc[gg].sub(cpm.loc[gg].mean(1), axis=0).div(cpm.loc[gg].std(1) + 1e-09, axis=0)
        sc[k] = z.mean(0)
    S = pd.DataFrame(sc)
    for (k, gname) in MARK.items():
        if gname in cpm.index:
            S[k] = cpm.loc[gname].values
    S['cohort'] = name
    rows.append(S)
S = pd.concat(rows)
S.to_csv(f'{O}/M3b_yang2026_signature_scores.csv')
sigs = list(SIG)
mk = list(MARK)
C = S[sigs + mk].corr(method='spearman')
pd.set_option('display.width', 260)
print('=== 样本数:', S.groupby('cohort').size().to_dict())
print('\n=== 我们的签名 vs Yang 四亚型 marker 的 Spearman (337 例)')
print(C.loc[sigs, mk].round(2).to_string())
print('\n=== 签名之间的 Spearman')
print(C.loc[sigs, sigs].round(2).to_string())
C.round(3).to_csv(f'{O}/M3b_yang2026_spearman.csv')
