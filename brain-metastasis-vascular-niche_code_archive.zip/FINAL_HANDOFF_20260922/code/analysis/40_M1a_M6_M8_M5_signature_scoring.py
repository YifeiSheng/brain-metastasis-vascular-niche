# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import numpy as np, pandas as pd, scanpy as sc, scipy.sparse as sp, json, os, time
D = str(_HANDOFF_ROOT / 'data/integrated')
O = str(_HANDOFF_ROOT / 'results/internal_programs_and_CNV')
L = open(f'{O}/progress_40.txt', 'a', buffering=1)
log = lambda *a: L.write(time.strftime('[%H:%M:%S] ') + ' '.join(map(str, a)) + '\n')
a = sc.read_h5ad(f'{D}/data/sc_counts.h5ad')
sc.pp.normalize_total(a, target_sum=10000.0)
sc.pp.log1p(a)
pc = pd.read_csv(f'{D}/output/per_cell_labels.csv', index_col=0)
a.obs['sub05'] = pc.sub05.reindex(a.obs_names).fillna(a.obs.atomic_cluster_id.astype(str))
a.obs['lineage'] = pc.lineage_l1.reindex(a.obs_names)
a.obs['label'] = pc.proposed_label.reindex(a.obs_names)
pm = pd.read_csv(f'{D}/data/patient_metadata.csv')
a.obs['disease'] = a.obs.patient_id.map(dict(zip(pm.patient_id, pm['疾病'])))
import decoupler as dc
try:
    hm = dc.op.hallmark(organism='human')
    hm.columns = [c.lower() for c in hm.columns]
    src = [c for c in hm.columns if c in ('source', 'geneset')][0]
    tgt = [c for c in hm.columns if c in ('target', 'genesymbol', 'gene')][0]
    HALL = {k.replace('HALLMARK_', ''): v[tgt].tolist() for (k, v) in hm.groupby(src)}
    log('hallmark 集合数', len(HALL))
except Exception as e:
    HALL = {}
    log('hallmark 获取失败', repr(e))
keep = ['G2M_CHECKPOINT', 'E2F_TARGETS', 'MITOTIC_SPINDLE', 'HYPOXIA', 'ANGIOGENESIS', 'EPITHELIAL_MESENCHYMAL_TRANSITION', 'INTERFERON_GAMMA_RESPONSE', 'INTERFERON_ALPHA_RESPONSE', 'TNFA_SIGNALING_VIA_NFKB', 'OXIDATIVE_PHOSPHORYLATION', 'GLYCOLYSIS', 'TGF_BETA_SIGNALING', 'NOTCH_SIGNALING', 'KRAS_SIGNALING_UP', 'P53_PATHWAY', 'APOPTOSIS', 'UNFOLDED_PROTEIN_RESPONSE', 'INFLAMMATORY_RESPONSE', 'IL6_JAK_STAT3_SIGNALING', 'CHOLESTEROL_HOMEOSTASIS', 'FATTY_ACID_METABOLISM', 'MYC_TARGETS_V1', 'MTORC1_SIGNALING', 'WNT_BETA_CATENIN_SIGNALING', 'HEDGEHOG_SIGNALING']
SETS = {f'HALLMARK_{k}': HALL[k] for k in keep if k in HALL}
CUSTOM = {'CIN70_子集(Carter2006,55基因)': ['TPX2', 'PRC1', 'FOXM1', 'CDK1', 'TGIF2', 'MCM2', 'H2AZ1', 'TOP2A', 'PCNA', 'UBE2C', 'MELK', 'TRIP13', 'NCAPD2', 'MCM7', 'RNASEH2A', 'RAD51AP1', 'KIF20A', 'CDC45', 'MAD2L1', 'ESPL1', 'CCNB2', 'FEN1', 'TTK', 'CCT5', 'RFC4', 'ATAD2', 'CKAP5', 'NUP205', 'CDC20', 'CKS2', 'RRM2', 'ELAVL1', 'CCNB1', 'RRM1', 'AURKB', 'MSH6', 'EZH2', 'CTPS1', 'DKC1', 'OIP5', 'CDCA8', 'PTTG1', 'CEP55', 'H2AX', 'CMAS', 'NCAPG', 'MCM10', 'LSM4', 'NCAPG2', 'ASF1B', 'ZWINT', 'PBK', 'ZWILCH', 'CDCA3', 'ECT2'], '神经样程序_自定义(Biermann/Tagore代理)': ['NCAM1', 'NELL1', 'LRRC1', 'L1CAM', 'GAP43', 'STMN2', 'DCX', 'TUBB3', 'ELAVL4', 'NRXN1', 'NLGN1', 'SYP', 'SNAP25', 'SYT1', 'NEFL', 'NEFM', 'MAP2', 'RTN1', 'UCHL1', 'BEX1', 'SCG2', 'STMN4', 'CRMP1', 'DPYSL3', 'GPM6A', 'NRCAM', 'CNTN1', 'ROBO2', 'KIF5A', 'ENO2'], '突触_谷氨酸GABA受体(Savchuk)': ['GRIA1', 'GRIA2', 'GRIA3', 'GRIA4', 'GRIN1', 'GRIN2A', 'GRIN2B', 'GRIN2D', 'GRIK2', 'GRM1', 'GRM5', 'GABRA1', 'GABRA2', 'GABRB1', 'GABRB2', 'GABRB3', 'GABRG2', 'GABBR1', 'GABBR2'], '突触_前后膜结构': ['SYP', 'SNAP25', 'SYT1', 'STX1A', 'VAMP2', 'DLG4', 'SHANK2', 'SHANK3', 'NRXN1', 'NLGN1', 'NLGN3', 'HOMER1', 'CAMK2A', 'CAMK2B', 'SYN1', 'SV2A', 'RIMS1', 'BSN'], '神经活动依赖(IEG)': ['FOS', 'NPAS4', 'EGR1', 'ARC', 'BDNF', 'NR4A1', 'FOSB', 'JUNB', 'EGR2', 'EGR3'], '电压门控通道': ['SCN1A', 'SCN2A', 'SCN3A', 'SCN8A', 'CACNA1A', 'CACNA1B', 'CACNA1C', 'CACNA1E', 'KCNQ2', 'KCNQ3', 'KCNC1', 'HCN1'], '小胶质稳态(Klemm/Bowman)': ['P2RY12', 'TMEM119', 'CX3CR1', 'SALL1', 'SLC2A5', 'GPR34', 'OLFML3', 'P2RY13', 'CSF1R', 'SELPLG'], '血源性巨噬MDM(Klemm/Bowman)': ['ITGA4', 'CCR2', 'TGFBI', 'S100A4', 'S100A6', 'VCAN', 'FCN1', 'LYZ', 'CD44', 'EMP3', 'CRIP1', 'LST1'], 'DAM(Keren-Shaul2017,Gan2024)': ['TREM2', 'APOE', 'LPL', 'CST7', 'CD9', 'ITGAX', 'CLEC7A', 'SPP1', 'LGALS3', 'CTSB', 'CTSD', 'CTSL', 'AXL', 'TYROBP', 'GPNMB', 'CD63', 'FABP5'], 'TAM_PLTP(Bai2026)': ['PLTP', 'C1QA', 'C1QB', 'C1QC', 'GPNMB', 'APOE', 'CD163', 'CCL18', 'MSR1', 'SELENOP', 'FOLR2', 'HLA-DRA', 'HLA-DPB1'], 'TAM_SPP1(Bai2026)': ['SPP1', 'VEGFA', 'VCAN', 'FN1', 'MARCKS', 'CTSB', 'LGALS1', 'TIMP1', 'IL1RN', 'CD44'], 'HSP70高应激T(Bai2026)': ['HSPA1A', 'HSPA1B', 'HSPH1', 'DNAJB1', 'HSPA6', 'HSPD1', 'HSPE1', 'BAG3', 'DNAJA1', 'HSP90AA1'], 'M1样(常用集合)': ['IL1B', 'TNF', 'IL6', 'CXCL9', 'CXCL10', 'CXCL11', 'CD80', 'CD86', 'IDO1', 'IRF1', 'IRF5', 'SOCS3', 'CCL5', 'GBP1', 'GBP5', 'STAT1'], 'M2样(常用集合)': ['CD163', 'MRC1', 'CD209', 'MSR1', 'IL10', 'TGFB1', 'CCL18', 'CCL22', 'FOLR2', 'VEGFA', 'MMP9', 'F13A1', 'LYVE1', 'SELENOP', 'CCL13', 'STAB1'], 'T耗竭': ['PDCD1', 'HAVCR2', 'LAG3', 'TIGIT', 'CTLA4', 'TOX', 'ENTPD1', 'LAYN', 'CXCL13', 'TNFRSF9'], 'T组织驻留Trm': ['ITGAE', 'ZNF683', 'CD69', 'CXCR6', 'ITGA1', 'RUNX3', 'PRDM1', 'CD101'], 'Tfh': ['CXCL13', 'CXCR5', 'PDCD1', 'ICOS', 'BCL6', 'IL21', 'TOX2', 'CD200', 'BTLA'], '浆母样PBL(Kobayashi2025)': ['CD38', 'ENTPD1', 'SLAMF7', 'PRDM1', 'XBP1', 'IRF4', 'MZB1', 'JCHAIN', 'TNFRSF17', 'SDC1', 'CD27', 'FKBP11', 'DERL3'], '反应性星形胶质': ['GFAP', 'VIM', 'SERPINA3', 'CD44', 'C3', 'CHI3L1', 'S100A10', 'LCN2', 'OSMR', 'STAT3', 'AQP4', 'SLC1A3'], '少突胶质脂质合成(Yang2026JTM)': ['FASN', 'ACACA', 'SCD', 'ELOVL6', 'HMGCR', 'HMGCS1', 'SREBF1', 'SREBF2', 'DHCR24', 'FDFT1', 'LSS', 'CYP51A1']}
SETS.update(CUSTOM)
genes = set(a.var_names)
SETS = {k: [g for g in v if g in genes] for (k, v) in SETS.items()}
SETS = {k: v for (k, v) in SETS.items() if len(v) >= 5}
json.dump(SETS, open(f'{O}/M_gene_sets_used.json', 'w'), ensure_ascii=False, indent=1)
log('基因集', len(SETS))
for (k, v) in SETS.items():
    sc.tl.score_genes(a, v, score_name=k, ctrl_size=50, n_bins=25, random_state=0)
sc_cols = list(SETS.keys())
df = a.obs[['sample', 'patient_id', 'disease', 'tissue_role', 'atomic_cluster_id', 'sub05', 'lineage', 'label'] + sc_cols].copy()
df.to_csv(f'{O}/M_signature_scores_per_cell.csv.gz', compression='gzip')
thr = {k: float(np.quantile(df[k], 0.9)) for k in sc_cols}
g = df.groupby(['lineage', 'atomic_cluster_id', 'sub05'], observed=True)
summ = g[sc_cols].mean().round(3)
summ.columns = [c + '__mean' for c in summ.columns]
pos = g[sc_cols].apply(lambda x: (x > pd.Series(thr)).mean()).round(3)
pos.columns = [c + '__pos' for c in pos.columns]
n = g.size().rename('n_cells')
lab = g['label'].first()
out = pd.concat([n, lab, summ, pos], axis=1)
out.to_csv(f'{O}/M_signature_scores_by_subcluster.csv')
gp = df.groupby(['sub05', 'patient_id'], observed=True)
npat = gp.size()
mp = gp[sc_cols].mean().round(3)
mp['n'] = npat
mp[mp.n >= 20].to_csv(f'{O}/M_signature_scores_by_subcluster_patient.csv')
for gsym in ['CCL19', 'CCR7', 'CXCL13', 'CXCR5', 'CCL21', 'PDGFB', 'PDGFRB', 'DLL4', 'JAG1', 'NOTCH3', 'ANGPT2', 'TEK', 'GAS6', 'AXL', 'SPP1', 'CD44', 'CXCL12', 'CXCR4', 'CSF1', 'CSF1R', 'IL34', 'TGFB1', 'VEGFA', 'KDR', 'FLT1', 'LYVE1']:
    if gsym in genes:
        df[gsym + '_det'] = (a[:, gsym].X > 0).toarray().ravel()
        df[gsym + '_expr'] = a[:, gsym].X.toarray().ravel()
gg = df.groupby(['lineage', 'sub05'], observed=True)
lr = pd.concat([gg.size().rename('n'), gg['label'].first()] + [gg[c].mean().round(3) for c in df.columns if c.endswith('_det') or c.endswith('_expr')], axis=1)
lr.to_csv(f'{O}/M_key_ligand_receptor_by_subcluster.csv')
log('完成')
