# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import pandas as pd, numpy as np, re, gzip
from lifelines import CoxPHFitter
O = str(_HANDOFF_ROOT / 'results/internal_programs_and_CNV')
E = str(_HANDOFF_ROOT / 'data/external')
SIG = {'NOTCH3+周细胞血管龛': ['PDGFRB', 'NOTCH3', 'RGS5', 'HIGD1B', 'NDUFA4L2', 'CSPG4', 'MCAM', 'KCNJ8'], 'BAM样巨噬': ['F13A1', 'COLEC12', 'SIGLEC1', 'CD209', 'FOLR2', 'LYVE1', 'MRC1', 'CD163'], '脂质TAM': ['SPP1', 'GPNMB', 'TREM2', 'PLIN2', 'LGALS3', 'CTSD', 'APOC1', 'APOE'], '干扰素巨噬': ['CXCL9', 'CXCL10', 'GBP4', 'GBP5', 'IFI44L', 'TNFSF10', 'CD163', 'IDO1'], '黏液分泌型肿瘤': ['MUC5B', 'TFF3', 'AGR2', 'LCN2', 'CEACAM5', 'MUC1', 'CEACAM6'], 'CXCL13+耗竭T': ['CXCL13', 'PDCD1', 'TNFRSF9', 'ENTPD1', 'LAG3', 'CTLA4', 'HAVCR2', 'CD8A'], '活化Treg': ['FOXP3', 'IL2RA', 'TNFRSF4', 'TNFRSF18', 'ICOS', 'CTLA4', 'TIGIT', 'CCR8'], '反应性星形胶质': ['GFAP', 'SERPINA3', 'CD44', 'C3', 'CHI3L1', 'VIM', 'AQP4'], '活化小胶质': ['P2RY12', 'GPR34', 'IL1B', 'CCL3', 'CCL4', 'ATF3', 'CX3CR1'], 'CCL19轴': ['CCL19', 'CCR7', 'CCL21']}

def score(df):
    out = {}
    for (k, g) in SIG.items():
        gg = [x for x in g if x in df.index]
        z = df.loc[gg].sub(df.loc[gg].mean(1), axis=0).div(df.loc[gg].std(1) + 1e-09, axis=0)
        out[k] = z.mean(0)
    return pd.DataFrame(out)
g = pd.read_csv(f'{E}/spatial/GSE200563/GSE200563_processed_data.txt.gz', sep='\t', index_col=0)
g = g[~g.index.duplicated()]
logg = np.log2(g.astype(float) + 1)

def region(c):
    c = str(c)
    if c.startswith('TIME-L'):
        return 'TIME-L(原发肺免疫区)'
    if c.startswith('TIME-B') or c.startswith('TIME_B'):
        return 'TIME-B(脑转移免疫区)'
    if c.startswith('TBME'):
        return 'TBME(脑转移的脑微环境)'
    if c.startswith('mLN'):
        return 'mLN(转移淋巴结)'
    if c.startswith('LB'):
        return 'LB(脑转移肿瘤核心)'
    if c.startswith('L'):
        return 'L(原发肺肿瘤核心)'
    return '其他:' + c[:6]
s = score(logg)
s['region'] = [region(c) for c in s.index]
print('ROI 分区计数:', s.region.value_counts().to_dict())
summ = s.groupby('region').mean().round(2)
summ.to_csv(f'{O}/M3_GSE200563_signature_by_region.csv')
s.to_csv(f'{O}/M3_GSE200563_signature_per_ROI.csv')
print(summ.T.to_string())
from scipy.stats import mannwhitneyu
rows = []
for k in SIG:
    a = s[s.region.str.startswith('LB')][k]
    b = s[s.region.str.startswith('L(')][k]
    c = s[s.region.str.startswith('TBME')][k]
    d = s[s.region.str.startswith('TIME-L')][k]
    rows.append(dict(signature=k, LB_vs_L_diff=round(a.mean() - b.mean(), 2), LB_vs_L_p=mannwhitneyu(a, b).pvalue if len(a) > 2 and len(b) > 2 else np.nan, TBME_vs_TIMEL_diff=round(c.mean() - d.mean(), 2), TBME_vs_TIMEL_p=mannwhitneyu(c, d).pvalue if len(c) > 2 and len(d) > 2 else np.nan))
cmp = pd.DataFrame(rows)
cmp.to_csv(f'{O}/M3_GSE200563_region_tests.csv', index=False)
print(cmp.to_string(index=False))
x = pd.read_csv(f'{E}/bulk/TCGA-LUAD/TCGA-LUAD.star_fpkm.tsv.gz', sep='\t', index_col=0)
try:
    pm = pd.read_csv(f'{E}/bulk/TCGA-LUAD/gencode.v36.annotation.gtf.gene.probemap', sep='\t')
    idmap = dict(zip(pm.id, pm.gene))
except Exception:
    import urllib.request
    urllib.request.urlretrieve('https://gdc-hub.s3.us-east-1.amazonaws.com/download/gencode.v36.annotation.gtf.gene.probemap', f'{E}/bulk/TCGA-LUAD/gencode.v36.annotation.gtf.gene.probemap')
    pm = pd.read_csv(f'{E}/bulk/TCGA-LUAD/gencode.v36.annotation.gtf.gene.probemap', sep='\t')
    idmap = dict(zip(pm.id, pm.gene))
x.index = [idmap.get(i, i) for i in x.index]
x = x[~x.index.duplicated()]
x = x.loc[:, [c for c in x.columns if c[13:15] in ('01', '02')]]
surv = pd.read_csv(f'{E}/bulk/TCGA-LUAD/TCGA-LUAD.survival.tsv.gz', sep='\t').set_index('sample')
st = score(x)
st = st.join(surv[['OS', 'OS.time']], how='inner')
st = st[st['OS.time'].notna()]
st.to_csv(f'{O}/M3_TCGA_LUAD_signature_scores.csv')
rows = []
for k in SIG:
    d = st[[k, 'OS', 'OS.time']].dropna()
    d = d.rename(columns={k: 'score'})
    d['score'] = (d.score - d.score.mean()) / d.score.std()
    cph = CoxPHFitter().fit(d, 'OS.time', 'OS')
    hr = float(np.exp(cph.params_['score']))
    p = float(cph.summary.loc['score', 'p'])
    d['high'] = (d.score > d.score.median()).astype(int)
    c2 = CoxPHFitter().fit(d[['high', 'OS', 'OS.time']], 'OS.time', 'OS')
    rows.append(dict(signature=k, n=len(d), HR_per_SD=round(hr, 3), p_continuous=p, HR_high_vs_low=round(float(np.exp(c2.params_['high'])), 3), p_median_split=float(c2.summary.loc['high', 'p'])))
cox = pd.DataFrame(rows)
cox.to_csv(f'{O}/M3_TCGA_LUAD_cox.csv', index=False)
print('\nTCGA-LUAD (原发肺, n=%d) Cox:' % len(st))
print(cox.to_string(index=False))
