# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import numpy as np, pandas as pd, os, json
from sklearn.neighbors import NearestNeighbors
from sklearn.cluster import KMeans
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
font_manager.fontManager.addfont(str(_HANDOFF_ROOT / 'environment/NotoSansCJKsc-Regular.otf'))
plt.rcParams['font.family'] = ['Noto Sans CJK SC', 'DejaVu Sans']
ST = str(_HANDOFF_ROOT / 'data/spatial')
X8 = str(_HANDOFF_ROOT / 'results/internal_spatial_validation')
O = str(_HANDOFF_ROOT / 'results/internal_programs_and_CNV')
SL = {'S1_T': ('batch_10562_2022_05_30', 'P1 肺腺癌瘤'), 'Toct6': ('batch_10562_2022_05_30', 'P8 肺腺癌瘤'), 'Coct6': ('batch_10562_2022_05_30', 'P8 肺腺癌旁'), 'S2_C': ('batch_10562_2022_05_30', 'P5 肺腺癌旁'), 'Toct4': ('batch_15551_2022_03_28', 'P6 淋巴瘤瘤'), 'Coct4': ('batch_15551_2022_03_28', 'P6 淋巴瘤旁'), 'Toct5': ('batch_15551_2022_03_28', 'P2 淋巴瘤瘤'), 'Coct5': ('batch_15551_2022_03_28', 'P2 淋巴瘤旁')}
FEAT = ['肺腺癌上皮', '淋巴瘤B', 'T细胞', '中性粒', '星形胶质(sc缺失)', '反应性星形胶质', '少突胶质成熟', '神经元(sc缺失)', 'TLS(三级淋巴结构)', '边界相关巨噬 BAM(LYVE1/CD209/COLEC12/F13A1+)', '脂质相关肿瘤相关巨噬(SPP1+/GPNMB+/TREM2+/PLIN2+)', '干扰素反应巨噬(GBP4/5+/CXCL9/10+/IFI44L+)', '稳态小胶质(P2RY12+/CX3CR1+/SALL1+)', '活化小胶质(IL1B+/CCL3+/CCL4+/ATF3+)', '血管周细胞/平滑肌(CSPG4+/NOTCH3+/RGS5+/KCNJ8+)', '内皮细胞(CDH5+/KDR+/CD34+/ABCB1+ 血脑屏障型)', '成纤维细胞(DCN+/LUM+/COL1A2+/PDGFRB+)', '活化调节性 T 细胞(FOXP3+/TNFRSF9+/LAYN+/IL2RA+)', 'CXCL13+ 耗竭样 CD8 T(TNFRSF9+/ENTPD1+/MIR155HG+)', '黏液/分泌型肺腺癌细胞(MUC5B+/TFF3+/AGR2+/CEACAM5+)', '经典单核细胞(FCN1+/S100A12+/SELL+/TREM1+)']
short = {f: f.split('(')[0].strip() for f in FEAT}
frames = []
for (sl, (b, desc)) in SL.items():
    ss = pd.read_csv(f'{X8}/spot_scores_{sl}.csv', index_col=0)
    bd = pd.read_csv(f'{X8}/spot_bands_{sl}.csv', index_col=0)
    pos = pd.read_csv(f'{ST}/{b}/1.SpaceRanger/{sl}/spatial/tissue_positions_list.csv', header=None, index_col=0)
    pos.columns = ['in_tissue', 'row', 'col', 'py', 'px']
    pos = pos.reindex(ss.index)
    xy = pos[['px', 'py']].values.astype(float)
    F = ss[[f for f in FEAT if f in ss.columns]].copy()
    nn = NearestNeighbors(n_neighbors=7).fit(xy)
    (dist, idx) = nn.kneighbors(xy)
    dmin = np.median(dist[:, 1])
    Nb = np.zeros_like(F.values)
    for i in range(len(F)):
        js = [j for (j, dd) in zip(idx[i, 1:], dist[i, 1:]) if dd < dmin * 1.3]
        Nb[i] = F.values[js].mean(axis=0) if js else F.values[i]
    df = pd.DataFrame(np.hstack([F.values, Nb]), index=ss.index, columns=[short[c] for c in F.columns] + ['邻居:' + short[c] for c in F.columns])
    df['slide'] = sl
    df['desc'] = desc
    df['band'] = bd.band.reindex(ss.index).values
    df['px'] = xy[:, 0]
    df['py'] = xy[:, 1]
    frames.append(df)
allf = pd.concat(frames)
feat_cols = [c for c in allf.columns if c not in ('slide', 'desc', 'band', 'px', 'py')]
allf = allf[allf.slide.isin(['S1_T', 'Toct6', 'Toct4', 'Toct5', 'Coct4'])].copy()
Z = allf.groupby('slide')[feat_cols].transform(lambda x: (x - x.mean()) / (x.std() + 1e-09)).fillna(0)
res = {}
for k in [6, 8, 10]:
    km = KMeans(n_clusters=k, n_init=10, random_state=0).fit(Z.values)
    allf[f'CN_k{k}'] = km.labels_
    res[k] = km.inertia_
K = 8
allf['CN'] = allf[f'CN_k{K}']
zc = Z.groupby(allf.CN.values).mean()
name = {}
for c in zc.index:
    top = zc.loc[c].sort_values(ascending=False).head(3)
    name[c] = f'CN{c}:' + '+'.join((t.replace('邻居:', '') for t in top.index[:2]))
allf['CN_name'] = allf.CN.map(name)
allf.to_csv(f'{O}/M4_spot_CN_assignments.csv.gz', compression='gzip')
zc.round(2).to_csv(f'{O}/M4_CN_centroids_z.csv')
comp = pd.crosstab(allf.slide, allf.CN_name, normalize='index') * 100
comp.round(1).to_csv(f'{O}/M4_CN_composition_by_slide.csv')
compb = pd.crosstab([allf.slide, allf.band], allf.CN_name, normalize='index') * 100
compb.round(1).to_csv(f'{O}/M4_CN_composition_by_slide_band.csv')
print('CN 命名:', name)
print(comp.round(1).to_string())
cmap = plt.get_cmap('tab10')
(fig, axes) = plt.subplots(1, 5, figsize=(25, 6))
for (ax, sl) in zip(axes.ravel(), ['S1_T', 'Toct6', 'Toct4', 'Toct5', 'Coct4']):
    d = allf[allf.slide == sl]
    ax.scatter(d.px, -d.py, c=[cmap(int(c) % 10) for c in d.CN], s=5, linewidths=0)
    ax.set_title(f'{sl} {SL[sl][1]}')
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_aspect('equal')
handles = [plt.Line2D([], [], marker='o', ls='', color=cmap(int(c) % 10), label=name[c]) for c in sorted(name)]
fig.legend(handles=handles, loc='lower center', ncol=4, fontsize=9)
fig.savefig(f'{O}/M4_CN_maps.png', dpi=110, bbox_inches='tight')
plt.close(fig)
(fig, ax) = plt.subplots(figsize=(14, 5))
im = ax.imshow(zc.values, cmap='RdBu_r', vmin=-2, vmax=2, aspect='auto')
ax.set_yticks(range(len(zc)))
ax.set_yticklabels([name[c] for c in zc.index], fontsize=8)
ax.set_xticks(range(len(feat_cols)))
ax.set_xticklabels(feat_cols, rotation=90, fontsize=7)
plt.colorbar(im, ax=ax)
fig.savefig(f'{O}/M4_CN_centroid_heatmap.png', dpi=120, bbox_inches='tight')
json.dump({'inertia': res, 'names': {int(k): v for (k, v) in name.items()}}, open(f'{O}/M4_meta.json', 'w'), ensure_ascii=False, indent=1)
