# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
"""L16 independent marker check in Kim2020: sample-level within-platform comparisons.
Operational marker support (not recalibrated T/M subtype frequency)."""
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os
for k in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS']:
    os.environ[k] = '2'
from pathlib import Path
import json
import numpy as np, pandas as pd, scipy.io
from scipy.stats import mannwhitneyu
from statsmodels.stats.multitest import multipletests
B = Path(str(_HANDOFF_ROOT / ''))
O = B / 'results/spatial_distance_and_state_validation'
D = B / 'results/external_replication/D4'
sets = json.load(open(O / 'gene_sets.json'))['gene_sets']
genes = pd.read_csv(D / 'features.tsv', header=None, sep='\t')[0].astype(str).values
bc = pd.read_csv(D / 'barcodes.tsv', header=None, sep='\t')[0].astype(str).values
ann = pd.read_csv(D / 'cell_annotation_subset.csv').set_index('Index').reindex(bc)
sel = ann.Cell_type.isin(['Fibroblasts', 'Endothelial cells']).values
print('READ matrix selected', int(sel.sum()), flush=True)
mat = scipy.io.mmread(D / 'matrix.mtx').tocsc()
x = mat[:, sel].T.tocsr()
del mat
tot = np.asarray(x.sum(axis=1)).ravel()
df = ann.iloc[np.where(sel)[0]].copy()
need = list(dict.fromkeys(sum(sets.values(), [])))
gi = {g: i for (i, g) in enumerate(genes)}
avail = [g for g in need if g in gi]
c = pd.DataFrame(x[:, [gi[g] for g in avail]].toarray(), index=df.index, columns=avail)
e = np.log1p(c.div(np.maximum(tot, 1), axis=0) * 10000.0)
for (k, gs) in sets.items():
    gg = [g for g in gs if g in e]
    df[k] = e[gg].mean(axis=1)
    df[k + '_ndet'] = (c[gg] > 0).sum(axis=1)
df['pericyte_candidate'] = (df.Cell_type == 'Fibroblasts') & (df.pericyte_identity_ndet >= 3)
df['pericyte_clean'] = df.pericyte_candidate & (df.epithelial_ndet < 2) & (df.endothelial_ndet < 2) & (df.astroglia_ndet < 2)
df['T_supported'] = df.T_transport_ndet >= 2
df['M_supported'] = df.M_matrix_ndet >= 2
df['both'] = df.T_supported & df.M_supported
df['functional_support'] = np.select([df['both'], df.T_supported, df.M_supported], ['T_and_M', 'T_only', 'M_only'], 'neither')
df.to_csv(O / 'kim_stromal_marker_states.csv.gz', compression='gzip')
rows = []
for gate in ['pericyte_candidate', 'pericyte_clean']:
    for ((s, origin), z) in df[df[gate]].groupby(['Sample', 'Sample_Origin']):
        rows.append(dict(sample=s, origin=origin, gate=gate, n_cells=len(z), T_fraction=float(z.T_supported.mean()), M_fraction=float(z.M_supported.mean()), both_fraction=float(z['both'].mean()), T_mean=float(z.T_transport.mean()), M_mean=float(z.M_matrix.mean())))
summ = pd.DataFrame(rows)
summ.to_csv(O / 'kim_pericyte_sample_scores.csv', index=False)
tests = []
rng = np.random.default_rng(20260922)
for gate in ['pericyte_candidate', 'pericyte_clean']:
    for min_n in [10, 20]:
        z = summ[(summ.gate == gate) & (summ.n_cells >= min_n)]
        for comp in ['tLung', 'nLung']:
            for metric in ['T_fraction', 'M_fraction', 'both_fraction', 'T_mean', 'M_mean']:
                a = z[z.origin == 'mBrain'][metric].dropna().values
                b = z[z.origin == comp][metric].dropna().values
                if min(len(a), len(b)) < 3:
                    continue
                (u, p) = mannwhitneyu(a, b, alternative='two-sided')
                boot = np.median(rng.choice(a, (2000, len(a)), replace=True), axis=1) - np.median(rng.choice(b, (2000, len(b)), replace=True), axis=1)
                tests.append(dict(gate=gate, min_cells=min_n, comparison='mBrain vs ' + comp, metric=metric, n_brain=len(a), n_comparator=len(b), median_brain=float(np.median(a)), median_comparator=float(np.median(b)), median_difference=float(np.median(a) - np.median(b)), bootstrap_ci_low=float(np.quantile(boot, 0.025)), bootstrap_ci_high=float(np.quantile(boot, 0.975)), rank_biserial=float(2 * u / (len(a) * len(b)) - 1), p=p))
t = pd.DataFrame(tests)
t['q_BH_all'] = multipletests(t.p, method='fdr_bh')[1]
t.to_csv(O / 'kim_pericyte_sample_tests.csv', index=False)
print('COMPLETE', summ.to_string(index=False), flush=True)
print(t.query("gate=='pericyte_clean' and min_cells==20").to_string(index=False), flush=True)
