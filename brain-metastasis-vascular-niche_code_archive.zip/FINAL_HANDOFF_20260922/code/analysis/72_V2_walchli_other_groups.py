# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os, glob, re, time, numpy as np, pandas as pd, scanpy as sc, scipy.io, scipy.sparse as sp, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
font_manager.fontManager.addfont(str(_HANDOFF_ROOT / 'environment/NotoSansCJKsc-Regular.otf'))
plt.rcParams['font.family'] = 'Noto Sans CJK SC'
os.environ['OMP_NUM_THREADS'] = '8'
sc.settings.n_jobs = 8
B = str(_HANDOFF_ROOT / '')
E = f'{B}/data/external/scrna/GSE256493/raw_other'
O = f'{B}/results/vascular_niche/V2'
os.makedirs(O, exist_ok=True)
L = open(f'{O}/progress.txt', 'a', buffering=1)
log = lambda *a: L.write(time.strftime('[%H:%M:%S] ') + ' '.join(map(str, a)) + '\n')
SAMPLES = [l.split(' ', 3) for l in open(f'{B}/data/external/scrna/GSE256493/download_list_other.txt').read().splitlines()]
LIN = {'EC': ['PECAM1', 'CDH5', 'CLDN5', 'VWF'], 'mural': ['PDGFRB', 'RGS5', 'NOTCH3', 'ACTA2', 'MYH11'], 'fibroblast': ['DCN', 'LUM', 'COL1A2', 'PDGFRA'], 'immune': ['PTPRC'], 'myeloid': ['CD68', 'CD163', 'C1QA', 'AIF1'], 'tumor_epi': ['EPCAM', 'KRT8', 'KRT18', 'KRT19'], 'oligo': ['PLP1', 'MBP', 'MOG'], 'astro': ['AQP4', 'GFAP', 'ALDH1L1']}
EC_SUB = {'动脉': ['GJA5', 'SEMA3G', 'HEY1', 'FBLN5', 'IGFBP3'], '毛细血管_血脑屏障': ['SLC2A1', 'MFSD2A', 'ABCB1', 'SLC7A5', 'CA4', 'SLC16A1'], '静脉': ['ACKR1', 'SELP', 'VCAM1', 'NR2F2', 'IL1R1'], '尖端_血管新生': ['ESM1', 'PLVAP', 'ANGPT2', 'APLN', 'COL4A1', 'INSR'], '淋巴管': ['PROX1', 'LYVE1', 'CCL21', 'FLT4']}
OURS = {'我们_血管周细胞平滑肌': ['CSPG4', 'NOTCH3', 'RGS5', 'PDGFRB', 'KCNJ8', 'HIGD1B', 'NDUFA4L2', 'ACTA2', 'TAGLN'], '我们_血脑屏障型内皮': ['CDH5', 'KDR', 'CD34', 'CLDN5', 'VWF', 'ABCB1', 'ANGPT2'], '我们_BAM': ['LYVE1', 'CD209', 'COLEC12', 'F13A1', 'SIGLEC1', 'MRC1'], '我们_成纤维细胞': ['DCN', 'LUM', 'COL1A1', 'COL1A2', 'COL3A1', 'FBLN1', 'PRRX1']}

def read_sample(pre):
    mtx = f'{E}/{pre}_matrix.mtx.gz'
    M = scipy.io.mmread(mtx).tocsr().T.astype(np.float32)
    bc = pd.read_csv(f'{E}/{pre}_barcodes.tsv.gz', header=None)[0].values
    gf = f'{E}/{pre}_features.tsv.gz' if os.path.exists(f'{E}/{pre}_features.tsv.gz') else f'{E}/{pre}_genes.tsv.gz'
    ft = pd.read_csv(gf, header=None, sep='\t')
    genes = ft[1].values if ft.shape[1] > 1 else ft[0].values
    a = sc.AnnData(M, obs=pd.DataFrame(index=bc), var=pd.DataFrame(index=genes))
    a.var_names_make_unique()
    return a
rows = []
cells = []
for (gsm, pre, name, grp) in SAMPLES:
    a = read_sample(pre)
    a.var['mt'] = a.var_names.str.startswith('MT-')
    sc.pp.calculate_qc_metrics(a, qc_vars=['mt'], inplace=True)
    a = a[(a.obs.n_genes_by_counts >= 300) & (a.obs.pct_counts_mt < 20)].copy()
    sc.pp.normalize_total(a, target_sum=10000.0)
    sc.pp.log1p(a)

    def mean_of(gs):
        gs = [g for g in gs if g in a.var_names]
        return np.asarray(a[:, gs].X.mean(axis=1)).ravel() if gs else np.zeros(a.n_obs)
    for (k, gs) in LIN.items():
        a.obs[f'lin_{k}'] = mean_of(gs)
    lin = a.obs[[f'lin_{k}' for k in LIN]].copy()
    lin.columns = list(LIN)
    top = lin.idxmax(axis=1)
    mx = lin.max(axis=1)
    a.obs['lineage_gate'] = np.where(mx > 0.3, top, 'unassigned')
    for (k, gs) in {**EC_SUB, **OURS}.items():
        gs = [g for g in gs if g in a.var_names]
        sc.tl.score_genes(a, gs, score_name=k, ctrl_size=50, n_bins=25)
        a.obs[f'{k}_ndet'] = np.asarray((a[:, gs].X > 0).sum(axis=1)).ravel()
        a.obs[f'{k}_ngenes'] = len(gs)
    ec = a.obs.lineage_gate == 'EC'
    sub = a.obs.loc[ec, list(EC_SUB)]
    a.obs['ec_subtype'] = np.nan
    if ec.sum() > 0:
        a.obs.loc[ec, 'ec_subtype'] = np.where(sub.max(axis=1) > 0.1, sub.idxmax(axis=1), '未定')
    for g in ['ABCB1', 'ANGPT2', 'PLVAP', 'CLDN5', 'NOTCH3', 'CSPG4', 'KCNJ8', 'LYVE1', 'CD209', 'F13A1', 'MFSD2A', 'SLC2A1', 'ACKR1', 'JAG1', 'DLL4', 'PDGFB', 'ESM1', 'APLN', 'VWF']:
        a.obs[f'det_{g}'] = np.asarray((a[:, g].X > 0).sum(axis=1)).ravel().astype(int) if g in a.var_names else np.nan
    o = a.obs.copy()
    o['sample'] = name
    o['gsm'] = gsm
    o['group'] = grp
    o['sorted'] = 'EC_sorted' if name.endswith('_EC') else 'unsorted'
    cells.append(o)
    nE = int(ec.sum())
    nM = int((o.lineage_gate == 'mural').sum())
    nMy = int((o.lineage_gate == 'myeloid').sum())
    r = dict(sample=name, gsm=gsm, group=grp, sorted=o['sorted'].iloc[0], n_cells=a.n_obs, n_EC=nE, n_mural=nM, n_myeloid=nMy, n_fibro=int((o.lineage_gate == 'fibroblast').sum()), n_tumor_epi=int((o.lineage_gate == 'tumor_epi').sum()))
    if nE > 0:
        e = o[ec]
        vc = e.ec_subtype.value_counts(normalize=True)
        for k in list(EC_SUB) + ['未定']:
            r[f'EC_{k}_frac'] = round(float(vc.get(k, 0)), 4)
        r['EC_ABCB1_det'] = round(e.det_ABCB1.mean(), 4)
        r['EC_ANGPT2_det'] = round(e.det_ANGPT2.mean(), 4)
        r['EC_PLVAP_det'] = round(e.det_PLVAP.mean(), 4)
        r['EC_MFSD2A_det'] = round(e.det_MFSD2A.mean(), 4)
        r['EC_JAG1_det'] = round(e.det_JAG1.mean(), 4)
        r['EC_DLL4_det'] = round(e.det_DLL4.mean(), 4)
        r['EC_PDGFB_det'] = round(e.det_PDGFB.mean(), 4)
        r['EC_ESM1_det'] = round(e.det_ESM1.mean(), 4)
        r['EC_ABCB1_and_ANGPT2'] = round(float(((e.det_ABCB1 == 1) & (e.det_ANGPT2 == 1)).mean()), 4)
        r['EC_ABCB1_and_PLVAP'] = round(float(((e.det_ABCB1 == 1) & (e.det_PLVAP == 1)).mean()), 4)
        r['EC_ours_BBB_sig_pos'] = round(float(((e['我们_血脑屏障型内皮'] > 0.15) & (e['我们_血脑屏障型内皮_ndet'] >= 4)).mean()), 4)
    if nM > 0:
        m = o[o.lineage_gate == 'mural']
        r['mural_ours_sig_pos'] = round(float(((m['我们_血管周细胞平滑肌'] > 0.15) & (m['我们_血管周细胞平滑肌_ndet'] >= 5)).mean()), 4)
        r['mural_NOTCH3_det'] = round(m.det_NOTCH3.mean(), 4)
        r['mural_CSPG4_det'] = round(m.det_CSPG4.mean(), 4)
        r['mural_KCNJ8_det'] = round(m.det_KCNJ8.mean(), 4)
    if nMy > 0:
        y = o[o.lineage_gate == 'myeloid']
        r['myeloid_BAM_sig_pos'] = round(float(((y['我们_BAM'] > 0.15) & (y['我们_BAM_ndet'] >= 3)).mean()), 4)
        r['myeloid_LYVE1_det'] = round(y.det_LYVE1.mean(), 4)
        r['myeloid_CD209_det'] = round(y.det_CD209.mean(), 4)
    rows.append(r)
    log(name, a.n_obs, '细胞; 门控:', o.lineage_gate.value_counts().to_dict())
res = pd.DataFrame(rows)
res.to_csv(f'{O}/V2_ec_state_by_sample.csv', index=False)
allc = pd.concat(cells)
allc.to_csv(f'{O}/V2_percell.csv.gz', compression='gzip')
(fig, ax) = plt.subplots(1, 3, figsize=(26, 5))
ecc = res.set_index('sample')[[f'EC_{k}_frac' for k in list(EC_SUB) + ['未定']]].fillna(0)
ecc.columns = list(EC_SUB) + ['未定']
ecc.plot.bar(stacked=True, ax=ax[0], width=0.8)
ax[0].set_title('GSE256493 脑转移 EC 亚型组成 (marker 打分)')
ax[0].set_ylabel('EC 占比')
ax[0].legend(fontsize=7)
res.set_index('sample')[['EC_ABCB1_det', 'EC_ANGPT2_det', 'EC_PLVAP_det', 'EC_ABCB1_and_ANGPT2']].plot.bar(ax=ax[1], width=0.8)
ax[1].set_title('EC 内 ABCB1/ANGPT2/PLVAP 检出率与共检出')
ax[1].legend(fontsize=7)
res.set_index('sample')[[c for c in ['mural_ours_sig_pos', 'myeloid_BAM_sig_pos', 'EC_ours_BBB_sig_pos'] if c in res]].plot.bar(ax=ax[2], width=0.8)
ax[2].set_title('我们的签名在对应谱系中的阳性率')
ax[2].legend(fontsize=7)
for x in ax:
    x.tick_params(axis='x', labelsize=7)
plt.tight_layout()
plt.savefig(f'{O}/V2_vascular_summary.png', dpi=130)
log('完成')
