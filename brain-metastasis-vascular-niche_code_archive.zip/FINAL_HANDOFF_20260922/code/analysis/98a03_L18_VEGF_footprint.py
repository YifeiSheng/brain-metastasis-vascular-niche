# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
"""L18 independently learned VEGF perturbation-response compatibility in sorted brain EC."""
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os
for k in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS']:
    os.environ[k] = '2'
from pathlib import Path
import pandas as pd, numpy as np, itertools, json, hashlib, datetime
from scipy.stats import rankdata
from statsmodels.stats.multitest import multipletests
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
B = Path(str(_HANDOFF_ROOT / ''))
O = B / 'results/endothelial_response'
S = B / 'results/VEGF_sprouting_calibration'
meta = pd.read_csv(O / 'EC_donor_manifest.csv')
tests = []
scores = []
selection = []
perms = {}
for gate in ['main', 'strict']:
    counts = pd.read_csv(O / f'EC_{gate}_pseudobulk_counts.csv.gz', index_col=0)
    m = meta[meta.gate == gate].set_index('donor').loc[counts.index]
    cpm = counts.div(counts.sum(1), axis=0) * 1000000.0
    log = np.log2(1 + cpm)
    z = (log - log.mean(0)) / log.std(0, ddof=1).replace(0, np.nan)
    measured = set((O / f'EC_{gate}_common_measured_genes.txt').read_text().splitlines())
    background = set(log.columns[(cpm >= 1).sum(0) >= 5]) & measured & set(z.columns[z.notna().all()])
    for study in ['GSE227549', 'GSE196776']:
        fn = S / study / 'all_gene_voom_limma.csv.gz'
        sig = pd.read_csv(fn)
        sig = sig.dropna(subset=['symbol', 't', 'AveExpr'])
        sig = sig[sig.symbol.astype(str).str.strip().ne('')]
        sig = sig.sort_values(['AveExpr', 'gene_id'], ascending=[False, True]).drop_duplicates('symbol')
        sig = sig[sig.symbol.isin(background)].copy()
        sig['abs_t'] = sig.t.abs()
        sig = sig.sort_values(['abs_t', 'symbol'], ascending=[False, True])
        for top in ['100', '500', 'all']:
            v = sig.copy() if top == 'all' else sig.head(int(top)).copy()
            w = np.clip(v.t.values, -10, 10)
            ss = z[v.symbol].values @ w / np.sqrt((w * w).sum())
            ss = (ss - ss.mean()) / ss.std(ddof=1)
            for (donor, value) in zip(m.index, ss):
                scores.append(dict(gate=gate, study=study, top=top, donor=donor, group=m.loc[donor, 'group'], score=float(value), n_genes=len(v)))
            for row in v.rename(columns={'adj.P.Val': 'external_q'}).itertuples():
                selection.append(dict(gate=gate, study=study, top=top, gene=row.symbol, t=float(row.t), weight=float(np.clip(row.t, -10, 10)), external_logFC=float(row.logFC), external_q=float(row.external_q)))
            for exclude_breast in [False, True]:
                include = m.index != 'MET_patient3' if exclude_breast else np.ones(len(m), bool)
                for ref in ['TL', 'GBM']:
                    x = ss[(m.group == 'BM').values & include]
                    y = ss[(m.group == ref).values & include]
                    nx = len(x)
                    ny = len(y)
                    r = rankdata(np.r_[x, y])
                    if (nx, ny) not in perms:
                        perms[nx, ny] = np.array(list(itertools.combinations(range(nx + ny), nx)), int)
                    null = np.abs(r[perms[nx, ny]].sum(1) - nx * (nx + ny + 1) / 2)
                    obs = abs(r[:nx].sum() - nx * (nx + ny + 1) / 2)
                    primary = gate == 'main' and study == 'GSE227549' and (top == '500') and (not exclude_breast)
                    tests.append(dict(gate=gate, study=study, top=top, exclude_breast=exclude_breast, comparison='BM_vs_' + ref, n_BM=nx, n_ref=ny, n_genes=len(v), median_BM=float(np.median(x)), median_ref=float(np.median(y)), median_diff=float(np.median(x) - np.median(y)), p_exact=float(np.mean(null >= obs - 1e-10)), primary=primary))
out = pd.DataFrame(tests)
assert len(out) == 48
out['q_BH_all48'] = multipletests(out.p_exact, method='fdr_bh')[1]
p = out.primary
out.loc[p, 'q_BH_primary2'] = multipletests(out.loc[p, 'p_exact'], method='fdr_bh')[1]
out.to_csv(O / 'VEGF_perturbation_footprint_tests.csv', index=False)
pd.DataFrame(scores).to_csv(O / 'VEGF_perturbation_footprint_scores.csv', index=False)
pd.DataFrame(selection).to_csv(O / 'VEGF_perturbation_footprint_weights.csv.gz', index=False, compression='gzip')
v = pd.DataFrame(scores)
v = v[(v.gate == 'main') & (v.study == 'GSE227549') & (v.top == '500')]
(fig, ax) = plt.subplots(figsize=(6.6, 4.6))
rng = np.random.default_rng(1803)
for (i, (group, color)) in enumerate([('TL', '#879ba4'), ('BM', '#208e99'), ('GBM', '#c68c52')]):
    a = v[v.group == group].score.values
    ax.scatter(i + rng.uniform(-0.11, 0.11, len(a)), a, c=color, s=44)
    ax.plot([i - 0.16, i + 0.16], [np.median(a)] * 2, color='black', lw=2)
ax.set_xticks([0, 1, 2], ['Temporal lobe\nn=9', 'Brain metastasis\nn=5', 'GBM\nn=7'])
ax.set_ylabel('3D VEGF response compatibility (SD)')
ax.set_title('External 3D sprouting perturbation footprint\nExpression similarity, not a direct sprouting-rate assay')
fig.tight_layout()
fig.savefig(O / 'VEGF_perturbation_footprint.png', dpi=190)
fig.savefig(O / 'VEGF_perturbation_footprint.pdf')
plt.close(fig)
json.dump(dict(timestamp_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), primary='GSE227549 top500 main gate, BMvsTL/BMvsGBM', source_studies={s: hashlib.sha256((S / s / 'all_gene_voom_limma.csv.gz').read_bytes()).hexdigest() for s in ['GSE227549', 'GSE196776']}, script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), limits=['PooledHUVEC experimentalreplicates not independenthumandonors', '2D study unknown batch; exploratory only', 'Different organs and in vitro versus in vivo; shared response not VEGF-specific causation', 'Human feature selection pooled and group-blind; all weights learned only from external intervention', 'No measured vesselnumber/perfusion or direct in vivo sprouting output']), open(O / 'FOOTPRINT_PROVENANCE.json', 'w'), indent=2)
print(out.loc[p].to_string(index=False))
print('COMPLETE')
