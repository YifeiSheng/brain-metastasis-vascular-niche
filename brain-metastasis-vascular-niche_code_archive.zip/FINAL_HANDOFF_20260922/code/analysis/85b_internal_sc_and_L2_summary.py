# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os, re, json, time, numpy as np, pandas as pd, scanpy as sc
from scipy.stats import mannwhitneyu
B = str(_HANDOFF_ROOT / '')
DL = f'{B}/data/integrated'
R = f'{B}/results/immune_glial_lymphoma'
O = f'{R}/L1_L2_L4_LYMPHOMA'
L = open(f'{O}/progress.txt', 'a', buffering=1)
log = lambda *a: L.write(time.strftime('[%H:%M:%S] ') + ' '.join(map(str, a)) + '\n')
J = json.load(open(f'{R}/L15_signatures.json'))
SIG = J['signatures']
SIG2LIN = J['lineage']
LIN = {'髓系': ['PTPRC', 'CD68', 'CD14', 'AIF1', 'CSF1R', 'C1QA', 'LYZ', 'TYROBP', 'FCER1G'], 'T/NK': ['CD3E', 'CD3D', 'CD2', 'NKG7', 'GNLY', 'TRAC', 'CD8A', 'IL7R'], '基质/血管': ['PDGFRB', 'RGS5', 'COL1A2', 'DCN', 'CLDN5', 'VWF', 'PECAM1', 'ACTA2'], '上皮/肿瘤': ['EPCAM', 'KRT8', 'KRT18', 'KRT19'], 'B': ['MS4A1', 'CD79A', 'CD79B', 'CD19']}
IGL = ['IGLC1', 'IGLC2', 'IGLC3', 'IGLC7']

def process(a, sample, dataset, extra):
    sc.pp.filter_cells(a, min_genes=200)
    sc.pp.filter_genes(a, min_cells=3)
    a.layers['counts'] = a.X.copy()
    sc.pp.normalize_total(a, target_sum=10000.0)
    sc.pp.log1p(a)
    LS = pd.DataFrame(index=a.obs_names)
    for (l, g) in LIN.items():
        gg = [x for x in g if x in a.var_names]
        LS[l] = np.asarray(a[:, gg].X.mean(axis=1)).ravel() if gg else 0
    lin = LS.idxmax(axis=1).where(LS.max(axis=1) > 0.3, '其他')
    cd8 = np.asarray((a[:, 'CD8A'].X > 0).todense()).ravel() if 'CD8A' in a.var_names else np.zeros(a.n_obs, bool)
    rows = []
    comp = dict(dataset=dataset, sample=sample, **extra, n_cells=a.n_obs)
    comp.update({f'n_{l}': int((lin == l).sum()) for l in list(LIN) + ['其他']})
    for (c, g) in SIG.items():
        gg = [x for x in g if x in a.var_names]
        if len(gg) < 3:
            continue
        sc.tl.score_genes(a, gg, score_name='_s', ctrl_size=50, n_bins=25, random_state=0)
        s = a.obs['_s'].values
        det = np.asarray((a[:, gg].X > 0).sum(axis=1)).ravel()
        pos = (s > 0.15) & (det >= max(2, len(gg) // 2))
        if c.startswith('CXCL13+ CD4'):
            pos = pos & ~cd8
        l = SIG2LIN[c]
        den = (lin == l).values if l in LIN else np.ones(len(lin), bool)
        rows.append(dict(dataset=dataset, sample=sample, **extra, signature=c, lineage=l, n_genes=len(gg), n_lineage_cells=int(den.sum()), n_positive=int((pos & den).sum()), frac_of_lineage=round(float((pos & den).sum() / max(den.sum(), 1)), 4), frac_of_all=round(float(pos.mean()), 4)))
    C = a.layers['counts']
    gi = {g: i for (i, g) in enumerate(a.var_names)}
    k = np.asarray(C[:, gi['IGKC']].todense()).ravel() if 'IGKC' in gi else np.zeros(a.n_obs)
    lam = sum((np.asarray(C[:, gi[g]].todense()).ravel() for g in IGL if g in gi)) if any((g in gi for g in IGL)) else np.zeros(a.n_obs)
    bm = (lin == 'B').values & (k + lam >= 3)
    kf = float((k[bm] > lam[bm]).mean()) if bm.sum() >= 20 else np.nan
    lc = dict(dataset=dataset, sample=sample, **extra, n_B=int((lin == 'B').sum()), n_B_with_lightchain=int(bm.sum()), kappa_cell_frac=round(kf, 4) if bm.sum() >= 20 else np.nan, restriction=round(max(kf, 1 - kf), 4) if bm.sum() >= 20 else np.nan, dominant_chain=('κ' if kf >= 0.5 else 'λ') if bm.sum() >= 20 else 'NA')
    return (rows, comp, lc)
S = sc.read_h5ad(f'{DL}/final_integrated_annotated.h5ad')
pm = pd.read_csv(f'{DL}/patient_metadata.csv')
dis = dict(zip(pm.patient_id.astype(str), pm['疾病'].astype(str)))
allrows = []
comps = []
lcs = []
for ((pt_, smp), sub) in S.obs.groupby(['patient_id', 'sample']):
    if str(sub.tissue_role.iloc[0]) != 'tumor':
        continue
    a = S[sub.index].copy()
    d = dis.get(str(pt_), '')
    grp = 'PCNSL(内部)' if '淋巴瘤' in d else '癌转移(内部)'
    (rows, comp, lc) = process(a, f'{pt_}_{smp}', '内部sc', dict(group=grp, patient=str(pt_), tissue=d, platform='scRNA'))
    allrows += rows
    comps.append(comp)
    lcs.append(lc)
    log('内部', pt_, smp, d, comp['n_cells'], {k: v for (k, v) in comp.items() if k.startswith('n_')})
for (name, new) in [('L1_L2_signature_frequency_by_sample.csv', pd.DataFrame(allrows)), ('L1_L2_lineage_composition.csv', pd.DataFrame(comps)), ('L4_light_chain_by_sample.csv', pd.DataFrame(lcs))]:
    old = pd.read_csv(f'{O}/{name}')
    old = old[old.dataset != '内部sc']
    pd.concat([old, new]).to_csv(f'{O}/{name}', index=False)
df = pd.read_csv(f'{O}/L1_L2_signature_frequency_by_sample.csv')
df = df[df.n_lineage_cells >= 20]
pt = df.groupby(['group', 'patient', 'signature', 'lineage'], as_index=False).frac_of_lineage.mean()
out = []
for (sig, sub) in pt.groupby('signature'):
    r = dict(signature=sig, lineage=sub.lineage.iloc[0])
    for g in ['PCNSL(内部)', 'PCNSL(外部)', '结内DLBCL', '滤泡性淋巴瘤', '扁桃体', '癌转移(内部)', 'PCNSL脑脊液(外部)']:
        v = sub[sub.group == g].frac_of_lineage
        r[f'{g}_median'] = round(v.median(), 4) if len(v) else np.nan
        r[f'{g}_n'] = len(v)
    x = sub[sub.group.isin(['PCNSL(内部)', 'PCNSL(外部)'])].frac_of_lineage
    y = sub[sub.group == '结内DLBCL'].frac_of_lineage
    y2 = sub[sub.group.isin(['结内DLBCL', '滤泡性淋巴瘤'])].frac_of_lineage
    z = sub[sub.group == '癌转移(内部)'].frac_of_lineage
    r['PCNSL_all_median'] = round(x.median(), 4) if len(x) else np.nan
    r['PCNSL_all_n'] = len(x)
    r['mwu_p_PCNSL_vs_nodalDLBCL'] = mannwhitneyu(x, y).pvalue if len(x) >= 3 and len(y) >= 3 else np.nan
    r['mwu_p_PCNSL_vs_nodal_all'] = mannwhitneyu(x, y2).pvalue if len(x) >= 3 and len(y2) >= 3 else np.nan
    r['mwu_p_PCNSL_vs_internal_BrM'] = mannwhitneyu(x, z).pvalue if len(x) >= 3 and len(z) >= 3 else np.nan
    out.append(r)
pd.DataFrame(out).to_csv(f'{O}/L2_pcnsl_vs_nodal_dlbcl.csv', index=False)
pt.to_csv(f'{O}/L2_patient_level_frequencies.csv', index=False)
log('85b 全部完成')
