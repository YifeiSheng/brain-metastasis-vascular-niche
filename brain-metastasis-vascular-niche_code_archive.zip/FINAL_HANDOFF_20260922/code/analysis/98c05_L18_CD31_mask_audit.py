# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
"""Audit public CD31 TIFF encoding; uncalibrated rendering is not a binary vessel mask."""
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os
for k in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS']:
    os.environ[k] = '2'
from pathlib import Path
import pandas as pd, numpy as np, tifffile as tf, hashlib, json
B = Path(str(_HANDOFF_ROOT / ''))
O = B / 'results/verified_vascular_geometry'
D = B / 'data/external/imc/Karimi2023/data/BrainData'
m = pd.read_csv(O / 'ALL_ROI_MAPPING_OFFICIAL_VERIFIED.csv')
r = []
for row in m.itertuples():
    f = D / 'BRAIN_IMC_MaskTif' / f'{row.legacy_roi}.tif'
    with tf.TiffFile(f) as z:
        a = z.pages[6].asarray()
        u = np.unique(a)
        positive = u[u > 0]
        r.append({'official_roi': row.official_roi, 'legacy_roi': row.legacy_roi, 'channel_index_one_based': 7, 'marker': 'CD31', 'n_pages': len(z.pages), 'dtype': str(a.dtype), 'n_unique_values': len(u), 'binary_0_255': bool(set(u).issubset({0, 255})), 'minimum_nonzero': int(positive.min()) if len(positive) else np.nan, 'maximum': int(u.max()), 'n_image_pixels': a.size, 'n_nonzero_pixels_diagnostic_only': int((a > 0).sum()), 'source_sha256': hashlib.sha256(f.read_bytes()).hexdigest()})
d = pd.DataFrame(r)
d.to_csv(O / 'IMC_CD31_rendering_audit.csv', index=False)
print('ROIs', len(d), 'binary', d.binary_0_255.sum(), 'unique_values_range', d.n_unique_values.min(), d.n_unique_values.max(), 'minpositive_range', d.minimum_nonzero.min(), d.minimum_nonzero.max(), flush=True)
(O / 'IMC_CD31_RENDERING_LIMIT.md').write_text('The official record assigns channel 7 to CD31, but these uint8 TIFF planes are not consistently binary. The per-ROI value distribution and minimum-positive encoding vary. No shared raw-intensity calibration or threshold metadata was provided. Nonzero pixel counts are archived as encoding diagnostics only, not compared as vessel area. Do not equate these planes with perfused lumen masks, or infer vessel diameter/count, without recovering and validating raw CD31 images and the author mask-processing parameters. The lineage-labelled nuclei remain usable for EC abundance and centroid geometry.\n')
