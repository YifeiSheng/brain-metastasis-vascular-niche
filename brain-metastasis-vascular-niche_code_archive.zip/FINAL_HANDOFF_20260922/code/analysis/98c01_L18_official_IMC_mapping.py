# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
"""L18: retrieve official corrected ROI names via HTTP ranges; exact content matching, no clinical-order assumption."""
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os
for k in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS']:
    os.environ[k] = '2'
from pathlib import Path
import io, json, urllib.request, zipfile, zlib, struct, hashlib, collections, scipy.io as sio, numpy as np, pandas as pd
B = Path(str(_HANDOFF_ROOT / ''))
O = B / 'results/verified_vascular_geometry'
O.mkdir(parents=True, exist_ok=True)
D = B / 'data/external/imc/Karimi2023/data/BrainData'
URL = 'https://zenodo.org/api/records/7884599/files/BrainData.zip/content'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def fetch(url, dest, headers=None):
    if dest.exists():
        return dest.read_bytes()
    req = urllib.request.Request(url, headers=headers or {})
    r = urllib.request.urlopen(req, timeout=120)
    b = r.read()
    dest.write_bytes(b)
    return b
rec = json.loads(fetch('https://zenodo.org/api/records/7884599', O / 'zenodo_updated_record.json'))
size = rec['files'][0]['size']
tail_start = size - 1500000
tail = fetch(URL, O / 'updated_zip_tail.bin', {'Range': f'bytes={tail_start}-{size - 1}'})
assert len(tail) == 1500000
z = zipfile.ZipFile(io.BytesIO(tail))
infos = {}
for x in z.infolist():
    infos[x.filename] = {'name': x.filename, 'size': x.file_size, 'compressed': x.compress_size, 'CRC': x.CRC, 'offset': x.header_offset + tail_start}
(O / 'updated_zip_inventory.json').write_text(json.dumps(list(infos.values()), indent=2))
names = [n for n in infos if '/BRAIN_IMC_CellType/' in n and n.endswith('.mat') and (not n.startswith('__MACOSX'))]
start = min((infos[n]['offset'] for n in names))
end = max((infos[n]['offset'] + infos[n]['compressed'] + len(n.encode()) + 500 for n in names))
block = fetch(URL, O / 'updated_celltypes_range.bin', {'Range': f'bytes={start}-{end}'})
assert len(block) == end - start + 1

def extract(n, base=None, base_start=None):
    f = infos[n]
    off = f['offset']
    if base is None:
        base = fetch(URL, O / ('range_' + sha(n.encode())[:16] + '.bin'), {'Range': f"bytes={off}-{off + f['compressed'] + len(n.encode()) + 500}"})
        base_start = off
    p = off - base_start
    h = struct.unpack('<IHHHHHIIIHH', base[p:p + 30])
    assert h[0] == 67324752
    body = base[p + 30 + h[-2] + h[-1]:p + 30 + h[-2] + h[-1] + f['compressed']]
    raw = zlib.decompress(body, -15) if h[3] == 8 else body
    assert len(raw) == f['size'] and zlib.crc32(raw) == f['CRC'], n
    return raw
newroot = O / 'official_updated'
(newroot / 'CellType').mkdir(parents=True, exist_ok=True)
oldsha = collections.defaultdict(list)
for p in (D / 'BRAIN_IMC_CellType').glob('*.mat'):
    oldsha[sha(p.read_bytes())].append(p.stem)
mapping = []
unmatched = []
for n in names:
    raw = extract(n, block, start)
    p = newroot / 'CellType' / Path(n).name
    p.write_bytes(raw)
    s = sha(raw)
    matches = oldsha[s]
    if len(matches) == 1:
        mapping.append({'official_roi': p.stem, 'legacy_roi': matches[0], 'mapping_method': 'identical_celltype_file_SHA256', 'celltype_SHA256': s})
    else:
        unmatched.append(n)
oldzip = zipfile.ZipFile(B / 'data/external/imc/Karimi2023/BrainData.zip')
oldseg = collections.defaultdict(list)
for i in oldzip.infolist():
    if '/BRAIN_IMC_Segmentation/' in i.filename and i.filename.endswith('/allRegionIndices.mat') and (not i.filename.startswith('__MACOSX')):
        oldseg[i.CRC, i.file_size].append(i.filename.split('/')[-2])
for n in unmatched:
    roi = Path(n).stem
    nn = f'Brain_Data2/BRAIN_IMC_MaskTif/{roi}.tif'
    f = infos[nn]
    candidates = [i.filename for i in oldzip.infolist() if '/BRAIN_IMC_MaskTif/' in i.filename and (not i.filename.startswith('__MACOSX')) and ((i.CRC, i.file_size) == (f['CRC'], f['size']))]
    assert len(candidates) == 1, (n, candidates)
    old = Path(candidates[0]).stem
    nr = extract(nn)
    orr = (D / 'BRAIN_IMC_MaskTif' / f'{old}.tif').read_bytes()
    assert sha(nr) == sha(orr)
    segsha = {}
    for fn in ['allRegionIndices.mat', 'nuclei_multiscale.mat']:
        sn = f'Brain_Data2/BRAIN_IMC_Segmentation/{roi}/{fn}'
        sr = extract(sn)
        sp = newroot / 'Segmentation' / roi / fn
        sp.parent.mkdir(parents=True, exist_ok=True)
        sp.write_bytes(sr)
        segsha[fn + '_SHA256'] = sha(sr)
    oldmat = sio.loadmat(D / 'BRAIN_IMC_CellType' / f'{old}.mat')
    newmat = sio.loadmat(newroot / 'CellType' / f'{roi}.mat')
    a = np.array([str(x[0]) if len(x) else '' for x in oldmat['cellTypes'].ravel()])
    b = np.array([str(x[0]) if len(x) else '' for x in newmat['cellTypes'].ravel()])
    mapping.append({'official_roi': roi, 'legacy_roi': old, 'mapping_method': 'identical_complete_marker_image_stack_SHA256_updated_segmentation', 'celltype_SHA256': sha((newroot / 'CellType' / f'{roi}.mat').read_bytes()), 'mask_tif_SHA256': sha(nr), 'n_cells_legacy': len(a), 'n_cells_updated': len(b), **segsha})
    print('REVISED SEGMENTATION', roi, old, len(a), len(b), flush=True)
old_zip_index = {i.filename: i for i in oldzip.infolist()}
for m in mapping:
    (roi, old) = (m['official_roi'], m['legacy_roi'])
    if m['mapping_method'] == 'identical_celltype_file_SHA256':
        for fn in ['allRegionIndices.mat', 'nuclei_multiscale.mat']:
            nf = infos[f'Brain_Data2/BRAIN_IMC_Segmentation/{roi}/{fn}']
            of = old_zip_index[f'BrainData/BRAIN_IMC_Segmentation/{old}/{fn}']
            assert (nf['CRC'], nf['size']) == (of.CRC, of.file_size), (roi, fn)
        m['segmentation_CRC_size_unchanged'] = True
clinical = extract('Brain_Data2/Clinical Data GBM BrM.xlsx')
(newroot / 'Clinical Data GBM BrM.xlsx').write_bytes(clinical)
clin = pd.read_excel(io.BytesIO(clinical))
clin.columns = clin.columns.str.strip()
mp = pd.DataFrame(mapping).sort_values('official_roi')
assert not mp.official_roi.duplicated().any() and (not mp.legacy_roi.duplicated().any())
mp = mp.merge(clin, left_on='official_roi', right_on='Image ID', how='left', validate='1:1')
assert mp['Patient ID'].notna().all()
oldclin = pd.read_excel(D / 'Clinical Data GBM BrM.xlsx')
oldclin.columns = oldclin.columns.str.strip()
oc = oldclin[oldclin['Tumor Type'].eq('Brain Metastasis')].copy()
oc['legacy_roi'] = [f'BrM_001C{k}' for k in range(1, len(oc) + 1)]
bm = mp[mp.official_roi.str.startswith('BrM_')].merge(oc[['legacy_roi', 'Image ID', 'Patient ID', 'Tissue Region']], on='legacy_roi', suffixes=('', '_legacy_order'))
for c in ['Image ID', 'Patient ID', 'Tissue Region']:
    bm[c + '_agrees_with_old_order'] = bm[c].eq(bm[c + '_legacy_order'])
bm.to_csv(O / 'BrM_ROI_MAPPING_OFFICIAL_VERIFIED.csv', index=False)
mp.to_csv(O / 'ALL_ROI_MAPPING_OFFICIAL_VERIFIED.csv', index=False)
files = []
for p in sorted(newroot.rglob('*')):
    if p.is_file():
        files.append({'path': str(p.relative_to(B)), 'size': p.stat().st_size, 'sha256': sha(p.read_bytes())})
(O / 'OFFICIAL_MAPPING_PROVENANCE.json').write_text(json.dumps({'source_record': 'https://zenodo.org/records/7884599', 'source_archive_md5': rec['files'][0]['checksum'], 'archive_size': size, 'http_range_retrieval': True, 'n_updated_celltype_files': len(names), 'n_BrM': len(bm), 'mapping_method_counts': mp.mapping_method.value_counts().to_dict(), 'old_order_agreement': {c: int(bm[c + '_agrees_with_old_order'].sum()) for c in ['Image ID', 'Patient ID', 'Tissue Region']}, 'files': files}, indent=2))
print('COMPLETE', len(mp), 'ROIs', len(bm), 'BrM', bm['Patient ID'].nunique(), 'BrM donors', 'agreement', bm.filter(like='agrees').sum().to_dict(), flush=True)
