# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
"""L18: same-section EC response-marker and cycling-marker detection in four breast BrM Xenium samples."""
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os
for k in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS']:
    os.environ[k] = '2'
from pathlib import Path
import hashlib, json, scanpy as sc, pandas as pd, numpy as np
B = Path(str(_HANDOFF_ROOT / ''))
O = B / 'results/verified_vascular_geometry'
rows = []
panels = []
manifest = []
cells = []
genes = ['ESM1', 'ANGPT2', 'MKI67', 'TOP2A', 'PECAM1', 'VWF', 'EPCAM', 'KRT8']
for h5 in sorted((B / 'data/external/spatial/GSE325935/raw').glob('*cell_feature_matrix.h5')):
    name = h5.name.split('_', 1)[1].replace('_cell_feature_matrix.h5', '')
    cp = Path(str(h5).replace('_cell_feature_matrix.h5', '_cells.parquet'))
    a = sc.read_10x_h5(h5, gex_only=True)
    a.var_names_make_unique()
    co = pd.read_parquet(cp)
    co.index = co.cell_id.astype(str)
    co = co.reindex(a.obs_names)
    assert co.x_centroid.notna().all()
    X = a.X.tocsc()
    cnt = {g: np.asarray(X[:, a.var_names.get_loc(g)].toarray()).ravel() for g in genes}
    for g in ['MKI67', 'TOP2A', 'ESM1', 'ANGPT2', 'PLVAP', 'ABCB1', 'MFSD2A', 'VEGFA', 'KDR']:
        panels.append({'section': name, 'gene': g, 'measured': g in a.var_names})
    depth = np.asarray(a.X.sum(axis=1)).ravel()
    norm = {g: np.log1p(cnt[g] / np.maximum(depth, 1) * 10000.0) for g in genes}
    for minQC in [20, 50]:
        qc = co.transcript_counts.values >= minQC
        for eg in [2, 3, 5]:
            for tg in [3, 5, 8]:
                er = cnt['PECAM1'] + cnt['VWF'] >= eg
                tr = cnt['EPCAM'] + cnt['KRT8'] >= tg
                ec = qc & er & ~tr
                tu = qc & tr & ~er
                assert not (ec & tu).any()
                for (lineage, sel) in [('EC', ec), ('tumor', tu)]:
                    if not sel.any():
                        continue
                    response = (cnt['ESM1'] > 0) | (cnt['ANGPT2'] > 0)
                    cycling = (cnt['MKI67'] > 0) | (cnt['TOP2A'] > 0)
                    r = {'section': name, 'min_transcript_counts': minQC, 'EC_marker_sum_min': eg, 'tumor_marker_sum_min': tg, 'lineage': lineage, 'n_cells': int(sel.sum()), 'n_QC_cells': int(qc.sum()), 'fraction_of_QC_cells': sel.sum() / qc.sum(), 'n_double_positive_excluded': int((qc & er & tr).sum()), 'ESM1_or_ANGPT2_fraction': float(response[sel].mean()), 'MKI67_or_TOP2A_fraction': float(cycling[sel].mean()), 'response_positive_cycling_negative_fraction_of_all': float((response & ~cycling)[sel].mean()), 'response_positive_cycling_negative_fraction_of_response': float((response & ~cycling & sel).sum() / max((response & sel).sum(), 1)), 'response_and_cycling_fraction': float((response & cycling)[sel].mean()), 'median_total_GEX_counts': float(np.median(depth[sel]))}
                    for g in genes:
                        r[g + '_fraction'] = float((cnt[g][sel] > 0).mean())
                        r[g + '_mean_logCP10k'] = float(norm[g][sel].mean())
                    rows.append(r)
                if (minQC, eg, tg) == (20, 3, 5):
                    q = pd.DataFrame({'section': name, 'cell': a.obs_names[ec], 'x_um': co.x_centroid.values[ec], 'y_um': co.y_centroid.values[ec], 'total_GEX_counts': depth[ec], **{g: cnt[g][ec] for g in genes}})
                    cells.append(q)
    for f in [h5, cp]:
        manifest.append({'path': str(f.relative_to(B)), 'size': f.stat().st_size, 'sha256': hashlib.sha256(f.read_bytes()).hexdigest()})
    print('COMPLETE', name, flush=True)
s = pd.DataFrame(rows)
s.to_csv(O / 'Xenium_EC_response_cycling_gate_sensitivity.csv', index=False)
main = s.query('min_transcript_counts==20 and EC_marker_sum_min==3 and tumor_marker_sum_min==5').copy()
main.to_csv(O / 'Xenium_EC_response_cycling_main.csv', index=False)
pd.concat(cells).to_csv(O / 'Xenium_EC_response_cycling_cells.csv.gz', index=False)
pd.DataFrame(panels).to_csv(O / 'Xenium_endpoint_panel_coverage.csv', index=False)
(O / 'XENIUM_INPUT_MANIFEST.json').write_text(json.dumps(manifest, indent=2))
print(main[['section', 'lineage', 'n_cells', 'ESM1_fraction', 'ANGPT2_fraction', 'MKI67_fraction', 'TOP2A_fraction', 'ESM1_or_ANGPT2_fraction', 'MKI67_or_TOP2A_fraction', 'response_positive_cycling_negative_fraction_of_response']].to_string(index=False), flush=True)
