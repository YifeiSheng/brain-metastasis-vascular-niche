# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os, sys, re, glob, gzip, json, time, numpy as np, pandas as pd, scanpy as sc, scipy.io, scipy.sparse as sp
from scipy.stats import mannwhitneyu
B = str(_HANDOFF_ROOT / '')
ES = f'{B}/data/external/scrna'
R = f'{B}/results/immune_glial_lymphoma'
O = f'{R}/M2_I2_SNRNA'
os.makedirs(O, exist_ok=True)
L = open(f'{O}/progress.txt', 'a', buffering=1)
log = lambda *a: L.write(time.strftime('[%H:%M:%S] ') + ' '.join(map(str, a)) + '\n')
cohorts = sys.argv[1:] or ['duke', 'simon', 'biermann', 'yang']
J = json.load(open(f'{R}/L15_signatures.json'))
SIG = J['signatures']
SIG2LIN = J['lineage']
LIN = {'髓系': ['PTPRC', 'CD68', 'CD14', 'AIF1', 'CSF1R', 'C1QA', 'LYZ', 'TYROBP', 'FCER1G'], 'T/NK': ['CD3E', 'CD3D', 'CD2', 'NKG7', 'GNLY', 'TRAC', 'CD8A', 'IL7R'], '基质/血管': ['PDGFRB', 'RGS5', 'COL1A2', 'DCN', 'CLDN5', 'VWF', 'PECAM1', 'ACTA2'], '上皮/肿瘤': ['EPCAM', 'KRT8', 'KRT18', 'KRT19'], 'B': ['MS4A1', 'CD79A', 'CD79B', 'CD19']}

def opn(p):
    return gzip.open(p, 'rt') if open(p, 'rb').read(2) == b'\x1f\x8b' else open(p, 'rt')

def read_trio(pre, suffix=('_matrix.mtx.gz', '_barcodes.tsv.gz', '_features.tsv.gz')):
    M = scipy.io.mmread(pre + suffix[0]).tocsr().T.astype(np.float32)
    bc = [l.strip() for l in opn(pre + suffix[1]) if l.strip()]
    ft = [l.strip().split('\t') for l in opn(pre + suffix[2]) if l.strip()]
    genes = [f[1] if len(f) > 1 else f[0] for f in ft]
    a = sc.AnnData(M, obs=pd.DataFrame(index=bc), var=pd.DataFrame(index=genes))
    a.var_names_make_unique()
    return a

def process(a, sample, dataset, extra, author=None):
    sc.pp.filter_cells(a, min_genes=300)
    a.var['mt'] = a.var_names.str.startswith('MT-')
    sc.pp.calculate_qc_metrics(a, qc_vars=['mt'], inplace=True)
    a = a[a.obs.pct_counts_mt < 10].copy()
    sc.pp.filter_genes(a, min_cells=3)
    sc.pp.normalize_total(a, target_sum=10000.0)
    sc.pp.log1p(a)
    LS = pd.DataFrame(index=a.obs_names)
    for (l, g) in LIN.items():
        gg = [x for x in g if x in a.var_names]
        LS[l] = np.asarray(a[:, gg].X.mean(axis=1)).ravel() if gg else 0
    lin = LS.idxmax(axis=1).where(LS.max(axis=1) > 0.3, '其他')
    a.obs['lineage_gate'] = lin.values
    cd8 = np.asarray((a[:, 'CD8A'].X > 0).todense()).ravel() if 'CD8A' in a.var_names else np.zeros(a.n_obs, bool)
    rows = []
    percell = pd.DataFrame(index=a.obs_names)
    percell['lineage_gate'] = lin.values
    comp = dict(dataset=dataset, sample=sample, **extra, n_cells=a.n_obs)
    comp.update({f'n_{l}': int((lin == l).sum()) for l in list(LIN) + ['其他']})
    for (c, g) in SIG.items():
        gg = [x for x in g if x in a.var_names]
        if len(gg) < 3:
            continue
        sc.tl.score_genes(a, gg, score_name='_s', ctrl_size=50, n_bins=25, random_state=0)
        s = a.obs['_s'].values
        det = np.asarray((a[:, gg].X > 0).sum(axis=1)).ravel()
        pos = (s > 0.15) & (det >= max(2, len(gg) // 2))
        if c.startswith('CXCL13+ CD4'):
            pos = pos & ~cd8
        percell[c] = pos
        l = SIG2LIN[c]
        den = (lin == l).values if l in LIN else np.ones(len(lin), bool)
        rows.append(dict(dataset=dataset, sample=sample, **extra, signature=c, lineage=l, n_genes=len(gg), n_lineage_cells=int(den.sum()), n_positive=int((pos & den).sum()), frac_of_lineage=round(float((pos & den).sum() / max(den.sum(), 1)), 4), frac_of_all=round(float(pos.mean()), 4)))
    ct = None
    if author is not None:
        a.obs['author_ct'] = pd.Series(author).reindex(a.obs_names).values
        percell['author_ct'] = a.obs['author_ct'].values
        ct = pd.crosstab(a.obs.author_ct, a.obs.lineage_gate)
        ct['sample'] = sample
        ct = ct.reset_index()
    return (rows, percell, comp, ct)
allrows = []
comps = []
cts = []

def save():
    for (name, new) in [('M2_I2_signature_frequency_by_sample.csv', pd.DataFrame(allrows)), ('M2_lineage_composition_by_sample.csv', pd.DataFrame(comps))]:
        p = f'{O}/{name}'
        if os.path.exists(p) and len(new):
            old = pd.read_csv(p)
            old = old[~old.dataset.isin(new.dataset.unique())]
            new = pd.concat([old, new])
        if len(new):
            new.to_csv(p, index=False)
    if cts:
        pd.concat(cts).to_csv(f'{O}/M2_yang_author_vs_gate.csv', index=False)
if 'duke' in cohorts:
    meta = pd.read_csv(f'{ES}/GSE325196/sample_meta.tsv', sep='\t', header=None, names=['gsm', 'title', 'ch'])
    meta = meta[meta.title.str.startswith('Single nuclei')]
    CMAP = {'NSCLC': '非小细胞肺癌', 'SCLC': '小细胞肺癌', 'Melanoma': '黑色素瘤', 'Sarcoma': '肉瘤'}
    for (_, m) in meta.iterrows():
        pre = glob.glob(f'{ES}/GSE325196/raw/{m.gsm}_S_*_matrix.mtx.gz')
        if not pre:
            log('缺', m.title)
            continue
        c = re.search('cell type: ([^;]+)', m.ch).group(1).strip()
        cancer = '乳腺癌' if 'BC' in c else CMAP.get(c, c)
        spec = re.search('(\\d{2}-\\d{4})', m.title).group(1)
        a = read_trio(pre[0].replace('_matrix.mtx.gz', ''))
        (rows, pc, comp, _) = process(a, spec, 'GSE325196', dict(cohort='Duke2026_sn', cancer=cancer, site='脑转移', platform='snRNA'))
        allrows += rows
        comps.append(comp)
        pc.to_csv(f'{O}/percell_GSE325196_{spec}.csv.gz', compression='gzip')
        log('duke', spec, cancer, comp['n_cells'], '核', {k: v for (k, v) in comp.items() if k.startswith('n_')})
        save()
if 'simon' in cohorts:
    for f in sorted(glob.glob(f'{ES}/GSE322964/raw/*_HPT_GEX_counts.csv.gz')):
        name = re.search('GSM\\d+_(.+)_HPT_GEX', os.path.basename(f)).group(1)
        cancer = '肺癌' if name.startswith('LBM') else '乳腺癌'
        genes = []
        blocks = []
        cells = None
        for chunk in pd.read_csv(f, index_col=0, chunksize=4000):
            if cells is None:
                cells = chunk.columns.tolist()
            genes += chunk.index.tolist()
            blocks.append(sp.csr_matrix(chunk.values.astype(np.float32)))
        M = sp.vstack(blocks).T.tocsr()
        a = sc.AnnData(M, obs=pd.DataFrame(index=cells), var=pd.DataFrame(index=genes))
        a.var_names_make_unique()
        (rows, pc, comp, _) = process(a, name, 'GSE322964', dict(cohort='Simon2026_multiome', cancer=cancer, site='脑转移', platform='snRNA'))
        allrows += rows
        comps.append(comp)
        pc.to_csv(f'{O}/percell_GSE322964_{name}.csv.gz', compression='gzip')
        log('simon', name, cancer, comp['n_cells'], {k: v for (k, v) in comp.items() if k.startswith('n_')})
        save()
if 'biermann' in cohorts:
    meta = pd.read_csv(f'{ES}/GSE185386/sample_meta.tsv', sep='\t', header=None, names=['gsm', 'title', 'ch'])
    meta = meta[meta.title.str.endswith('_sn')]
    for (_, m) in meta.iterrows():
        pre = glob.glob(f'{ES}/GSE185386/raw/{m.gsm}_*_sn_matrix.mtx.gz')
        if not pre:
            log('缺', m.title)
            continue
        site = '脑转移' if 'site: MBM' in m.ch else '颅外转移'
        a = read_trio(pre[0].replace('_matrix.mtx.gz', ''))
        (rows, pc, comp, _) = process(a, m.title, 'GSE185386', dict(cohort='Biermann2022_sn', cancer='黑色素瘤', site=site, platform='snRNA'))
        allrows += rows
        comps.append(comp)
        pc.to_csv(f'{O}/percell_GSE185386_{m.title}.csv.gz', compression='gzip')
        log('biermann', m.title, site, comp['n_cells'], {k: v for (k, v) in comp.items() if k.startswith('n_')})
        save()
if 'yang' in cohorts:
    Y = f'{B}/data/external/bulk/Yang2026_BrM_zenodo/snRNA_mtx'
    if os.path.exists(f'{Y}/matrix.mtx'):
        M = scipy.io.mmread(f'{Y}/matrix.mtx').tocsr().T.astype(np.float32)
        genes = [l.strip() for l in open(f'{Y}/genes.tsv')]
        bcs = [l.strip() for l in open(f'{Y}/barcodes.tsv')]
        meta = pd.read_csv(f'{Y}/meta.csv', index_col=0)
        meta = meta.reindex(bcs)
        for s in sorted(meta['orig.ident'].dropna().unique()):
            idx = np.where(meta['orig.ident'].values == s)[0]
            a = sc.AnnData(M[idx], obs=pd.DataFrame(index=[bcs[i] for i in idx]), var=pd.DataFrame(index=genes))
            a.var_names_make_unique()
            au = meta.iloc[idx]['Label']
            grp = str(meta.iloc[idx]['Group'].mode().iloc[0]) if meta.iloc[idx]['Group'].notna().any() else 'NA'
            (rows, pc, comp, ct) = process(a, str(s), 'Yang2026_sn', dict(cohort='Yang2026_sn', cancer='未注明(泛癌)', site='脑转移', platform='snRNA', yang_group=grp), author=au)
            allrows += rows
            comps.append(comp)
            cts.append(ct)
            pc.to_csv(f'{O}/percell_Yang2026_{s}.csv.gz', compression='gzip')
            log('yang', s, grp, comp['n_cells'], {k: v for (k, v) in comp.items() if k.startswith('n_')})
            save()
    else:
        log('Yang mtx 不存在, 跳过')
save()
if 'biermann' in cohorts:
    df = pd.read_csv(f'{O}/M2_I2_signature_frequency_by_sample.csv')
    df = df[df.dataset == 'GSE185386']
    out = []
    for (sig, sub) in df.groupby('signature'):
        x = sub[sub.site == '脑转移']
        y = sub[sub.site == '颅外转移']
        x = x[x.n_lineage_cells >= 20].frac_of_lineage
        y = y[y.n_lineage_cells >= 20].frac_of_lineage
        out.append(dict(signature=sig, lineage=sub.lineage.iloc[0], MBM_median=round(x.median(), 4) if len(x) else np.nan, MBM_n=len(x), ECM_median=round(y.median(), 4) if len(y) else np.nan, ECM_n=len(y), mwu_p=mannwhitneyu(x, y).pvalue if len(x) >= 3 and len(y) >= 3 else np.nan))
    pd.DataFrame(out).sort_values('mwu_p').to_csv(f'{O}/M2_biermann_site_effect.csv', index=False)
log('完成', cohorts)
