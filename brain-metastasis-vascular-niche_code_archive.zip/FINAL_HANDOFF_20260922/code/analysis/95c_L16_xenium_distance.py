# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
"""L16 Xenium distance sensitivity and local EC-response models.
4 breast-cancer brain-metastasis sections; independent evidence, not LUAD replication.
No VEGFA/PDGFB measurement in this panel; absent genes are unavailable, never zero.
"""
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os
for k in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS']:
    os.environ[k] = '2'
from pathlib import Path
import json
import numpy as np, pandas as pd, scanpy as sc, statsmodels.api as sm
from scipy.spatial import cKDTree
from scipy.stats import wilcoxon
from statsmodels.stats.multitest import multipletests
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
B = Path(str(_HANDOFF_ROOT / ''))
O = B / 'results/spatial_distance_and_state_validation'
rows = []
models = []
bins = []
cover = []
panel = []
ecresponses = []

def demean(z, grp):
    return z - z.groupby(grp).transform('mean')
for h5 in sorted((B / 'data/external/spatial/GSE325935/raw').glob('*cell_feature_matrix.h5')):
    name = h5.name.split('_', 1)[1].replace('_cell_feature_matrix.h5', '')
    pre = str(h5).replace('_cell_feature_matrix.h5', '')
    a = sc.read_10x_h5(str(h5), gex_only=False)
    allfeat = a.n_vars
    a = a[:, a.var.feature_types == 'Gene Expression'].copy()
    a.var_names_make_unique()
    c = pd.read_parquet(pre + '_cells.parquet')
    c.index = c.cell_id.astype(str)
    a.obs = a.obs.join(c[['x_centroid', 'y_centroid', 'transcript_counts', 'cell_area']])
    a = a[(a.obs.transcript_counts >= 20) & a.obs.x_centroid.notna()].copy()
    X = a.X.tocsc()
    gi = {g: i for (i, g) in enumerate(a.var_names)}

    def cnt(g):
        return X[:, gi[g]].toarray().ravel() if g in gi else np.full(a.n_obs, np.nan)
    totals = np.asarray(a.X.sum(axis=1)).ravel()
    xy = a.obs[['x_centroid', 'y_centroid']].values
    edge = np.minimum.reduce([xy[:, 0] - xy[:, 0].min(), xy[:, 0].max() - xy[:, 0], xy[:, 1] - xy[:, 1].min(), xy[:, 1].max() - xy[:, 1]])
    for g in ['VEGFA', 'PDGFB', 'CA9', 'SLC2A1', 'ACSS1', 'ACSS2', 'PHGDH', 'ESM1', 'ANGPT2', 'FASN', 'SCD', 'LDHB', 'MKI67']:
        cover.append(dict(slide=name, gene=g, available=g in gi))
    panel.append(dict(slide=name, n_total_features=allfeat, n_gene_expression_features=a.n_vars, n_cells=a.n_obs))
    for threshold in [2, 3, 5]:
        for tthr in [3, 5, 8]:
            eraw = cnt('PECAM1') + cnt('VWF') >= threshold
            traw = cnt('EPCAM') + cnt('KRT8') >= tthr
            ec = eraw & ~traw
            tum = traw & ~eraw
            if ec.sum() < 20 or tum.sum() < 20:
                continue
            d = cKDTree(xy[ec]).query(xy[tum])[0]
            safe = edge[tum] > d
            row = dict(slide=name, EC_threshold=threshold, tumor_threshold=tthr, n_ec=int(ec.sum()), n_tumor=int(tum.sum()), n_double_positive=int((eraw & traw).sum()), median_distance_um=float(np.median(d)), q25=float(np.quantile(d, 0.25)), q75=float(np.quantile(d, 0.75)), safe_n=int(safe.sum()), safe_median_um=float(np.median(d[safe])) if safe.sum() else np.nan)
            for r in [30, 50, 100, 150, 200]:
                row[f'fraction_within_{r}um'] = float((d <= r).mean())
            rows.append(row)
            if threshold != 3 or tthr != 5:
                continue
            de = cKDTree(xy[tum]).query(xy[ec])[0]
            cellout = pd.DataFrame({'cell': a.obs_names[tum], 'x': xy[tum, 0], 'y': xy[tum, 1], 'distance_to_EC_centroid_um': d, 'bbox_edge_safe': safe})
            cellout.to_csv(O / f'xenium_tumor_distance_{name}.csv.gz', index=False, compression='gzip')
            for (typ, mask, dist, gs) in [('EC', ec, de, ['ESM1', 'ANGPT2']), ('tumor', tum, d, ['FASN', 'SCD', 'LDHB', 'MKI67'])]:
                base = pd.DataFrame({'distance': dist, 'log_distance': np.log1p(dist), 'log_depth': np.log1p(totals[mask]), 'log_area': np.log1p(a.obs.cell_area.values[mask]), 'x': xy[mask, 0], 'y': xy[mask, 1]})
                base['tile'] = (base.x // 200).astype(int).astype(str) + '_' + (base.y // 200).astype(int).astype(str)
                base['cluster'] = (base.x // 500).astype(int).astype(str) + '_' + (base.y // 500).astype(int).astype(str)
                base['bin'] = pd.cut(dist, [-1, 30, 50, 100, 150, 200, np.inf], labels=['0-30', '30-50', '50-100', '100-150', '150-200', '>200'])
                for g in gs:
                    if g not in gi:
                        continue
                    y = np.log1p(cnt(g)[mask] / np.maximum(totals[mask], 1) * 10000.0)
                    base['y'] = y
                    base['det'] = cnt(g)[mask] > 0
                    for (bn, z) in base.groupby('bin', observed=True):
                        bins.append(dict(slide=name, compartment=typ, gene=g, distance_bin=str(bn), n_cells=len(z), mean_logCP10k=float(z.y.mean()), det_fraction=float(z.det.mean())))
                    near = dist <= 30
                    far = dist > 100
                    ecresponses.append(dict(slide=name, compartment=typ, gene=g, near_n=int(near.sum()), far_n=int(far.sum()), near_mean=float(y[near].mean()), far_mean=float(y[far].mean()), near_det=float(base.det[near].mean()), far_det=float(base.det[far].mean()), near_minus_far=float(y[near].mean() - y[far].mean())))
                    z = base[['y', 'log_distance', 'log_depth', 'log_area']].copy()
                    z = demean(z, base.tile)
                    z = z.replace([np.inf, -np.inf], np.nan)
                    ok = z.notna().all(axis=1)
                    fit = sm.OLS(z.loc[ok, 'y'], z.loc[ok, ['log_distance', 'log_depth', 'log_area']]).fit(cov_type='cluster', cov_kwds={'groups': base.loc[ok, 'cluster']})
                    ci = fit.conf_int().loc['log_distance']
                    models.append(dict(slide=name, compartment=typ, gene=g, n_cells=int(ok.sum()), n_clusters=base.loc[ok, 'cluster'].nunique(), beta_logdistance=float(fit.params['log_distance']), ci_low=float(ci[0]), ci_high=float(ci[1]), p=float(fit.pvalues['log_distance']), specification='log1p(CP10k) ~ log1p(distance)+log1p(total GEX counts)+log1p(cell area); 200um tile fixed effects; 500um cluster-robust SE'))
    print('COMPLETE', name, a.n_obs, 'cells', flush=True)
pd.DataFrame(rows).to_csv(O / 'xenium_distance_threshold_sensitivity.csv', index=False)
pd.DataFrame(bins).to_csv(O / 'xenium_distance_expression_bins.csv', index=False)
pd.DataFrame(cover).to_csv(O / 'xenium_panel_coverage.csv', index=False)
pd.DataFrame(panel).to_csv(O / 'xenium_panel_inventory.csv', index=False)
md = pd.DataFrame(models)
md['q_BH'] = multipletests(md.p, method='fdr_bh')[1]
md.to_csv(O / 'xenium_spatial_models.csv', index=False)
r = pd.DataFrame(ecresponses)
r.to_csv(O / 'xenium_near_far_effects.csv', index=False)
ss = []
for ((typ, g), z) in r.groupby(['compartment', 'gene']):
    d = z.near_minus_far.values
    ss.append(dict(compartment=typ, gene=g, n_sections=len(z), n_positive=int((d > 0).sum()), median_near_minus_far=float(np.median(d)), p_section_wilcoxon=float(wilcoxon(d, method='exact').pvalue) if np.any(d) else 1))
ss = pd.DataFrame(ss)
ss['q_BH'] = multipletests(ss.p_section_wilcoxon, method='fdr_bh')[1]
ss.to_csv(O / 'xenium_section_level_tests.csv', index=False)
base = pd.DataFrame(rows).query('EC_threshold==3 and tumor_threshold==5')
print(base.to_string(index=False))
print(ss.to_string(index=False))
(fig, axs) = plt.subplots(1, 2, figsize=(10, 4))
for (_, z) in base.iterrows():
    axs[0].plot([30, 50, 100, 150, 200], [z[f'fraction_within_{r}um'] for r in [30, 50, 100, 150, 200]], marker='o', label=z.slide)
axs[0].set(xlabel='Distance to EC centroid (um)', ylabel='Cumulative tumor fraction')
axs[0].legend(fontsize=7)
for (_, z) in r.query("compartment=='EC' and gene=='ESM1'").iterrows():
    axs[1].plot([0, 1], [z.near_mean, z.far_mean], marker='o', label=z.slide)
axs[1].set(xticks=[0, 1], xticklabels=['EC <=30 um from tumor', 'EC >100 um'], ylabel='ESM1 mean log1p(CP10k)')
fig.tight_layout()
fig.savefig(O / 'xenium_distance_EC_response.png', dpi=180)
fig.savefig(O / 'xenium_distance_EC_response.pdf')
