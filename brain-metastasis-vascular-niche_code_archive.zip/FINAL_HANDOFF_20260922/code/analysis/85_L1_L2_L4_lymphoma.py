# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os, re, glob, gzip, json, time, numpy as np, pandas as pd, scanpy as sc, scipy.io, scipy.sparse as sp
from scipy.stats import mannwhitneyu
B = str(_HANDOFF_ROOT / '')
ES = f'{B}/data/external/scrna'
DL = f'{B}/data/integrated'
R = f'{B}/results/immune_glial_lymphoma'
O = f'{R}/L1_L2_L4_LYMPHOMA'
os.makedirs(O, exist_ok=True)
L = open(f'{O}/progress.txt', 'a', buffering=1)
log = lambda *a: L.write(time.strftime('[%H:%M:%S] ') + ' '.join(map(str, a)) + '\n')
J = json.load(open(f'{R}/L15_signatures.json'))
SIG = J['signatures']
SIG2LIN = J['lineage']
LIN = {'髓系': ['PTPRC', 'CD68', 'CD14', 'AIF1', 'CSF1R', 'C1QA', 'LYZ', 'TYROBP', 'FCER1G'], 'T/NK': ['CD3E', 'CD3D', 'CD2', 'NKG7', 'GNLY', 'TRAC', 'CD8A', 'IL7R'], '基质/血管': ['PDGFRB', 'RGS5', 'COL1A2', 'DCN', 'CLDN5', 'VWF', 'PECAM1', 'ACTA2'], '上皮/肿瘤': ['EPCAM', 'KRT8', 'KRT18', 'KRT19'], 'B': ['MS4A1', 'CD79A', 'CD79B', 'CD19']}
IGL = ['IGLC1', 'IGLC2', 'IGLC3', 'IGLC7']

def opn(p):
    return gzip.open(p, 'rt') if open(p, 'rb').read(2) == b'\x1f\x8b' else open(p, 'rt')

def read_trio(pre):
    M = scipy.io.mmread(pre + '_matrix.mtx.gz').tocsr().T.astype(np.float32)
    bc = [l.strip() for l in opn(pre + '_barcodes.tsv.gz') if l.strip()]
    ft = [l.strip().split('\t') for l in opn(pre + '_features.tsv.gz') if l.strip()]
    genes = [f[1] if len(f) > 1 else f[0] for f in ft]
    a = sc.AnnData(M, obs=pd.DataFrame(index=bc), var=pd.DataFrame(index=genes))
    a.var_names_make_unique()
    return a

def process(a, sample, dataset, extra, author=None):
    sc.pp.filter_cells(a, min_genes=200)
    sc.pp.filter_genes(a, min_cells=3)
    a.layers['counts'] = a.X.copy()
    sc.pp.normalize_total(a, target_sum=10000.0)
    sc.pp.log1p(a)
    LS = pd.DataFrame(index=a.obs_names)
    for (l, g) in LIN.items():
        gg = [x for x in g if x in a.var_names]
        LS[l] = np.asarray(a[:, gg].X.mean(axis=1)).ravel() if gg else 0
    lin = LS.idxmax(axis=1).where(LS.max(axis=1) > 0.3, '其他')
    a.obs['lineage_gate'] = lin.values
    cd8 = np.asarray((a[:, 'CD8A'].X > 0).todense()).ravel() if 'CD8A' in a.var_names else np.zeros(a.n_obs, bool)
    rows = []
    percell = pd.DataFrame(index=a.obs_names)
    percell['lineage_gate'] = lin.values
    comp = dict(dataset=dataset, sample=sample, **extra, n_cells=a.n_obs)
    comp.update({f'n_{l}': int((lin == l).sum()) for l in list(LIN) + ['其他']})
    for (c, g) in SIG.items():
        gg = [x for x in g if x in a.var_names]
        if len(gg) < 3:
            continue
        sc.tl.score_genes(a, gg, score_name='_s', ctrl_size=50, n_bins=25, random_state=0)
        s = a.obs['_s'].values
        det = np.asarray((a[:, gg].X > 0).sum(axis=1)).ravel()
        pos = (s > 0.15) & (det >= max(2, len(gg) // 2))
        if c.startswith('CXCL13+ CD4'):
            pos = pos & ~cd8
        percell[c] = pos
        l = SIG2LIN[c]
        den = (lin == l).values if l in LIN else np.ones(len(lin), bool)
        rows.append(dict(dataset=dataset, sample=sample, **extra, signature=c, lineage=l, n_genes=len(gg), n_lineage_cells=int(den.sum()), n_positive=int((pos & den).sum()), frac_of_lineage=round(float((pos & den).sum() / max(den.sum(), 1)), 4), frac_of_all=round(float(pos.mean()), 4)))
    C = a.layers['counts']
    gi = {g: i for (i, g) in enumerate(a.var_names)}
    k = np.asarray(C[:, gi['IGKC']].todense()).ravel() if 'IGKC' in gi else np.zeros(a.n_obs)
    lam = sum((np.asarray(C[:, gi[g]].todense()).ravel() for g in IGL if g in gi)) if any((g in gi for g in IGL)) else np.zeros(a.n_obs)
    bm = (lin == 'B').values & (k + lam >= 3)
    lc = dict(dataset=dataset, sample=sample, **extra, n_B=int((lin == 'B').sum()), n_B_with_lightchain=int(bm.sum()), kappa_cell_frac=round(float((k[bm] > lam[bm]).mean()), 4) if bm.sum() >= 20 else np.nan)
    lc['restriction'] = round(max(lc['kappa_cell_frac'], 1 - lc['kappa_cell_frac']), 4) if bm.sum() >= 20 else np.nan
    lc['dominant_chain'] = ('κ' if lc['kappa_cell_frac'] >= 0.5 else 'λ') if bm.sum() >= 20 else 'NA'
    ct = None
    if author is not None:
        a.obs['author_ct'] = pd.Series(author).reindex(a.obs_names).values
        percell['author_ct'] = a.obs['author_ct'].values
        ct = pd.crosstab(a.obs.author_ct, a.obs.lineage_gate)
        ct['sample'] = sample
        ct = ct.reset_index()
    return (rows, percell, comp, ct, lc)
allrows = []
comps = []
cts = []
lcs = []

def save():
    pd.DataFrame(allrows).to_csv(f'{O}/L1_L2_signature_frequency_by_sample.csv', index=False)
    pd.DataFrame(comps).to_csv(f'{O}/L1_L2_lineage_composition.csv', index=False)
    pd.DataFrame(lcs).to_csv(f'{O}/L4_light_chain_by_sample.csv', index=False)
    if cts:
        pd.concat(cts).to_csv(f'{O}/L2_author_celltype_vs_gate.csv', index=False)
for h5 in sorted(glob.glob(f'{ES}/GSE203552/raw/*_rna.h5')):
    nm = re.search('_(p\\d+_(?:biopsy\\d*|csf|blood\\d*))_rna', h5).group(1)
    if 'blood' in nm:
        continue
    a = sc.read_10x_h5(h5)
    a.var_names_make_unique()
    pt = nm.split('_')[0]
    tissue = '脑脊液' if 'csf' in nm else '活检'
    (rows, pc, comp, _, lc) = process(a, nm, 'GSE203552', dict(group='PCNSL(外部)' if tissue == '活检' else 'PCNSL脑脊液(外部)', patient='Heming_' + pt, tissue=tissue, platform='scRNA'))
    allrows += rows
    comps.append(comp)
    lcs.append(lc)
    pc.to_csv(f'{O}/percell_GSE203552_{nm}.csv.gz', compression='gzip')
    log('Heming', nm, comp['n_cells'], {k: v for (k, v) in comp.items() if k.startswith('n_')})
    save()
pre = glob.glob(f'{ES}/GSE181304/raw/GSM5494566_matrix.mtx.gz')
if pre:
    a = read_trio(pre[0].replace('_matrix.mtx.gz', ''))
    (rows, pc, comp, _, lc) = process(a, 'GSE181304_p1', 'GSE181304', dict(group='PCNSL(外部)', patient='GSE181304_p1', tissue='活检', platform='scRNA'))
    allrows += rows
    comps.append(comp)
    lcs.append(lc)
    pc.to_csv(f'{O}/percell_GSE181304_p1.csv.gz', compression='gzip')
    log('GSE181304', comp['n_cells'], {k: v for (k, v) in comp.items() if k.startswith('n_')})
    save()
ann = pd.read_csv(f'{ES}/GSE182434/raw/GSE182434_cell_annotation.txt.gz', sep='\t', index_col=0)
genes = []
blocks = []
cells = None
for chunk in pd.read_csv(f'{ES}/GSE182434/raw/GSE182434_raw_count_matrix.txt.gz', sep='\t', index_col=0, chunksize=3000):
    if cells is None:
        cells = chunk.columns.tolist()
    genes += chunk.index.tolist()
    blocks.append(sp.csr_matrix(chunk.values.astype(np.float32)))
M = sp.vstack(blocks).T.tocsr()
A = sc.AnnData(M, obs=pd.DataFrame(index=cells), var=pd.DataFrame(index=genes))
A.var_names_make_unique()
A.obs = A.obs.join(ann, how='left')
log('GSE182434', A.n_obs, '细胞', dict(A.obs.Tissue.value_counts()))
GMAP = {'DLBCL': '结内DLBCL', 'FL': '滤泡性淋巴瘤', 'Tonsil': '扁桃体', 'tonsil': '扁桃体'}
for (pt_, sub) in A.obs.groupby('Patient'):
    a = A[sub.index].copy()
    tissue = str(sub.Tissue.iloc[0])
    grp = GMAP.get(tissue, tissue)
    coo = str(sub.COO.iloc[0])
    (rows, pc, comp, ct, lc) = process(a, str(pt_), 'GSE182434', dict(group=grp, patient=str(pt_), tissue=f'{tissue}/{coo}', platform='scRNA'), author=sub.CellType)
    allrows += rows
    comps.append(comp)
    cts.append(ct)
    lcs.append(lc)
    pc.to_csv(f'{O}/percell_GSE182434_{pt_}.csv.gz', compression='gzip')
    log('GSE182434', pt_, grp, comp['n_cells'], {k: v for (k, v) in comp.items() if k.startswith('n_')})
    save()
lab = pd.read_csv(f'{DL}/per_cell_labels.csv')
pm = pd.read_csv(f'{DL}/patient_metadata.csv')
log('patient_metadata 列:', pm.columns.tolist())
dis = dict(zip(pm.iloc[:, 0].astype(str), pm.iloc[:, 1].astype(str))) if pm.shape[1] >= 2 else {}
try:
    S = sc.read_h5ad(f'{DL}/final_integrated_annotated.h5ad')
    log('内部 h5ad', S.shape, list(S.obs.columns)[:8])
    lab = lab.set_index('cell')
    common = S.obs_names.intersection(lab.index)
    S = S[common].copy()
    S.obs = S.obs.join(lab[['sample', 'patient_id', 'tissue_role']])
    for ((pt_, smp), sub) in S.obs.groupby(['patient_id', 'sample']):
        if str(sub.tissue_role.iloc[0]).lower() in ('adjacent', 'normal', '癌旁', 'paired_normal'):
            continue
        a = S[sub.index].copy()
        d = dis.get(str(pt_), '')
        grp = 'PCNSL(内部)' if str(pt_) in ('P2', 'P4', 'P6', 'P7') else '癌转移(内部)'
        (rows, pc, comp, _, lc) = process(a, f'{pt_}_{smp}', '内部sc', dict(group=grp, patient=str(pt_), tissue=str(sub.tissue_role.iloc[0]), platform='scRNA'))
        allrows += rows
        comps.append(comp)
        lcs.append(lc)
        log('内部', pt_, smp, comp['n_cells'], {k: v for (k, v) in comp.items() if k.startswith('n_')})
        save()
except Exception as e:
    log('内部 sc 失败', str(e)[:200])
bcr = []
for f in sorted(glob.glob(f'{ES}/GSE203552/raw/*_bcr.csv.gz')):
    nm = re.search('_(p\\d+_(?:biopsy\\d*|csf|blood\\d*))_bcr', f).group(1)
    d = pd.read_csv(f)
    d = d[(d.is_cell.astype(str).str.lower() == 'true') & (d.high_confidence.astype(str).str.lower() == 'true') & (d.productive.astype(str).str.lower() == 'true')]
    h = d[d.chain == 'IGH']
    top = h.raw_clonotype_id.value_counts(normalize=True)
    kcells = set(d[d.chain == 'IGK'].barcode)
    lcells = set(d[d.chain == 'IGL'].barcode)
    bcr.append(dict(sample=nm, n_cells_with_bcr=d.barcode.nunique(), n_IGH_cells=h.barcode.nunique(), top_clonotype_frac=round(float(top.iloc[0]), 4) if len(top) else np.nan, top_clonotype=top.index[0] if len(top) else None, kappa_cells=len(kcells - lcells), lambda_cells=len(lcells - kcells), kappa_frac_bcr=round(len(kcells - lcells) / max(len(kcells - lcells) + len(lcells - kcells), 1), 4)))
pd.DataFrame(bcr).to_csv(f'{O}/L4_heming_bcr_clonality.csv', index=False)
df = pd.DataFrame(allrows)
df = df[df.n_lineage_cells >= 20]
pt = df.groupby(['group', 'patient', 'signature', 'lineage'], as_index=False).frac_of_lineage.mean()
out = []
for (sig, sub) in pt.groupby('signature'):
    r = dict(signature=sig, lineage=sub.lineage.iloc[0])
    for g in ['PCNSL(内部)', 'PCNSL(外部)', '结内DLBCL', '滤泡性淋巴瘤', '扁桃体', '癌转移(内部)', 'PCNSL脑脊液(外部)']:
        v = sub[sub.group == g].frac_of_lineage
        r[f'{g}_median'] = round(v.median(), 4) if len(v) else np.nan
        r[f'{g}_n'] = len(v)
    x = sub[sub.group.isin(['PCNSL(内部)', 'PCNSL(外部)'])].frac_of_lineage
    y = sub[sub.group == '结内DLBCL'].frac_of_lineage
    y2 = sub[sub.group.isin(['结内DLBCL', '滤泡性淋巴瘤'])].frac_of_lineage
    r['PCNSL_all_median'] = round(x.median(), 4) if len(x) else np.nan
    r['PCNSL_all_n'] = len(x)
    r['mwu_p_PCNSL_vs_nodalDLBCL'] = mannwhitneyu(x, y).pvalue if len(x) >= 3 and len(y) >= 3 else np.nan
    r['mwu_p_PCNSL_vs_nodal_all'] = mannwhitneyu(x, y2).pvalue if len(x) >= 3 and len(y2) >= 3 else np.nan
    out.append(r)
pd.DataFrame(out).to_csv(f'{O}/L2_pcnsl_vs_nodal_dlbcl.csv', index=False)
pt.to_csv(f'{O}/L2_patient_level_frequencies.csv', index=False)
log('全部完成')
