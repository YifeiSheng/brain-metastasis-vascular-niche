# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import numpy as np, pandas as pd, scanpy as sc, json, time
from sklearn.decomposition import NMF
from scipy.cluster.hierarchy import linkage, fcluster
from scipy.spatial.distance import squareform
D = str(_HANDOFF_ROOT / 'data/integrated')
O = str(_HANDOFF_ROOT / 'results/internal_programs_and_CNV')
L = open(f'{O}/progress_46.txt', 'a', buffering=1)
log = lambda *a: L.write(time.strftime('[%H:%M:%S] ') + ' '.join(map(str, a)) + '\n')
a = sc.read_h5ad(f'{D}/data/sc_counts.h5ad')
sc.pp.normalize_total(a, target_sum=10000.0)
sc.pp.log1p(a)
pc = pd.read_csv(f'{D}/output/per_cell_labels.csv', index_col=0)
a.obs['lineage'] = pc.lineage_l1.reindex(a.obs_names)
a.obs['sub05'] = pc.sub05.reindex(a.obs_names).fillna(a.obs.atomic_cluster_id.astype(str))
excl_low = ['r4_029', 'r4_035', 'r4_047', 'r4_034']
tum = a[a.obs.lineage.isin(['上皮/肺腺癌', '上皮/神经内分泌']) & ~a.obs.atomic_cluster_id.isin(excl_low)].copy()
SETS = json.load(open(f'{O}/M_gene_sets_used.json'))
progs = {}
W_all = {}
for p in ['P1', 'P5', 'P3']:
    t = tum[tum.obs.patient_id == p].copy()
    if t.n_obs < 100:
        continue
    sc.pp.filter_genes(t, min_cells=10)
    sc.pp.highly_variable_genes(t, n_top_genes=2000, flavor='seurat')
    X = t[:, t.var.highly_variable].X.toarray()
    X[X < 0] = 0
    nmf = NMF(n_components=10, init='nndsvda', random_state=0, max_iter=500)
    W = nmf.fit_transform(X)
    H = nmf.components_
    genes = t.var_names[t.var.highly_variable]
    for k in range(10):
        top = list(genes[np.argsort(-H[k])[:50]])
        progs[f'{p}_P{k}'] = top
    Wdf = pd.DataFrame(W, index=t.obs_names, columns=[f'{p}_P{k}' for k in range(10)])
    Wdf['sub05'] = t.obs.sub05.values
    W_all[p] = Wdf
    log(p, '细胞', t.n_obs, 'NMF 完成')
names = list(progs)
n = len(names)
J = np.zeros((n, n))
for i in range(n):
    for j in range(n):
        (A, B) = (set(progs[names[i]]), set(progs[names[j]]))
        J[i, j] = len(A & B) / len(A | B)
Z = linkage(squareform(1 - J, checks=False), 'average')
cl = fcluster(Z, t=0.85, criterion='distance')
mp = pd.DataFrame({'program': names, 'patient': [x.split('_')[0] for x in names], 'metaprogram': cl})
rows = []
for (m, g) in mp.groupby('metaprogram'):
    pts = sorted(set(g.patient))
    allg = pd.Series([x for pnm in g.program for x in progs[pnm]]).value_counts()
    shared = allg[allg >= 2].index.tolist() if len(g) > 1 else []
    top = allg.head(30).index.tolist()
    ann = []
    for (s, gs) in SETS.items():
        ov = len(set(top) & set(gs))
        if ov >= 4:
            ann.append(f'{s}({ov})')
    rows.append(dict(metaprogram=m, n_programs=len(g), patients=';'.join(pts), programs=';'.join(g.program), n_shared_genes=len(shared), top_genes=';'.join(top), annotation=';'.join(ann)))
res = pd.DataFrame(rows).sort_values(['patients', 'n_programs'], ascending=[False, False])
res.to_csv(f'{O}/M1b_metaprograms.csv', index=False)
json.dump(progs, open(f'{O}/M1b_program_top50.json', 'w'), ensure_ascii=False, indent=1)
pd.DataFrame(J, index=names, columns=names).round(3).to_csv(f'{O}/M1b_program_jaccard.csv')
wrows = []
for (p, Wdf) in W_all.items():
    g = Wdf.groupby('sub05').mean()
    g['patient'] = p
    wrows.append(g)
pd.concat(wrows).round(3).to_csv(f'{O}/M1b_program_weights_by_subcluster.csv')
pd.set_option('display.width', 260)
pd.set_option('display.max_colwidth', 120)
pd.set_option('display.max_rows', 100)
print(res[['metaprogram', 'patients', 'n_programs', 'n_shared_genes', 'annotation', 'top_genes']].to_string(index=False))
log('完成')
