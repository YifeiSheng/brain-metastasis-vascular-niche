# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
"""Download and prepare public experimental state transitions, GEO GSE237317.
GEO calls these normalized expression values; do NOT assume raw counts."""
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os
for k in ['OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS']:
    os.environ[k] = '2'
from pathlib import Path
import urllib.request, tarfile, gzip, json, hashlib
import numpy as np, pandas as pd
B = Path(str(_HANDOFF_ROOT / ''))
O = B / 'results/pericyte_differentiation/GSE237317'
O.mkdir(exist_ok=True, parents=True)
downloads = []
for (suffix, path) in [('suppl/GSE237317_RAW.tar', 'GSE237317_RAW.tar'), ('soft/GSE237317_family.soft.gz', 'GSE237317_family.soft.gz')]:
    u = 'https://ftp.ncbi.nlm.nih.gov/geo/series/GSE237nnn/GSE237317/' + suffix
    f = O / path
    if not f.exists():
        urllib.request.urlretrieve(u, f)
    downloads.append({'url': u, 'file': str(f), 'sha256': hashlib.sha256(f.read_bytes()).hexdigest()})
with tarfile.open(O / 'GSE237317_RAW.tar') as t:
    for m in t.getmembers():
        if m.isfile():
            (O / Path(m.name).name).write_bytes(t.extractfile(m).read())
matrix = []
for f in sorted(O.glob('GSM*.txt.gz')):
    d = pd.read_csv(f, header=None, sep='\t', names=['gene_id', 'value'])
    d['gene_id'] = d.gene_id.str.split('.').str[0]
    s = d.groupby('gene_id').value.sum()
    s.name = f.name.split('_', 1)[1].replace('.txt.gz', '')
    matrix.append(s)
x = pd.concat(matrix, axis=1).fillna(0)
x.to_csv(O / 'author_expression_matrix.csv')
fp = B / 'data/external/scrna/GSE256493/raw/GSM8101557_metastasis_23-10-19_Ecs_features.tsv.gz'
f = pd.read_csv(fp, header=None, sep='\t', names=['gene_id', 'symbol', 'type'])
f.gene_id = f.gene_id.str.split('.').str[0]
f[['gene_id', 'symbol']].drop_duplicates('gene_id').to_csv(O / 'ensembl_symbol_map.csv', index=False)
metadata = [l.strip() for l in gzip.open(O / 'GSE237317_family.soft.gz', 'rt') if l.startswith(('^SAMPLE', '!Sample_title', '!Sample_characteristics', '!Sample_growth_protocol', '!Sample_data_processing'))]
(O / 'metadata_excerpt.txt').write_text('\n'.join(metadata) + '\n')
json.dump({'downloads': downloads, 'annotation_lookup': {'file': str(fp), 'sha256': hashlib.sha256(fp.read_bytes()).hexdigest()}, 'input_type_note': 'GEO describes normalized expression although deposited values are integral; primary model log2(author expression+1), sensitivity log2(CPM+1), limma-trend, not edgeR raw-count inference', 'samples_per_state': 2, 'donor_independence': 'not established by GEO; no human donor-level inference', 'culture_media_confound': 'CSCs/PdCSCs neurobasal, Cdpericytes pericyte-special medium', 'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, open(O / 'PROVENANCE.json', 'w'), indent=2)
print(x.shape, x.columns.tolist(), flush=True)
