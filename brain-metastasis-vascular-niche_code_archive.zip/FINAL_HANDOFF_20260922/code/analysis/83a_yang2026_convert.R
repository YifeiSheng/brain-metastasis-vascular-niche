# Current scientific analysis; package-relative paths.
handoff_arg <- grep("^--file=", commandArgs(), value=TRUE)
handoff_file <- sub("^--file=", "", handoff_arg[1])
HANDOFF_ROOT <- Sys.getenv("SAFEPOSTER_HANDOFF_ROOT", unset=normalizePath(file.path(dirname(handoff_file), "../.."), mustWork=TRUE))
# L15: Yang 2026 Zenodo 17879312 snRNAcounts.rds -> mtx; meta -> csv; 检查 sce.mergeSCT.rds (空间对象) 的结构
suppressMessages({library(Matrix)})
E=file.path(HANDOFF_ROOT, "data/external/bulk/Yang2026_BrM_zenodo")
x=readRDS(file.path(E,"snRNAcounts.rds")); cat("class:",class(x),"\n")
if (inherits(x,"Seurat")) { suppressMessages(library(Seurat)); x=GetAssayData(x,assay="RNA",layer="counts") }
if (is.list(x) && !inherits(x,"dgCMatrix")) { cat("list names:",names(x),"\n"); x=x[[1]] }
x=as(x,"dgCMatrix"); cat("dim:",dim(x),"\n"); cat(head(rownames(x)),"\n"); cat(head(colnames(x)),"\n")
writeMM(x,file.path(E,"snRNA_mtx/matrix.mtx")); writeLines(rownames(x),file.path(E,"snRNA_mtx/genes.tsv")); writeLines(colnames(x),file.path(E,"snRNA_mtx/barcodes.tsv"))
m=readRDS(file.path(E,"snRNA.meta.rds")); write.csv(m[,c("orig.ident","Group","Label","celltype","nCount_RNA","nFeature_RNA","percent.mt")],file.path(E,"snRNA_mtx/meta.csv"))
cat("barcode 与 meta 重叠:",sum(colnames(x) %in% rownames(m)),"/",ncol(x),"\n")
cat("=== 空间对象 ===\n")
s=tryCatch(readRDS(file.path(E,"sce.mergeSCT.rds")),error=function(e){cat("读取失败",conditionMessage(e),"\n");NULL})
if (!is.null(s)) {
  cat("class:",class(s),"\n")
  if (inherits(s,"Seurat")) { suppressMessages(library(Seurat)); print(s); cat("assays:",names(s@assays),"\n"); cat("images:",names(s@images),"\n"); print(head(s@meta.data,3)); print(table(s$orig.ident))
    for (a in names(s@assays)) cat(a, "layers:", paste(Layers(s[[a]]),collapse=","), "\n") }
  else if (inherits(s,"SingleCellExperiment")) { suppressMessages(library(SingleCellExperiment)); print(s); print(head(as.data.frame(colData(s)),3)) }
}
cat("DONE\n")
