# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os, glob, numpy as np, pandas as pd, scipy.io, time
from sklearn.neighbors import KDTree
B = str(_HANDOFF_ROOT / '')
D = f'{B}/data/external/imc/Karimi2023/data/BrainData'
O = f'{B}/results/immune_glial_lymphoma/X_XENIUM_RARE'
os.makedirs(O, exist_ok=True)
roi_meta = pd.read_csv(f'{B}/results/immune_glial_lymphoma/M1_I1_IMC/M1_imc_immune_by_roi.csv', index_col=0)[['group', 'region', 'Patient ID', 'primary']]
rows = []
for f in sorted(glob.glob(f'{D}/BRAIN_IMC_CellType/*.mat')):
    roi = os.path.basename(f)[:-4]
    try:
        m = scipy.io.loadmat(f)
        ct = np.array([str(x[0]) if len(x) else 'NONE' for x in m['cellTypes'].ravel()])
        seg = scipy.io.loadmat(f'{D}/BRAIN_IMC_Segmentation/{roi}/allRegionIndices.mat')['allRegInds'].ravel()
        (H, W) = scipy.io.loadmat(f'{D}/BRAIN_IMC_Segmentation/{roi}/nuclei_multiscale.mat')['nucleiImage'].shape
    except Exception:
        continue
    if len(seg) != len(ct):
        continue
    cent = np.array([[np.mean((np.asarray(i).ravel() - 1) // H), np.mean((np.asarray(i).ravel() - 1) % H)] if np.size(i) else [np.nan, np.nan] for i in seg])
    ok = ~np.isnan(cent[:, 0]) & (ct != 'NONE')
    cent = cent[ok]
    ct = ct[ok]
    ec = ct == 'Endothelial cell'
    canc = ct == 'Cancer'
    if ec.sum() < 5:
        continue
    (d, _) = KDTree(cent[ec]).query(cent, k=1)
    near = d[:, 0] <= 20
    base = float(near[~ec & ~canc].mean()) if (~ec & ~canc).sum() else np.nan
    (dc, _) = KDTree(cent[canc]).query(cent, k=1) if canc.sum() >= 20 else (np.full((len(ct), 1), np.nan), None)
    r = dict(roi=roi, base_within20_EC=round(base, 4))
    for k in ['Mast cell', 'DCs cell', 'Neutrophils', 'B cell', 'Tc', 'Cl BMDM', 'Cl MG']:
        idx = ct == k
        if idx.sum() >= 5:
            r[f'{k}_n'] = int(idx.sum())
            r[f'{k}_within20_EC'] = round(float(near[idx].mean()), 4)
            r[f'{k}_enrich_EC'] = round(float(near[idx].mean()) / max(base, 1e-06), 3)
            r[f'{k}_med_dist_cancer'] = round(float(np.nanmedian(dc[idx, 0])), 1)
    rows.append(r)
res = pd.DataFrame(rows).set_index('roi').join(roi_meta)
res.to_csv(f'{O}/X_imc_perivascular_rare_by_roi.csv')
pt = res.groupby(['group', 'Patient ID']).mean(numeric_only=True).reset_index()
pt.to_csv(f'{O}/X_imc_perivascular_rare_by_patient.csv', index=False)
print(pt.groupby('group')[[c for c in pt.columns if c.endswith('_enrich_EC') or c.endswith('_med_dist_cancer')]].median().round(2).T.to_string())
print('done')
