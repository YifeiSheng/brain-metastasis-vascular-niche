# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
"""L16: donor-resolved ligand sources and separate frozen-graph state analyses.
Exploratory, observational. No new clustering/UMAP, no lineage-conversion inference.
"""
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os
for k in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS']:
    os.environ[k] = '2'
from pathlib import Path
import json, hashlib, platform, time
import numpy as np, pandas as pd, anndata as ad, scipy.sparse as sp
from scipy.io import mmread
from scipy.sparse.csgraph import connected_components, dijkstra
from scipy.stats import spearmanr, rankdata
from statsmodels.stats.multitest import multipletests
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
B = Path(str(_HANDOFF_ROOT / ''))
O = B / 'results/spatial_distance_and_state_validation'
SETS = {'pericyte_identity': ['PDGFRB', 'RGS5', 'CSPG4', 'KCNJ8', 'ABCC9', 'HIGD1B', 'NDUFA4L2', 'NOTCH3'], 'T_transport': ['SLC6A1', 'SLC1A3', 'SLC12A7', 'SLC20A2'], 'M_matrix': ['COL4A1', 'COL4A2', 'COL4A3', 'COL4A4', 'ADAMTS1', 'LAMA4'], 'SMC_contractile': ['ACTA2', 'MYH11', 'TAGLN', 'CNN1', 'LMOD1', 'MYL9'], 'fibroblast': ['DCN', 'LUM', 'COL1A1', 'COL1A2', 'FBLN1', 'PDGFRA'], 'endothelial': ['PECAM1', 'VWF', 'CLDN5', 'CDH5', 'KDR'], 'astroglia': ['GFAP', 'AQP4', 'SLC1A2', 'ALDH1L1'], 'epithelial': ['EPCAM', 'KRT8', 'KRT18', 'KRT19'], 'AT2_differentiation': ['SFTPA1', 'SFTPA2', 'SFTPB', 'SFTPC', 'ABCA3', 'NAPSA', 'NKX2-1'], 'secretory': ['MUC1', 'MUC5AC', 'MUC5B', 'AGR2', 'SPDEF', 'TFF3', 'CLDN18'], 'NE_ASCL1': ['ASCL1', 'INSM1', 'CHGA', 'CHGB', 'SYP', 'DLL3'], 'NE_NEUROD1': ['NEUROD1', 'NEUROD2', 'NCAM1', 'CHGA', 'SYP'], 'mesenchymal': ['VIM', 'ZEB1', 'ZEB2', 'SNAI1', 'SNAI2', 'FN1', 'ITGA5'], 'cycling': ['MKI67', 'TOP2A', 'UBE2C', 'CCNB1', 'CDK1', 'PCNA'], 'hypoxia': ['CA9', 'EGLN3', 'BNIP3', 'BNIP3L', 'NDRG1', 'PDK1', 'ADM', 'ANGPTL4'], 'glycolysis': ['SLC2A1', 'HK2', 'PFKP', 'ALDOA', 'PGK1', 'ENO1', 'LDHA', 'PKM'], 'lactate_transport': ['SLC16A1', 'SLC16A3', 'LDHB'], 'acetate': ['ACSS1', 'ACSS2'], 'serine_synthesis': ['PHGDH', 'PSAT1', 'PSPH'], 'glutamine': ['SLC1A5', 'SLC38A1', 'SLC38A2', 'GLS', 'GLUL'], 'EC_activation': ['ESM1', 'ANGPT2', 'PLVAP', 'APLN', 'DLL4'], 'BBB': ['ABCB1', 'MFSD2A', 'CLDN5', 'SLC2A1']}
LIGANDS = ['VEGFA', 'VEGFB', 'VEGFC', 'PGF', 'PDGFA', 'PDGFB', 'ANGPT1', 'ANGPT2', 'FGF2', 'TGFB1', 'CXCL12']
RECEPTORS = ['KDR', 'FLT1', 'FLT4', 'PDGFRA', 'PDGFRB', 'TEK', 'FGFR1', 'TGFBR2', 'CXCR4']
ALL = list(dict.fromkeys(sum(SETS.values(), []) + LIGANDS + RECEPTORS))
a = ad.read_h5ad(B / 'data/integrated/final_integrated_annotated.h5ad')
pc = pd.read_csv(B / 'data/integrated/per_cell_labels.csv', index_col='cell').reindex(a.obs_names)
assert pc.patient_id.notna().all()
x = a.X.tocsr()
totals = np.asarray(x.sum(axis=1)).ravel()
idx = [a.var_names.get_loc(g) for g in ALL if g in a.var_names]
genes = [g for g in ALL if g in a.var_names]
counts = x[:, idx].toarray()
expr = np.log1p(counts / np.maximum(totals[:, None], 1) * 10000.0)
E = pd.DataFrame(expr, index=a.obs_names, columns=genes)
C = pd.DataFrame(counts, index=a.obs_names, columns=genes)
df = pc.copy()
df['total_counts'] = totals
df['n_genes'] = np.diff(x.indptr)
df['sub05'] = df.sub05.fillna(df.atomic_cluster_id)
for (k, gs) in SETS.items():
    g = [z for z in gs if z in E]
    df[k] = E[g].mean(axis=1)
    df[k + '_ndet'] = (C[g] > 0).sum(axis=1)
for g in LIGANDS + RECEPTORS:
    if g in E:
        df[g] = E[g]
        df[g + '_det'] = C[g] > 0
json.dump({'definition': 'mean log1p(CP10k), descriptive literature-informed modules; not calibrated cell classes or flux', 'gene_sets': SETS, 'available': {k: [g for g in gs if g in E] for (k, gs) in SETS.items()}, 'ligands': LIGANDS, 'receptors': RECEPTORS}, open(O / 'gene_sets.json', 'w'), indent=2)
df['pericyte_candidate'] = (df.lineage_l1 == '基质') & (df.pericyte_identity_ndet >= 3)
df['pericyte_clean'] = df.pericyte_candidate & (df.epithelial_ndet < 2) & (df.endothelial_ndet < 2) & (df.astroglia_ndet < 2)
df['T_supported'] = df.T_transport_ndet >= 2
df['M_supported'] = df.M_matrix_ndet >= 2
df['functional_support'] = np.select([df.T_supported & df.M_supported, df.T_supported, df.M_supported], ['T_and_M', 'T_only', 'M_only'], 'neither')
df['tumor_scope'] = np.select([df.patient_id.isin(['P1', 'P5']) & (df.lineage_l1 == '上皮/肺腺癌'), (df.patient_id == 'P3') & (df.lineage_l1 == '上皮/神经内分泌')], ['LUAD', 'SCLC'], 'other')
df.to_csv(O / 'internal_cell_states.csv.gz', compression='gzip')
metrics = list(SETS) + [g for g in LIGANDS + RECEPTORS if g in E] + [g + '_det' for g in LIGANDS + RECEPTORS if g in E]
summ = df.groupby(['patient_id', 'tissue_role', 'lineage_l1'], observed=True)[metrics].mean()
summ.insert(0, 'n_cells', df.groupby(['patient_id', 'tissue_role', 'lineage_l1']).size())
summ.to_csv(O / 'internal_patient_lineage_scores.csv')
source = []
for p in df.patient_id.unique():
    for g in LIGANDS:
        if g not in C:
            continue
        pp = df.patient_id.eq(p)
        tot = C.loc[pp, g].sum()
        for l in df.loc[pp, 'lineage_l1'].unique():
            sel = pp & df.lineage_l1.eq(l)
            n = int(sel.sum())
            source.append(dict(patient=p, lineage=l, gene=g, n_cells=n, pct_detected=float((C.loc[sel, g] > 0).mean()), mean_logCP10k=float(E.loc[sel, g].mean()), captured_UMI=float(C.loc[sel, g].sum()), captured_transcript_share=float(C.loc[sel, g].sum() / tot) if tot else np.nan))
pd.DataFrame(source).to_csv(O / 'ligand_sources_by_patient.csv', index=False)
pairs = [('VEGFA', 'KDR', '内皮'), ('VEGFA', 'FLT1', '内皮'), ('PGF', 'FLT1', '内皮'), ('PDGFB', 'PDGFRB', '基质'), ('ANGPT1', 'TEK', '内皮'), ('ANGPT2', 'TEK', '内皮')]
lr = []
for p in ['P1', 'P3', 'P5']:
    for (lig, rec, receiver) in pairs:
        for send in ['tumor', '内皮', '髓系', '基质']:
            sm = (df.patient_id == p) & (df.tumor_scope != 'other' if send == 'tumor' else df.lineage_l1 == send)
            rm = (df.patient_id == p) & (df.lineage_l1 == receiver)
            lr.append(dict(patient=p, source=send, receiver=receiver, ligand=lig, receptor=rec, n_sender=int(sm.sum()), n_receiver=int(rm.sum()), ligand_detection=float((C.loc[sm, lig] > 0).mean()), receptor_detection=float((C.loc[rm, rec] > 0).mean())))
pd.DataFrame(lr).to_csv(O / 'LR_expression_compatibility.csv', index=False)
sub = df[df.tumor_scope != 'other'].groupby(['patient_id', 'sub05'], observed=True)[list(SETS) + LIGANDS].mean()
sub['n_cells'] = df[df.tumor_scope != 'other'].groupby(['patient_id', 'sub05']).size()
sub.to_csv(O / 'tumor_frozen_subcluster_programs.csv')
peri = df[df.pericyte_candidate].copy()
ps = peri.groupby(['patient_id', 'functional_support']).size().rename('n').reset_index()
ps.to_csv(O / 'pericyte_support_counts.csv', index=False)
clean = df[df.pericyte_clean]
ps2 = clean.groupby(['patient_id', 'functional_support']).size().rename('n').reset_index()
ps2.to_csv(O / 'pericyte_clean_support_counts.csv', index=False)
clean.groupby('patient_id')[list(SETS) + LIGANDS].mean().to_csv(O / 'pericyte_programs_by_patient.csv')
pred = pd.read_csv(B / 'results/vascular_niche/V3/V3_percell_predictions.csv.gz', index_col=0)
pred = pred[pred.source == '我们_sc'].reindex(peri.index)
peri['legacy_label'] = pred.predicted_labels
peri['legacy_conf'] = pred.conf
peri.to_csv(O / 'pericyte_legacy_vs_marker_audit.csv.gz', compression='gzip')
assoc = []
for p in ['P1', 'P3', 'P5']:
    z = sub.loc[p]
    z = z[z.n_cells >= 20]
    for g in ['VEGFA', 'PDGFB']:
        for s in ['AT2_differentiation', 'secretory', 'NE_ASCL1', 'NE_NEUROD1', 'hypoxia', 'glycolysis', 'cycling']:
            (rho, pv) = spearmanr(z[g], z[s]) if len(z) >= 5 and z[g].nunique() > 1 and (z[s].nunique() > 1) else (np.nan, np.nan)
            assoc.append(dict(patient=p, x=g, y=s, n_subclusters=len(z), rho=rho, p_descriptive=pv))
assoc = pd.DataFrame(assoc)
ok = assoc.p_descriptive.notna()
assoc.loc[ok, 'q_BH_descriptive'] = multipletests(assoc.loc[ok, 'p_descriptive'], method='fdr_bh')[1]
assoc.to_csv(O / 'tumor_subcluster_associations.csv', index=False)
gn = O / 'frozen_induced_snn.mtx'
if gn.exists():
    cells = pd.read_csv(O / 'frozen_induced_cells.tsv', header=None)[0]
    G = mmread(gn).tocsr()
    lookup = pd.Series(np.arange(len(cells)), index=cells)
    graph = []
    traj = []
    corr = []
    scopes = {p: df.index[(df.patient_id == p) & (df.tumor_scope != 'other')] for p in ['P1', 'P3', 'P5']}
    scopes['pericytes'] = df.index[df.pericyte_clean]
    for (name, ids) in scopes.items():
        positions = lookup.reindex(ids).dropna().astype(int).values
        ids = cells.iloc[positions].values
        g = G[positions][:, positions].copy()
        g.setdiag(0)
        g.eliminate_zeros()
        g = g.maximum(g.T)
        (nc, lab) = connected_components(g, directed=False)
        sizes = np.bincount(lab)
        lcc = lab == sizes.argmax()
        state = df.loc[ids]
        graph.append(dict(scope=name, n_cells=len(ids), components=nc, largest_component=int(lcc.sum()), largest_fraction=float(lcc.mean()), patient_counts=state.patient_id.value_counts().to_json()))
        if lcc.sum() < 30:
            continue
        ids = ids[lcc]
        state = df.loc[ids]
        g = g[lcc][:, lcc].copy()
        g.data = 1 / np.maximum(g.data, 1e-08)
        root_sets = ['T_transport', 'M_matrix'] if name == 'pericytes' else ['NE_ASCL1', 'NE_NEUROD1'] if name == 'P3' else ['AT2_differentiation', 'secretory']
        orders = {}
        for root_score in root_sets:
            scores = state[root_score].values
            if np.max(scores) <= 0:
                continue
            roots = np.argsort(-scores, kind='stable')[:5]
            dist = np.min(dijkstra(g, directed=False, indices=roots), axis=0)
            pt = rankdata(dist) / len(dist)
            orders[root_score] = pt
            for (cid, t) in zip(ids, pt):
                traj.append(dict(scope=name, root_program=root_score, cell=cid, patient=df.loc[cid, 'patient_id'], graph_order=t, root_cell=cid in ids[roots]))
            for score in list(SETS):
                (rho, pv) = spearmanr(pt, state[score])
                corr.append(dict(scope=name, root_program=root_score, program=score, rho=rho, n=len(ids), interpretation='descriptive cellular graph order; not developmental time'))
        if len(orders) == 2:
            vals = list(orders.values())
            graph[-1]['root_order_correlation'] = float(spearmanr(vals[0], vals[1]).statistic)
    pd.DataFrame(graph).to_csv(O / 'frozen_graph_topology.csv', index=False)
    pd.DataFrame(traj).to_csv(O / 'root_sensitivity_graph_orders.csv.gz', index=False, compression='gzip')
    pd.DataFrame(corr).to_csv(O / 'graph_order_program_correlations.csv', index=False)
(fig, ax) = plt.subplots(1, 3, figsize=(13, 4))
for (i, p) in enumerate(['P1', 'P3', 'P5']):
    m = (df.patient_id == p) & (df.tumor_scope != 'other')
    v = ax[i].scatter(df.loc[m, 'UMAP_1'], df.loc[m, 'UMAP_2'], c=df.loc[m, 'hypoxia'], s=3, cmap='viridis')
    ax[i].set_title(p + ' tumor / hypoxia')
    ax[i].set_xlabel('Frozen UMAP 1')
    ax[i].set_ylabel('Frozen UMAP 2')
    fig.colorbar(v, ax=ax[i])
fig.tight_layout()
fig.savefig(O / 'internal_tumor_states.png', dpi=180)
fig.savefig(O / 'internal_tumor_states.pdf')
plt.close(fig)
(fig, ax) = plt.subplots(figsize=(7, 4))
if len(clean):
    tab = pd.crosstab(clean.patient_id, clean.functional_support, normalize='index').reindex(columns=['T_only', 'T_and_M', 'M_only', 'neither'], fill_value=0)
    tab.plot.bar(stacked=True, ax=ax, color=['#2a9d8f', '#73bfb8', '#e9c46a', '#bbbbbb'])
    ax.set_ylabel('Fraction of screened pericyte candidates')
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(O / 'pericyte_functional_support.png', dpi=180)
    fig.savefig(O / 'pericyte_functional_support.pdf')
print('COMPLETE', len(df), 'cells', int(df.pericyte_candidate.sum()), 'pericyte candidates', int(df.pericyte_clean.sum()), 'screened', flush=True)
print(pd.DataFrame(source).query("patient in ['P1','P3','P5'] and gene in ['VEGFA','PDGFB']").to_string(index=False), flush=True)
print(ps2.to_string(index=False), flush=True)
