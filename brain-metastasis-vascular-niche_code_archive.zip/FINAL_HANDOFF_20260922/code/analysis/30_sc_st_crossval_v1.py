# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os, json, numpy as np, pandas as pd, scanpy as sc, scipy.sparse as sp, anndata as ad
from scipy.stats import hypergeom, binom, spearmanr
from sklearn.decomposition import NMF
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
for f in [str(_HANDOFF_ROOT / 'environment/NotoSansCJKsc-Regular.otf')]:
    try:
        font_manager.fontManager.addfont(f)
    except Exception:
        pass
plt.rcParams['font.family'] = ['Noto Sans CJK SC', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False
rng = np.random.default_rng(0)
ST = str(_HANDOFF_ROOT / 'data/spatial')
DL = str(_HANDOFF_ROOT / 'data/integrated')
OUT = str(_HANDOFF_ROOT / 'results/internal_spatial_validation')
FIG = f'{OUT}/figures'
LOG = open(f'{OUT}/progress.txt', 'a', buffering=1)

def log(*a):
    import time
    LOG.write(time.strftime('[%H:%M:%S] ') + ' '.join(map(str, a)) + '\n')
SLIDES = {'S1_T': ('batch_10562_2022_05_30', 'P1', '肺腺癌', 'tumor'), 'S2_C': ('batch_10562_2022_05_30', 'P5', '肺腺癌', 'adjacent'), 'Toct6': ('batch_10562_2022_05_30', 'P8', '肺腺癌', 'tumor'), 'Coct6': ('batch_10562_2022_05_30', 'P8', '肺腺癌', 'adjacent'), 'Toct4': ('batch_15551_2022_03_28', 'P6', '弥漫大B细胞淋巴瘤', 'tumor'), 'Coct4': ('batch_15551_2022_03_28', 'P6', '弥漫大B细胞淋巴瘤', 'adjacent'), 'Toct5': ('batch_15551_2022_03_28', 'P2', '弥漫大B细胞淋巴瘤', 'tumor'), 'Coct5': ('batch_15551_2022_03_28', 'P2', '弥漫大B细胞淋巴瘤', 'adjacent')}
TUMOR_PANEL = {'肺腺癌': ['EPCAM', 'KRT8', 'KRT18', 'KRT7', 'SFTPB', 'NAPSA', 'NKX2-1', 'MUC1'], '弥漫大B细胞淋巴瘤': ['MS4A1', 'CD79A', 'CD79B', 'CD19', 'PAX5', 'BANK1']}
BRAIN_PANEL = ['GFAP', 'AQP4', 'PLP1', 'MBP', 'MOBP', 'MOG', 'SNAP25', 'SYT1', 'GJA1', 'SLC1A2']
a = sc.read_h5ad(f'{DL}/final_integrated_annotated.h5ad')
X = sp.csc_matrix(a.X)
gi = {g: i for (i, g) in enumerate(a.var_names)}
obs = a.obs.copy()
pc = pd.read_csv(f'{DL}/per_cell_labels.csv', index_col=0)
obs['sub05'] = pc.sub05.reindex(obs.index)
obs['lineage'] = pc.lineage_l1.reindex(obs.index)
cand = pd.read_csv(f'{DL}/output/rare_cell_candidates.csv')
mk = pd.read_csv(f'{DL}/output/rare_cell_markers.csv')

def parse_def(s):
    cl = []
    subs = []
    mark = []
    for part in s.split('|'):
        if part.startswith('marker:'):
            mark = part[7:].split('&')
        elif part.startswith('r4_') and '.' in part:
            subs += part.split(';')
        elif part:
            cl += part.split(';')
    return (cl, subs, mark)
det_all = None

def mask_of(cl, subs, mark):
    m = obs.atomic_cluster_id.isin(cl).values | obs.sub05.isin(subs).values
    if mark:
        m = np.ones(len(obs), bool)
        for g in mark:
            m &= (X[:, gi[g]] > 0).toarray().ravel()
    return m
SIG = {}
TOPG = {}
detX = (X > 0).astype(np.float32)
for r in cand.itertuples():
    name = r.candidate
    (cl, subs, mark) = parse_def(r.definition)
    m = mask_of(cl, subs, mark)
    if m.sum() < 10:
        continue
    pin = np.asarray(detX[m].mean(axis=0)).ravel()
    pout = np.asarray(detX[~m].mean(axis=0)).ravel()
    d = pin - pout
    order = np.argsort(-d)
    TOPG[name] = [a.var_names[i] for i in order[:50] if d[i] > 0.1]
    sub = mk[mk.candidate == name]
    spec = sub[(sub.pct_in > 0.5) & (sub.pct_out < 0.05)].sort_values('diff', ascending=False).gene.tolist()
    if len(spec) < 3:
        extra = [a.var_names[i] for i in order[:30] if pin[i] > 0.5 and pout[i] < 0.08]
        spec = list(dict.fromkeys(spec + extra))[:8]
    SIG[name] = spec[:10]
LIN_SIG = {'星形胶质(sc缺失)': ['GFAP', 'AQP4', 'SLC1A2', 'ALDH1L1', 'GJA1', 'SLC1A3', 'SOX9'], '反应性星形胶质': ['GFAP', 'VIM', 'SERPINA3', 'CD44', 'C3', 'CHI3L1'], '神经元(sc缺失)': ['SNAP25', 'SYT1', 'RBFOX3', 'SLC17A7', 'GAD1', 'NRGN', 'NEFL'], '少突胶质成熟': ['MOG', 'MAG', 'MOBP', 'PLP1', 'OPALIN', 'ERMN'], '肺腺癌上皮': ['SFTPB', 'NAPSA', 'NKX2-1', 'KRT7', 'EPCAM', 'SFTPA1'], '淋巴瘤B': ['MS4A1', 'CD79A', 'CD79B', 'PAX5', 'BANK1', 'CD19'], 'T细胞': ['CD3D', 'CD3E', 'CD2', 'TRAC', 'IL7R'], '中性粒': ['CSF3R', 'FCGR3B', 'S100A8', 'S100A9', 'CXCR2', 'G0S2'], 'TLS(三级淋巴结构)': ['CXCL13', 'CCL19', 'CCL21', 'MS4A1', 'CD3E', 'LTB', 'CR2']}
SIG.update(LIN_SIG)
json.dump({'signatures': SIG, 'top_genes': TOPG}, open(f'{OUT}/signatures_used.json', 'w'), ensure_ascii=False, indent=1)
log('签名数', len(SIG))
fam = pd.read_csv(f'{DL}/work/S2_findallmarkers_xing.csv')
ATOM = {c: g.sort_values(['p_val_adj', 'avg_log2FC'], ascending=[True, False]).gene.head(50).tolist() for (c, g) in fam.groupby('cluster')}
annot = pd.read_csv(f'{DL}/output/cluster_annotation.csv').set_index('atomic_cluster_id')

def load(slide):
    b = SLIDES[slide][0]
    p = f'{ST}/{b}/1.SpaceRanger/{slide}'
    v = sc.read_visium(p, count_file='filtered_feature_bc_matrix.h5', library_id=slide)
    v.var_names_make_unique()
    v.obs['slide'] = slide
    v.obs['patient'] = SLIDES[slide][1]
    v.obs['disease'] = SLIDES[slide][2]
    v.obs['role'] = SLIDES[slide][3]
    sc.pp.filter_genes(v, min_cells=3)
    v.layers['counts'] = v.X.copy()
    sc.pp.normalize_total(v, target_sum=10000.0)
    sc.pp.log1p(v)
    return v

def band(v):
    tp = [g for g in TUMOR_PANEL[v.obs.disease.iloc[0]] if g in v.var_names]
    bp = [g for g in BRAIN_PANEL if g in v.var_names]
    t = np.asarray(v[:, tp].X.mean(axis=1)).ravel()
    b = np.asarray(v[:, bp].X.mean(axis=1)).ravel()
    v.obs['tumor_score'] = t
    v.obs['brain_score'] = b
    lab = np.array(['other'] * v.n_obs, dtype=object)
    lab[(t >= 0.5) & (b < 0.5)] = 'tumor'
    lab[(b >= 0.5) & (t < 0.5)] = 'brain'
    lab[(t >= 0.5) & (b >= 0.5)] = 'interface'
    from sklearn.neighbors import NearestNeighbors
    xy = v.obsm['spatial']
    nn = NearestNeighbors(n_neighbors=7).fit(xy)
    (dist, idx) = nn.kneighbors(xy)
    dmin = np.median(dist[:, 1])
    neigh = [[j for (j, dd) in zip(idx[i, 1:], dist[i, 1:]) if dd < dmin * 1.3] for i in range(v.n_obs)]
    lab2 = lab.copy()
    for i in range(v.n_obs):
        if lab[i] == 'tumor' and any((lab[j] == 'brain' for j in neigh[i])):
            lab2[i] = 'interface'
        elif lab[i] == 'brain' and any((lab[j] == 'tumor' for j in neigh[i])):
            lab2[i] = 'interface'
    v.obs['band'] = pd.Categorical(lab2, categories=['tumor', 'interface', 'brain', 'other'])
    v.uns['neigh'] = neigh
    return v

def score_sig(v, genes, n_null=100):
    g = [x for x in genes if x in v.var_names]
    if len(g) < 2:
        return (None, None, len(g))
    sc.tl.score_genes(v, g, score_name='_s', ctrl_size=50, n_bins=25, random_state=0)
    s = v.obs['_s'].values.copy()
    mean = np.asarray(v.X.mean(axis=0)).ravel()
    bins = pd.qcut(pd.Series(mean).rank(method='first'), 25, labels=False).values
    gb = [bins[v.var_names.get_loc(x)] for x in g]
    pool = {b: np.where(bins == b)[0] for b in set(gb)}
    null = []
    for k in range(n_null):
        rg = [v.var_names[rng.choice(pool[b])] for b in gb]
        sc.tl.score_genes(v, rg, score_name='_n', ctrl_size=50, n_bins=25, random_state=k)
        null.append(v.obs['_n'].values.copy())
    null = np.vstack(null)
    thr = np.quantile(null, 0.99)
    return (s, thr, len(g))
slides = {}
sigrows = []
spot_scores = {}
for sl in SLIDES:
    v = band(load(sl))
    slides[sl] = v
    log(sl, v.n_obs, 'spots; band:', v.obs.band.value_counts().to_dict())
    ss = pd.DataFrame(index=v.obs_names)
    for (name, genes) in SIG.items():
        (s, thr, ng) = score_sig(v, genes, n_null=60)
        if s is None:
            continue
        pos = s > thr
        ss[name] = s
        ss[name + '__pos'] = pos
        row = dict(signature=name, slide=sl, patient=SLIDES[sl][1], disease=SLIDES[sl][2], role=SLIDES[sl][3], n_genes_used=ng, n_spots=v.n_obs, pos_frac_all=round(pos.mean(), 4), mean_score_all=round(float(s.mean()), 4), null_thr=round(float(thr), 4))
        for bd in ['tumor', 'interface', 'brain', 'other']:
            m = (v.obs.band == bd).values
            row[f'n_{bd}'] = int(m.sum())
            row[f'pos_frac_{bd}'] = round(pos[m].mean(), 4) if m.sum() else np.nan
            row[f'mean_{bd}'] = round(float(s[m].mean()), 4) if m.sum() else np.nan
        sigrows.append(row)
    spot_scores[sl] = ss
    ss.to_csv(f'{OUT}/spot_scores_{sl}.csv')
    v.obs[['slide', 'patient', 'disease', 'role', 'tumor_score', 'brain_score', 'band']].to_csv(f'{OUT}/spot_bands_{sl}.csv')
    log(sl, '签名打分完成')
sig = pd.DataFrame(sigrows)
sig.to_csv(f'{OUT}/signature_presence_by_slide_band.csv', index=False)
PAIRS = {'肥大细胞': ['TPSAB1', 'CPA3'], 'BAM': ['LYVE1', 'CD209', 'F13A1'], 'BAM2': ['COLEC12', 'F13A1', 'SIGLEC1'], 'TLS': ['CXCL13', 'CCL19', 'MS4A1'], 'TLS2': ['CXCL13', 'MS4A1', 'CD3E'], '血管龛': ['NOTCH3', 'HIGD1B', 'CLDN5'], '周细胞': ['RGS5', 'HIGD1B', 'NDUFA4L2'], '小胶质': ['P2RY12', 'TMEM119'], 'pDC': ['LILRA4', 'CLEC4C'], 'mregDC': ['LAMP3', 'CCR7'], 'cDC1': ['CLEC9A', 'XCR1'], '活化Treg': ['FOXP3', 'TNFRSF9'], 'CXCL13耗竭CD8': ['CXCL13', 'CD8A', 'ENTPD1'], '脂质TAM': ['SPP1', 'GPNMB', 'TREM2'], '黏液肿瘤': ['MUC5B', 'TFF3', 'AGR2'], 'EMT肿瘤': ['LOX', 'SERPINE1', 'EPCAM'], '反应性星形胶质': ['GFAP', 'SERPINA3', 'CD44'], '未成熟少突': ['BCAS1', 'SOX2', 'OLIG2'], 'NEUROD1_NE': ['NEUROD1', 'CHGB', 'EPCAM'], 'IFN巨噬': ['CXCL9', 'CXCL10', 'CD163']}
prow = []
for (sl, v) in slides.items():
    for (name, genes) in PAIRS.items():
        g = [x for x in genes if x in v.var_names]
        if len(g) < 2:
            continue
        D = (v[:, g].layers['counts'] > 0).toarray()
        obs_n = int(D.all(axis=1).sum())
        p = np.prod(D.mean(axis=0))
        exp = p * v.n_obs
        pval = binom.sf(obs_n - 1, v.n_obs, p) if obs_n > 0 else 1.0
        prow.append(dict(pair=name, genes=';'.join(g), slide=sl, patient=SLIDES[sl][1], disease=SLIDES[sl][2], role=SLIDES[sl][3], n_spots=v.n_obs, spots_all_detected=obs_n, expected_if_independent=round(exp, 2), obs_over_exp=round(obs_n / exp, 2) if exp > 0 else np.nan, binom_p=pval, marginal_detect=';'.join((f'{x}={D[:, i].mean():.3f}' for (i, x) in enumerate(g)))))
pairs = pd.DataFrame(prow)
pairs.to_csv(f'{OUT}/marker_pair_cooccurrence.csv', index=False)
log('共检出完成')
nrows = []
NMFK = 12
for (sl, v) in slides.items():
    sc.pp.highly_variable_genes(v, n_top_genes=3000, flavor='seurat')
    hv = v.var_names[v.var.highly_variable]
    M = v[:, hv].X.toarray()
    M[M < 0] = 0
    nmf = NMF(n_components=NMFK, init='nndsvda', random_state=0, max_iter=400)
    W = nmf.fit_transform(M)
    H = nmf.components_
    v.obsm['nmf'] = W
    universe = set(v.var_names)
    Nuni = len(universe)
    for k in range(NMFK):
        top = [hv[i] for i in np.argsort(-H[k])[:40]]
        best = []
        for (name, genes) in list(TOPG.items()) + [(f"atomic:{c} {annot.loc[c, 'proposed_label'][:30]}", g) for (c, g) in ATOM.items()]:
            gs = set(genes) & universe
            ov = len(gs & set(top))
            if ov >= 3:
                pval = hypergeom.sf(ov - 1, Nuni, len(gs), len(top))
                best.append((pval, name, ov))
        best.sort()
        wb = W[:, k]
        bd = v.obs.band.values
        nrows.append(dict(slide=sl, patient=SLIDES[sl][1], disease=SLIDES[sl][2], role=SLIDES[sl][3], factor=k, top_genes=';'.join(top[:25]), best_match=best[0][1] if best else 'UNMAPPED', best_overlap=best[0][2] if best else 0, best_p=best[0][0] if best else np.nan, second_match=best[1][1] if len(best) > 1 else '', second_p=best[1][0] if len(best) > 1 else np.nan, mean_w_tumor=round(float(wb[bd == 'tumor'].mean()), 3) if (bd == 'tumor').any() else np.nan, mean_w_interface=round(float(wb[bd == 'interface'].mean()), 3) if (bd == 'interface').any() else np.nan, mean_w_brain=round(float(wb[bd == 'brain'].mean()), 3) if (bd == 'brain').any() else np.nan))
    log(sl, 'NMF 完成')
nmfdf = pd.DataFrame(nrows)
nmfdf.to_csv(f'{OUT}/nmf_factors_mapped_to_sc.csv', index=False)
crow = []
KEY = [k for k in SIG if any((t in k for t in ['BAM', '脂质', '小胶质', 'TLS', 'Treg', 'CXCL13', '周细胞', '内皮', '肥大', 'pDC', 'mregDC', '星形', '少突', '黏液', '干扰素', 'γδ', '单核', '中性粒', '肺腺癌上皮', '淋巴瘤B', 'T细胞']))]
for (sl, ss) in spot_scores.items():
    cols = [k for k in KEY if k in ss.columns]
    C = ss[cols].corr(method='spearman')
    C.to_csv(f'{OUT}/signature_spearman_{sl}.csv')
    for (i, x) in enumerate(cols):
        for y in cols[i + 1:]:
            crow.append(dict(slide=sl, sig1=x, sig2=y, rho=round(C.loc[x, y], 3)))
pd.DataFrame(crow).to_csv(f'{OUT}/signature_coloc_long.csv', index=False)
for (sl, v) in slides.items():
    xy = v.obsm['spatial']
    ss = spot_scores[sl]
    keys = ['band', '肺腺癌上皮' if SLIDES[sl][2] == '肺腺癌' else '淋巴瘤B', '星形胶质(sc缺失)', '反应性星形胶质', '边界相关巨噬 BAM(LYVE1/CD209/COLEC12/F13A1+)', '脂质相关肿瘤相关巨噬(SPP1+/GPNMB+/TREM2+/PLIN2+)', '稳态小胶质(P2RY12+/CX3CR1+/SALL1+)', '活化小胶质(IL1B+/CCL3+/CCL4+/ATF3+)', 'TLS(三级淋巴结构)', '活化调节性 T 细胞(FOXP3+/TNFRSF9+/LAYN+/IL2RA+)', 'CXCL13+ 耗竭样 CD8 T(TNFRSF9+/ENTPD1+/MIR155HG+)', '干扰素反应巨噬(GBP4/5+/CXCL9/10+/IFI44L+)', '肥大细胞', '浆细胞样树突状细胞 pDC', '血管周细胞/平滑肌(CSPG4+/NOTCH3+/RGS5+/KCNJ8+)', '内皮细胞(CDH5+/KDR+/CD34+/ABCB1+ 血脑屏障型)', '未成熟少突胶质(BCAS1+/SOX2+/OLIG2+，髓鞘基因低)', '黏液/分泌型肺腺癌细胞(MUC5B+/TFF3+/AGR2+/CEACAM5+)', '中性粒', 'T细胞']
    keys = [k for k in keys if k == 'band' or k in ss.columns]
    n = len(keys)
    nc = 5
    nr = int(np.ceil(n / nc))
    (fig, axes) = plt.subplots(nr, nc, figsize=(4.2 * nc, 4 * nr))
    for (ax, k) in zip(axes.ravel(), keys):
        if k == 'band':
            colors = {'tumor': '#d62728', 'interface': '#ff7f0e', 'brain': '#1f77b4', 'other': '#cccccc'}
            ax.scatter(xy[:, 0], -xy[:, 1], s=6, c=[colors[b] for b in v.obs.band], linewidths=0)
            ax.set_title(f"{sl} 三带 (T{int((v.obs.band == 'tumor').sum())}/I{int((v.obs.band == 'interface').sum())}/B{int((v.obs.band == 'brain').sum())})", fontsize=9)
        else:
            s = ss[k].values
            sca = ax.scatter(xy[:, 0], -xy[:, 1], s=6, c=s, cmap='magma', vmin=np.quantile(s, 0.02), vmax=max(np.quantile(s, 0.98), 1e-06), linewidths=0)
            ax.set_title(f"{k[:26]}\n阳性 {100 * ss[k + '__pos'].mean():.1f}%", fontsize=8)
        ax.set_xticks([])
        ax.set_yticks([])
        ax.set_aspect('equal')
    for ax in axes.ravel()[n:]:
        ax.axis('off')
    fig.suptitle(f'{sl}  {SLIDES[sl][1]} {SLIDES[sl][2]} {SLIDES[sl][3]}', fontsize=12)
    fig.savefig(f'{FIG}/spatial_{sl}.png', dpi=110, bbox_inches='tight')
    plt.close(fig)
piv = sig.pivot(index='signature', columns='slide', values='pos_frac_all').reindex(columns=list(SLIDES))
(fig, ax) = plt.subplots(figsize=(10, 0.32 * len(piv) + 2))
im = ax.imshow(piv.values, cmap='viridis', aspect='auto', vmin=0, vmax=min(1, np.nanmax(piv.values)))
ax.set_yticks(range(len(piv)))
ax.set_yticklabels([s[:34] for s in piv.index], fontsize=7)
ax.set_xticks(range(len(piv.columns)))
ax.set_xticklabels([f'{c}\n{SLIDES[c][1]} {SLIDES[c][3]}' for c in piv.columns], fontsize=8)
for i in range(piv.shape[0]):
    for j in range(piv.shape[1]):
        ax.text(j, i, f'{100 * piv.values[i, j]:.0f}', ha='center', va='center', fontsize=6, color='white' if piv.values[i, j] < 0.5 * np.nanmax(piv.values) else 'black')
plt.colorbar(im, ax=ax, label='阳性 spot 比例')
ax.set_title('单细胞签名在 8 张 Visium 切片上的阳性 spot 比例（置换零模型 99% 阈值）')
fig.savefig(f'{FIG}/heatmap_signature_by_slide.png', dpi=130, bbox_inches='tight')
plt.close(fig)
log('全部完成')
