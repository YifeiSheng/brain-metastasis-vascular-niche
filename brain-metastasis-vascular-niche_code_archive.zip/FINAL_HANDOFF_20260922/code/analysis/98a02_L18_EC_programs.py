# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
"""L18 donor-level EC programs: predeclared primary panels, contrasts and complete sensitivities."""
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os
for k in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS']:
    os.environ[k] = '2'
from pathlib import Path
import pandas as pd, numpy as np, json, itertools, hashlib, datetime
from scipy.stats import rankdata
from statsmodels.stats.multitest import multipletests
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
B = Path(str(_HANDOFF_ROOT / ''))
O = B / 'results/endothelial_response'
cfg = json.loads((B / 'data/analysis_definitions/vascular_gene_sets.json').read_text())
ap = json.loads((O / 'ANALYSIS_PLAN.json').read_text())
panels = {**cfg['primary_panels'], **cfg['sensitivity_panels']}
pairs = ap['relative_contrasts']
meta = pd.read_csv(O / 'EC_donor_manifest.csv')
out = []
long = []
genestat = []
perms = {}
rng = np.random.default_rng(1802)

def test(x, y, bootstrap=False):
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    assert np.isfinite(x).all() and np.isfinite(y).all() and (len(x) > 1) and (len(y) > 1)
    z = rankdata(np.r_[x, y])
    nx = len(x)
    ny = len(y)
    if (nx, ny) not in perms:
        perms[nx, ny] = np.array(list(itertools.combinations(range(nx + ny), nx)), dtype=int)
    null = np.abs(z[perms[nx, ny]].sum(1) - nx * (nx + ny + 1) / 2)
    observed = abs(z[:nx].sum() - nx * (nx + ny + 1) / 2)
    u = z[:nx].sum() - nx * (nx + 1) / 2
    d = dict(n_BM=nx, n_ref=ny, median_BM=float(np.median(x)), median_ref=float(np.median(y)), median_diff=float(np.median(x) - np.median(y)), mean_diff=float(x.mean() - y.mean()), rank_biserial=float(2 * u / (nx * ny) - 1), p_exact=float(np.mean(null >= observed - 1e-10)), n_permutations=len(null))
    if bootstrap:
        v = np.median(x[rng.integers(nx, size=(10000, nx))], axis=1) - np.median(y[rng.integers(ny, size=(10000, ny))], axis=1)
        (d['median_bootstrap95_low'], d['median_bootstrap95_high']) = np.quantile(v, [0.025, 0.975]).astype(float)
        v = [np.median(np.delete(x, i)) - np.median(y) for i in range(nx)] + [np.median(x) - np.median(np.delete(y, i)) for i in range(ny)]
        d['leave_one_donor_min_median_diff'] = float(min(v))
        d['leave_one_donor_max_median_diff'] = float(max(v))
    return d
for gate in ['main', 'strict']:
    counts = pd.read_csv(O / f'EC_{gate}_pseudobulk_counts.csv.gz', index_col=0)
    m = meta[meta.gate == gate].set_index('donor').loc[counts.index]
    common = set((O / f'EC_{gate}_common_measured_genes.txt').read_text().splitlines())
    log = np.log2(1 + counts.div(counts.sum(1), axis=0) * 1000000.0)
    z = log.sub(log.mean(0), axis=1).div(log.std(0, ddof=1).replace(0, np.nan), axis=1)
    for (method, expr) in [('mean_log2CPM', log), ('mean_gene_z', z)]:
        score = pd.DataFrame(index=expr.index)
        for (name, gs) in panels.items():
            avail = [g for g in gs if g in common and g in expr and expr[g].notna().all()]
            assert len(avail) >= max(2, len(gs) // 2), (gate, name, avail)
            score[name] = expr[avail].mean(1)
            for donor in score.index:
                long.append(dict(gate=gate, method=method, donor=donor, group=m.loc[donor, 'group'], module=name, score=float(score.loc[donor, name]), n_genes=len(avail), genes=';'.join(avail), kind='panel'))
        for (a, b) in pairs:
            name = a + '__minus__' + b
            score[name] = score[a] - score[b]
            for donor in score.index:
                long.append(dict(gate=gate, method=method, donor=donor, group=m.loc[donor, 'group'], module=name, score=float(score.loc[donor, name]), n_genes=None, genes='', kind='relative_panel_contrast'))
        for exclude_breast in [False, True]:
            use = m.index != 'MET_patient3' if exclude_breast else np.ones(len(m), bool)
            for reference in ['TL', 'GBM']:
                bm = (m.group == 'BM').values & use
                ref = (m.group == reference).values & use
                assert bm.sum() >= 4 and ref.sum() >= 5
                for name in score:
                    primary = gate == 'main' and method == 'mean_log2CPM' and (not exclude_breast) and (name != 'tip_core')
                    result = test(score.loc[bm, name], score.loc[ref, name], bootstrap=primary)
                    out.append(dict(gate=gate, method=method, exclude_breast=exclude_breast, comparison='BM_vs_' + reference, module=name, kind='relative_panel_contrast' if '__minus__' in name else 'panel', primary=primary, **result))
    for reference in ['TL', 'GBM']:
        bm = m.group == 'BM'
        ref = m.group == reference
        for gene in sorted(set(sum(cfg['primary_panels'].values(), [])) & common):
            genestat.append(dict(gate=gate, comparison='BM_vs_' + reference, gene=gene, **test(log.loc[bm, gene], log.loc[ref, gene])))
res = pd.DataFrame(out)
res['q_BH_all176'] = multipletests(res.p_exact, method='fdr_bh')[1]
primary = res.primary
assert primary.sum() == 20
res.loc[primary, 'q_BH_primary20'] = multipletests(res.loc[primary, 'p_exact'], method='fdr_bh')[1]
pan = primary & res.kind.eq('panel')
rel = primary & ~res.kind.eq('panel')
res.loc[pan, 'q_BH_panels12'] = multipletests(res.loc[pan, 'p_exact'], method='fdr_bh')[1]
res.loc[rel, 'q_BH_relative8'] = multipletests(res.loc[rel, 'p_exact'], method='fdr_bh')[1]
assert len(res) == 176
res.to_csv(O / 'EC_program_donor_tests.csv', index=False)
pd.DataFrame(long).to_csv(O / 'EC_program_donor_scores.csv', index=False)
gs = pd.DataFrame(genestat)
gs['q_BH_all_component_tests'] = multipletests(gs.p_exact, method='fdr_bh')[1]
mm = gs.gate == 'main'
gs.loc[mm, 'q_BH_main_component_tests'] = multipletests(gs.loc[mm, 'p_exact'], method='fdr_bh')[1]
gs.to_csv(O / 'EC_component_gene_tests.csv', index=False)
ds = pd.read_csv(O / 'EC_donor_state_support.csv')
supp = []
for ((gate, module), v) in ds.groupby(['gate', 'module']):
    for reference in ['TL', 'GBM']:
        bm = v.group == 'BM'
        ref = v.group == reference
        supp.append(dict(gate=gate, module=module, comparison='BM_vs_' + reference, **test(v.loc[bm, 'fraction_atleast2'], v.loc[ref, 'fraction_atleast2'])))
sp = pd.DataFrame(supp)
sp['q_BH_all_support32'] = multipletests(sp.p_exact, method='fdr_bh')[1]
assert len(sp) == 32
sp.to_csv(O / 'EC_support_donor_tests.csv', index=False)
label = {'EC_cycle': 'Cell cycle', 'tip_guidance': 'Tip / guidance', 'activation_fenestration': 'Activation / fenestration', 'ECM_associated': 'ECM-associated', 'BBB_transport': 'BBB transport', 'junction': 'Junction'}
names = list(cfg['primary_panels'])
(fig, ax) = plt.subplots(1, 2, figsize=(12.6, 5.2), sharey=True)
for (axis, comp) in zip(ax, ['BM_vs_TL', 'BM_vs_GBM']):
    v = res[primary & res.comparison.eq(comp) & res.kind.eq('panel')].set_index('module').loc[names]
    for (i, row) in enumerate(v.itertuples()):
        lo = row.median_bootstrap95_low
        hi = row.median_bootstrap95_high
        col = '#087f8c' if row.q_BH_primary20 < 0.05 else '#89959c'
        axis.plot([lo, hi], [i, i], color=col, lw=2)
        axis.scatter(row.median_diff, i, color=col, zorder=3, s=45)
        axis.text(0.99, i, 'q=' + format(row.q_BH_primary20, '.3g'), transform=axis.get_yaxis_transform(), ha='right', va='bottom', fontsize=8)
    axis.axvline(0, color='black', lw=0.8)
    axis.set_yticks(range(6), [label[n] for n in names])
    axis.set_title(comp.replace('_', ' '))
    axis.set_xlabel('Median expression-panel difference\nmean log2(CPM+1); descriptive bootstrap95% CI')
axis.invert_yaxis()
fig.suptitle('Independent sorted-EC donors: BM 5 / temporal-lobe 9 / GBM 7\nExpression panels do not directly measure new vessels or permeability', fontsize=12)
fig.tight_layout(rect=[0, 0, 1, 0.91])
fig.savefig(O / 'EC_state_validation.png', dpi=190)
fig.savefig(O / 'EC_state_validation.pdf')
plt.close(fig)
json.dump(dict(timestamp_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), program_tests=len(res), primary_tests=int(primary.sum()), component_gene_tests=len(gs), support_tests=len(sp), signature_sha256=hashlib.sha256((B / 'data/analysis_definitions/vascular_gene_sets.json').read_bytes()).hexdigest(), script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), bootstrap='10000 donor resamples; descriptive median-difference CI, not equivalent to rank-distribution test', statistic='Exact two-sided ranksum donor-label permutation; tied ranks averaged; all label allocations. No cell-level inference.'), open(O / 'PROGRAM_PROVENANCE.json', 'w'), indent=2)
print(res.loc[primary, ['comparison', 'module', 'median_BM', 'median_ref', 'median_diff', 'p_exact', 'q_BH_primary20', 'q_BH_all176']].to_string(index=False), flush=True)
print('COMPLETE', flush=True)
