# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
"""Shared-feature sensitivity: same measurable genes in all sixteen sections, tumor >=50 UMI, author EC; local-block/depth adjusted."""
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os
for k in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS']:
    os.environ[k] = '2'
from pathlib import Path
import numpy as np, pandas as pd, json, itertools, hashlib
from scipy.spatial import cKDTree
from scipy.stats import rankdata
from statsmodels.stats.multitest import multipletests
B = Path(str(_HANDOFF_ROOT / ''))
O = B / 'results/nutrition'
E = B / 'data/external/scrna/GSE185386/raw'
S0 = json.load(open(O / 'gene_sets.json'))['sets']
common = set.intersection(*[set(np.load(f, allow_pickle=False)['genes'].tolist()) for f in O.glob('*_selected_counts.npz')])
S = {k: [g for g in gs if g in common] for (k, gs) in S0.items()}
valid_sets = {k: len(S[k]) >= min(2, len(gs)) and len(S[k]) / len(gs) >= 0.5 for (k, gs) in S0.items()}
(O / 'slideseq_common_gene_sets.json').write_text(json.dumps({'common': S, 'nominal': S0, 'valid_sets': valid_sets}, indent=2))
rows = []
qc = []
for f in sorted(E.glob('*_slide_spatial_info.csv.gz')):
    name = f.name.split('_', 1)[1].replace('_slide_spatial_info.csv.gz', '')
    patient = name.split('_rep')[0]
    site = 'BM' if name.startswith('MBM') else 'ECM'
    z = np.load(O / (name + '_selected_counts.npz'))
    bc = z['barcodes']
    tot = z['total']
    info = pd.read_csv(f, index_col=0).reindex(bc)
    xy = info[['xcoord', 'ycoord']].values
    valid = np.isfinite(xy).all(axis=1)
    lab = info.rctd_cell_type.astype(str).values
    ec = valid & (lab == 'Endothelial cells')
    tu = valid & (lab == 'Tumor cells') & (tot >= 50)
    qc.append(dict(section=name, patient=patient, site=site, n_EC_author=int(ec.sum()), n_tumor_50=int(tu.sum())))
    if ec.sum() < 20 or tu.sum() < 200:
        continue
    di = cKDTree(xy[ec]).query(xy[tu])[0]
    nnd = cKDTree(xy[valid]).query(xy[valid], k=2)[0][:, 1]
    bw = 20 * np.median(nnd[nnd > 0])
    coord = xy[tu]
    box = np.floor((coord - coord.min(axis=0)) / bw).astype(int)
    bl = pd.factorize(pd.Series([str(x) + '_' + str(y) for (x, y) in box]))[0]
    c = z['counts'][tu]
    genes = z['genes'].tolist()
    ex = np.log1p(c / np.maximum(tot[tu, None], 1) * 10000.0)
    dep = np.log1p(tot[tu])
    for (k, gs) in S.items():
        jj = [genes.index(g) for g in gs if g in genes]
        yy = ex[:, jj].mean(axis=1) if jj else np.full(len(ex), np.nan)
        if not valid_sets[k]:
            rows.append(dict(section=name, patient=patient, site=site, pathway=k, partial_rank_r=np.nan, n_tumor=int(tu.sum()), n_EC=int(ec.sum())))
            continue
        xx = np.column_stack([rankdata(di), rankdata(yy), dep])
        df = pd.DataFrame(xx)
        df['block'] = bl
        xx -= df.groupby('block')[[0, 1, 2]].transform('mean').values
        design = np.column_stack([np.ones(len(xx)), xx[:, 2]])
        rr = xx[:, :2] - design @ np.linalg.lstsq(design, xx[:, :2], rcond=None)[0]
        r = float(np.corrcoef(rr.T)[0, 1]) if np.isfinite(rr).all() and np.min(np.std(rr, axis=0)) > 1e-12 else np.nan
        rows.append(dict(section=name, patient=patient, site=site, pathway=k, partial_rank_r=r, n_tumor=int(tu.sum()), n_EC=int(ec.sum())))
r = pd.DataFrame(rows)
r.to_csv(O / 'slideseq_common_genes_section.csv', index=False)
pd.DataFrame(qc).to_csv(O / 'slideseq_common_genes_qc.csv', index=False)
p = r.groupby(['site', 'patient', 'pathway'], as_index=False).partial_rank_r.median()
p.to_csv(O / 'slideseq_common_genes_patient.csv', index=False)
tests = []
for ((site, k), ss) in p.groupby(['site', 'pathway']):
    v = ss.partial_rank_r.values
    v = v[np.isfinite(v)]
    if len(v) < 3:
        tests.append(dict(site=site, pathway=k, n_patients=len(v), median_partial_rank_r=np.nan, mean_partial_rank_r=np.nan, n_positive=int((v > 0).sum()), n_negative=int((v < 0).sum()), p=np.nan))
        continue
    sg = np.array(list(itertools.product([-1, 1], repeat=len(v))))
    pv = float((np.abs((sg * v).mean(axis=1)) >= abs(v.mean()) - 1e-12).mean())
    tests.append(dict(site=site, pathway=k, n_patients=len(v), median_partial_rank_r=float(np.median(v)), mean_partial_rank_r=float(v.mean()), n_positive=int((v > 0).sum()), n_negative=int((v < 0).sum()), p=pv))
t = pd.DataFrame(tests)
t['q_BH_all24'] = np.nan
ok = t.p.notna()
t.loc[ok, 'q_BH_all24'] = multipletests(t.loc[ok, 'p'], method='fdr_bh')[1]
t.to_csv(O / 'slideseq_common_genes_tests.csv', index=False)
print(t.to_string(index=False))
