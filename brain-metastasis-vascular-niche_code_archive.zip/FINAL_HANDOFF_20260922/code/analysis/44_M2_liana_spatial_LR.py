# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import numpy as np, pandas as pd, scanpy as sc, liana as li, time, scipy.sparse as sp
from sklearn.neighbors import NearestNeighbors
D = str(_HANDOFF_ROOT / 'data/integrated')
O = str(_HANDOFF_ROOT / 'results/internal_programs_and_CNV')
ST = str(_HANDOFF_ROOT / 'data/spatial')
L = open(f'{O}/progress_44.txt', 'a', buffering=1)
log = lambda *a: L.write(time.strftime('[%H:%M:%S] ') + ' '.join(map(str, a)) + '\n')
a = sc.read_h5ad(f'{D}/data/sc_counts.h5ad')
sc.pp.normalize_total(a, target_sum=10000.0)
sc.pp.log1p(a)
pc = pd.read_csv(f'{D}/output/per_cell_labels.csv', index_col=0)
a.obs['sub05'] = pc.sub05.reindex(a.obs_names).fillna(a.obs.atomic_cluster_id.astype(str))
a.obs['lineage'] = pc.lineage_l1.reindex(a.obs_names)
ann = pd.read_csv(f'{D}/output/cluster_annotation.csv').set_index('atomic_cluster_id')
bad = ann.index[ann.assignment_status.isin(['DOUBLET', 'CROSS_LINEAGE_OR_AMBIENT'])]
a = a[~a.obs.atomic_cluster_id.isin(bad)].copy()
grp = a.obs.sub05.astype(str).copy()
grp[a.obs.lineage == 'B细胞谱系'] = 'B淋巴瘤/B细胞'
grp[a.obs.lineage == '胶质'] = '少突胶质谱系'
low = {'r4_009': '巨噬低深度', 'r4_039': 'T/NK低深度', 'r4_056': '髓系低深度', 'r4_029': 'NE肿瘤低深度', 'r4_035': 'LUAD肿瘤低深度', 'r4_047': 'LUAD肿瘤低深度'}
for (k, v) in low.items():
    grp[a.obs.atomic_cluster_id == k] = v
vc = grp.value_counts()
grp[grp.isin(vc.index[vc < 30])] = '其他小群'
a.obs['lr_group'] = grp.values
log('分组数', a.obs.lr_group.nunique())
li.mt.rank_aggregate(a, groupby='lr_group', resource_name='consensus', expr_prop=0.1, n_perms=200, use_raw=False, verbose=False, n_jobs=16)
res = a.uns['liana_res']
res.to_csv(f'{O}/M2_liana_sc_all.csv.gz', compression='gzip')
log('liana 完成', len(res))
top = res[res.magnitude_rank < 0.05].copy()
top.to_csv(f'{O}/M2_liana_sc_top.csv')
log('top 对', len(top))
pairs = top[['ligand_complex', 'receptor_complex']].drop_duplicates()
pairs = pairs[~pairs.ligand_complex.str.contains('_') & ~pairs.receptor_complex.str.contains('_')]
lig = set(pairs.ligand_complex)
rec = set(pairs.receptor_complex)
log('待检 LR 对', len(pairs))
SL = {'S1_T': 'batch_10562_2022_05_30', 'Toct6': 'batch_10562_2022_05_30', 'Toct4': 'batch_15551_2022_03_28', 'Toct5': 'batch_15551_2022_03_28', 'Coct4': 'batch_15551_2022_03_28'}
rng = np.random.default_rng(0)
rows = []
for (sl, b) in SL.items():
    v = sc.read_visium(f'{ST}/{b}/1.SpaceRanger/{sl}', count_file='filtered_feature_bc_matrix.h5', library_id=sl)
    v.var_names_make_unique()
    X = (v.X > 0).tocsc()
    xy = v.obsm['spatial'].astype(float)
    nn = NearestNeighbors(n_neighbors=7).fit(xy)
    (dist, idx) = nn.kneighbors(xy)
    dmin = np.median(dist[:, 1])
    A = sp.lil_matrix((v.n_obs, v.n_obs))
    for i in range(v.n_obs):
        for (j, dd) in zip(idx[i, 1:], dist[i, 1:]):
            if dd < dmin * 1.3:
                A[i, j] = 1
    A = A.tocsr()
    A = A + sp.eye(v.n_obs, format='csr')
    gi = {g: i for (i, g) in enumerate(v.var_names)}
    for r in pairs.itertuples():
        (l, rc) = (r.ligand_complex, r.receptor_complex)
        if l not in gi or rc not in gi:
            continue
        Lv = X[:, gi[l]].toarray().ravel().astype(float)
        Rv = X[:, gi[rc]].toarray().ravel().astype(float)
        if Lv.mean() < 0.02 or Rv.mean() < 0.02:
            continue
        obs = float((Lv * (A @ Rv > 0)).sum())
        null = []
        for k in range(100):
            Rp = rng.permutation(Rv)
            null.append(float((Lv * (A @ Rp > 0)).sum()))
        null = np.array(null)
        z = (obs - null.mean()) / (null.std() + 1e-09)
        p = (np.sum(null >= obs) + 1) / 101
        rows.append(dict(slide=sl, ligand=l, receptor=rc, lig_det=round(Lv.mean(), 3), rec_det=round(Rv.mean(), 3), obs=obs, null_mean=round(null.mean(), 1), z=round(z, 2), p=p))
    log(sl, '完成')
st = pd.DataFrame(rows)
st.to_csv(f'{O}/M2_LR_spatial_neighbor_test.csv', index=False)
sup = st[(st.z > 3) & (st.p < 0.02)].groupby(['ligand', 'receptor']).slide.apply(lambda x: ';'.join(sorted(x))).rename('slides_supported')
top2 = top.merge(sup, left_on=['ligand_complex', 'receptor_complex'], right_index=True, how='left')
top2.to_csv(f'{O}/M2_LR_sc_with_spatial_support.csv', index=False)
log('全部完成')
