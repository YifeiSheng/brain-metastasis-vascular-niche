# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
"""Download/parse author-provided Kim clinical sample summary without modifying the workbook."""
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as E
import csv, urllib.request, json, hashlib
B = Path(str(_HANDOFF_ROOT / ''))
O = B / 'results/nutrition'
url = 'https://ftp.ncbi.nlm.nih.gov/geo/series/GSE131nnn/GSE131907/suppl/GSE131907_Lung_Cancer_Feature_Summary.xlsx'
p = O / 'GSE131907_Lung_Cancer_Feature_Summary.xlsx'
if not p.exists():
    urllib.request.urlretrieve(url, p)
n = {'s': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
with ZipFile(p) as z:
    strings = [''.join(t.itertext()) for t in E.fromstring(z.read('xl/sharedStrings.xml')).findall('s:si', n)]
    rows = []
    for row in E.fromstring(z.read('xl/worksheets/sheet1.xml')).findall('.//s:row', n):
        cells = {}
        for c in row.findall('s:c', n):
            v = c.find('s:v', n)
            if v is not None:
                cells[c.get('r').rstrip('0123456789')] = strings[int(v.text)] if c.get('t') == 's' else v.text
        if cells.get('B', '').startswith('P') and cells.get('C', '').startswith(('LUNG', 'EBUS', 'BRONCHO', 'EFFUSION', 'LN_', 'NS_')):
            rows.append(dict(patient=cells['B'], sample=cells['C'], site=cells.get('D'), histology=cells.get('E'), sex=cells.get('F'), age=cells.get('G'), smoking=cells.get('H'), pathology=cells.get('I'), EGFR=cells.get('J'), stage=cells.get('K'), author_n_cells=cells.get('L')))
with (O / 'kim_author_sample_metadata.csv').open('w') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0]))
    w.writeheader()
    w.writerows(rows)
(O / 'AUTHOR_METADATA_PROVENANCE.json').write_text(json.dumps({'url': url, 'path': str(p), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'n_samples': len(rows), 'parse': 'direct xlsx XML; retain cell coordinates to preserve blanks'}, indent=2))
print('Parsed', len(rows), 'samples')
