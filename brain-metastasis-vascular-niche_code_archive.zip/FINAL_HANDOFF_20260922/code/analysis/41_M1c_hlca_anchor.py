# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import numpy as np, pandas as pd, scanpy as sc, anndata as ad, time, scipy.sparse as sp, celltypist
D = str(_HANDOFF_ROOT / 'data/integrated')
O = str(_HANDOFF_ROOT / 'results/internal_programs_and_CNV')
L = open(f'{O}/progress_41.txt', 'a', buffering=1)
log = lambda *a: L.write(time.strftime('[%H:%M:%S] ') + ' '.join(map(str, a)) + '\n')
h = ad.read_h5ad(str(_HANDOFF_ROOT / 'data/external/reference/hlca.h5ad'), backed='r')
o = h.obs
keep_types = ['AT2', 'AT1', 'AT0', 'AT2 proliferating', 'Club (non-nasal)', 'Goblet (bronchial)', 'Goblet (subsegmental)', 'Basal resting', 'Suprabasal', 'Multiciliated (non-nasal)', 'pre-TB secretory', 'Neuroendocrine', 'Tuft', 'Ionocyte', 'SMG serous (bronchial)', 'SMG duct', 'SMG mucous', 'Hillock-like', 'Deuterosomal']
m = (o.disease == 'normal') & (o.ann_level_1 == 'Epithelial') & o.ann_finest_level.isin(keep_types)
rng = np.random.default_rng(0)
idx = []
for (t, sub) in o[m].groupby('ann_finest_level', observed=True):
    ii = np.where(o.index.isin(sub.index))[0]
    idx += list(rng.choice(ii, min(1500, len(ii)), replace=False))
idx = sorted(idx)
log('参考细胞', len(idx))
ref = h[idx].to_memory()
X = ref.raw.X if ref.raw is not None else ref.X
ref2 = ad.AnnData(X=X.copy(), obs=ref.obs[['ann_finest_level', 'ann_level_3', 'dataset']].copy(), var=pd.DataFrame(index=(ref.raw.var if ref.raw is not None else ref.var)['feature_name'].astype(str).values))
ref2.var_names_make_unique()
mx = ref2.X.max()
log('参考矩阵最大值', float(mx), '(整数counts则应>50)')
if mx < 50:
    log('警告: raw 不是 counts, 直接视为已归一化')
else:
    sc.pp.normalize_total(ref2, target_sum=10000.0)
    sc.pp.log1p(ref2)
model = celltypist.train(ref2, labels='ann_finest_level', n_jobs=16, feature_selection=True, top_genes=300, check_expression=False)
model.write(f'{O}/M1c_HLCA_normal_epithelium.pkl')
log('模型训练完成')
a = sc.read_h5ad(f'{D}/data/sc_counts.h5ad')
sc.pp.normalize_total(a, target_sum=10000.0)
sc.pp.log1p(a)
pc = pd.read_csv(f'{D}/output/per_cell_labels.csv', index_col=0)
a.obs['sub05'] = pc.sub05.reindex(a.obs_names).fillna(a.obs.atomic_cluster_id.astype(str))
a.obs['lineage'] = pc.lineage_l1.reindex(a.obs_names)
q = a[a.obs.lineage.isin(['上皮/肺腺癌', '上皮/神经内分泌'])].copy()
log('查询细胞', q.n_obs)
pr = celltypist.annotate(q, model=model, majority_voting=True, over_clustering='sub05')
res = pr.predicted_labels
res['conf'] = pr.probability_matrix.max(axis=1).values
res = res.join(q.obs[['patient_id', 'atomic_cluster_id', 'sub05', 'lineage']])
res.to_csv(f'{O}/M1c_hlca_anchor_per_cell.csv')
tab = res.groupby(['lineage', 'atomic_cluster_id', 'sub05'], observed=True).agg(n=('predicted_labels', 'size'), majority=('majority_voting', 'first'), mean_conf=('conf', 'mean'), top=('predicted_labels', lambda x: ';'.join((f'{k}:{v}' for (k, v) in x.value_counts().head(3).items()))))
tab.to_csv(f'{O}/M1c_hlca_anchor_by_subcluster.csv')
pt = res.groupby(['patient_id', 'predicted_labels'], observed=True).size().unstack(fill_value=0)
(pt.div(pt.sum(1), axis=0) * 100).round(1).to_csv(f'{O}/M1c_hlca_anchor_by_patient_pct.csv')
log('完成')
