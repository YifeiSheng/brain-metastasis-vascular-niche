# Current scientific analysis; package-relative paths.
handoff_arg <- grep("^--file=", commandArgs(), value=TRUE)
handoff_file <- sub("^--file=", "", handoff_arg[1])
HANDOFF_ROOT <- Sys.getenv("SAFEPOSTER_HANDOFF_ROOT", unset=normalizePath(file.path(dirname(handoff_file), "../.."), mustWork=TRUE))
suppressPackageStartupMessages({library(edgeR);library(limma);library(jsonlite)})
B <- file.path(HANDOFF_ROOT, "")
O <- file.path(B,"results/VEGF_sprouting_calibration")
mp <- read.csv(file.path(O,"gene_id_symbol_annotation.csv"),stringsAsFactors=FALSE)
gs <- fromJSON(file.path(B,"data/analysis_definitions/vascular_gene_sets.json"))
allpan <- c(gs$primary_panels,gs$sensitivity_panels)
for (acc in c("GSE227549","GSE196776")) {
 d <- file.path(O,acc)
 counts <- as.matrix(read.csv(gzfile(file.path(d,"counts_gene_id.csv.gz")),row.names=1,check.names=FALSE))
 sm <- read.csv(file.path(d,"selected_samples.csv"),stringsAsFactors=FALSE)
 stopifnot(identical(colnames(counts),sm$gsm),all(counts>=0),all(counts==round(counts)))
 group <- factor(sm$group,levels=c("Control","VEGF"))
 design <- model.matrix(~group)
 yall <- DGEList(counts=counts); keep <- filterByExpr(yall,design=design)
 y <- yall[keep,,keep.lib.sizes=FALSE]; y <- calcNormFactors(y,method="TMM")
 pdf(file.path(d,"voom_mean_variance.pdf"));v <- voom(y,design,plot=TRUE);dev.off()
 fit <- eBayes(lmFit(v,design),robust=TRUE)
 tab <- topTable(fit,coef="groupVEGF",number=Inf,sort.by="none",confint=TRUE)
 tab$gene_id <- rownames(tab);tab$symbol <- mp$symbol[match(tab$gene_id,mp$gene_id)]
 tab$mean_logCPM_Control <- rowMeans(v$E[,group=="Control",drop=FALSE])
 tab$mean_logCPM_VEGF <- rowMeans(v$E[,group=="VEGF",drop=FALSE])
 tab$study <- acc;tab <- tab[,c("study","gene_id","symbol",setdiff(names(tab),c("study","gene_id","symbol")))]
 write.csv(tab,gzfile(file.path(d,"all_gene_voom_limma.csv.gz")),row.names=FALSE)
 E <- data.frame(gene_id=rownames(v$E),symbol=mp$symbol[match(rownames(v$E),mp$gene_id)],v$E,check.names=FALSE)
 write.csv(E,gzfile(file.path(d,"voom_logCPM.csv.gz")),row.names=FALSE)
 univ <- data.frame(gene_id=rownames(counts),symbol=mp$symbol[match(rownames(counts),mp$gene_id)],expressed_filter=keep,rowSums(counts),check.names=FALSE)
 write.csv(univ,gzfile(file.path(d,"all_quantified_gene_universe.csv.gz")),row.names=FALSE)
 sm$TMM_factor <- y$samples$norm.factors;sm$filtered_library_size <- y$samples$lib.size
 write.csv(sm,file.path(d,"sample_normalization.csv"),row.names=FALSE)
 mark <- tab[!is.na(tab$symbol)&tab$symbol%in%unlist(allpan),]
 write.csv(mark,file.path(d,"prespecified_marker_DE.csv"),row.names=FALSE)
 write.csv(data.frame(input_genes=nrow(counts),tested_genes=nrow(tab),FDR_lt_05=sum(tab$adj.P.Val<0.05),n_Control=sum(group=="Control"),n_VEGF=sum(group=="VEGF")),file.path(d,"DE_summary.csv"),row.names=FALSE)
 cat(acc,nrow(tab),"tested; markers",nrow(mark),"\n")
}
capture.output(sessionInfo(),file=file.path(O,"R_sessionInfo.txt"))
