# Current scientific analysis; package-relative paths.
handoff_arg <- grep("^--file=", commandArgs(), value=TRUE)
handoff_file <- sub("^--file=", "", handoff_arg[1])
HANDOFF_ROOT <- Sys.getenv("SAFEPOSTER_HANDOFF_ROOT", unset=normalizePath(file.path(dirname(handoff_file), "../.."), mustWork=TRUE))
# L12 M7c: 肺腺癌 inferCNV 复核 —— 参考组改为 免疫 + 少突胶质 + 内皮 (多谱系参考抵消谱系表达程序), 观察组只放肺腺癌上皮簇
Sys.setenv(OPENBLAS_NUM_THREADS="4",OMP_NUM_THREADS="4",MKL_NUM_THREADS="4")
suppressPackageStartupMessages({library(infercnv); library(Seurat); library(Matrix)})
pat<-commandArgs(TRUE)[1]; nthread<-as.numeric(commandArgs(TRUE)[2]); if(is.na(nthread)) nthread<-12
ROOT<-file.path(HANDOFF_ROOT, "data/external/upstream_spatial"); D<-file.path(HANDOFF_ROOT, "data/integrated")
OUT<-file.path(file.path(HANDOFF_ROOT, "results/internal_programs_and_CNV/M7c_infercnv_multiref"),pat); dir.create(OUT,recursive=TRUE,showWarnings=FALSE)
PROG<-file.path(OUT,"progress.txt"); log<-function(...){con<-file(PROG,open="a");writeLines(paste0(format(Sys.time(),"[%H:%M:%S] "),paste0(...,collapse="")),con);close(con)}
options(error=function(){con<-file(PROG,open="a");writeLines(c("!!! ERROR",capture.output(traceback(3))),con);close(con);quit(status=1)})
GENE_ORDER<-file.path(HANDOFF_ROOT, "data/external/reference_code/PBMA/hg38_gencode_v27.txt")
PAT_SAMPLES<-list(P1=c("T1_BRM01","C1_BRM01"),P5=c("M_T","M_C"))
pc<-read.csv(file.path(D,"per_cell_labels.csv"),stringsAsFactors=FALSE)
pc<-pc[pc$patient_id==pat,]
set.seed(1)
imm<-pc$cell[pc$lineage_l1 %in% c("T/NK","髓系") & !pc$atomic_cluster_id %in% c("r4_061","r4_066","r4_068")]
oli<-pc$cell[pc$atomic_cluster_id %in% c("r4_016","r4_017","r4_040","r4_041","r4_059")]
endo<-pc$cell[pc$sub05 %in% c("r4_051.1")]
tum<-pc$cell[pc$lineage_l1=="上皮/肺腺癌"]
imm<-sample(imm,min(3000,length(imm))); oli<-sample(oli,min(1500,length(oli)))
anno<-c(setNames(rep("ref_immune",length(imm)),imm),setNames(rep("ref_oligodendrocyte",length(oli)),oli),setNames(rep("ref_endothelial",length(endo)),endo),setNames(rep("LUAD_epithelial",length(tum)),tum))
log(pat," 参考: 免疫 ",length(imm)," 少突 ",length(oli)," 内皮 ",length(endo)," | 观察 肺腺癌上皮 ",length(tum))
mats<-lapply(PAT_SAMPLES[[pat]],function(s){o<-readRDS(file.path(ROOT,"data/scRNA/seurat_preintegration_moderateQC",s,paste0(s,".report_seurat.pre_integration.rds"))); m<-GetAssayData(o,assay="RNA",layer="counts"); m[,intersect(colnames(m),names(anno)),drop=FALSE]})
genes<-Reduce(intersect,lapply(mats,rownames)); counts<-do.call(cbind,lapply(mats,function(m) m[genes,,drop=FALSE]))
anno<-anno[colnames(counts)]; log("counts ",nrow(counts)," x ",ncol(counts)); print(table(anno))
refs<-names(table(anno))[table(anno)>=50 & grepl("^ref_",names(table(anno)))]
afile<-file.path(OUT,"annotations.txt"); write.table(data.frame(anno),afile,row.names=TRUE,col.names=FALSE,quote=FALSE,sep="\t")
obj<-CreateInfercnvObject(raw_counts_matrix=counts,annotations_file=afile,delim="\t",gene_order_file=GENE_ORDER,ref_group_names=refs,max_cells_per_group=NULL,min_max_counts_per_cell=c(100,+Inf),chr_exclude=c("chrX","chrY","chrM"))
log("开始 inferCNV, 参考组: ",paste(refs,collapse=","))
obj<-infercnv::run(obj,cutoff=0.1,out_dir=file.path(OUT,"infercnv_out"),cluster_by_groups=TRUE,denoise=TRUE,HMM=TRUE,analysis_mode="subclusters",tumor_subcluster_partition_method="leiden",leiden_resolution=0.05,BayesMaxPNormal=0,output_format="png",num_threads=nthread)
# 逐细胞 CNV 分数 (denoised 表达偏离 1 的均方)
E<-obj@expr.data; cnv<-colMeans((E-1)^2); ref_idx<-unlist(obj@reference_grouped_cell_indices)
df<-data.frame(cell=colnames(E),cnv_score=cnv,group=anno[colnames(E)],stringsAsFactors=FALSE)
thr<-quantile(cnv[ref_idx],0.99); df$malignant<-df$cnv_score>thr & df$group=="LUAD_epithelial"
write.csv(df,file.path(OUT,"cnv_scores_multiref.csv"),row.names=FALSE)
log("完成: 阈值(参考99%)=",signif(thr,3)," 肺腺癌上皮判恶性比例=",round(mean(df$malignant[df$group=="LUAD_epithelial"]),3))
