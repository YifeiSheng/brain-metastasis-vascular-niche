# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os, glob, json, numpy as np, pandas as pd
from scipy.stats import mannwhitneyu, wilcoxon
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
font_manager.fontManager.addfont(str(_HANDOFF_ROOT / 'environment/NotoSansCJKsc-Regular.otf'))
plt.rcParams['font.family'] = ['Noto Sans CJK SC', 'DejaVu Sans']
B = str(_HANDOFF_ROOT / '')
R = f'{B}/results/immune_glial_lymphoma'
L13 = f'{B}/results/external_replication'
O = f'{R}/SUMMARY'
os.makedirs(O, exist_ok=True)
pd.set_option('display.width', 260)
pd.set_option('display.max_columns', 50)
pd.set_option('display.max_rows', 400)

def rd(p):
    return pd.read_csv(p) if os.path.exists(p) else None
CMAP_186344 = {'Lung': '肺癌', 'Breast': '乳腺癌', 'Melan': '黑色素瘤', 'Ovarian': '卵巢癌', 'Colorectal': '结直肠癌', 'Renal': '肾癌', 'Rhabdo': '横纹肌肉瘤', 'Unknown': '未知原发'}
frames = []
d2 = rd(f'{L13}/D2/D2_D3_signature_frequency_by_sample.csv')
if d2 is not None:
    x = d2[d2.dataset == 'GSE186344'].copy()
    x['cohort'] = 'Gonzalez2022_sc'
    x['platform'] = 'scRNA'
    x['site'] = '脑转移'
    x['patient'] = x['sample']
    x['cancer'] = x['sample'].map(lambda s: next((v for (k, v) in CMAP_186344.items() if s.startswith(k)), '其他'))
    x['group'] = '脑转移'
    frames.append(x)
d4 = rd(f'{L13}/D4/D4_signature_frequency_by_sample.csv')
if d4 is not None:
    x = d4.copy()
    x['dataset'] = 'GSE131907'
    x['cohort'] = 'Kim2020_sc'
    x['platform'] = 'scRNA'
    x['site'] = x.origin.map({'nLung': '正常肺', 'tLung': '肺原发', 'mBrain': '脑转移'})
    x['patient'] = x['sample']
    x['cancer'] = '肺腺癌'
    x['group'] = x['site']
    frames.append(x)
d8 = rd(f'{L13}/D8/D8_signature_frequency_by_sample.csv')
if d8 is not None:
    x = d8.copy()
    x['dataset'] = 'GSE223499'
    x['cohort'] = 'Izar2023_sn'
    x['platform'] = 'snRNA'
    x['site'] = x.site.map({'BM': '脑转移', 'PT': '肺原发'})
    x['cancer'] = '非小细胞肺癌'
    x['group'] = x['site']
    frames.append(x)
m2 = rd(f'{R}/M2_I2_SNRNA/M2_I2_signature_frequency_by_sample.csv')
if m2 is not None:
    x = m2.copy()
    x['patient'] = x['sample']
    x['group'] = x['site']
    frames.append(x)
l12 = rd(f'{R}/L1_L2_L4_LYMPHOMA/L1_L2_signature_frequency_by_sample.csv')
if l12 is not None:
    x = l12.copy()
    x['cohort'] = x.dataset.map({'GSE203552': 'Heming2022_sc', 'GSE181304': 'GSE181304_sc', 'GSE182434': 'Steen2021_sc', '内部sc': '内部_sc'}).fillna(x.dataset)
    x['site'] = x.group
    x['cancer'] = x.group
    frames.append(x)
cols = ['cohort', 'dataset', 'sample', 'patient', 'cancer', 'site', 'group', 'platform', 'signature', 'lineage', 'n_lineage_cells', 'n_positive', 'frac_of_lineage']
A = pd.concat([f.reindex(columns=cols) for f in frames], ignore_index=True)
A = A[A.n_lineage_cells >= 20]
A.to_csv(f'{O}/S1_all_signature_frequencies.csv', index=False)
print('=== 样本数 (按队列×组) ===')
print(A.groupby(['cohort', 'group'])['sample'].nunique().to_string())
MYE = ['边界相关巨噬 BAM(LYVE1/CD209/COLEC12/F13A1+)', '脂质相关肿瘤相关巨噬(SPP1+/GPNMB+/TREM2+/PLIN2+)', '活化小胶质(IL1B+/CCL3+/CCL4+/ATF3+)', '稳态小胶质(P2RY12+/CX3CR1+/SALL1+)', '干扰素巨噬(GBP4/5+/CXCL9/10+)', 'ADAMDEC1+ 巨噬(LGALS2/MMP9/IL4I1/CYP27A1+)', '经典单核细胞(FCN1+/S100A12+/SELL+/TREM1+)', '肥大细胞', '浆细胞样树突状细胞 pDC', '成熟调节型树突状细胞 mregDC', '经典 1 型树突状细胞 cDC1(marker 定义: CLEC9A 与 XCR1 共检出)', '经典 2 型树突状细胞 cDC2']
TC = ['活化调节性 T 细胞(FOXP3+/TNFRSF9+/LAYN+/IL2RA+)', 'CXCL13+ 耗竭样 CD8 T(TNFRSF9+/ENTPD1+/MIR155HG+)', 'CXCL13+ CD4 T(Tfh/Tph 样)', 'γδ 型/细胞毒 T 细胞(CD3+/TRGC2+/CD8A+ 活化)', '组织驻留 NK/ILC1 样(KLRB1+/ZNF683+/XCL2+)', 'NK 细胞(KLRC1+/KIR2DL4+ 干扰素反应型)']
BB = ['PRDM1+ 浆母样 B 细胞(PRDM1+/SELL+/CCR7+/IGLC6+)']

def summarize(sigs, name):
    sub = A[A.signature.isin(sigs)]
    g = sub.groupby(['signature', 'cohort', 'group', 'platform']).frac_of_lineage
    t = pd.DataFrame({'n': g.size(), 'median': g.median().round(4), 'q25': g.quantile(0.25).round(4), 'q75': g.quantile(0.75).round(4), 'frac_samples_ge5pct': g.apply(lambda v: round(float((v >= 0.05).mean()), 3)), 'frac_samples_ge2pct': g.apply(lambda v: round(float((v >= 0.02).mean()), 3))}).reset_index()
    t.to_csv(f'{O}/S2_{name}_by_cohort.csv', index=False)
    return t
tm = summarize(MYE, 'myeloid')
tt = summarize(TC, 'tcell')
tb = summarize(BB, 'bcell')
short = lambda s: s.split('(')[0].strip()

def strip_plot(sigs, name, title):
    sub = A[A.signature.isin(sigs)].copy()
    sub['sig'] = sub.signature.map(short)
    sub['cg'] = sub.cohort + '|' + sub.group
    order = sorted(sub.cg.unique(), key=lambda s: ('PCNSL' in s or '淋巴' in s or '扁桃' in s, '原发' in s or '正常' in s, s))
    (fig, axes) = plt.subplots(len(sigs), 1, figsize=(max(10, 0.45 * len(order)), 2.2 * len(sigs)), sharex=True)
    for (ax, sg) in zip(np.atleast_1d(axes), sigs):
        d = sub[sub.signature == sg]
        for (i, cg) in enumerate(order):
            v = d[d.cg == cg].frac_of_lineage.values
            if len(v):
                ax.scatter(np.random.normal(i, 0.08, len(v)), v, s=10, alpha=0.7, c=['#d62728' if p == 'snRNA' else '#1f77b4' for p in d[d.cg == cg].platform])
                ax.hlines(np.median(v), i - 0.3, i + 0.3, color='k', lw=1.5)
        ax.set_ylabel(short(sg)[:18], fontsize=8)
        ax.set_ylim(-0.02, min(1.02, max(0.3, d.frac_of_lineage.quantile(0.98) * 1.2 if len(d) else 0.3)))
    np.atleast_1d(axes)[-1].set_xticks(range(len(order)))
    np.atleast_1d(axes)[-1].set_xticklabels(order, rotation=90, fontsize=7)
    fig.suptitle(title + '（蓝=scRNA 红=snRNA，黑线=中位数）', fontsize=10)
    fig.savefig(f'{O}/S2_{name}_strip.png', dpi=110, bbox_inches='tight')
    plt.close(fig)
strip_plot(MYE[:8], 'myeloid', '髓系状态占髓系细胞比例，按队列')
strip_plot(TC[:5], 'tcell', 'T 细胞状态占 T/NK 比例，按队列')
strip_plot(MYE[7:12], 'dc_mast', '肥大细胞与树突状细胞占髓系比例，按队列')
out = []

def cmp(sigs, a_mask, b_mask, label):
    for sg in sigs:
        x = A[(A.signature == sg) & a_mask].frac_of_lineage
        y = A[(A.signature == sg) & b_mask].frac_of_lineage
        out.append(dict(contrast=label, signature=short(sg), n_a=len(x), n_b=len(y), median_a=round(x.median(), 4) if len(x) else np.nan, median_b=round(y.median(), 4) if len(y) else np.nan, mwu_p=mannwhitneyu(x, y).pvalue if len(x) >= 3 and len(y) >= 3 else np.nan))
cmp(MYE + TC, (A.cohort == 'Biermann2022_sn') & (A.group == '脑转移'), (A.cohort == 'Biermann2022_sn') & (A.group == '颅外转移'), 'Biermann 黑色素瘤 脑内 vs 颅外 (snRNA)')
cmp(MYE + TC, (A.cohort == 'Izar2023_sn') & (A.group == '脑转移'), (A.cohort == 'Izar2023_sn') & (A.group == '肺原发'), 'Izar 非小细胞肺癌 脑转移 vs 肺原发 (snRNA)')
cmp(MYE + TC, (A.cohort == 'Kim2020_sc') & (A.group == '脑转移'), (A.cohort == 'Kim2020_sc') & (A.group == '肺原发'), 'Kim 肺腺癌 脑转移 vs 肺原发 (scRNA)')
sc_bm = (A.platform == 'scRNA') & (A.group == '脑转移')
sc_pc = (A.platform == 'scRNA') & A.group.isin(['PCNSL(内部)', 'PCNSL(外部)'])
sc_nd = (A.platform == 'scRNA') & (A.group == '结内DLBCL')
cmp(MYE + TC + BB, sc_pc, sc_bm, 'PCNSL (内部+外部) vs 脑转移 (scRNA 队列)')
cmp(MYE + TC + BB, sc_pc, sc_nd, 'PCNSL (内部+外部) vs 结内 DLBCL (scRNA)')
sn_lung = (A.platform == 'snRNA') & (A.group == '脑转移') & A.cancer.str.contains('肺', na=False)
sn_other = (A.platform == 'snRNA') & (A.group == '脑转移') & ~A.cancer.str.contains('肺|未注明', na=False)
cmp(MYE + TC, sn_lung, sn_other, 'snRNA 脑转移: 肺癌来源 vs 其他癌种')
pd.DataFrame(out).to_csv(f'{O}/S3_key_contrasts.csv', index=False)
print('\n=== 关键对比 ===')
print(pd.DataFrame(out).to_string(index=False))
V = f'{R}/M3_I3_L3_VISIUM'
VY = f'{R}/M3_I3_L3_VISIUM_YANG'
arch = pd.concat([x for x in [rd(f'{V}/I3_archetype_30slides.csv'), rd(f'{VY}/I3_archetype_30slides.csv')] if x is not None], ignore_index=True)
pairs = pd.concat([x for x in [rd(f'{V}/M3_I3_L3_cooccurrence.csv'), rd(f'{VY}/M3_I3_L3_cooccurrence.csv')] if x is not None], ignore_index=True)
ves = pd.concat([x for x in [rd(f'{V}/L3_vessel_coverage_by_slide.csv'), rd(f'{VY}/L3_vessel_coverage_by_slide.csv')] if x is not None], ignore_index=True)
band = pd.concat([x for x in [rd(f'{V}/M3_interface_by_slide.csv'), rd(f'{VY}/M3_interface_by_slide.csv')] if x is not None], ignore_index=True)
if len(arch):
    arch['group2'] = np.where(arch.cancer.str.contains('淋巴瘤'), 'PCNSL', np.where(arch.cancer.str.contains('原发'), '泛癌原发(Yang)', '脑转移'))
    print('\n=== 原型分布 (Visium) ===')
    print(pd.crosstab([arch.group2, arch.cancer], arch.archetype).to_string())
    print('\nCXCL13≥8% 且 MS4A1<5% (CXCL13 无 TLS):')
    print(pd.crosstab(arch.group2, arch.CXCL13_without_TLS).to_string())
    print('TLS 样:')
    print(pd.crosstab(arch.group2, arch.TLS_like).to_string())
    arch.to_csv(f'{O}/S4_visium_archetypes_all.csv', index=False)
if len(pairs):
    pairs['group2'] = np.where(pairs.cancer.str.contains('淋巴瘤'), 'PCNSL', np.where(pairs.cancer.str.contains('原发'), '泛癌原发(Yang)', '脑转移'))
    pairs.to_csv(f'{O}/S5_visium_cooccurrence_all.csv', index=False)
    hb = band.set_index('slide')['n_brain'] if len(band) else None
    ok = pairs.z.notna()
    t = pairs[ok].copy()
    t['sig'] = t.z > 2
    if hb is not None:
        t['has_brain'] = t.slide.map(hb).fillna(0) >= 20
    s = t.groupby(['group2', 'pair']).agg(n=('sig', 'size'), n_z_gt2=('sig', 'sum'), median_ratio=('obs_over_null', 'median')).reset_index()
    s.to_csv(f'{O}/S5_cooccurrence_summary.csv', index=False)
    print('\n=== 高阈值共检出 z>2 的切片数 (按组) ===')
    print(s.to_string(index=False))
    if hb is not None:
        s2 = t[t.has_brain].groupby(['group2', 'pair']).agg(n=('sig', 'size'), n_z_gt2=('sig', 'sum')).reset_index()
        print('\n--- 仅含脑带(≥20 spot)的切片 ---')
        print(s2[s2.pair.str.contains('GFAP|P2RY12|IL1B')].to_string(index=False))
if len(band):
    band['group2'] = np.where(band.cancer.str.contains('淋巴瘤'), 'PCNSL', np.where(band.cancer.str.contains('原发'), '泛癌原发(Yang)', '脑转移'))
    band.to_csv(f'{O}/S6_visium_interface_all.csv', index=False)
    kb = band[(band.n_interface >= 20) & (band.n_tumor >= 20)]
    print('\n=== 界面带 vs 肿瘤带 签名阳性率 (有界面带切片) ===')
    for c in ['反应性星形胶质', '活化小胶质', '星形胶质']:
        if f'{c}_pos_interface' in kb:
            d = kb[[f'{c}_pos_interface', f'{c}_pos_tumor', 'group2']].dropna()
            for (g, dd) in d.groupby('group2'):
                p = wilcoxon(dd[f'{c}_pos_interface'], dd[f'{c}_pos_tumor']).pvalue if len(dd) >= 5 else np.nan
                print(f"{c} {g}: n={len(dd)} 界面中位 {dd[f'{c}_pos_interface'].median():.3f} vs 肿瘤 {dd[f'{c}_pos_tumor'].median():.3f} wilcoxon p={p}")
if len(ves):
    ves['group2'] = np.where(ves.cancer.str.contains('淋巴瘤'), 'PCNSL', np.where(ves.cancer.str.contains('原发'), '泛癌原发(Yang)', '脑转移'))
    ves.to_csv(f'{O}/S7_vessel_coverage_all.csv', index=False)
    keys = [c for c in ['all_vessel_frac', 'all_vessel_strict_frac', 'all_cov_mural', 'all_cov_NOTCH3', 'all_cov_RGS5', 'all_cov_Tperi', 'all_cov_SMC', 'all_bg_mural_nonvessel', 'all_cov_mural_hidepth', 'all_cov_mural_strict', 'tumor_vessel_frac', 'tumor_cov_mural', 'tumor_cov_NOTCH3', 'tumor_cov_Tperi', 'brain_cov_mural', 'median_umi'] if c in ves]
    print('\n=== 血管存在 vs 壁细胞覆盖 (按组中位) ===')
    print(ves.groupby('group2')[keys].median().round(3).T.to_string())
    rows = []
    for c in keys:
        x = ves[ves.group2 == '脑转移'][c].dropna()
        y = ves[ves.group2 == 'PCNSL'][c].dropna()
        rows.append(dict(metric=c, BrM_median=round(x.median(), 4) if len(x) else np.nan, BrM_n=len(x), PCNSL_median=round(y.median(), 4) if len(y) else np.nan, PCNSL_n=len(y), mwu_p=mannwhitneyu(x, y).pvalue if len(x) >= 3 and len(y) >= 3 else np.nan))
    pd.DataFrame(rows).to_csv(f'{O}/S7_vessel_BrM_vs_PCNSL.csv', index=False)
    print(pd.DataFrame(rows).to_string(index=False))
    y = ves[ves.dataset == 'Yang2026_ST'].copy()
    if len(y):
        y['pt'] = y.slide.str.replace('Yang2026_', '').str.replace('.update', '', regex=False).str.replace('.Primary', '', regex=False).str.replace('T$', '', regex=True).str.replace('^X', '', regex=True)
        y['kind'] = np.where(y.cancer.str.contains('原发'), '原发', '脑转移')
        w = y.pivot_table(index='pt', columns='kind', values=['all_cov_mural', 'all_cov_NOTCH3', 'all_vessel_frac', 'all_cov_Tperi'], aggfunc='first')
        w.to_csv(f'{O}/S7_yang_paired_primary_vs_brm.csv')
        print('\n=== Yang 2026 同病人 原发 vs 脑转移 ===')
        print(w.round(3).to_string())
print('\n完成')
