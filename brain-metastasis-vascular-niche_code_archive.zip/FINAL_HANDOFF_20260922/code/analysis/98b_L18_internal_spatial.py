# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
"""L18 internal vascular evidence: separate state programs, donor/tissue summaries, mixed spatial associations.
Read-only original data. A state score is not sprouting, permeability, or perfusion.
"""
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os
for key in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS']:
    os.environ[key] = '2'
from pathlib import Path
import json, hashlib, itertools, platform
import numpy as np, pandas as pd, anndata as ad, scanpy as sc, statsmodels.api as sm
from scipy.spatial import cKDTree
from scipy.stats import rankdata, t as tdist
from statsmodels.stats.multitest import multipletests
from threadpoolctl import threadpool_limits
threadpool_limits(2)
B = Path(str(_HANDOFF_ROOT / ''))
O = B / 'results/internal_VEGFA_spatial'
O.mkdir(parents=True, exist_ok=True)
CFG = B / 'data/analysis_definitions/vascular_gene_sets.json'
config = json.load(open(CFG))
sets = config['primary_panels']
assert isinstance(sets, dict)
sets = {k: v['genes'] if isinstance(v, dict) else v for (k, v) in sets.items()}
assert len(sets) == 6, sets
primary_modules = list(sets)
tip = [k for k in sets if 'tip' in k.lower()][0]
sets.update(config['sensitivity_panels'])
CORE = config['EC_content_controls']
LIG = ['VEGFA', 'PGF', 'FGF2', 'PDGFB', 'ANGPT1', 'ANGPT2', 'TGFB1']
REC = ['KDR', 'FLT1', 'FLT4', 'PDGFRB', 'TEK', 'FGFR1']
CONTROLS = {'EC_content': CORE, 'myeloid': ['LYZ', 'AIF1', 'LST1', 'CSF1R', 'CD68'], 'brain': ['GFAP', 'AQP4', 'PLP1', 'MBP', 'MOBP', 'SNAP25'], 'LUAD': ['EPCAM', 'KRT8', 'KRT18', 'KRT7', 'NAPSA', 'SFTPB'], 'PCNSL': ['MS4A1', 'CD79A', 'CD79B', 'CD19', 'PAX5'], 'hypoxia': ['CA9', 'EGLN3', 'BNIP3', 'BNIP3L', 'NDRG1', 'PDK1', 'ADM', 'ANGPTL4']}
assert not set(CORE) & set(sum([sets[k] for k in primary_modules], []))
assert not {'VEGFA', 'PGF', 'FGF2'} & set(sum(sets.values(), []))
allgenes = list(dict.fromkeys(sum(sets.values(), []) + sum(CONTROLS.values(), []) + LIG + REC))
coverage = []
inputs = [CFG, B / 'data/integrated/final_integrated_annotated.h5ad', B / 'data/integrated/per_cell_labels.csv']
a = ad.read_h5ad(inputs[1])
pc = pd.read_csv(inputs[2], index_col='cell').reindex(a.obs_names)
assert pc.patient_id.notna().all() and (not a.var_names.duplicated().any())
raw = a.X.tocsr()
total = np.asarray(raw.sum(1)).ravel()
gs = [g for g in allgenes if g in a.var_names]
C = pd.DataFrame(raw[:, a.var_names.get_indexer(gs)].toarray(), index=a.obs_names, columns=gs)
E = np.log1p(C.div(np.maximum(total, 1), axis=0) * 10000.0)
states = pc.copy()
states['total_UMI'] = total
for (k, gg) in sets.items():
    avail = [g for g in gg if g in E]
    coverage.append(dict(dataset='internal_sc', module=k, n_expected=len(gg), n_available=len(avail), available=';'.join(avail), missing=';'.join((g for g in gg if g not in avail))))
    states[k] = E[avail].mean(1) if avail else np.nan
    states[k + '_ndet'] = (C[avail] > 0).sum(1) if avail else np.nan
states['EC_core_ndet'] = (C[[g for g in CORE if g in C]] > 0).sum(1)
states['strict_EC'] = (states.lineage_l1 == '内皮') & (states.EC_core_ndet >= 2) & ((C[['EPCAM', 'KRT8', 'KRT18']] > 0).sum(1) < 2) & ((C[['LYZ', 'AIF1', 'LST1']] > 0).sum(1) < 2)
ecrows = []
genesrows = []
for gate in ['atlas', 'strict']:
    sel = states.lineage_l1.eq('内皮') if gate == 'atlas' else states.strict_EC
    for ((pat, sample, role), idx) in states[sel].groupby(['patient_id', 'sample', 'tissue_role'], observed=True).groups.items():
        idx = list(idx)
        n = len(idx)
        for k in sets:
            ecrows.append(dict(gate=gate, patient=pat, sample=sample, tissue_role=role, n_EC=n, module=k, mean_logCP10k=states.loc[idx, k].mean(), median_logCP10k=states.loc[idx, k].median(), fraction_at_least2_genes=(states.loc[idx, k + '_ndet'] >= 2).mean()))
        for g in list(dict.fromkeys(sum(sets.values(), []) + REC)):
            if g in C:
                genesrows.append(dict(gate=gate, patient=pat, sample=sample, tissue_role=role, n_EC=n, gene=g, fraction_detected=(C.loc[idx, g] > 0).mean(), mean_logCP10k=E.loc[idx, g].mean(), captured_UMI=C.loc[idx, g].sum()))
pd.DataFrame(ecrows).to_csv(O / 'internal_EC_sample_modules.csv', index=False)
pd.DataFrame(genesrows).to_csv(O / 'internal_EC_sample_genes.csv', index=False)
states[states.lineage_l1.eq('内皮')].to_csv(O / 'internal_EC_cell_states.csv.gz', compression='gzip')
source = []
specific = []
for ((pat, role), idx) in states.groupby(['patient_id', 'tissue_role'], observed=True).groups.items():
    idx = list(idx)
    for (lin, ix) in states.loc[idx].groupby('lineage_l1', observed=True).groups.items():
        ix = list(ix)
        for g in LIG:
            den = C.loc[idx, g].sum()
            source.append(dict(patient=pat, tissue_role=role, lineage=lin, n_cells=len(ix), gene=g, mean_logCP10k=E.loc[ix, g].mean(), fraction_detected=(C.loc[ix, g] > 0).mean(), captured_UMI=C.loc[ix, g].sum(), captured_transcript_share=C.loc[ix, g].sum() / den if den else np.nan, total_UMI=states.loc[ix, 'total_UMI'].sum()))
        for (k, gg) in sets.items():
            avail = [g for g in gg if g in C]
            den = C.loc[idx, avail].sum().sum()
            specific.append(dict(patient=pat, tissue_role=role, lineage=lin, n_cells=len(ix), module=k, mean_logCP10k=states.loc[ix, k].mean(), captured_module_UMI=C.loc[ix, avail].sum().sum(), captured_module_share=C.loc[ix, avail].sum().sum() / den if den else np.nan))
pd.DataFrame(source).to_csv(O / 'internal_ligand_sources_by_tissue.csv', index=False)
pd.DataFrame(specific).to_csv(O / 'internal_module_celltype_specificity.csv', index=False)
states.groupby(['patient_id', 'sample', 'tissue_role', 'lineage_l1'], observed=True).size().rename('n_cells').reset_index().to_csv(O / 'internal_sample_manifest.csv', index=False)
del raw, a, C, E, states
ST = Path(str(_HANDOFF_ROOT / 'data/spatial'))
slides = {'S1_T': ('batch_10562_2022_05_30', 'P1', 'LUAD'), 'S2_C': ('batch_10562_2022_05_30', 'P5', 'LUAD'), 'Toct6': ('batch_10562_2022_05_30', 'P8', 'LUAD'), 'Coct6': ('batch_10562_2022_05_30', 'P8', 'LUAD'), 'Toct4': ('batch_15551_2022_03_28', 'P6', 'PCNSL'), 'Coct4': ('batch_15551_2022_03_28', 'P6', 'PCNSL'), 'Toct5': ('batch_15551_2022_03_28', 'P2', 'PCNSL'), 'Coct5': ('batch_15551_2022_03_28', 'P2', 'PCNSL')}
models = []
qc = []
variants = [('primary', 0.75, False, 'mean'), ('ECq50', 0.5, False, 'mean'), ('ECq90', 0.9, False, 'mean'), ('hypoxia_adjusted', 0.75, True, 'mean'), ('EC_ratio', 0.75, False, 'ratio')]
for (slide, (batch, pat, disease)) in slides.items():
    root = ST / batch / '1.SpaceRanger' / slide
    countpath = root / 'filtered_feature_bc_matrix.h5'
    inputs.append(countpath)
    a = sc.read_10x_h5(str(countpath))
    a.var_names_make_unique()
    pf = root / 'spatial/tissue_positions_list.csv'
    if pf.exists():
        pos = pd.read_csv(pf, header=None, names=['barcode', 'in_tissue', 'array_row', 'array_col', 'y', 'x']).set_index('barcode')
    else:
        pf = root / 'spatial/tissue_positions.csv'
        pos = pd.read_csv(pf).set_index('barcode').rename(columns={'pxl_row_in_fullres': 'y', 'pxl_col_in_fullres': 'x'})
    pos = pos.reindex(a.obs_names)
    keep = pos.in_tissue.eq(1).values
    a = a[keep].copy()
    pos = pos[keep]
    sfpath = root / 'spatial/scalefactors_json.json'
    sf = json.load(open(sfpath))
    inputs.extend([pf, sfpath])
    xy = pos[['x', 'y']].values * (55 / sf['spot_diameter_fullres'])
    X = a.X.tocsr()
    tot = np.asarray(X.sum(1)).ravel()
    gg = [g for g in allgenes if g in a.var_names]
    c = pd.DataFrame(X[:, a.var_names.get_indexer(gg)].toarray(), index=a.obs_names, columns=gg)
    normalized = c.div(np.maximum(tot, 1), axis=0) * 10000.0
    ex = np.log1p(normalized)
    d = pd.DataFrame(index=a.obs_names)
    for (k, gg) in {**sets, **CONTROLS}.items():
        avail = [g for g in gg if g in ex]
        coverage.append(dict(dataset=slide, module=k, n_expected=len(gg), n_available=len(avail), available=';'.join(avail), missing=';'.join((g for g in gg if g not in avail))))
        d[k] = ex[avail].mean(1) if avail else np.nan
        if k in sets:
            d[k + '_ratio'] = np.log1p(normalized[avail].mean(1)) - np.log1p(normalized[[g for g in CORE if g in ex]].mean(1)) if avail else np.nan
    for g in ['VEGFA', 'PGF', 'FGF2']:
        d[g] = ex[g] if g in ex else np.nan
    d['log_depth'] = np.log1p(tot)
    d['tumor_score'] = d[disease]
    d['slide'] = slide
    d['patient'] = pat
    d['disease'] = disease
    d['x_um'] = xy[:, 0]
    d['y_um'] = xy[:, 1]
    d['block'] = (xy[:, 0] // 500).astype(int).astype(str) + np.char.add('_', (xy[:, 1] // 500).astype(int).astype(str))
    nb = cKDTree(xy).query(xy, k=7)[1][:, 1:]
    for lig in ['VEGFA', 'PGF', 'FGF2']:
        d[lig + '_neighbor'] = d[lig].values[nb].mean(1)
    for (name, q, hyp, outform) in variants:
        selected = (d.EC_content > 0) & (d.EC_content >= d.EC_content.quantile(q)) & (tot >= 100)
        for module in sets:
            if module not in primary_modules and name != 'primary':
                continue
            outcome = module if outform == 'mean' else module + '_ratio'
            ctrls = ['log_depth', 'EC_content', 'tumor_score', 'myeloid', 'brain'] + (['hypoxia'] if hyp else [])
            for lig in ['VEGFA', 'PGF', 'FGF2']:
                cols = [lig + '_neighbor', outcome] + ctrls
                z = d.loc[selected, cols + ['block']].replace([np.inf, -np.inf], np.nan).dropna()
                row = dict(slide=slide, patient=pat, disease=disease, variant=name, EC_quantile=q, module=module, outcome_form=outform, ligand=lig, n_spots=len(z), n_blocks=z.block.nunique())
                if len(z) < 50 or z.block.nunique() < 8 or any((z[col].nunique() < 2 for col in cols[:2])):
                    row.update(status='insufficient_or_constant', partial_r=np.nan, p=np.nan)
                    models.append(row)
                    continue
                ranked = z[cols].apply(rankdata)
                block = pd.get_dummies(z.block, drop_first=True, dtype=float).reset_index(drop=True)
                design = sm.add_constant(pd.concat([ranked[ctrls].reset_index(drop=True), block], axis=1)).values
                rx = ranked.iloc[:, 0].values - design @ np.linalg.lstsq(design, ranked.iloc[:, 0].values, rcond=None)[0]
                ry = ranked.iloc[:, 1].values - design @ np.linalg.lstsq(design, ranked.iloc[:, 1].values, rcond=None)[0]
                if rx.std() < 1e-08 or ry.std() < 1e-08:
                    row.update(status='zero_residual_variance', partial_r=np.nan, p=np.nan)
                    models.append(row)
                    continue
                rx = (rx - rx.mean()) / rx.std()
                ry = (ry - ry.mean()) / ry.std()
                fit = sm.OLS(ry, sm.add_constant(rx)).fit(cov_type='cluster', cov_kwds={'groups': z.block.values, 'use_correction': True}, use_t=True)
                designrank = int(np.linalg.matrix_rank(design))
                se = float(fit.bse[1]) * np.sqrt((len(z) - 2) / (len(z) - designrank - 1))
                pv = float(2 * tdist.sf(abs(fit.params[1] / se), z.block.nunique() - 1))
                width = float(tdist.ppf(0.975, z.block.nunique() - 1) * se)
                (lo, hi) = (fit.params[1] - width, fit.params[1] + width)
                row.update(status='ok', partial_r=float(fit.params[1]), ci_low=float(lo), ci_high=float(hi), p=pv, nuisance_rank=int(np.linalg.matrix_rank(design)), residual_df=int(len(z) - np.linalg.matrix_rank(design) - 1))
                models.append(row)
        qc.append(dict(slide=slide, patient=pat, disease=disease, variant=name, n_tissue_spots=len(d), n_selected=int(selected.sum()), fraction_selected=float(selected.mean()), n_EC_positive=int((d.EC_content > 0).sum()), EC_content_cutoff=d.EC_content.quantile(q), n_blocks=d.loc[selected, 'block'].nunique(), median_depth=float(np.median(tot)), median_nearest_neighbor_um=float(np.median(cKDTree(xy).query(xy, k=2)[0][:, 1])), identity_note='spatial-only ID; cross-modality match unconfirmed' if pat == 'P8' else 'mapping inferred; use as within-spatial donor ID' if pat == 'P2' else 'project donor ID'))
    d.to_csv(O / f'visium_spot_states_{slide}.csv.gz', compression='gzip')
    print('COMPLETE SLIDE', slide, len(d), flush=True)
r = pd.DataFrame(models)
valid = r.p.notna() & np.isfinite(r.p)
r.loc[valid, 'q_BH_all_models'] = multipletests(r.loc[valid, 'p'], method='fdr_bh')[1]
primary = (r.variant == 'primary') & r.module.isin(primary_modules) & r.ligand.eq('VEGFA') & valid
r.loc[primary, 'q_BH_primary_48'] = multipletests(r.loc[primary, 'p'], method='fdr_bh')[1]
r.to_csv(O / 'visium_ligand_neighborhood_associations.csv', index=False)
pd.DataFrame(qc).to_csv(O / 'visium_sample_QC.csv', index=False)
pd.DataFrame(coverage).to_csv(O / 'module_coverage.csv', index=False)
don = r[r.status == 'ok'].groupby(['disease', 'patient', 'variant', 'module', 'ligand'], observed=True).agg(partial_r=('partial_r', 'median'), n_sections=('slide', 'nunique'), n_spots=('n_spots', 'sum')).reset_index()
don.to_csv(O / 'visium_donor_aggregate_effects.csv', index=False)
tests = []
for (keys, z) in don.groupby(['disease', 'variant', 'module', 'ligand'], observed=True):
    vals = z.partial_r.values
    vals = vals[np.isfinite(vals)]
    n = len(vals)
    if n < 2:
        continue
    observed = abs(np.mean(vals))
    null = np.abs(np.asarray(list(itertools.product([-1, 1], repeat=n))) @ vals / n)
    p = float(np.mean(null >= observed - 1e-12))
    tests.append(dict(zip(['disease', 'variant', 'module', 'ligand'], keys), n_donors=n, mean_effect=float(np.mean(vals)), median_effect=float(np.median(vals)), positive_donors=int((vals > 0).sum()), negative_donors=int((vals < 0).sum()), p_exact_signflip=p))
t = pd.DataFrame(tests)
t['q_BH_all_donor_tests'] = multipletests(t.p_exact_signflip, method='fdr_bh')[1]
primary = t.variant.eq('primary') & t.module.isin(primary_modules) & t.ligand.eq('VEGFA')
t.loc[primary, 'q_BH_primary_12'] = multipletests(t.loc[primary, 'p_exact_signflip'], method='fdr_bh')[1]
t.to_csv(O / 'visium_donor_tests.csv', index=False)

def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for c in iter(lambda : f.read(1024 * 1024), b''):
            h.update(c)
    return h.hexdigest()
json.dump({'definition': 'six-state frozen modules, exploratory mean log1p(CP10k); not validated functional assays', 'primary_modules': primary_modules, 'tip_core_sensitivity': sets['tip_core'], 'ligands_primary': ['VEGFA'], 'ligands_exploratory': ['PGF', 'FGF2'], 'EC_content_genes': CORE, 'spatial': 'six nearest neighbors excluding self; tissue spot diameter 55um used for coordinate calibration; positive PECAM1/VWF/ERG score AND EC score>=whole-slidequantile+UMI>=100; positivity prevents zero-score quantile ties admitting every spot; rank covariate residualization including 500um block fixed effects; block clustered t SE', 'primary_controls': ['depth', 'EC_content', 'tumor', 'myeloid', 'brain', '500um block FE'], 'primary_family': 48, 'donor_analysis': 'median of each donor sections, exact two-sided signflip of equal-donor mean assuming symmetric effects; LUAD3donors,PCNSL2donors; no cell/spot pseudoreplication', 'cautions': ['Mixed spots cannot assign ligands or outcomes to a cell type', 'EC-ratio difference-of-log meanCP10k is a sensitivity proxy, not per-EC gene expression', 'Transcript state cannot identify perfused vessels, new sprouts, co-option or permeability', 'adjacent_or_field is not a healthy brain control', 'P8 cross-modality identity unconfirmed; P2 spatial mapping inferred']}, open(O / 'METHODS.json', 'w'), indent=2)
json.dump({'script': str(Path(__file__)), 'script_sha256': sha(Path(__file__)), 'input_files': [{'path': str(p), 'sha256': sha(p), 'size': p.stat().st_size} for p in dict.fromkeys(inputs)], 'gene_set_sha256': sha(CFG), 'python': platform.python_version()}, open(O / 'PROVENANCE.json', 'w'), indent=2)
print(t[primary].to_string(index=False), flush=True)
print('COMPLETE ANALYSIS', flush=True)
