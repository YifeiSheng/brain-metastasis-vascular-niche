# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
"""L17 pericyte state and tumor mimicry evidence; all outputs on server.
No fresh UMAP, no inferred developmental direction. Author labels retained in Kim;
Walchli cells operationally marker gated because no author metadata available locally."""
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os
for k in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS']:
    os.environ[k] = '2'
from pathlib import Path
import numpy as np, pandas as pd, scipy.io, scipy.sparse as sp, scanpy as sc
import warnings
warnings.filterwarnings('ignore', category=pd.errors.PerformanceWarning)
import json, re, hashlib, datetime, itertools, math
from scipy.stats import rankdata, spearmanr
from statsmodels.stats.multitest import multipletests
B = Path(str(_HANDOFF_ROOT / ''))
O = B / 'results/pericyte_differentiation'
O.mkdir(exist_ok=True, parents=True)
SETS = {'identity': ['PDGFRB', 'RGS5', 'CSPG4', 'KCNJ8', 'ABCC9', 'HIGD1B', 'NDUFA4L2', 'NOTCH3'], 'capillary': ['KCNJ8', 'ABCC9', 'HIGD1B'], 'T_transport': ['SLC6A1', 'SLC1A3', 'SLC12A7', 'SLC20A2'], 'M_matrix': ['COL4A1', 'COL4A2', 'COL4A3', 'COL4A4', 'ADAMTS1', 'LAMA4'], 'contractile': ['ACTA2', 'MYH11', 'TAGLN', 'CNN1', 'LMOD1', 'MYL9'], 'fibro': ['DCN', 'LUM', 'COL1A1', 'COL1A2', 'FBLN1', 'PDGFRA'], 'endothelial': ['PECAM1', 'VWF', 'CLDN5', 'CDH5', 'KDR'], 'astro': ['GFAP', 'AQP4', 'SLC1A2', 'ALDH1L1'], 'epithelial': ['EPCAM', 'KRT8', 'KRT18', 'KRT19'], 'immune': ['PTPRC', 'LST1', 'TYROBP', 'CD3D', 'CD79A'], 'hypoxia': ['CA9', 'EGLN3', 'BNIP3', 'BNIP3L', 'NDRG1', 'PDK1', 'ADM', 'ANGPTL4'], 'remodeling': ['SERPINE1', 'CCN2', 'CCN1', 'TGFBI', 'FN1', 'SERPINH1', 'S100A4'], 'AP1_MAPK_response': ['JUN', 'JUNB', 'FOS', 'FOSB', 'EGR1', 'DUSP1', 'DUSP5', 'DUSP6'], 'cycling': ['MKI67', 'TOP2A', 'UBE2C', 'CCNB1', 'CDK1', 'PCNA'], 'stemness_literature': ['CD44', 'ABCG2'], 'mimicry_literature': ['MCAM', 'PDGFRB', 'CSPG4']}
EXTRA = ['AXL', 'GAS6', 'VEGFA', 'PDGFB', 'PDGFD', 'PDGFRA', 'IGF2', 'IGF1R', 'INSR', 'IGF1', 'ANGPT1', 'ANGPT2', 'TEK', 'TGFB1', 'TGFBR1', 'TGFBR2', 'ADGRA2', 'SOX2', 'SOX9', 'PROM1', 'ALDH1A1', 'ANPEP', 'DES', 'STAT3', 'KDR', 'FLT1']
need = list(dict.fromkeys(sum(SETS.values(), []) + EXTRA))
json.dump({'gene_sets': SETS, 'individual_genes': EXTRA, 'primary_gate': 'identity >=3; capillary >=1; EC, epithelial, astro and immune marker detection each <2', 'scores': 'mean log1p(CP10k), not pathway activity or flux', 'T_support': 'at least 2 of 4 markers', 'M_support': 'at least 2 of 6 markers'}, open(O / 'gene_sets.json', 'w'), indent=2)
inputs = []

def states(x, genes, obs):
    x = x.tocsr()
    tot = np.asarray(x.sum(axis=1)).ravel()
    gi = {}
    genevals = {}
    for (j, g) in enumerate(genes):
        gi.setdefault(str(g), []).append(j)
    for g in need:
        inds = gi.get(g, [])
        if not inds and g == 'CCN2':
            inds = gi.get('CTGF', [])
        if not inds and g == 'CCN1':
            inds = gi.get('CYR61', [])
        genevals[g] = np.asarray(x[:, inds].sum(axis=1)).ravel() if inds else np.full(x.shape[0], np.nan)
    c = pd.DataFrame(genevals, index=obs.index)
    e = np.log1p(c.div(np.maximum(tot, 1), axis=0) * 10000.0)
    z = obs.copy()
    z['total_counts'] = tot
    for (k, gs) in SETS.items():
        z[k] = e[gs].mean(axis=1)
        z[k + '_ndet'] = (c[gs] > 0).sum(axis=1)
    for g in need:
        z['expr_' + g] = e[g]
        z['det_' + g] = (c[g] > 0).astype(float).where(c[g].notna(), np.nan)
    z['candidate'] = z.identity_ndet >= 3
    z['clean'] = z.candidate & (z.endothelial_ndet < 2) & (z.epithelial_ndet < 2) & (z.astro_ndet < 2) & (z.immune_ndet < 2)
    z['capillary_clean'] = z.clean & (z.capillary_ndet >= 1)
    z['MYH11_negative'] = z.capillary_clean & (z.det_MYH11 == 0)
    z['T_support'] = z.T_transport_ndet >= 2
    z['M_support'] = z.M_matrix_ndet >= 2
    z['both_support'] = z.T_support & z.M_support
    z['T_minus_M'] = z.T_transport - z.M_matrix
    return z
W = B / 'data/external/scrna/GSE256493'
manifest = []
for (file, sub, default) in [('download_list.txt', 'raw', 'MET'), ('download_list_other.txt', 'raw_other', None)]:
    for line in (W / file).read_text().splitlines():
        a = line.split()
        if not a:
            continue
        (gsm, pre, sample) = a[:3]
        if 'all' not in sample:
            continue
        grp = sample.split('_')[0]
        donor = re.match('([A-Z]+_patient\\d+)', sample).group(1)
        manifest.append(dict(gsm=gsm, prefix=pre, sample=sample, donor=donor, group=grp, subdir=sub))
pd.DataFrame(manifest).to_csv(O / 'walchli_unsorted_manifest.csv', index=False)
allz = []
for m in manifest:
    pre = W / m['subdir'] / m['prefix']
    for suffix in ['_matrix.mtx.gz', '_barcodes.tsv.gz', '_features.tsv.gz', '_genes.tsv.gz']:
        pth = Path(str(pre) + suffix)
        if pth.exists():
            inputs.append(str(pth))
for m in manifest:
    cache = O / ('cache_' + m['gsm'] + '.csv.gz')
    if cache.exists():
        z = pd.read_csv(cache, index_col=0)
        allz.append(z)
        continue
    pre = W / m['subdir'] / m['prefix']
    fp = Path(str(pre) + '_features.tsv.gz')
    if not fp.exists():
        fp = Path(str(pre) + '_genes.tsv.gz')
    mp = Path(str(pre) + '_matrix.mtx.gz')
    bp = Path(str(pre) + '_barcodes.tsv.gz')
    inputs += [str(fp), str(mp), str(bp)]
    f = pd.read_csv(fp, sep='\t', header=None)
    genes = f[1].astype(str).values
    x = scipy.io.mmread(mp).T.tocsr().astype(np.float32)
    bc = pd.read_csv(bp, header=None)[0].astype(str).values
    tot = np.asarray(x.sum(axis=1)).ravel()
    ng = np.diff(x.indptr)
    mito = np.asarray(x[:, np.char.startswith(genes.astype(str), 'MT-')].sum(axis=1)).ravel() / np.maximum(tot, 1) * 100
    keep = (ng >= 300) & (mito < 20)
    x = x[keep]
    obs = pd.DataFrame(index=[m['gsm'] + '_' + b for b in bc[keep]])
    for k in ['gsm', 'sample', 'donor', 'group']:
        obs[k] = m[k]
    obs['dataset'] = 'Walchli'
    obs['n_genes'] = ng[keep]
    obs['pct_mito'] = mito[keep]
    z = states(x, genes, obs)
    z = z[z.candidate].copy()
    z.to_csv(cache, compression='gzip')
    allz.append(z)
    print(m['sample'], 'candidate', len(z), 'capillary clean', z.capillary_clean.sum(), flush=True)
wall = pd.concat(allz)
wall.to_csv(O / 'walchli_pericyte_states.csv.gz', compression='gzip')
ip = B / 'data/integrated/final_integrated_annotated.h5ad'
lp = B / 'data/integrated/per_cell_labels.csv'
inputs += [str(ip), str(lp)]
lab = pd.read_csv(lp).set_index('cell')
a = sc.read_h5ad(ip)
lab = lab.reindex(a.obs_names)
lab['sub05'] = lab.sub05.fillna(lab.atomic_cluster_id)
keep = lab.lineage_l1.isin(['基质', '内皮']) | lab.patient_id.isin(['P1', 'P5']) & (lab.lineage_l1 == '上皮/肺腺癌') | (lab.patient_id == 'P3') & lab.lineage_l1.str.contains('神经内分泌', na=False)
a = a[keep].copy()
obs = lab[keep].copy()
obs['dataset'] = 'Internal'
obs['donor'] = obs.patient_id
obs['group'] = obs.patient_id.map({'P1': 'LUAD_BM', 'P5': 'LUAD_BM', 'P3': 'SCLC_BM'}).fillna('PCNSL')
ours = states(a.X, a.var_names, obs)
ours['is_tumor'] = ours.patient_id.isin(['P1', 'P5']) & (ours.lineage_l1 == '上皮/肺腺癌') | (ours.patient_id == 'P3') & ours.lineage_l1.str.contains('神经内分泌', na=False)
ours['is_stroma'] = ours.lineage_l1 == '基质'
ours.to_csv(O / 'internal_tumor_mural_states.csv.gz', compression='gzip')
metrics = ['T_transport', 'M_matrix', 'T_minus_M', 'T_support', 'M_support', 'both_support', 'hypoxia', 'remodeling', 'contractile', 'AP1_MAPK_response', 'cycling'] + ['det_' + g for g in ['SLC6A1', 'SLC1A3', 'SLC12A7', 'SLC20A2', 'PDGFRB', 'IGF2', 'MCAM', 'ANPEP', 'DES', 'GAS6', 'AXL']]
rows = []
for (dataset, z) in [('Walchli', wall), ('Internal', ours[ours.is_stroma])]:
    for gate in ['clean', 'capillary_clean', 'MYH11_negative']:
        for ((donor, group), q) in z[z[gate]].groupby(['donor', 'group']):
            d = dict(dataset=dataset, gate=gate, donor=donor, group=group, n_cells=len(q), n_samples=q['sample'].nunique() if 'sample' in q else 1, median_UMI=q.total_counts.median())
            d.update({m: float(q[m].mean()) for m in metrics})
            rows.append(d)
summ = pd.DataFrame(rows)
summ.to_csv(O / 'pericyte_donor_scores.csv', index=False)

def exact(a, b, seed=20260922):
    v = np.r_[a, b]
    n = len(a)
    r = rankdata(v)
    expect = n * (len(v) + 1) / 2
    obs = abs(r[:n].sum() - expect)
    ncomb = math.comb(len(v), n)
    if ncomb <= 100000:
        vals = [abs(r[list(c)].sum() - expect) for c in itertools.combinations(range(len(v)), n)]
        return (float(np.mean(np.asarray(vals) >= obs - 1e-10)), ncomb)
    rng = np.random.default_rng(seed)
    vals = np.array([abs(r[rng.choice(len(v), n, replace=False)].sum() - expect) for _ in range(19999)])
    return (float((1 + (vals >= obs - 1e-10).sum()) / 20000), 20000)
tests = []
for gate in ['clean', 'capillary_clean', 'MYH11_negative']:
    for min_n in [10, 20]:
        q = summ[(summ.dataset == 'Walchli') & (summ.gate == gate) & (summ.n_cells >= min_n)]
        for m in metrics:
            aa = q[q.group == 'MET'][m].dropna().values
            bb = q[q.group == 'TL'][m].dropna().values
            if min(len(aa), len(bb)) < 2:
                continue
            (p, nperm) = exact(aa, bb)
            tests.append(dict(gate=gate, min_cells=min_n, metric=m, n_MET=len(aa), n_TL=len(bb), median_MET=np.median(aa), median_TL=np.median(bb), difference=np.median(aa) - np.median(bb), p=p, n_permutations=nperm))
test = pd.DataFrame(tests)
if len(test):
    test['q_BH_all'] = multipletests(test.p, method='fdr_bh')[1]
    primary = (test.gate == 'capillary_clean') & (test.min_cells == 20)
    test['q_BH_primary'] = np.nan
    test.loc[primary, 'q_BH_primary'] = multipletests(test.loc[primary, 'p'], method='fdr_bh')[1]
test.to_csv(O / 'walchli_donor_tests.csv', index=False)
tr = []
tm = ours[ours.is_tumor]
for ((p, sub), z) in tm.groupby(['patient_id', 'sub05']):
    if len(z) < 20:
        continue
    d = dict(patient=p, sub05=sub, n_cells=len(z))
    for m in ['T_transport', 'M_matrix', 'identity', 'capillary', 'hypoxia', 'stemness_literature', 'mimicry_literature', 'AP1_MAPK_response', 'cycling'] + [f'expr_{g}' for g in ['MCAM', 'AXL', 'VEGFA', 'CD44', 'ABCG2', 'ADGRA2', 'PDGFRB', 'CSPG4', 'IGF1R']]:
        d[m] = z[m].mean()
    tr.append(d)
tr = pd.DataFrame(tr)
tr.to_csv(O / 'tumor_frozen_subcluster_states.csv', index=False)
cors = []
for (p, z) in tr.groupby('patient'):
    for xg in ['expr_MCAM', 'expr_AXL', 'expr_CD44', 'mimicry_literature']:
        for yg in ['expr_VEGFA', 'hypoxia', 'AP1_MAPK_response', 'T_transport']:
            if z[xg].nunique() < 2 or z[yg].nunique() < 2:
                continue
            (r, _) = spearmanr(z[xg], z[yg])
            xr = rankdata(z[xg])
            yr = rankdata(z[yg])
            xr = (xr - xr.mean()) / np.linalg.norm(xr - xr.mean())
            yr = (yr - yr.mean()) / np.linalg.norm(yr - yr.mean())
            if len(z) <= 8:
                null = np.array([abs(xr @ yr[list(v)]) for v in itertools.permutations(range(len(z)))])
                pv = float(np.mean(null >= abs(r) - 1e-10))
                nperm = len(null)
            else:
                rng = np.random.default_rng(20260922)
                null = np.array([abs(xr @ rng.permutation(yr)) for _ in range(19999)])
                pv = float((1 + (null >= abs(r) - 1e-10).sum()) / 20000)
                nperm = 20000
            cors.append(dict(patient=p, x=xg, y=yg, n_subclusters=len(z), rho=r, p=pv, n_permutations=nperm))
cor = pd.DataFrame(cors)
if len(cor):
    cor['q_BH_all'] = multipletests(cor.p, method='fdr_bh')[1]
cor.to_csv(O / 'tumor_subcluster_associations.csv', index=False)
co = []
for (p, z) in ours.groupby('patient_id'):
    for (pop, mask) in [('tumor', z.is_tumor), ('mural_capillary_clean', z.is_stroma & z.capillary_clean), ('endothelial', z.lineage_l1 == '内皮')]:
        w = z[mask]
        if not len(w):
            continue
        row = dict(patient=p, population=pop, n_cells=len(w))
        for g in ['MCAM', 'AXL', 'VEGFA', 'CD44', 'ABCG2', 'PDGFRB', 'CSPG4', 'ADGRA2', 'IGF2', 'IGF1R', 'INSR', 'GAS6', 'PDGFB']:
            row['det_' + g] = w['det_' + g].mean()
            row['expr_' + g] = w['expr_' + g].mean()
        row['MCAM_CD44_codet'] = ((w.det_MCAM > 0) & (w.det_CD44 > 0)).mean()
        row['MCAM_PDGFRB_CSPG4_any_codet'] = ((w.det_MCAM > 0) & ((w.det_PDGFRB > 0) | (w.det_CSPG4 > 0))).mean()
        row['T2_codet'] = w.T_support.mean()
        row['M2_codet'] = w.M_support.mean()
        row['peri3_codet'] = (w.identity_ndet >= 3).mean()
        row['capillary1_codet'] = (w.capillary_ndet >= 1).mean()
        co.append(row)
pd.DataFrame(co).to_csv(O / 'internal_tumor_mural_ligand_receptor.csv', index=False)
prov = {'timestamp_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'inputs': [{'path': str(p), 'bytes': Path(p).stat().st_size, 'sha256': hashlib.sha256(Path(p).read_bytes()).hexdigest()} for p in dict.fromkeys(inputs)], 'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'python': os.sys.version, 'numpy': np.__version__, 'pandas': pd.__version__, 'scanpy': sc.__version__}
json.dump(prov, open(O / 'PROVENANCE.json', 'w'), indent=2)
print('COMPLETE', len(wall), len(ours), flush=True)
print(summ.query("gate=='capillary_clean' and dataset=='Walchli'")[['donor', 'group', 'n_cells', 'T_support', 'M_support', 'hypoxia', 'remodeling']].to_string(index=False), flush=True)
