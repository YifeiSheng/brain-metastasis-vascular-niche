# Current scientific analysis; package-relative paths. See code/ANALYSIS_GUIDE.md.
"""L18: sorted EC pseudobulk plus distinct per-cell state support, same gates as L17."""
import os as _handoff_os
from pathlib import Path as _HandoffPath
_HANDOFF_ROOT = _HandoffPath(_handoff_os.environ.get('SAFEPOSTER_HANDOFF_ROOT', str(_HandoffPath(__file__).resolve().parents[2]))).resolve()
import os
for k in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS']:
    os.environ[k] = '2'
from pathlib import Path
import pandas as pd, numpy as np, scipy.io as sio, json, hashlib, datetime, time
from threadpoolctl import threadpool_limits
threadpool_limits(2)
B = Path(str(_HANDOFF_ROOT / ''))
O = B / 'results/endothelial_response'
O.mkdir(parents=True, exist_ok=True)
plan = json.loads((B / 'data/analysis_definitions/vascular_gene_sets.json').read_text())
panels = {**plan['primary_panels'], **plan['sensitivity_panels']}
lin = {'EC': ['PECAM1', 'CDH5', 'CLDN5', 'VWF'], 'mural': ['PDGFRB', 'RGS5', 'NOTCH3', 'ACTA2', 'MYH11'], 'fibroblast': ['DCN', 'LUM', 'COL1A2', 'PDGFRA'], 'immune': ['PTPRC'], 'myeloid': ['CD68', 'CD163', 'C1QA', 'AIF1'], 'tumor_epi': ['EPCAM', 'KRT8', 'KRT18', 'KRT19'], 'oligo': ['PLP1', 'MBP', 'MOG'], 'astro': ['AQP4', 'GFAP', 'ALDH1L1']}
corecycle = ['MKI67', 'TOP2A', 'UBE2C', 'CENPF', 'BIRC5', 'CCNB1', 'CDK1']
required = list(dict.fromkeys(sum(lin.values(), []) + ['CD3D', 'TYROBP', 'LYZ'] + sum(panels.values(), [])))
sums = {}
ncell = {}
states = []
libraries = []
genesets = {}
source = []
for (namefile, raw) in [('download_list.txt', 'raw'), ('download_list_other.txt', 'raw_other')]:
    for line in (B / 'data/external/scrna/GSE256493' / namefile).read_text().splitlines():
        (gsm, prefix, sample, *_) = line.split()
        if '_EC' not in sample or not sample.startswith(('MET_', 'TL_', 'GBM_')):
            continue
        donor = '_'.join(sample.split('_')[:2])
        group = {'MET': 'BM', 'TL': 'TL', 'GBM': 'GBM'}[sample.split('_')[0]]
        cp = O / ('cache_' + gsm + '.npz')
        mp = O / ('cache_' + gsm + '.json')
        if cp.exists() and mp.exists():
            cache = np.load(cp, allow_pickle=False)
            meta = json.loads(mp.read_text())
            if meta['plan_sha256'] != hashlib.sha256((B / 'data/analysis_definitions/vascular_gene_sets.json').read_bytes()).hexdigest():
                raise RuntimeError('Stale cache; archive it first')
            genes = cache['genes'].astype(str)
            gs = set(genes)
            for gate in ['main', 'strict']:
                n = meta[gate]['n_EC']
                key = (gate, donor, group)
                libraries.append(dict(sample=sample, gsm=gsm, donor=donor, group=group, gate=gate, **meta[gate]))
                if n < 20:
                    continue
                sums[key] = sums.get(key, pd.Series(dtype=float)).add(pd.Series(cache[gate + '_counts'], index=genes), fill_value=0)
                ncell[key] = ncell.get(key, 0) + n
                genesets[key] = genesets.get(key, gs) & gs
            states.extend(meta['states'])
            source.extend(meta['sources'])
            print('CACHE', sample, flush=True)
            continue
        start = time.time()
        print('READ', sample, flush=True)
        p = B / 'data/external/scrna/GSE256493' / raw
        xf = p / (prefix + '_matrix.mtx.gz')
        gf = p / (prefix + '_features.tsv.gz')
        if not gf.exists():
            gf = p / (prefix + '_genes.tsv.gz')
        X = sio.mmread(xf).tocsr().T.tocsr().astype(np.float32)
        features = pd.read_csv(gf, sep='\t', header=None)
        genes = features.iloc[:, 1 if features.shape[1] > 1 else 0].astype(str).values
        ix = {g: i for (i, g) in reversed(list(enumerate(genes)))}
        total = np.asarray(X.sum(1)).ravel()
        ng = np.diff(X.indptr)
        mito = np.char.startswith(genes.astype(str), 'MT-')
        mt = np.asarray(X[:, mito].sum(1)).ravel() / np.maximum(total, 1)
        qc = (ng >= 300) & (mt < 0.2)
        duplicates = pd.Series(genes).value_counts()
        avail = [g for g in required if g in ix]
        C = pd.DataFrame(np.column_stack([np.asarray(X[:, genes == g].sum(1)).ravel() for g in avail]), columns=avail)
        legacyC = pd.DataFrame(np.column_stack([X[:, ix[g]].toarray().ravel() for g in avail]), columns=avail)
        gateC = legacyC.reindex(columns=required, fill_value=0)
        E = np.log1p(gateC.div(np.maximum(total, 1), axis=0) * 10000.0)
        lm = pd.DataFrame({k: E[v].mean(1) for (k, v) in lin.items()})
        main = qc & (lm.idxmax(1).values == 'EC') & (lm.max(1).values > 0.3)
        strict = qc & ((gateC[lin['EC']] > 0).sum(1).values >= 2) & ((gateC[lin['tumor_epi']] > 0).sum(1).values < 2) & ((gateC[['PTPRC', 'CD3D', 'TYROBP', 'LYZ']] > 0).sum(1).values < 2)
        E = np.log1p(C.div(np.maximum(total, 1), axis=0) * 10000.0)
        cacheout = {}
        cachemeta = {'plan_sha256': hashlib.sha256((B / 'data/analysis_definitions/vascular_gene_sets.json').read_bytes()).hexdigest(), 'states': [], 'sources': []}
        for f in [xf, gf]:
            rec = dict(path=str(f), size=f.stat().st_size, mtime=f.stat().st_mtime)
            if f == gf:
                rec['sha256'] = hashlib.sha256(f.read_bytes()).hexdigest()
            cachemeta['sources'].append(rec)
            source.append(rec)
        for (gate, sel) in [('main', main), ('strict', strict)]:
            n = int(sel.sum())
            key = (gate, donor, group)
            v = pd.Series(np.asarray(X[sel].sum(0)).ravel(), index=genes).groupby(level=0).sum()
            cacheout[gate + '_counts'] = v.values
            cacheout['genes'] = v.index.astype(str).values
            rec = dict(n_qc=int(qc.sum()), n_EC=n, n_total_cells=len(total), median_UMI=float(np.median(total[sel])) if n else None)
            cachemeta[gate] = rec
            libraries.append(dict(sample=sample, gsm=gsm, donor=donor, group=group, gate=gate, **rec))
            if n < 20:
                continue
            sums[key] = sums.get(key, pd.Series(dtype=float)).add(v, fill_value=0)
            ncell[key] = ncell.get(key, 0) + n
            gs = set(genes)
            genesets[key] = genesets.get(key, gs) & gs
            for (module, panel) in panels.items():
                measured = [g for g in panel if g in C]
                observed = C.loc[sel, measured]
                ndet = (observed > 0).sum(1)
                rec = dict(sample=sample, gsm=gsm, donor=donor, group=group, gate=gate, module=module, n_EC=n, n_available=len(measured), n_expected=len(panel), missing=';'.join((g for g in panel if g not in C)), mean_logCP10k=float(E.loc[sel, measured].mean(1).mean()) if measured else None, n_atleast2=int((ndet >= 2).sum()), n_atleast1=int((ndet >= 1).sum()))
                states.append(rec)
                cachemeta['states'].append(rec)
            cycling = ((C.loc[sel, corecycle] > 0).sum(1) >= 2) & ((C.loc[sel, ['MKI67', 'TOP2A']] > 0).sum(1) >= 1)
            rec = dict(sample=sample, gsm=gsm, donor=donor, group=group, gate=gate, module='cycling_core_support', n_EC=n, n_available=7, n_expected=7, missing='', mean_logCP10k=None, n_atleast2=int(cycling.sum()), n_atleast1=int((C.loc[sel, 'MKI67'] > 0).sum()))
            states.append(rec)
            cachemeta['states'].append(rec)
        np.savez_compressed(cp, **cacheout)
        mp.write_text(json.dumps(cachemeta, indent=2))
        print('DONE', sample, 'main', int(main.sum()), 'strict', int(strict.sum()), round(time.time() - start, 1), 'sec', flush=True)
pd.DataFrame(libraries).to_csv(O / 'EC_library_manifest.csv', index=False)
pd.DataFrame(states).to_csv(O / 'EC_library_state_support.csv', index=False)
meta = []
coverage = []
for gate in ['main', 'strict']:
    keys = [k for k in sums if k[0] == gate]
    frame = pd.DataFrame({k[1]: sums[k] for k in keys}).T.fillna(0)
    frame.to_csv(O / f'EC_{gate}_pseudobulk_counts.csv.gz', compression='gzip')
    common = set.intersection(*(genesets[k] for k in keys))
    (O / f'EC_{gate}_common_measured_genes.txt').write_text('\n'.join(sorted(common)) + '\n')
    for k in keys:
        meta.append(dict(gate=gate, donor=k[1], group=k[2], n_EC=ncell[k], total_UMI=float(frame.loc[k[1]].sum())))
    for (mod, gs) in panels.items():
        coverage.append(dict(gate=gate, module=mod, available=';'.join((g for g in gs if g in common)), missing=';'.join((g for g in gs if g not in common)), n_available=sum((g in common for g in gs)), n_expected=len(gs)))
pd.DataFrame(meta).to_csv(O / 'EC_donor_manifest.csv', index=False)
pd.DataFrame(coverage).to_csv(O / 'panel_coverage.csv', index=False)
st = pd.DataFrame(states)
ds = st.groupby(['gate', 'donor', 'group', 'module'], as_index=False)[['n_EC', 'n_atleast2', 'n_atleast1']].sum()
ds['fraction_atleast2'] = ds.n_atleast2 / ds.n_EC
ds['fraction_atleast1'] = ds.n_atleast1 / ds.n_EC
ds.to_csv(O / 'EC_donor_state_support.csv', index=False)
checks = []
for gate in ['main', 'strict']:
    old = pd.read_csv(B / 'results/ligand_response' / f'EC_{gate}_pseudobulk_counts.csv.gz', index_col=0)
    new = pd.read_csv(O / f'EC_{gate}_pseudobulk_counts.csv.gz', index_col=0)
    diff = float(np.abs(old.values - new.reindex(index=old.index, columns=old.columns).values).max())
    assert diff == 0, (gate, diff)
    checks.append(dict(gate=gate, max_abs_difference_from_L17=diff))
json.dump(dict(timestamp_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), inputs=source, plan_sha256=hashlib.sha256((B / 'data/analysis_definitions/vascular_gene_sets.json').read_bytes()).hexdigest(), script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), legacy_reproduction=checks, QC='genes>=300,mito<20%; legacy/max-lineage and strict 2ECmarker gates. Independent donor sum; duplicates combined. Symbol duplicate features summed for state scores; original first-feature gate retained for exact L17 reproduction. Main donors require20EC perlibrary.', cell_support='Positive co-detection support, not calibrated subtype frequency or proof of cycling/sprouting/permeability. Cycling core requires>=2of7 plus MKI67orTOP2A.'), open(O / 'EXPORT_PROVENANCE.json', 'w'), indent=2)
print('COMPLETE', pd.DataFrame(meta).groupby(['gate', 'group']).agg(donors=('donor', 'size'), cells=('n_EC', 'sum')).to_string(), flush=True)
