# 外部输入下载、预处理与验收

本指南用于从公开来源恢复当前外部验证的分析输入。公开表达矩阵、原始分割/临床文件和参考网络已按交付要求移出 ZIP；下载来源见[外部来源清单](../manuscript/EXTERNAL_DATA_DOWNLOADS.md)，当前最终统计与图源表仍在包内。五张正式图无需重新下载这些原始外部数据。

**实际验证范围。** 本次已在服务器用既有作者原始 RDS/annotation 实际重建 Kim D4 的四个输入，矩阵、features、barcodes、annotation 的 SHA256 全部与被移出原件一致，见[验证记录](../validation/kim_D4_reconstruction.json)。下述其余来源是对现存脚本和原输入布局的重建说明；新增准备工具经过语法和小样例检查，没有重新下载全部公开数据或端到端重跑全部外部队列。移出输入之前完成的四项离线分析检查，不等于现在的 ZIP 可以离线重跑外部原始分析。

## 运行位置与顺序

在交付包的**工作副本**内执行，以免分析脚本覆盖已经接受的最终结果。下列命令的当前目录均为该工作副本根目录；Python/R 环境以 environment/ 中的版本记录及 code/ANALYSIS_GUIDE.md 为准。原分析脚本保留编号作为定位依据；这里的编号不代表要依次执行全部脚本。

```bash
export SAFEPOSTER_HANDOFF_ROOT="$PWD"
export OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 NUMEXPR_NUM_THREADS=2
python code/external_reconstruction/restore_sample_rosters.py
python code/external_reconstruction/download_selected_inputs.py --dataset GSE131907
# 审阅上一步输出后，加入 --download 才实际下载所选来源：
python code/external_reconstruction/download_selected_inputs.py --dataset GSE131907 --download
```

下载器使用 specifications/source_downloads.json 中冻结的文件名与目标路径；不按未来网页排序自动重选样本。清单优先列当前使用的单个 GSM 文件，避免再下载含重复内容的整套 RAW.tar；需要原始 tar 的公开实验由各自原分析入口下载。已有文件校验 bytes，已固定 SHA 的来源还校验 SHA；校验不同会停止，不能用新版输入悄悄替换当前来源。网络地址核验和文件名列举不是本次实际重下载的证明。

specifications/ 内的 10 份小型 roster 是分析参数：保留 GSM、作者样本名、分组及供者连接关系，没有表达矩阵。restore_sample_rosters.py 将它们恢复到脚本期望路径，遇到内容不同的已有文件会停止。完整原始树目录见 data/external/PUBLIC_RAW_INPUT_CATALOG.json，该目录包含辅助与历史来源，**不要把它当成必须全部下载的清单**。

## Kim：从原始 RDS 复原 D4 与营养分支

来源是 GSE131907 的 GSE131907_Lung_Cancer_raw_UMI_matrix.rds.gz、GSE131907_Lung_Cancer_cell_annotation.txt.gz；这里的 raw UMI 指作者公开的计数矩阵，不是测序 FASTQ。下载器另外取得营养分期所需的 Feature_Summary.xlsx。

```bash
Rscript code/external_reconstruction/export_kim_D4.R \
  data/external/scrna/GSE131907 results/external_replication/D4
python code/external_reconstruction/verify_reconstructed_inputs.py \
  --prefix results/external_replication/D4/ --require-all \
  --report validation/local_Kim_D4_reconstruction.json
python code/analysis/66_D4_gse131907_score.py
python code/analysis/95d_L16_kim_pericyte_validation.py
```

导出器在缺少 GSE131907_raw_UMI_matrix.rds 时，剥除 GEO 文件**一层外部 gzip**，再由 readRDS 读取本身压缩的 RDS。完整作者矩阵为 29,634 × 208,506；筛选 annotation 的 Sample_Origin ∈ {mBrain,tLung,nLung}，通过 intersect 保留原矩阵列顺序，annotation 用 match 同序对齐，所有原始基因/UMI保留，不做 QC、归一化、log 或按注释重排。

当前 D4 为 **29,634 基因 × 117,204 细胞、206,684,756 非零值、873,769,061 总 UMI**，32 个样本；mBrain 29,060、tLung 45,149、nLung 42,995 细胞。四文件的逐字节相同已同时确认基因顺序、细胞顺序、矩阵值和注释匹配；这比只比较 shape 更严格。新导出器拒绝覆盖已有 D4 四个 payload 文件，需使用尚未恢复输入的工作副本或新输出目录。

营养分支不能拿 D4 子集代替全病程输入。先运行 96b_L17_kim_metadata.py 从作者 Feature_Summary.xlsx 建立 sample/stage 连接，运行 96b_L17_nutrition.py 生成内部与 D4 比较，再执行：

```bash
Rscript code/analysis/96b_L17_kim_full_export.R
python code/analysis/96b_L17_nutrition_stage.py
```

全病程导出从完整 raw RDS 取作者 Cell_subtype 为 Malignant cells/tS1/tS2/tS3、Sample_Origin 为 mBrain/tLung/tL/B/mLN/PE 的细胞。总 UMI 先按全部基因求和，然后保留冻结 gene_sets.json 的所需基因；ATP5F1A/ATP5F1B 缺失时按原规则映射旧名 ATP5A1/ATP5B，不因模块基因子集重新计算测序深度。输出在 results/nutrition/；患者和分期字段按作者表连接，不由细胞条码猜测。

## 血管、配体与受体：GSE256493 + 固定网络

download_selected_inputs.py --dataset GSE256493 --download 恢复 raw/ 和 raw_other/ 下冻结文件，roster 恢复 download_list.txt、download_list_other.txt、other_groups_gsm.txt。分选 EC 与未分选样本分开；重复文库按脚本 donor_id 合并，尤其 TL9/TL10，不以 GSM 数当供者数。

```bash
python code/analysis/64_D5_gse256493_vascular.py
python code/analysis/72_V2_walchli_other_groups.py
python code/analysis/96a02_L17_EC_pseudobulk.py
python code/external_reconstruction/download_selected_inputs.py --dataset signaling-resources --download
Rscript code/analysis/96a03_L17_export_resources.R
python code/analysis/96a04_L17_signaling.py
python code/analysis/96a05_L17_ligand_robustness.py
python code/analysis/98a01_L18_EC_export.py
python code/analysis/98a02_L18_EC_programs.py
```

96a02 的 pseudobulk 是 98a01 核查兼容性的前置输入，不能跳过后只生成新版 EC 表。98a01 固定 QC 为检测基因≥300、线粒体<20%；主门控为 EC 最大谱系分数且 >0.3，严格门控要求至少2个EC marker、低上皮/免疫 marker，主供者要求每库≥20个EC。纳入23文库、合并为21供者（BM5/TL9/GBM7）；重复符号在状态得分中加和，旧版第一feature门控保留用于精确兼容核查。

网络下载必须是 PROGENy commit **cad6be0514c3248b9465e48f1cfd2f6a4c3dfb6f** 的 model_human_full.rda，以及 NicheNet Zenodo **7074291** 的 ligand_target_matrix_nsga2r_final.rds、lr_network_human_21122021.rds。固定下载器包含这三文件 SHA，禁止以 GitHub master 替换。96a03 生成 PROGENy 全网络 CSV、NicheNet LR表、有序ligand/target轴与float32二进制；R按列写 as.vector，读取必须采用相同列主序，不能随意转置/排序。源记录与校验同时保留在 results/ligand_response/resources/manifest.json。

## 公开扰动与实际培养数据

这些实验由外部研究完成，本项目重分析表达结果；不意味着对本项目患者新做了湿实验。

| 来源 | 执行顺序/输入重建 | 保留的关键定义 |
|---|---|---|
| GSE237317，CSC→Cd-pericyte→PdCSC | 先恢复 GSE256493 的 GSM8101557_metastasis_23-10-19_Ecs_features.tsv.gz；运行 96c_reversible_differentiation.py，再运行同名 .R | Python自行下载RAW.tar和family.SOFT，展开6文件；按原gene_id去Ensembl版本并加和重复ID，列按文件名排序。作者表达已处理，主分析log2(author expression+1)，不是raw-UMI edgeR。每状态2份，独立供者关系未提供，培养基差异保留为局限。 |
| GSE248935，CD146敲低 | 96d_L17_collect_causal_evidence.py → 96d_L17_CD146_perturbation.R | 原gene_fpkm.txt.gz及GSM7923254–7923259标题。按shNC 1–3 / shCD146 4–6匹配矩阵sample1–6，不按GSM顺序推断。FPKM主模型log2(x+0.5)、limma-trend，伪计数0.1/1敏感性；不能称原始计数DE。 |
| GSE227549/GSE196776，VEGF对照 | 98d01_L18_download_VEGF_controls.py → 98d02_L18_prepare_VEGF_controls.py → Rscript 98d03_L18_VEGF_controls.R → 98d04_L18_VEGF_panel_scores.py | RAW.tar/SOFT中仅按标题正则选 Control/VEGF；3D为5+5，2D为3+3。featureCounts基因ID去版本并加和重复，TMM/filterByExpr→voom/robust limma，供者/批次配对未公开，不按数字后缀臆造配对。 |
| 人体EC中的独立VEGF足迹 | 上述3D/2D全基因DE及98a01/98a02完成后，运行98a03_L18_VEGF_footprint.py | 权重来自外部扰动，人体脑数据只作投射；3D18h和2D24h不是同一时间序列，表达响应不是灌注血管增多的直接测量。 |

**基因注释来源**：GSE237317准备步骤产生的 ensembl_symbol_map.csv 实际取自 GSE256493/GSM8101557 的作者 features.tsv.gz，VEGF准备步骤复用该稳定ID→symbol字典。它不来自GSE237317表达值，也没有把该实验的表达量混入HUVEC分析。98d02 再输出 results/VEGF_sprouting_calibration/gene_id_symbol_annotation.csv。

内部/外部周细胞状态由 96c_pericyte_states.py、95h_L16_mural_identity_sensitivity.py 消费已恢复的GSE256493、D4及内部最终标签；保持作者恶性标记、周细胞/平滑肌/成纤维细胞敏感性定义，不能把转录轨迹或参考映射称为谱系追踪。

## 其余单细胞/单核来源

下表中的下载均可用新 download_selected_inputs.py 的 --dataset 参数；恢复roster后保留原文件名和原barcode。原脚本定义的阈值/基因表是最终参数来源，下列是关键入口和容易遗漏的步骤。

| 来源 | 从下载到当前结果 | 必须保留的选择/路径 |
|---|---|---|
| GSE186344 Gonzalez | 单GSM matrix/features/barcodes 与作者annotation → 61_D2_D3_public_scRNA_replication.py → results/external_replication/D2 | 冻结下载清单排除mouse model和不需要的LogNormalized副本；原counts按每样本独立处理，QC≥200 genes、gene≥3cells，logCP10K及内部固定签名。作者注释覆盖按脚本报告。 |
| GSE223499 NSCLC | 单GSM h5 + sample_meta.csv → 67_D8_gse223499_snrna.py → D8 | UMI≥500、features≥300、mito<10%，每样本最多30000个最高UMI细胞；gene≥3cells。病人/部位/基因型来自冻结roster，不将同供者文库当独立供者。 |
| GSE185386 Biermann | snRNA三件套 + sample_meta.tsv → 74_V5_biermann_mbm_vs_ecm.py；83_M2_I2_snrna_cohorts.py biermann | MBM/ECM及重复来自作者标题；保持sn和sc_CD45neg分支，snRNA QC≥300genes、mito<10%。周细胞门控score>0.15且≥4marker。已存在结果时部分脚本会复用cache，只在工作副本管理要重建的cache。 |
| GSE325196 Duke | snRNA/Visium三件套、positions/scales + sample_meta.tsv → 75_V4_duke_sn_visium_xenium.py；83_M2_I2_snrna_cohorts.py duke | S_* 与 V_* 分开；部分扩展名.gz文件实际未gzip压缩，原reader使用magic字节识别，不能再次盲目gunzip。 |
| GSE322964 Simon | 9份HPT_GEX_counts.csv.gz → 83_M2_I2_snrna_cohorts.py simon | 冻结清单排除_CM0；仅GEX，不将ATAC当作表达；保留作者样本/癌种ID。 |
| GSE163577 Yang VINE-seq | 下载各GSM *_filtered_feature_bc_matrix.tar.gz；prepare_archives.py --mode vine-seq；运行76_V3_pericyte_atlas_mapping.py | tar内部目录名原样展开到data/external/scrna/GSE163577/raw/，不要再人为加GSM父目录。仅Control组10库，QC≥500genes、mito<5%、gene≥10cells；固定CellTypist训练参数与随机过程，最终模型亦保留。 |
| GSE203552 Heming | biopsy/CSF RNA H5、BCR注释和空间文件 → 61、65、85_L1_L2_L4_lymphoma.py | 61限biopsy；85纳入定义见脚本，不将CSF与biopsy或多个同供者样本当独立患者；不能以所有GSM数作为病例数。 |
| GSE181304 | GSM5494566三件套 → 85_L1_L2_L4_lymphoma.py | 额外PCNSL病例；可用series RAW.tar恢复，但下载器已列单GSM三件套，不需重复下载。 |
| GSE182434 Steen | series raw_count_matrix.txt.gz + cell_annotation.txt.gz → 85 | 原作者注释筛选，结内DLBCL4、FL3、tonsil1；不按同名marker重新定义临床分组。 |
| HLCA | 固定dataset dbb5ad81-1713-4aee-8257-396fbabe7c6e.h5ad → data/external/reference/hlca.h5ad → 41_M1c_hlca_anchor.py | **full atlas**，2,282,447×55,329，schema7.0.0；normal/Epithelial/19类ann_finest_level，seed0、每类cap1500、CellTypist top_genes300。优先raw，原max<50分支决定是否归一化，不能换core版。SHA见provenance/HLCA_REFERENCE.json。 |

## 空间输入、Biermann计数缓存与IMC

| 来源 | 准备入口 → 当前分析 | 坐标/身份约束 |
|---|---|---|
| GSE179572，6张Visium | 下载6个filtered H5和各GSM_spatial.tar.gz；prepare_archives.py --mode visium179572；运行60_D1_public_visium_replication.py/82_M3_I3_L3_visium_30slides.py | 展开到raw/GSM5420749…5420754/spatial/tissue_positions_list.csv。2.75GB all_spatial_images.tar.gz仅含TIF，非当前计数/坐标必要输入，下载器不取。 |
| GSE320505，4张Visium | H5、positions.csv.gz、scales→60/82 | GSM9544605–9544608，保留四个具体癌种/样本，不混入不同平台重复。 |
| GSE230207，4张PCNSL Visium | H5、positions、scales→65_D3b_pcnsl_visium.py/82 | GSM7192449/2450/2451/2453；hot/cold/IME/IMS保留作者区域名。 |
| GSE223501，Slide-seq | counts+coordinates+sample_meta.tsv→71_V1_slideseq_vascular.py | 14份下载，KRAS11与PA056重复，分析去重为13张；坐标尺度0.65 µm/pixel，邻域与置换规则沿用脚本。 |
| GSE325935，Xenium | cell_feature_matrix.h5、cells.parquet.gz；prepare_archives.py --mode xenium；75、93、95c、98c03 | 四片X_10_0184/X_14_0024/X_16_0239/X_18_0267；解压保留cells.parquet，原.gz不删除。实际280 GEX基因，不能把全部541探针都称为基因。98c03使用UMI20/50、EC PECAM1+VWF2/3/5、tumor EPCAM+KRT8 3/5/8阈值并排除双阳性。 |
| GSE185386，Slide-seq营养 | 作者 *_slide_raw_counts.csv.gz 与spatial_info.csv.gz → cache_biermann_spatial.py → 96b_L17_nutrition_spatial.py → 同系列commongenes及ECsensitivity | 16切片/11患者，先切片统计再患者聚合。缓存见下文，分支不代替snRNA。 |

```bash
python code/external_reconstruction/cache_biermann_spatial.py
python code/analysis/96b_L17_nutrition_spatial.py
python code/analysis/96b_L17_nutrition_spatial_commongenes.py
python code/analysis/96b_L17_nutrition_spatial_ECsensitivity.py
```

cache_biermann_spatial.py 是原缓存脚本的可移植副本，仅更换输入/输出根目录并取消自动启动下一步。2个worker逐行读取作者CSV，按原barcode顺序累计**所有基因**的total UMI，再保存所需模块基因的counts；旧ATP5A1/ATP5B符号映射到ATP5F1A/ATP5F1B，保存实际测得的gene交集，不能把未测基因填0。NPZ format_version=2，包含barcodes/counts/total/genes；算法没有重算或修改模块定义。

IMC当前身份与几何入口使用更正作者记录 **Zenodo 7884599**：
```bash
python code/external_reconstruction/download_selected_inputs.py --dataset Karimi2023 --download
python code/external_reconstruction/prepare_archives.py --mode imc-updated \
  --archive data/external/imc/Karimi2023/BrainData_updated.zip
python code/analysis/98c02_L18_IMC_geometry.py
```

准备器把Brain_Data2中的CellType/Segmentation和临床表放到 results/verified_vascular_geometry/official_updated/，并按包内 ALL_ROI_MAPPING_OFFICIAL_VERIFIED.csv 检查393个官方ROI必需文件。98c02按官方名字读取，不重新按临床表行次推断患者；生成细胞质心、EC密度、肿瘤到EC距离后先聚合供者。123个BrM ROI的旧→官方身份核验已冻结，生存统计没有因此被重新审计。

原81/94脚本读取旧archive 7383719的legacy ROI命名。若需重算这两个已有免疫分支，应额外下载旧BrainData.zip并将内部BrainData/原样展开到 data/external/imc/Karimi2023/data/，同时以现成官方映射检验身份；不要把7884599新名字硬塞给旧reader。98c01是旧/新两档案身份一致性复核入口，需要两份archive及旧数据；它的HTTP range缓存不是科学输入，没必要为一般几何重算恢复。未提供可定量CD31连续血管网络原图，不能从细胞分割TIF冒称获得完整血管管腔。

## Yang2026、TCGA及在线cBioPortal

Yang来源固定 Zenodo **17879312**。下载器提供snRNAcounts.rds、snRNA.meta.rds、sce.mergeSCT.rds、discovery.counts.rds、inhouse.validation.counts.rds、cnv.gistic.xlsx、Mutation.xlsx及readme。

```bash
python code/external_reconstruction/download_selected_inputs.py --dataset Yang2026 --download
mkdir -p data/external/bulk/Yang2026_BrM_zenodo/snRNA_mtx
mkdir -p data/external/bulk/Yang2026_BrM_zenodo/spatial_export
Rscript code/analysis/83a_yang2026_convert.R
Rscript code/analysis/83b_yang2026_spatial_export.R
Rscript code/external_reconstruction/export_yang_bulk.R data/external/bulk/Yang2026_BrM_zenodo
python code/analysis/83_M2_I2_snrna_cohorts.py yang
python code/analysis/82_M3_I3_L3_visium_30slides.py yang
python code/analysis/83c_gate_calibration_yang.py
```

83a保留snRNA raw counts的行列顺序，metadata导出orig.ident/Group/Label/celltype/nCount_RNA/nFeature_RNA/percent.mt七列及rowname，按barcode连接。83b取Spatial assay的**counts**，不是SCT校正值；17个image按坐标中与count列相交的条码导出，<50spots的图像跳过，坐标优先imagecol/x/col与imagerow/y/row。输出tissue_positions_list中in_tissue=1、阵列row/col=0为作者对象导出约定；不要拿阵列占位0作真实物理坐标。

新bulk导出器只将两个RDS的矩阵原样write.csv为discovery.counts.csv和validation.counts.csv，不归一化、不重排。50_M3b_yang2026_signatures.py与84_I4_bulk_genotype_immune.py再按各自定义处理；临床/突变来自原作者表与ID，不由列顺序合并。

TCGA-LUAD下载Xena GDC star_fpkm、clinical、survival和GENCODE v36 probemap，随后45_M3_external_cohorts.py/63_D6_D7_cbioportal.py/84_I4_bulk_genotype_immune.py。45还需要GSE200563_processed_data.txt.gz，该辅助GeoMx来源通过同一下载器恢复；它不是当前主结论的独立重复数。Xena star_fpkm已是log2(FPKM+1)，不能重复log；原发样本筛选barcode位置13:15 == 01，病人连接取TCGA条码前12位。

MSK-MET与TCGA突变通过63/84内的cBioPortal API直接取得；固定study分别msk_met_2021、luad_tcga_pan_can_atlas_2018，CNA为msk_met_2021_cna，基因Entrez列表及筛选字段就在代码中。MSK按Lung Adenocarcinoma、转移部位Brain/CNS或Primary分组，CNA扩大/深缺失阈值为2/−2；交付结果的174个脑转移与2479个原发样本应作纳入数对照。API未来可能更新，在线返回与冻结表不同应保留版本差异记录，不能声称固定旧API返回已被离线完整封存。

## 验收和可复现边界

```bash
python code/external_reconstruction/verify_reconstructed_inputs.py \
  --dataset GSE131907 --report validation/reconstructed_GSE131907.json
```

验收器按 provenance/external_inputs_excluded.json 的原路径和SHA检查现存输入，并分别报告identical/different/missing。只恢复部分队列时missing正常；--require-all只对已明确准备完整的prefix使用。505个排除文件包含HTTP范围缓存和文献拷贝，不是每个科学分支都需要恢复所有505个文件。

字节不同必须调查；gzip头时间、NPZ压缩器、R/Matrix序列化可造成文件字节差异，不能把它自动当数值改变，也不能据此直接宣布等价。语义核查应比较有序轴、维度、稀疏矩阵非零坐标/数值、注释匹配及所有分析阈值，保存检查报告；D4本次没有这类歧义，四文件是逐字节一致。

目前包内环境快照和分析说明记录原执行环境；重建工具不自动安装依赖、不改现有结论。R导出需要Matrix/jsonlite（D4验证为R4.3.1、Matrix1.6.5），Yang空间需要Seurat，公开实验DE需要edgeR/limma，Biermann缓存需要NumPy；Python读取10x/空间/参考使用原分析环境。作者的原始湿实验设计、抽样单位、缺失注释和不支持的因果推断不会因恢复数据文件而消失。
