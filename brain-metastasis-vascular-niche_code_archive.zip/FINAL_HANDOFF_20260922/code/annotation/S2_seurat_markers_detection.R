Sys.setlocale("LC_CTYPE","C.UTF-8")
# S2: 建 Seurat 对象(冻结 Harmony latent + 冻结 UMAP 作为 reduction, 不重算) →
#     FindAllMarkers (Xing 2025 参数, 逐细胞 Wilcoxon) → 逐簇逐病人检出率证据 (全细胞, 不降采样)
Sys.setenv(OPENBLAS_NUM_THREADS="8",OMP_NUM_THREADS="8",MKL_NUM_THREADS="8")
suppressPackageStartupMessages({library(Seurat);library(Matrix);library(dplyr);library(data.table)})
set.seed(42)
D<-Sys.getenv("ANNOTATION_WORKSPACE"); stopifnot(nzchar(D))
W<-file.path(D,"work"); PROG<-file.path(D,"logs/S2_progress.txt")
log<-function(...){con<-file(PROG,open="a");writeLines(paste0(format(Sys.time(),"[%H:%M:%S] "),paste0(...,collapse="")),con);close(con)}
options(error=function(){con<-file(PROG,open="a");writeLines(c("!!! ERROR",capture.output(traceback(3))),con);close(con);quit(status=1)})
H<-Sys.getenv("FROZEN_REFERENCE"); stopifnot(nzchar(H))

log("读取 MTX")
cnt<-ReadMtx(mtx=file.path(D,"data/matrix.mtx.gz"),cells=file.path(D,"data/barcodes.tsv"),
             features=file.path(D,"data/features.tsv"),feature.column=1)
log("矩阵 ",nrow(cnt)," x ",ncol(cnt))
md<-read.csv(file.path(D,"data/cell_metadata.csv"),stringsAsFactors=FALSE)
stopifnot(identical(md$cell,colnames(cnt)))
rownames(md)<-md$cell
obj<-CreateSeuratObject(cnt,meta.data=md[,setdiff(colnames(md),"cell")],min.cells=0,min.features=0)
rm(cnt);gc()
# 冻结 reduction
lat<-readRDS(file.path(H,"integration/harmony_biology_preserving_hvg3000_theta0p5_seed41.latent.rds"))
hm<-lat$latent; rownames(hm)<-lat$cell; hm<-hm[colnames(obj),]; colnames(hm)<-paste0("harmony_",1:ncol(hm))
obj[["harmony"]]<-CreateDimReducObject(embeddings=hm,key="harmony_",assay="RNA")
um<-as.matrix(md[,c("UMAP_1","UMAP_2")]); rownames(um)<-md$cell; colnames(um)<-c("umap_1","umap_2")
obj[["umap"]]<-CreateDimReducObject(embeddings=um,key="umap_",assay="RNA")
obj<-NormalizeData(obj,verbose=FALSE)
Idents(obj)<-"atomic_cluster_id"
log("对象就绪: ",ncol(obj)," 细胞, ",length(levels(obj))," 簇")
saveRDS(obj,file.path(W,"S2_seurat_frozen.rds"))
log("已存 rds")

# ---- FindAllMarkers, Xing 2025 参数 ----
t0<-Sys.time()
mk<-FindAllMarkers(obj,only.pos=TRUE,min.pct=0.2,logfc.threshold=0.25,max.cells.per.ident=200,
                   assay="RNA",slot="data",test.use="wilcox",verbose=FALSE,random.seed=42)
log("FindAllMarkers 完成 ",nrow(mk)," 行, 用时 ",round(as.numeric(difftime(Sys.time(),t0,units="mins")),1)," min")
fwrite(mk,file.path(W,"S2_findallmarkers_xing.csv"))

# ---- 检出率证据 (全细胞) ----
panel<-readLines(file.path(D,"scripts/canonical_panel.txt")); panel<-unique(trimws(panel[panel!="" & !grepl("^#",panel)]))
top<-mk%>%group_by(cluster)%>%arrange(p_val_adj,desc(avg_log2FC))%>%slice_head(n=40)%>%pull(gene)
genes<-unique(c(panel,top)); genes<-genes[genes%in%rownames(obj)]
log("证据基因数 ",length(genes)," (panel 命中 ",sum(panel%in%rownames(obj)),"/",length(panel),")")
X<-GetAssayData(obj,assay="RNA",layer="counts")[genes,]
det<-X; det@x[]<-1   # 检出指示
cl<-obj$atomic_cluster_id; pt<-obj$patient_id
grp<-paste(cl,pt,sep="|")
mkG<-function(f){f<-factor(f);sparseMatrix(i=seq_along(f),j=as.integer(f),x=1,dims=c(length(f),nlevels(f)),dimnames=list(NULL,levels(f)))}
Gcp<-mkG(grp); Gc<-mkG(cl); Gp<-mkG(pt)
ncp<-colSums(Gcp); nc<-colSums(Gc); np<-colSums(Gp)
Dcp<-as.matrix(det%*%Gcp); Dc<-as.matrix(det%*%Gc); Dp<-as.matrix(det%*%Gp); Dall<-rowSums(Dc)
# 整体
ov<-data.table(gene=rep(genes,times=ncol(Dc)),atomic_cluster_id=rep(colnames(Dc),each=length(genes)),
  n_cluster=rep(nc,each=length(genes)),pct_cluster=as.vector(Dc)/rep(nc,each=length(genes)),
  pct_rest=(Dall-as.vector(Dc))/(ncol(obj)-rep(nc,each=length(genes))))
# 逐病人
sp<-strsplit(colnames(Dcp),"|",fixed=TRUE); cpc<-sapply(sp,`[`,1); cpp<-sapply(sp,`[`,2)
pp<-data.table(gene=rep(genes,times=ncol(Dcp)),atomic_cluster_id=rep(cpc,each=length(genes)),patient_id=rep(cpp,each=length(genes)),
  n_cluster_patient=rep(ncp,each=length(genes)),
  pct_cluster_patient=as.vector(Dcp)/rep(ncp,each=length(genes)),
  pct_rest_patient=(as.vector(Dp[,cpp])-as.vector(Dcp))/(rep(np[cpp],each=length(genes))-rep(ncp,each=length(genes))))
# 基因在该病人所有样本是否都存在 (gene_absent: 只记缺失)
ga<-fread(file.path(D,"data/gene_absent_per_sample.csv"))
pm<-read.csv(file.path(D,"data/patient_metadata.csv"),stringsAsFactors=FALSE)
ga<-merge(ga,pm[,c("sample","patient_id")],by="sample")
absent_pp<-unique(ga[gene%in%genes,.(gene,patient_id)]); absent_pp[,gene_absent_in_patient:=TRUE]
pp<-merge(pp,absent_pp,by=c("gene","patient_id"),all.x=TRUE); pp[is.na(gene_absent_in_patient),gene_absent_in_patient:=FALSE]
pp[,evaluable:=n_cluster_patient>=20 & !gene_absent_in_patient]
pp[,detection_diff:=pct_cluster_patient-pct_rest_patient]
fwrite(ov,file.path(W,"S2_detection_overall.csv")); fwrite(pp,file.path(W,"S2_detection_per_patient.csv"))

# ---- 簇构成 / QC 表 ----
comp<-obj@meta.data%>%group_by(atomic_cluster_id)%>%summarise(n_cells=n(),
  n_patients_ge20=sum(table(patient_id)>=20), n_patients_any=n_distinct(patient_id),
  median_nCount=median(nCount_RNA),median_nFeature=median(nFeature_RNA),median_pct_mito=median(pct_mito),
  pct_tumor_tissue=round(100*mean(tissue_role=="tumor"),1),
  patient_composition=paste(names(sort(table(patient_id),decreasing=TRUE)),sort(table(patient_id),decreasing=TRUE),sep=":",collapse=";"))
dis<-setNames(pm[["\u75be\u75c5"]],pm$patient_id)[!duplicated(pm$patient_id)]
obj$disease<-unname(dis[as.character(obj$patient_id)])
dcomp<-obj@meta.data%>%group_by(atomic_cluster_id,disease)%>%summarise(n=n(),.groups="drop")%>%
  group_by(atomic_cluster_id)%>%summarise(disease_composition=paste(disease,n,sep=":",collapse=";"))
comp<-left_join(comp,dcomp,by="atomic_cluster_id")
fwrite(comp,file.path(W,"S2_cluster_composition.csv"))
log("S2 完成")
