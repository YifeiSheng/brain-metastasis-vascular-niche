# S3c: 罕见细胞类型 marker 全局扫描 —— 每个 marker 集合, 统计"≥k 个基因检出"的细胞落在哪些簇/病人
import numpy as np, pandas as pd, scanpy as sc, scipy.sparse as sp
D=__import__("os").environ["ANNOTATION_WORKSPACE"]; W=f"{D}/work"
a=sc.read_h5ad(f"{D}/data/sc_counts.h5ad"); X=a.X.tocsc() if not sp.isspmatrix_csc(a.X) else a.X
obs=a.obs; gi={g:i for i,g in enumerate(a.var_names)}
SETS={
 "肥大细胞":(["TPSAB1","TPSB2","CPA3","MS4A2","HDC","KIT"],2),
 "浆细胞":(["JCHAIN","MZB1","SDC1","XBP1","PRDM1","TNFRSF17","IGHG1"],4),
 "pDC":(["LILRA4","CLEC4C","PLD4","PTCRA","IRF7"],3),
 "cDC1":(["CLEC9A","XCR1","BATF3","CADM1","DNASE1L3"],2),
 "cDC2":(["CD1C","FCER1A","CLEC10A","CD1E"],2),
 "mregDC":(["LAMP3","CCR7","FSCN1","CCL19","CCL22","IDO1"],3),
 "朗格汉斯":(["CD207","CD1A"],2),
 "gd_T":(["TRDC","TRGC1","TRGC2","TRDV2","TRGV9"],2),
 "MAIT":(["SLC4A10","KLRB1","ZBTB16","NCR3","IL18R1"],3),
 "Tfh":(["CXCL13","CXCR5","PDCD1","ICOS","BCL6","IL21"],3),
 "Treg":(["FOXP3","IL2RA","CTLA4","IKZF2","TNFRSF4","TNFRSF18"],3),
 "ILC":(["KIT","IL7R","IL1RL1","GATA3","RORC","KLRB1"],4),
 "巨核/血小板":(["PPBP","PF4","GP9","ITGA2B"],2),
 "红细胞":(["HBB","HBA1","HBA2","ALAS2","GYPA"],3),
 "HSPC":(["CD34","SPINK2","KIT"],2),
 "嗜酸/嗜碱":(["CLC","IL5RA","CCR3","GATA1","HDC"],2),
 "星形胶质":(["GFAP","AQP4","SLC1A2","SLC1A3","ALDH1L1","GJA1","SOX9"],4),
 "OPC":(["PDGFRA","CSPG4","PTPRZ1","VCAN","OLIG1","OLIG2","SOX6"],4),
 "神经元":(["SNAP25","SYT1","RBFOX3","SLC17A7","GAD1","GAD2","NRGN","NEFL"],4),
 "室管膜":(["FOXJ1","CCDC153","DNAH11","PIFO","CAPS"],3),
 "脉络丛":(["TTR","CLIC6","KCNJ13","FOLR1","HTR2C"],3),
 "施万":(["MPZ","PMP22","SOX10","NGFR","CDH19","PRX","S100B"],4),
 "淋巴管内皮":(["PROX1","LYVE1","PDPN","CCL21","FLT4"],3),
 "动脉内皮":(["GJA5","SEMA3G","HEY1","BMX","EFNB2","CLDN5"],3),
 "静脉内皮":(["ACKR1","SELE","SELP","VCAM1","NR2F2","VWF"],3),
 "tip_EC":(["ESM1","ANGPT2","APLN","KCNE3","PLVAP","INSR"],3),
 "血脑屏障EC":(["ABCB1","MFSD2A","SLC7A5","SLC2A1","CLDN5"],3),
 "周细胞":(["PDGFRB","RGS5","KCNJ8","ABCC9","NOTCH3","HIGD1B","NDUFA4L2"],4),
 "平滑肌":(["ACTA2","MYH11","TAGLN","CNN1","DES","MYL9"],4),
 "成纤维/CAF":(["COL1A1","COL1A2","COL3A1","DCN","LUM","FAP","POSTN","CTHRC1"],4),
 "脑膜成纤维":(["PTGDS","SLC47A1","CRABP2","DCN","LUM","ALDH1A2","SLC6A13","SLC22A6"],4),
 "纤毛上皮":(["FOXJ1","CAPS","PIFO","TPPP3","DNAH5"],3),
 "簇状tuft":(["POU2F3","TRPM5","AVIL","LRMP","ASCL2","SOX9"],3),
 "离子细胞":(["FOXI1","ASCL3","CFTR"],2),
 "club/分泌":(["SCGB1A1","SCGB3A1","SCGB3A2","MUC5B","BPIFB1"],2),
 "基底/鳞状":(["KRT5","KRT17","TP63","SOX2","KRT6A","KRT14"],3),
 "AT1样":(["AGER","PDPN","HOPX","CAV1","CLIC5","RTKN2"],3),
 "肠样/黏液":(["CDX2","VIL1","LGALS4","TFF1","TFF3","MUC5AC","HNF4A","CDH17"],3),
 "NEUROD1_NE":(["NEUROD1","CHGB","STMN2","NEFL","ADCYAP1","DACH1"],3),
 "POU2F3_NE":(["POU2F3","TRPM5","AVIL","GFI1B","SOX9"],3),
 "YAP1_NE低":(["YAP1","VCAN","HEY1","REST","SOX9","MYC"],4),
 "EMT肿瘤":(["VIM","ZEB1","SNAI2","TWIST1","CDH2","SPARC","TGFBI"],4),
 "干扰素高":(["ISG15","IFI6","IFIT1","IFIT3","MX1","IFI44L","CXCL10"],5),
 "增殖":(["MKI67","TOP2A","CENPF","UBE2C","BIRC5","TYMS"],3),
 "LYVE1_BAM":(["LYVE1","F13A1","FOLR2","MRC1","CD163","SIGLEC1","CD209"],4),
 "小胶质":(["P2RY12","TMEM119","CX3CR1","SALL1","GPR34","SLC2A5","OLFML3"],4),
 "ADAMDEC1巨噬":(["ADAMDEC1","PLA2G7","MMP9","IL4I1","LGALS2","CYP27A1"],3),
 "SPP1_TAM":(["SPP1","GPNMB","TREM2","PLIN2","LGALS3","CTSD"],5),
}
rows=[]; percell={}
for name,(genes,k) in SETS.items():
    g=[x for x in genes if x in gi]
    if len(g)<k: rows.append(dict(set=name,note="基因不足")); continue
    det=(X[:,[gi[x] for x in g]]>0).sum(axis=1).A1
    pos=det>=k; percell[name]=pos
    n=int(pos.sum()); sub=obs[pos]
    cl=sub.atomic_cluster_id.value_counts(); pt=sub.patient_id.value_counts()
    rows.append(dict(set=name,genes_used=";".join(g),k=k,n_pos=n,frac_all=round(n/len(obs),4),
        n_patients_ge5=int((pt>=5).sum()),top_clusters=";".join(f"{i}:{v}" for i,v in cl.head(6).items()),
        patients=";".join(f"{i}:{v}" for i,v in pt.items())))
df=pd.DataFrame(rows); df.to_csv(f"{W}/S3c_rare_marker_scan.csv",index=False)
pd.DataFrame(percell,index=obs.index).to_csv(f"{W}/S3c_rare_marker_percell.csv")
pd.set_option('display.width',260); pd.set_option('display.max_colwidth',90); pd.set_option('display.max_rows',100)
print(df[["set","k","n_pos","n_patients_ge5","top_clusters","patients"]].to_string(index=False))
# 特定簇的特定基因检出率
CHK={"r4_044":["PDGFRA","CSPG4","MPZ","BCAS1","GPR17","TNR","PCDH15","VCAN","MLANA","PMEL","PRX","NGFR","OLIG2","SOX2","GFAP","AQP4","PTPRZ1","SOX6","BCAN","ENPP6","TCF7L2","ITPR2","OPALIN","KLK6","APOD","DCN","LUM","EGFR","CD44"],
     "r4_026":["FOXP3","IL2RA","IKZF2","RTKN2","CCR8","TNFRSF9"],
     "r4_018":["TRDC","TRGC1","TRGC2","TRDV2","TRGV9","TRDV1","KLRF1","NCAM1","FCGR3A","CD3E","CD3D","TRAC","XCL1","KLRC1","ITGAE","ZNF683","CD8A"],
     "r4_010":["SLC4A10","KLRB1","RORC","CXCR5","CCR7","SELL","TCF7","LEF1","CXCL13","IL17A","CCR6","IL22","CD40LG","GZMK","ANXA1","AQP3","TRAV1-2"],
     "r4_053":["TPSAB1","CPA3","KIT","MS4A2","CLEC9A","XCR1","BATF3","LAMP3","CCR7","CD207","CD1A","CLEC10A","CD1C","FCER1A","IDO1","CCL19","CCL22","AXL","SIGLEC6","PPP1R14A"],
     "r4_051":["ACKR1","SELE","VCAM1","GJA5","SEMA3G","BMX","HEY1","ESM1","ANGPT2","PLVAP","APLN","ABCB1","MFSD2A","SLC7A5","PROX1","CCL21","LYVE1","CA4","RGCC","KDR","PGF","COL4A1","SPARC","MKI67"],
     "r4_048":["PDGFRB","RGS5","KCNJ8","ABCC9","HIGD1B","NDUFA4L2","ACTA2","MYH11","TAGLN","DES","COL1A1","COL1A2","DCN","LUM","FAP","POSTN","CTHRC1","PTGDS","SLC47A1","CRABP2","ALDH1A2","SLC6A13","PI16","CXCL12","MKI67","SFRP2"],
     "r4_004":["LYVE1","F13A1","FOLR2","CD209","SIGLEC1","MRC1","CD163","MARCO","FABP4","PPARG","SPP1","TREM2","GPNMB","P2RY12","TMEM119","MKI67","CCL18","APOC1","C3","CX3CR1"],
     "r4_014":["ASCL1","NEUROD1","POU2F3","YAP1","DLL3","INSM1","CHGA","GRP","CALCA","SYP","MKI67","HES1","HEY1","REST","VIM","SOX9","MYC","MYCL","MYCN","KRT8","EPCAM"],
     "r4_060":["ASCL1","NEUROD1","POU2F3","YAP1","HES1","HEY1","NOTCH1","NOTCH2","REST","VIM","SOX9","VCAN","MYC","MYCL","EPCAM","KRT8","CDH1","CDH2","COL1A1","TSPAN8","KRT19"],
     "r4_057":["IGKC","IGLC1","IGLC2","IGLC3","IGLC7","IGHM","IGHD","IGHG1","IGHA1","MS4A1","CD79A","XIST"],
     "r4_037":["IGKC","IGLC2","IGLC3","IGHM","IGHD","AICDA","BCL6","MME","LMO2","IRF4","PRDM1","XBP1","JCHAIN","CCR7","CD1C","FCRL4","ITGAX","TBX21","ZEB2","CD27"],
     "r4_003":["IGKC","IGLC2","IGHM","IGHD","IGHG1","BCL6","MME","LMO2","MYC","IRF4","PRDM1","CD8B","CD1C","AICDA","CCND1","SOX11","TCL1A","FCRL5"],
     "r4_020":["IGKC","IGLC2","IGHM","IGHD","BCL6","MME","LMO2","JCHAIN","CD27","IRF4","PRDM1","TCL1A","FCER2","CCR7","SELL","CD1C","XBP1"],
     "r4_034":["MT-CO1","MT-ND1","MALAT1","NEAT1","EPCAM","INSM1","MKI67","NCAM1"],
     "r4_001":["IGKC","IGLC2","IGHM","MS4A1","CD79A","CD74","HLA-DRA","PTPRC","MALAT1","MT-CO1","EPCAM","PLP1"],
     "r4_036":["PLP1","MBP","MOG","MAG","S100B","PTGDS","CRYAB","MT-CO1","MALAT1","PTPRC","SNAP25","GFAP"]}
out=[]
for cl,genes in CHK.items():
    m=(obs.atomic_cluster_id==cl).values
    for g in genes:
        if g not in gi: out.append(dict(cluster=cl,gene=g,pct_cluster=np.nan,pct_rest=np.nan)); continue
        col=(X[:,gi[g]]>0).toarray().ravel()
        out.append(dict(cluster=cl,gene=g,pct_cluster=round(col[m].mean(),3),pct_rest=round(col[~m].mean(),3)))
chk=pd.DataFrame(out); chk.to_csv(f"{W}/S3c_specific_gene_checks.csv",index=False)
for cl,sub in chk.groupby("cluster",sort=False):
    print(f"\n{cl}: "+", ".join(f"{r.gene} {r.pct_cluster}/{r.pct_rest}" for r in sub.itertuples()))
