# S4b: 子簇特征摘要 —— 每个子簇 vs 父簇其余细胞 的检出率差 (全细胞), 构成, Scrublet
import pandas as pd, numpy as np, scanpy as sc, scipy.sparse as sp, sys
D=__import__("os").environ["ANNOTATION_WORKSPACE"]; W=f"{D}/work"
RES=sys.argv[1] if len(sys.argv)>1 else "res0.5"
a=sc.read_h5ad(f"{D}/data/sc_counts.h5ad"); X=sp.csr_matrix(a.X); obs=a.obs.copy()
sub=pd.read_csv(f"{W}/S4_subclusters_frozen_graph.csv").set_index("cell")
scr=pd.read_csv(f"{W}/S1_scrublet_per_cell.csv",index_col=0)
pm=pd.read_csv(f"{D}/data/patient_metadata.csv"); dis=dict(zip(pm.patient_id,pm["疾病"]))
obs["disease"]=obs.patient_id.map(dis)
panel=[g for g in open(f"{D}/scripts/canonical_panel.txt").read().split() if g in a.var_names]
gi={g:i for i,g in enumerate(a.var_names)}
mito=[g for g in a.var_names if g.startswith("MT-")]
# 候选基因: panel + 高变? 用 panel + 每个父簇内检出率>0.05 的所有基因 (为发现新 marker)
lines=[]; tab=[]
for parent,grp in sub.groupby("atomic_cluster_id"):
    cells=grp.index; idx=obs.index.get_indexer(cells); Xp=X[idx]; det=(Xp>0).astype(np.float32)
    keep=np.asarray(det.mean(axis=0)).ravel()>0.05; genes=a.var_names[keep]; det=det[:,keep]
    lab=grp[RES].values; ul=sorted(set(lab),key=lambda s:int(s.split(".")[-1]))
    lines.append(f"\n{'#'*90}\n# 父簇 {parent}  n={len(cells)}  {RES}: {len(ul)} 个子簇  (子簇大小: "+", ".join(f"{u}={int((lab==u).sum())}" for u in ul)+")")
    for u in ul:
        m=lab==u; n=int(m.sum())
        if n<10: lines.append(f"  {u}: n={n} (<10, 略)"); continue
        pin=np.asarray(det[m].mean(axis=0)).ravel(); pout=np.asarray(det[~m].mean(axis=0)).ravel() if (~m).sum()>0 else np.zeros_like(pin)
        diff=pin-pout; order=np.argsort(-diff)
        top=[(genes[i],pin[i],pout[i]) for i in order[:25] if diff[i]>0.15]
        o=obs.loc[cells[m]]; pt=o.patient_id.value_counts(); ds=o.disease.value_counts()
        s=scr.loc[cells[m]]
        # panel 阳性
        pidx=[list(genes).index(g) for g in panel if g in set(genes)]
        pan=sorted([(genes[i],pin[i],pout[i]) for i in pidx if pin[i]>0.3 and pin[i]-pout[i]>0.15],key=lambda x:-(x[1]-x[2]))[:25]
        lines.append(f"\n  ## {u}  n={n}  病人≥20:{int((pt>=20).sum())}  UMI中位={int(o.nCount_RNA.median())} 线粒体={o.pct_mito.median():.1f}%  瘤占比={100*(o.tissue_role=='tumor').mean():.0f}%  Scrublet中位={s.scrublet_score.median():.3f} 双胞比例={s.scrublet_pred.mean():.3f}")
        lines.append("     病人: "+";".join(f"{k}:{v}" for k,v in pt.items() if v>0)+"   疾病: "+";".join(f"{k}:{v}" for k,v in ds.items() if v>0))
        lines.append("     top 差异(vs 父簇其余, gene in/out): "+", ".join(f"{g} {x:.2f}/{y:.2f}" for g,x,y in top))
        lines.append("     panel 阳性: "+", ".join(f"{g} {x:.2f}/{y:.2f}" for g,x,y in pan))
        tab.append(dict(parent=parent,subcluster=u,resolution=RES,n=n,n_patients_ge20=int((pt>=20).sum()),patients=";".join(f"{k}:{v}" for k,v in pt.items() if v>0),
            disease=";".join(f"{k}:{v}" for k,v in ds.items() if v>0),median_umi=int(o.nCount_RNA.median()),scrublet_median=round(s.scrublet_score.median(),3),scrublet_pred_frac=round(s.scrublet_pred.mean(),3),
            top_markers=";".join(f"{g}({x:.2f}/{y:.2f})" for g,x,y in top[:15])))
open(f"{W}/S4b_subcluster_digest_{RES}.txt","w").write("\n".join(lines)); pd.DataFrame(tab).to_csv(f"{W}/S4b_subcluster_table_{RES}.csv",index=False)
print("written",len(tab))
