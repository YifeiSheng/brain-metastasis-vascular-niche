# S5: 罕见细胞类型候选 —— 定义(冻结图子簇/atomic 簇)、跨病人/跨癌种分布、marker 检出率(候选 vs 其余全部细胞, 逐病人), 冻结 UMAP 图
import pandas as pd, numpy as np, scanpy as sc, scipy.sparse as sp, matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
for _f in ["/home/researcher/.fonts/NotoSansCJKsc-Regular.otf","/usr/share/fonts/google-droid-sans-fonts/DroidSansFallbackFull.ttf"]:
    try: font_manager.fontManager.addfont(_f)
    except Exception: pass
plt.rcParams["font.family"]=["Noto Sans CJK SC","Droid Sans Fallback","DejaVu Sans"]; plt.rcParams["axes.unicode_minus"]=False
D=__import__("os").environ["ANNOTATION_WORKSPACE"]; W=f"{D}/work"; O=f"{D}/output"; F=f"{O}/figures"
a=sc.read_h5ad(f"{D}/data/sc_counts.h5ad"); X=sp.csc_matrix(a.X); obs=a.obs.copy(); gi={g:i for i,g in enumerate(a.var_names)}
sub=pd.read_csv(f"{W}/S4_subclusters_frozen_graph.csv").set_index("cell")
obs["sub05"]=sub["res0.5"].reindex(obs.index)
pm=pd.read_csv(f"{D}/data/patient_metadata.csv"); dis=dict(zip(pm.patient_id,pm["疾病"])); obs["disease"]=obs.patient_id.map(dis)
ann=pd.read_csv(f"{O}/cluster_annotation.csv").set_index("atomic_cluster_id"); obs["lineage_l1"]=obs.atomic_cluster_id.map(ann.lineage_l1)
def col(g): return (X[:,gi[g]]>0).toarray().ravel()
def cells_of(clusters=(),subs=(),marker_all=None):
    m=obs.atomic_cluster_id.isin(clusters).values | obs.sub05.isin(subs).values
    if marker_all: m=np.ones(len(obs),bool); 
    if marker_all:
        for g in marker_all: m&=col(g)
    return m
# 候选定义: 名称, 定义方式, marker 列表(用于验证/检出率), 蛋白验证建议
C=[
 ("肥大细胞",dict(subs=["r4_053.2"]),["TPSAB1","TPSB2","CPA3","KIT","MS4A2","HDC","GATA2","IL1RL1","HPGDS"],"类胰蛋白酶(tryptase)/CD117(KIT) 免疫组化或 IHC 双染"),
 ("肥大细胞(marker 定义: TPSAB1 与 CPA3 共检出, 不限簇)",dict(marker_all=["TPSAB1","CPA3"]),["TPSAB1","TPSB2","CPA3","KIT","MS4A2","HDC","GATA2"],"同上；用于估计各病人真实肥大细胞数"),
 ("浆细胞样树突状细胞 pDC",dict(clusters=["r4_055"]),["LILRA4","CLEC4C","PLD4","IL3RA","JCHAIN","IRF7","TCF4","PTCRA","GZMB"],"CD123(IL3RA)/BDCA2(CLEC4C)/TCF4"),
 ("成熟调节型树突状细胞 mregDC",dict(subs=["r4_053.1"]),["LAMP3","CCR7","CCL19","CCL22","FSCN1","IDO1","BIRC3","CD274","PDCD1LG2","CD80","CD83"],"LAMP3(DC-LAMP)/CCR7 双染；PD-L1"),
 ("经典 2 型树突状细胞 cDC2",dict(subs=["r4_053.3"]),["CD1C","CLEC10A","FCER1A","CD1E","HLA-DQA2","CLEC4A","IL1B"],"CD1c/CLEC10A"),
 ("经典 1 型树突状细胞 cDC1(marker 定义: CLEC9A 与 XCR1 共检出)",dict(marker_all=["CLEC9A","XCR1"]),["CLEC9A","XCR1","BATF3","CADM1","IRF8","CPVL"],"CLEC9A/XCR1；数量极少，先确认是否存在"),
 ("γδ 型/细胞毒 T 细胞(CD3+/TRGC2+/CD8A+ 活化)",dict(subs=["r4_018.4"]),["CD3D","CD3E","TRGC2","TRDC","TRGV9","TRDV1","TRDV2","CD8A","VCAM1","CTLA4","LAG3","PDCD1","CRTAM","IRF4"],"TCRδ(TRDC)/TCRγ 免疫组化 + CD3；流式 Vδ1/Vδ2"),
 ("组织驻留 NK/ILC1 样(KLRB1+/ZNF683+/XCL2+)",dict(subs=["r4_018.3"]),["KLRB1","ZNF683","XCL2","XCL1","KLRC1","TRDC","ITGAE","CD3E","NCAM1","FCGR3A","GNLY"],"CD161(KLRB1)/Hobit(ZNF683)/CD103；P1 私有，需先在其他病人中找"),
 ("NK 细胞(KLRC1+/KIR2DL4+ 干扰素反应型)",dict(subs=["r4_018.2"]),["KLRD1","KLRC1","KIR2DL4","GNLY","NKG7","TRDC","FCGR3A","MX1","IFI44L","ISG15","TNFRSF18"],"NKG2A(KLRC1)/CD56/CD16"),
 ("边界相关巨噬 BAM(LYVE1/CD209/COLEC12/F13A1+)",dict(subs=["r4_004.2","r4_004.5"]),["LYVE1","CD209","COLEC12","F13A1","FOLR2","MRC1","CD163","SIGLEC1","CD93","THBD","PDPN","MARCO"],"LYVE1/CD206(MRC1)/CD163 三染；CD209"),
 ("干扰素反应巨噬(GBP4/5+/CXCL9/10+/IFI44L+)",dict(subs=["r4_004.4","r4_031.3"]),["GBP4","GBP5","CXCL9","CXCL10","IFI44L","IFIT3","SLAMF7","TNFSF10","CD38","CD163","CD14"],"CXCL9/CXCL10 RNAscope 或 GBP5；CD68 共染"),
 ("ADAMDEC1+ 巨噬(LGALS2/MMP9/IL4I1/CYP27A1+)",dict(clusters=["r4_065"]),["ADAMDEC1","LGALS2","MMP9","IL4I1","CYP27A1","RARRES1","PLA2G7","PLA2G2D","GPNMB","CD14","CD163"],"ADAMDEC1/MMP9 + CD68；P4 私有"),
 ("稳态小胶质(P2RY12+/CX3CR1+/SALL1+)",dict(subs=["r4_042.3","r4_025.1"]),["P2RY12","CX3CR1","TMEM119","SALL1","GPR34","P2RY13","SLC2A5","OLFML3","CSF1R","ENTPD1"],"P2RY12/TMEM119 免疫组化"),
 ("活化小胶质(IL1B+/CCL3+/CCL4+/ATF3+)",dict(subs=["r4_042.2","r4_025.4"]),["P2RY12","GPR34","IL1B","CCL3","CCL4","ATF3","KLF4","NR4A1","HSPA1B","CD83"],"P2RY12 + IL1B/CCL3 RNAscope"),
 ("活化调节性 T 细胞(FOXP3+/TNFRSF9+/LAYN+/IL2RA+)",dict(subs=["r4_026.2","r4_026.4"]),["FOXP3","IL2RA","TNFRSF9","LAYN","IKZF2","CTLA4","TNFRSF4","TNFRSF18","ICOS","TIGIT","CCR8","MKI67"],"FOXP3/CD25 + 4-1BB(TNFRSF9) 或 CCR8"),
 ("CXCL13+ CD4 T(Tfh/Tph 样)",dict(subs=["r4_026.3"]),["CXCL13","CD4","IFNG","KLRB1","CCL5","GZMA","PDCD1","ICOS","CD3E","CD8A"],"CXCL13 RNAscope + CD4；PD-1"),
 ("CXCL13+ 耗竭样 CD8 T(TNFRSF9+/ENTPD1+/MIR155HG+)",dict(subs=["r4_011.1"]),["CXCL13","CD8A","TNFRSF9","TNFRSF18","ENTPD1","LAG3","HAVCR2","PDCD1","CTLA4","CCND2","MIR155HG","GZMB"],"CD8 + CXCL13/PD-1/CD39(ENTPD1)"),
 ("细胞毒 CD4 T(GZMA+/CCL5+/NKG7+)",dict(subs=["r4_010.3"]),["CD4","CD3E","GZMA","GZMH","GZMB","CCL5","NKG7","GNLY","PRF1","CD8A","IL7R"],"CD4 + Granzyme A/K；需排除 CD8"),
 ("Tfh/Th2 样 CD4 T(MAF+/ICOS+/CCR4+)",dict(subs=["r4_010.4"]),["MAF","ICOS","CCR4","IL6ST","CD28","TNFRSF4","CD4","GATA3","IL4R","CXCR5","BCL6"],"CD4 + c-MAF/ICOS"),
 ("干扰素反应 T 细胞(IFIT1+/RSAD2+/IFI44L+)",dict(subs=["r4_008.3"]),["IFIT1","IFIT3","RSAD2","IFI44L","MX1","ISG15","CD3E","CD8A","GNLY"],"MX1 + CD3；P2 私有"),
 ("增殖 T/NK 细胞",dict(clusters=["r4_043"]),["MKI67","TOP2A","CD3E","CD8A","GZMB","NKG7","KLRD1","EOMES"],"Ki-67 + CD3/CD8"),
 ("血管周细胞/平滑肌(CSPG4+/NOTCH3+/RGS5+/KCNJ8+)",dict(subs=["r4_048.1"]),["CSPG4","NOTCH3","RGS5","PDGFRB","KCNJ8","ABCC9","HIGD1B","MCAM","ACTA2","TAGLN","MYH11","NDUFA4L2"],"PDGFRβ/NG2(CSPG4)/αSMA"),
 ("成纤维细胞(DCN+/LUM+/COL1A2+/PDGFRB+)",dict(subs=["r4_048.4","r4_048.5"]),["DCN","LUM","COL1A1","COL1A2","COL3A1","PDGFRB","FBLN1","PRRX1","CTHRC1","POSTN","FAP","PTGDS","CXCL8"],"胶原 I/DCN；FAP/POSTN 判 CAF"),
 ("内皮细胞(CDH5+/KDR+/CD34+/ABCB1+ 血脑屏障型)",dict(subs=["r4_051.1"]),["PECAM1","CDH5","KDR","CD34","CLDN5","VWF","ABCB1","MFSD2A","SLC2A1","ACKR1","PLVAP","ANGPT2","ESM1","CA4"],"CD31/CD34；ACKR1 静脉、PLVAP 活化"),
 ("NEUROD1+ 神经内分泌肿瘤亚群(CHGB+/STMN2+/NEFL+)",dict(clusters=["r4_064"]),["NEUROD1","ASCL1","CHGB","STMN2","NEFL","ADCYAP1","DACH1","CHGA","INSM1","EPCAM","KRT8","DLL3"],"NEUROD1 与 ASCL1 免疫组化双染；仅 P3"),
 ("NE 低/Notch 活化神经内分泌肿瘤(HEY1+/HES1+/SOX9+/VCAN+)",dict(clusters=["r4_060"]),["HEY1","HES1","SOX9","VCAN","TSPAN8","NOTCH2","REST","CHGA","INSM1","ASCL1","EPCAM","KRT8","YAP1","MYCL"],"HES1/SOX9 + 低 INSM1/CHGA；仅 P3"),
 ("OPC 样程序+上皮 marker 共阳(PDGFRA+/PTPRZ1+/FABP7+/FOXG1+/EPCAM+)",dict(subs=["r4_044.4"]),["PDGFRA","PTPRZ1","FABP7","FOXG1","SOX6","HEY1","VCAN","NRXN1","GFAP","EPCAM","KRT8","KRT18","SOX2","OLIG2"],"PDGFRα/OLIG2 + EPCAM/KRT 共染，判断是肿瘤还是胶质"),
 ("未成熟少突胶质(BCAS1+/SOX2+/OLIG2+，髓鞘基因低)",dict(subs=["r4_044.1","r4_044.2"]),["BCAS1","SOX2","OLIG2","NGFR","KLK6","APOD","PLP1","MOG","MAG","MBP","PDGFRA","ATF4","NKX6-2"],"BCAS1/OLIG2；与 MOG 比较"),
 ("EMT 样肺腺癌细胞(SPARC+/LOX+/SERPINE1+/COL1A2+)",dict(subs=["r4_052.3"]),["SPARC","LOX","SERPINE1","COL1A2","VCAN","CAV1","VIM","EPCAM","KRT8","KRT18","NKX2-1","SFTPB","CDH1","CDH2","ZEB1"],"仅 14 个细胞(P1)；需 EPCAM/KRT + VIM/SPARC 共染验证"),
 ("黏液/分泌型肺腺癌细胞(MUC5B+/TFF3+/AGR2+/CEACAM5+)",dict(clusters=["r4_058"],subs=["r4_052.2"]),["MUC5B","TFF3","AGR2","CEACAM5","CEACAM6","LCN2","MUC1","FOLR1","NAPSA","NKX2-1","SFTPB","KRT7"],"MUC5B/TFF3 免疫组化；P1 与 P5 均有"),
 ("λ 轻链限制 B 细胞(IGLC2+/IGLC7+，IGKC−)",dict(clusters=["r4_057"]),["IGLC2","IGLC3","IGLC7","IGKC","IGHM","MS4A1","CD79A","TCL1A"],"κ/λ 原位杂交；克隆性"),
 ("PRDM1+ 浆母样 B 细胞(PRDM1+/SELL+/CCR7+/IGLC6+)",dict(subs=["r4_037.1"]),["PRDM1","XBP1","IRF4","SELL","CCR7","IGLC6","IGLC7","MS4A1","CD19","JCHAIN","TNFRSF17","MNDA"],"BLIMP1(PRDM1)/CD20 双染；P6 私有"),
 ("经典单核细胞(FCN1+/S100A12+/SELL+/TREM1+)",dict(subs=["r4_031.4","r4_031.1"]),["FCN1","S100A12","S100A8","S100A9","SELL","TREM1","IL1R1","CD14","VCAN","LYZ","FCGR3A"],"CD14 + S100A12；血源性单核"),
 ("脂质相关肿瘤相关巨噬(SPP1+/GPNMB+/TREM2+/PLIN2+)",dict(clusters=["r4_063","r4_046"],subs=["r4_031.2"]),["SPP1","GPNMB","TREM2","PLIN2","LGALS3","CTSD","MSR1","CD163","MRC1","APOE","APOC1","SDS"],"TREM2/GPNMB + CD68"),
]
rows=[]; mrows=[]; masks={}
for name,df,markers,val in C:
    m=cells_of(**df); masks[name]=m; n=int(m.sum()); o=obs[m]
    pt=o.patient_id.value_counts(); ds=o.disease.value_counts()
    d=dict(candidate=name,definition=";".join(df.get("clusters",[]))+("|"+";".join(df.get("subs",[])) if df.get("subs") else "")+("|marker:"+"&".join(df.get("marker_all",[])) if df.get("marker_all") else ""),
           n_cells=n,frac_of_all=round(n/len(obs),5),n_patients_ge5=int((pt>=5).sum()),n_patients_ge20=int((pt>=20).sum()),
           patients=";".join(f"{k}:{v}" for k,v in pt.items() if v>0),
           肺腺癌=int(ds.get("肺腺癌",0)),A型小细胞肺癌=int(ds.get("A型小细胞肺癌",0)),弥漫大B细胞淋巴瘤=int(ds.get("弥漫大B细胞淋巴瘤",0)),
           pct_tumor_tissue=round(100*(o.tissue_role=="tumor").mean(),1) if n else np.nan,median_umi=int(o.nCount_RNA.median()) if n else np.nan,
           validation_suggestion=val)
    good=[]
    for g in markers:
        if g not in gi: continue
        c=col(g); pin=c[m].mean() if n else np.nan; pout=c[~m].mean()
        r=dict(candidate=name,gene=g,pct_in=round(pin,3),pct_out=round(pout,3),diff=round(pin-pout,3),specific=bool(pin>0.5 and pout<0.05))
        for p in ["P1","P2","P3","P4","P5","P6","P7"]:
            mp=m&(obs.patient_id==p).values
            r[f"pct_in_{p}"]=round(c[mp].mean(),3) if mp.sum()>=5 else np.nan
            r[f"n_{p}"]=int(mp.sum())
        mrows.append(r)
        if r["specific"]: good.append(f"{g}({pin:.2f}/{pout:.3f})")
    d["specific_markers(pct_in/pct_out; in>0.5 & out<0.05)"]=";".join(good)
    rows.append(d)
cand=pd.DataFrame(rows); cand.to_csv(f"{O}/rare_cell_candidates.csv",index=False)
mk=pd.DataFrame(mrows); mk.to_csv(f"{O}/rare_cell_markers.csv",index=False)
pd.set_option('display.width',300); pd.set_option('display.max_colwidth',120); pd.set_option('display.max_rows',100)
print(cand[["candidate","n_cells","n_patients_ge5","n_patients_ge20","patients","肺腺癌","A型小细胞肺癌","弥漫大B细胞淋巴瘤","specific_markers(pct_in/pct_out; in>0.5 & out<0.05)"]].to_string(index=False))
# ---------- 图 ----------
import os; os.makedirs(F,exist_ok=True)
u1,u2=obs.UMAP_1.values,obs.UMAP_2.values
def base(ax): ax.scatter(u1,u2,s=0.3,c="#dddddd",linewidths=0,rasterized=True); ax.set_xticks([]);ax.set_yticks([]);ax.set_aspect("equal")
# 1) 谱系
lins=sorted(obs.lineage_l1.dropna().unique()); cmap=plt.get_cmap("tab10")
fig,ax=plt.subplots(figsize=(9,8)); base(ax)
for i,l in enumerate(lins):
    m=(obs.lineage_l1==l).values; ax.scatter(u1[m],u2[m],s=0.5,c=[cmap(i)],linewidths=0,label=f"{l} ({m.sum()})",rasterized=True)
ax.legend(markerscale=12,fontsize=8,loc="best"); ax.set_title("冻结 UMAP：一级谱系（本次独立注释）",fontsize=11)
fig.savefig(f"{F}/umap_lineage_l1.png",dpi=160,bbox_inches="tight"); plt.close(fig)
# 2) atomic 簇编号
fig,ax=plt.subplots(figsize=(11,10)); base(ax)
cl=obs.atomic_cluster_id.astype(str).values; ucl=sorted(set(cl)); cm20=plt.get_cmap("tab20")
for i,c in enumerate(ucl):
    m=cl==c; ax.scatter(u1[m],u2[m],s=0.4,c=[cm20(i%20)],linewidths=0,rasterized=True)
    ax.text(np.median(u1[m]),np.median(u2[m]),c.replace("r4_",""),fontsize=6,ha="center",va="center",bbox=dict(boxstyle="round,pad=0.15",fc="white",ec="none",alpha=0.7))
ax.set_title("冻结 UMAP：68 个 atomic 簇（编号去掉 r4_ 前缀）"); fig.savefig(f"{F}/umap_atomic_clusters.png",dpi=160,bbox_inches="tight"); plt.close(fig)
# 3) 罕见候选高亮 (每图 6 个)
names=[c[0] for c in C]; per=6
for k in range(0,len(names),per):
    grp=names[k:k+per]; fig,axes=plt.subplots(2,3,figsize=(15,10))
    for ax,nm in zip(axes.ravel(),grp):
        base(ax); m=masks[nm]; ax.scatter(u1[m],u2[m],s=3,c="crimson",linewidths=0,rasterized=True)
        ax.set_title(f"{nm}\nn={int(m.sum())}",fontsize=9)
    for ax in axes.ravel()[len(grp):]: ax.axis("off")
    fig.savefig(f"{F}/umap_rare_candidates_{k//per+1}.png",dpi=130,bbox_inches="tight"); plt.close(fig)
# 4) 子簇在同一 UMAP 上 (关键父簇)
for parent in ["r4_053","r4_018","r4_048","r4_004","r4_051","r4_044","r4_026","r4_010","r4_011","r4_025","r4_042","r4_031"]:
    m=(obs.atomic_cluster_id==parent).values; labs=obs.sub05[m].astype(str).values; ul=sorted(set(labs),key=lambda s:int(s.split(".")[-1]))
    fig,axes=plt.subplots(1,2,figsize=(14,6.5))
    for ax in axes: base(ax)
    for i,s in enumerate(ul):
        mm=m.copy(); mm[m]=labs==s
        for ax in axes: ax.scatter(u1[mm],u2[mm],s=4,c=[cmap(i)],linewidths=0,label=f"{s} ({mm.sum()})",rasterized=True)
    x0,x1=np.percentile(u1[m],[1,99]); y0,y1=np.percentile(u2[m],[1,99]); pad=max(x1-x0,y1-y0)*0.25
    axes[1].set_xlim(x0-pad,x1+pad); axes[1].set_ylim(y0-pad,y1+pad); axes[1].set_title("局部放大（坐标不变）")
    axes[0].set_title(f"{parent} 冻结 SNN 图子聚类（res 0.5），画在全局冻结 UMAP 上"); axes[1].legend(markerscale=5,fontsize=8)
    fig.savefig(f"{F}/umap_subclusters_{parent}.png",dpi=130,bbox_inches="tight"); plt.close(fig)
# 保存逐细胞标签
obs[["sample","patient_id","tissue_role","atomic_cluster_id","sub05","lineage_l1","UMAP_1","UMAP_2"]].assign(proposed_label=obs.atomic_cluster_id.map(ann.proposed_label)).to_csv(f"{O}/per_cell_labels.csv")
print("figures done")
