Sys.setlocale("LC_CTYPE","C.UTF-8")
# S4: 在【冻结的 k30 SNN 图】上对指定 atomic 簇做子聚类 (Seurat::FindSubCluster 的做法:
#     取既有图的诱导子图跑 Leiden), 不重算 PCA/Harmony/邻居/UMAP, 因此子簇天然落在冻结 UMAP 上。
# 输入: scripts/S4_subcluster_targets.csv  (atomic_cluster_id, resolution)
Sys.setenv(OPENBLAS_NUM_THREADS="8",OMP_NUM_THREADS="8",MKL_NUM_THREADS="8")
suppressPackageStartupMessages({library(Seurat);library(Matrix);library(igraph);library(data.table);library(dplyr)})
set.seed(42)
D<-Sys.getenv("ANNOTATION_WORKSPACE"); stopifnot(nzchar(D))
W<-file.path(D,"work"); PROG<-file.path(D,"logs/S4_progress.txt")
log<-function(...){con<-file(PROG,open="a");writeLines(paste0(format(Sys.time(),"[%H:%M:%S] "),paste0(...,collapse="")),con);close(con)}
options(error=function(){con<-file(PROG,open="a");writeLines(c("!!! ERROR",capture.output(traceback(3))),con);close(con);quit(status=1)})
H<-file.path(Sys.getenv("FROZEN_REFERENCE"),"graph/v2_2_selected_graph_grid/snn_matrix_v2_2.rds")
tg<-fread(file.path(D,"scripts/S4_subcluster_targets.csv"))
md<-fread(file.path(D,"data/cell_metadata.csv"))
snn<-readRDS(H)$snn
log("SNN ",nrow(snn)," 细胞, nnz ",length(snn@x))
out<-list()
for(i in seq_len(nrow(tg))){
  cl<-tg$atomic_cluster_id[i]; res<-tg$resolution[i]
  cells<-md$cell[md$atomic_cluster_id==cl]
  g<-snn[cells,cells]; diag(g)<-0
  gr<-graph_from_adjacency_matrix(g,mode="undirected",weighted=TRUE,diag=FALSE)
  memb<-list()
  for(r in as.numeric(strsplit(as.character(res),";")[[1]])){
    cm<-cluster_leiden(gr,objective_function="modularity",weights=E(gr)$weight,resolution=r,n_iterations=4)
    m<-unname(membership(cm)); memb[[paste0("res",r)]]<-m
    log(cl," res=",r," -> ",length(unique(m))," 子簇, 最小 ",min(table(m)))
  }
  df<-data.table(cell=cells,atomic_cluster_id=cl); for(n in names(memb)) df[[n]]<-paste0(cl,".",memb[[n]])
  out[[cl]]<-df
}
res<-rbindlist(out,fill=TRUE); fwrite(res,file.path(W,"S4_subclusters_frozen_graph.csv"))
log("S4 完成")
