# S3b: 规则引擎 —— 用 S2 的逐病人检出率证据对人工指认的 core marker 做跨病人门槛判定 (PROMPT §三 S4)
import pandas as pd, numpy as np
D=__import__("os").environ["ANNOTATION_WORKSPACE"]; W=f"{D}/work"; O=f"{D}/output"
tab=pd.DataFrame([l.rstrip("\n").split("|") for l in open(f"{D}/scripts/S3b_assignment_table.csv")][1:],
    columns=["atomic_cluster_id","lineage_l1","proposed_label","core_markers","supporting_markers","override","notes"])
comp=pd.read_csv(f"{W}/S2_cluster_composition.csv").set_index("atomic_cluster_id")
ov=pd.read_csv(f"{W}/S2_detection_overall.csv"); ov["diff"]=ov.pct_cluster-ov.pct_rest
pp=pd.read_csv(f"{W}/S2_detection_per_patient.csv")
mk=pd.read_csv(f"{W}/S2_findallmarkers_xing.csv")
ct=pd.read_csv(f"{W}/S1_celltypist_cluster_summary.csv"); ph=pd.read_csv(f"{W}/S1b_panhumanpy_cluster_summary.csv").set_index("atomic_cluster_id")
scr=pd.read_csv(f"{W}/S1_scrublet_per_cell.csv",index_col=0).groupby("atomic_cluster_id").agg(scrublet_median=("scrublet_score","median"),scrublet_pred_frac=("scrublet_pred","mean")).round(3)
PATIENTS=["P1","P2","P3","P4","P5","P6","P7"]
cm=pd.read_csv(f"{D}/data/cell_metadata.csv",usecols=["cell","patient_id","atomic_cluster_id"])
lin=dict(zip(tab.atomic_cluster_id,tab.lineage_l1)); cm["lineage"]=cm.atomic_cluster_id.map(lin)
def same_lineage_frac(cl,p):
    sub=cm[(cm.patient_id==p)&(cm.atomic_cluster_id!=cl)]
    return round(float((sub.lineage==lin[cl]).mean()),2) if len(sub) else np.nan
ovi=ov.set_index(["atomic_cluster_id","gene"]); ppi=pp.set_index(["atomic_cluster_id","gene","patient_id"])
rows=[]; ev=[]
for r in tab.itertuples():
    cl=r.atomic_cluster_id; c=comp.loc[cl]; core=[g for g in r.core_markers.split(";") if g]; sup=[g for g in r.supporting_markers.split(";") if g]
    core_res=[]; allmin=[]; 
    for g in core+sup:
        role="core" if g in core else "supporting"
        if (cl,g) not in ovi.index: ev.append(dict(atomic_cluster_id=cl,gene=g,marker_role=role,note="基因不在证据表")); continue
        o=ovi.loc[(cl,g)]; d=dict(atomic_cluster_id=cl,gene=g,marker_role=role,pct_cluster=round(o.pct_cluster,3),pct_rest=round(o.pct_rest,3),detection_diff=round(o["diff"],3),
                  rest_too_high=bool(o.pct_rest>0.6))
        n_eval=0; fails=[]; mins=[]
        for p in PATIENTS:
            k=(cl,g,p)
            if k in ppi.index:
                q=ppi.loc[k]
                if q.evaluable:
                    n_eval+=1; d[f"diff_{p}"]=round(q.detection_diff,3); d[f"pct_{p}"]=round(q.pct_cluster_patient,3); mins.append((q.detection_diff,p))
                    if q.detection_diff<=0.15: fails.append(p)
                else: d[f"diff_{p}"]="NA_absent" if q.gene_absent_in_patient else "NA_lt20"
            else: d[f"diff_{p}"]="NA_lt20"
        d["n_patients_evaluable"]=n_eval; d["patients_fail_diff"]=";".join(fails)
        d["core_pass"]=bool(role=="core" and o.pct_cluster>0.5 and n_eval>0 and not fails and not d["rest_too_high"])
        if role=="core": core_res.append(d); allmin+=mins
        m=mk[(mk.cluster==cl)&(mk.gene==g)]
        if len(m): d["findallmarkers_avg_log2FC"]=round(float(m.avg_log2FC.iloc[0]),2); d["findallmarkers_p_val_adj"]=float(m.p_val_adj.iloc[0]); d["findallmarkers_pct1"]=float(m["pct.1"].iloc[0]); d["findallmarkers_pct2"]=float(m["pct.2"].iloc[0])
        ev.append(d)
    n_pass=sum(x["core_pass"] for x in core_res); n_core=len(core_res)
    failing=[x for x in core_res if not x["core_pass"]]
    npg=int(c.n_patients_ge20)
    if r.override: status=r.override; conf="high" if r.override=="DOUBLET" else "medium"
    elif npg<3: status="NOT_SUPPORTED"; conf="low"
    elif n_pass==n_core and n_core>=2: status="SUPPORTED"; conf="high"
    elif n_pass>=n_core-1 and n_pass>=2: status="MARGINAL"; conf="medium"
    else: status="NOT_SUPPORTED"; conf="low"
    # 簇内 marker 证据强度 (与病人数无关)
    strong=sum(1 for x in core_res if x["pct_cluster"]>0.5 and x["detection_diff"]>0.3)
    ident="STRONG" if strong>=3 else "MODERATE" if strong>=2 else "WEAK"
    mn=min(allmin) if allmin else (np.nan,"")
    why=[]
    if npg<3: why.append(f"细胞≥20的病人数={npg}<3，跨病人门槛无法满足")
    for x in failing:
        reasons=[]
        if x["pct_cluster"]<=0.5: reasons.append(f"簇内检出率{x['pct_cluster']}≤0.5")
        if x["patients_fail_diff"]:
            fp=x["patients_fail_diff"].split(";")
            reasons.append("检出率差≤0.15于"+"，".join(f"{p}(该病人其余细胞中同谱系占{same_lineage_frac(cl,p):.0%})" for p in fp))
        if x["rest_too_high"]: reasons.append(f"其余细胞检出率{x['pct_rest']}>0.6")
        if x["n_patients_evaluable"]==0: reasons.append("无可评估病人")
        why.append(f"{x['gene']}: "+"，".join(reasons))
    s1=ct[ct.atomic_cluster_id==cl].set_index("model")
    auto=f"CellTypist-HLCA={s1.loc['HLCA','top_label']}({s1.loc['HLCA','top_label_frac']}); CellTypist-ImmuneLow={s1.loc['ImmuneLow','top_label']}({s1.loc['ImmuneLow','top_label_frac']}); CellTypist-Brain={s1.loc['BrainMTG','top_label']}({s1.loc['BrainMTG','top_label_frac']}); panhumanpy={ph.loc[cl,'azimuth_fine_top']}({ph.loc[cl,'azimuth_fine_frac']})"
    unc=f"HLCA_mean_maxprob={s1.loc['HLCA','mean_max_prob']}; ImmuneLow_mean_maxprob={s1.loc['ImmuneLow','mean_max_prob']}; panhumanpy_mean_conf={ph.loc[cl,'mean_final_conf']}; panhumanpy_frac_consistent={ph.loc[cl,'frac_consistent_hierarchy']}"
    rows.append(dict(atomic_cluster_id=cl,n_cells=int(c.n_cells),n_patients_ge20=npg,lineage_l1=r.lineage_l1,proposed_label=r.proposed_label,confidence=conf,
        assignment_status=status,marker_identity_within_cluster=ident,core_markers=";".join(core),n_core_pass=f"{n_pass}/{n_core}",
        min_detection_diff=round(mn[0],3) if allmin else np.nan,min_detection_patient=mn[1],
        cluster_pct=";".join(f"{x['gene']}={x['pct_cluster']}" for x in core_res),rest_pct=";".join(f"{x['gene']}={x['pct_rest']}" for x in core_res),
        auto_label_S1=auto,auto_uncertainty=unc,scrublet_median=scr.loc[cl,"scrublet_median"],scrublet_pred_frac=scr.loc[cl,"scrublet_pred_frac"],
        median_nCount=int(c.median_nCount),median_pct_mito=c.median_pct_mito,patient_composition=c.patient_composition,disease_composition=c.disease_composition,
        status_reason="；".join(why) if why else "全部 core marker 在所有可评估病人中通过",notes=r.notes,
        graph_umap_leiden_recomputed=False,patient_or_disease_used_for_assignment=False))
ann=pd.DataFrame(rows); ann.to_csv(f"{O}/cluster_annotation.csv",index=False)
evd=pd.DataFrame(ev); cols=["atomic_cluster_id","gene","marker_role","pct_cluster","pct_rest","detection_diff","rest_too_high","n_patients_evaluable","patients_fail_diff","core_pass"]+[f"diff_{p}" for p in PATIENTS]+[f"pct_{p}" for p in PATIENTS]+["findallmarkers_avg_log2FC","findallmarkers_p_val_adj","findallmarkers_pct1","findallmarkers_pct2","note"]
evd=evd.reindex(columns=[c for c in cols if c in evd.columns]); evd.to_csv(f"{O}/marker_evidence.csv",index=False)
# S1 原始输出
s1w=ct.pivot(index="atomic_cluster_id",columns="model",values=["majority_label","top_label","top_label_frac","second_label","second_label_frac","mean_max_prob","label_entropy_bits","n_distinct_labels"])
s1w.columns=[f"CellTypist_{m}_{v}" for v,m in s1w.columns]; s1w=s1w.reset_index()
s1w=s1w.merge(ph.reset_index().rename(columns={c:f"panhumanpy_{c}" for c in ph.columns}),on="atomic_cluster_id")
s1w.to_csv(f"{O}/auto_annotation_S1.csv",index=False)
pd.set_option('display.width',250); pd.set_option('display.max_colwidth',60); pd.set_option('display.max_rows',100)
print(ann[["atomic_cluster_id","n_cells","n_patients_ge20","assignment_status","marker_identity_within_cluster","n_core_pass","min_detection_diff","min_detection_patient","status_reason"]].to_string(index=False))
print(ann.assignment_status.value_counts())
