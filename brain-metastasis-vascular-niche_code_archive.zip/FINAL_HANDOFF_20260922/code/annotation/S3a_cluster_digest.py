# S3a: 汇总每个 atomic 簇的证据摘要 (供人工指认阅读): 构成/QC, S1 自动标签, Scrublet, FindAllMarkers top, panel 检出率
import pandas as pd, numpy as np, sys
D=__import__("os").environ["ANNOTATION_WORKSPACE"]; W=f"{D}/work"
comp=pd.read_csv(f"{W}/S2_cluster_composition.csv").set_index("atomic_cluster_id")
ov=pd.read_csv(f"{W}/S2_detection_overall.csv"); ov["diff"]=ov.pct_cluster-ov.pct_rest
mk=pd.read_csv(f"{W}/S2_findallmarkers_xing.csv")
ct=pd.read_csv(f"{W}/S1_celltypist_cluster_summary.csv")
sc_=pd.read_csv(f"{W}/S1_scrublet_per_cell.csv",index_col=0)
scr=sc_.groupby("atomic_cluster_id").agg(scrublet_median=("scrublet_score","median"),scrublet_pred_frac=("scrublet_pred","mean")).round(3)
panel=set(open(f"{D}/scripts/canonical_panel.txt").read().split())
try:
    ph=pd.read_csv(f"{W}/panhumanpy/annotated_cell_metadata.csv",index_col=0)
    phcols=[c for c in ph.columns if c.startswith("azimuth_") or c.startswith("full_consensus") or c.startswith("final_level")]
except Exception: ph=None
lines=[]
for cl in comp.index:
    c=comp.loc[cl]
    lines.append(f"\n{'='*100}\n## {cl}  n={c.n_cells}  病人≥20:{c.n_patients_ge20}  中位UMI={c.median_nCount:.0f} 基因={c.median_nFeature:.0f} 线粒体={c.median_pct_mito:.1f}%  瘤组织占比={c.pct_tumor_tissue}%")
    lines.append(f"   病人构成: {c.patient_composition}\n   疾病构成: {c.disease_composition}")
    s=scr.loc[cl]; lines.append(f"   Scrublet: 中位分 {s.scrublet_median}, 判双胞比例 {s.scrublet_pred_frac}")
    for m in ["HLCA","BrainMTG","ImmuneLow","ImmuneHigh"]:
        r=ct[(ct.atomic_cluster_id==cl)&(ct.model==m)].iloc[0]
        lines.append(f"   S1 {m:10s}: {r.top_label} {r.top_label_frac:.2f} | 次 {r.second_label} {r.second_label_frac:.2f} | 均最大概率 {r.mean_max_prob:.2f} | 熵 {r.label_entropy_bits:.2f}")
    if ph is not None:
        sub=ph.loc[ph.index.isin(sc_.index[sc_.atomic_cluster_id==cl])]
        for col in phcols[:4]:
            vc=sub[col].value_counts(normalize=True).head(2)
            lines.append(f"   panhumanpy {col}: "+"; ".join(f"{k} {v:.2f}" for k,v in vc.items()))
    t=mk[mk.cluster==cl].sort_values(["p_val_adj","avg_log2FC"],ascending=[True,False]).head(30)
    lines.append("   FindAllMarkers top30 (gene pct1/pct2 log2FC): "+", ".join(f"{g} {a:.2f}/{b:.2f} {f:.1f}" for g,a,b,f in zip(t.gene,t["pct.1"],t["pct.2"],t.avg_log2FC)))
    p=ov[(ov.atomic_cluster_id==cl)&(ov.gene.isin(panel))&(ov.pct_cluster>0.3)&(ov["diff"]>0.15)].sort_values("diff",ascending=False).head(40)
    lines.append("   Panel 阳性(pct簇>0.3 & 差>0.15): "+", ".join(f"{g} {a:.2f}/{b:.2f}" for g,a,b in zip(p.gene,p.pct_cluster,p.pct_rest)))
    key=["PTPRC","CD3E","CD8A","CD4","MS4A1","CD79A","JCHAIN","NKG7","CD14","CD68","C1QA","P2RY12","TMEM119","EPCAM","KRT8","SFTPB","NAPSA","CHGA","INSM1","ASCL1","GFAP","AQP4","MBP","PLP1","SNAP25","PECAM1","CLDN5","PDGFRB","RGS5","COL1A1","DCN","MKI67","HBB","TPSAB1","LILRA4","CLEC9A","CD1C","LAMP3","CSF3R","FCGR3B"]
    k=ov[(ov.atomic_cluster_id==cl)&(ov.gene.isin(key))].set_index("gene").reindex(key)
    lines.append("   关键门控 pct簇/pct余: "+", ".join(f"{g} {r.pct_cluster:.2f}/{r.pct_rest:.2f}" for g,r in k.iterrows() if not np.isnan(r.pct_cluster)))
open(f"{W}/S3_cluster_digest.txt","w").write("\n".join(lines)); print("written", len(comp))
