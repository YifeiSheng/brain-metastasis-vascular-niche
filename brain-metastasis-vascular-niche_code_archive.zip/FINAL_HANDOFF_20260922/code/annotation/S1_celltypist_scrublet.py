# S1 自动注释 (CellTypist, 三个参考模型) + 逐样本 Scrublet 双胞打分
# 注释单位 = 冻结 atomic_cluster_id (majority voting over_clustering), 不重新聚类。
import os, sys, time, json, numpy as np, pandas as pd, scanpy as sc, anndata as ad
import celltypist
from celltypist import models
D=__import__("os").environ["ANNOTATION_WORKSPACE"]
W=f"{D}/work"; L=open(f"{D}/logs/S1_progress.txt","a",buffering=1)
def log(*a): L.write(time.strftime("[%H:%M:%S] ")+" ".join(map(str,a))+"\n"); L.flush()
sc.settings.n_jobs=16
log("读取 h5ad")
adata=sc.read_h5ad(f"{D}/data/sc_counts.h5ad")
adata.layers["counts"]=adata.X.copy()
sc.pp.normalize_total(adata,target_sum=1e4); sc.pp.log1p(adata)
log("归一化完成", adata.shape)

# ---------- Scrublet 逐样本 ----------
import scrublet as scr
ds=pd.Series(np.nan,index=adata.obs_names); dp=pd.Series(False,index=adata.obs_names)
for s in adata.obs["sample"].cat.categories:
    idx=np.where(adata.obs["sample"]==s)[0]
    X=adata.layers["counts"][idx]
    sb=scr.Scrublet(X, expected_doublet_rate=0.06, random_state=0)
    sco,pred=sb.scrub_doublets(min_counts=2,min_cells=3,n_prin_comps=30,verbose=False)
    if pred is None: pred=sb.call_doublets(threshold=0.25)
    ds.iloc[idx]=sco; dp.iloc[idx]=pred
    log(f"scrublet {s}: n={len(idx)} threshold={getattr(sb,'threshold_',np.nan):.3f} doublets={int(pred.sum())}")
adata.obs["scrublet_score"]=ds.values; adata.obs["scrublet_pred"]=dp.values
adata.obs[["sample","atomic_cluster_id","scrublet_score","scrublet_pred"]].to_csv(f"{W}/S1_scrublet_per_cell.csv")

# ---------- CellTypist ----------
MODELS={"HLCA":"Human_Lung_Atlas.pkl","BrainMTG":"Adult_Human_MTG.pkl","ImmuneLow":"Immune_All_Low.pkl","ImmuneHigh":"Immune_All_High.pkl"}
percell=adata.obs[["sample","patient_id","atomic_cluster_id"]].copy()
summ=[]
for tag,m in MODELS.items():
    log("celltypist",tag)
    mod=models.Model.load(__import__("os").path.join(__import__("os").environ["ANNOTATION_MODELS"],m))
    pr=celltypist.annotate(adata,model=mod,majority_voting=True,over_clustering="atomic_cluster_id")
    pl=pr.predicted_labels
    percell[f"{tag}_label"]=pl["predicted_labels"].values
    percell[f"{tag}_conf"]=pr.probability_matrix.max(axis=1).values
    percell[f"{tag}_majority"]=pl["majority_voting"].values
    # 簇级汇总: 多数票标签, 同意比例, 平均最大概率, 标签熵
    g=percell.groupby("atomic_cluster_id",observed=True)
    for cl,sub in g:
        vc=sub[f"{tag}_label"].value_counts(normalize=True)
        p=vc.values; ent=float(-(p*np.log2(p)).sum())
        summ.append(dict(atomic_cluster_id=cl,model=tag,n_cells=len(sub),majority_label=sub[f"{tag}_majority"].iloc[0],
            top_label=vc.index[0],top_label_frac=round(float(vc.iloc[0]),3),
            second_label=vc.index[1] if len(vc)>1 else "",second_label_frac=round(float(vc.iloc[1]),3) if len(vc)>1 else 0.0,
            mean_max_prob=round(float(sub[f"{tag}_conf"].mean()),3),label_entropy_bits=round(ent,3),n_distinct_labels=len(vc)))
    log("done",tag)
percell.to_csv(f"{W}/S1_celltypist_per_cell.csv")
pd.DataFrame(summ).to_csv(f"{W}/S1_celltypist_cluster_summary.csv",index=False)
log("S1 完成")
