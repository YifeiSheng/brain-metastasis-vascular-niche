#!/usr/bin/env python3
"""Create a new isolated workspace for the preserved annotation chain."""
import argparse, gzip, shutil
from pathlib import Path
import anndata as ad
from scipy.io import mmwrite
p=argparse.ArgumentParser()
p.add_argument("--workspace",required=True)
p.add_argument("--export-mtx",action="store_true")
args=p.parse_args()
P=Path(__file__).resolve().parents[2]
W=Path(args.workspace).expanduser().resolve()
if W.exists() and any(W.iterdir()):raise RuntimeError("Choose a new empty annotation workspace")
if W==P or P/"data" in W.parents:raise RuntimeError("Do not target the frozen package data directory")
for x in ["data","scripts","work","output","logs"]:(W/x).mkdir(parents=True,exist_ok=True)
a=ad.read_h5ad(P/"data/integrated/final_integrated_annotated.h5ad")
cols=["sample","patient_id","tissue_role","atomic_cluster_id","UMAP_1","UMAP_2","nCount_RNA","nFeature_RNA","pct_mito"]
a.obs=a.obs[cols].copy()
a.obsp.clear(); a.obsm.clear(); a.uns.clear()
a.obsm["X_umap_frozen"]=a.obs[["UMAP_1","UMAP_2"]].to_numpy()
a.write_h5ad(W/"data/sc_counts.h5ad",compression="gzip")
a.obs.rename_axis("cell").to_csv(W/"data/cell_metadata.csv")
for n in ["patient_metadata.csv","gene_absent_per_sample.csv"]:shutil.copy2(P/"data/integrated"/n,W/"data"/n)
for src in (P/"data/integrated/annotation_rules").iterdir():shutil.copy2(src,W/"scripts"/src.name)
for src in (P/"data/integrated/annotation_evidence").iterdir():shutil.copy2(src,W/"work"/src.name)
for src in (P/"code/annotation").iterdir():
    if src.suffix in [".py",".R"] and src.name!=Path(__file__).name:shutil.copy2(src,W/"scripts"/src.name)
if args.export_mtx:
    with gzip.open(W/"data/matrix.mtx.gz","wb") as f:mmwrite(f,a.X.T,field="integer")
    (W/"data/barcodes.tsv").write_text("\n".join(a.obs_names)+"\n")
    (W/"data/features.tsv").write_text("\n".join(a.var_names)+"\n")
print("Prepared",W)
print("Set ANNOTATION_WORKSPACE to this directory and FROZEN_REFERENCE to data/integrated/frozen_reference in the package.")
