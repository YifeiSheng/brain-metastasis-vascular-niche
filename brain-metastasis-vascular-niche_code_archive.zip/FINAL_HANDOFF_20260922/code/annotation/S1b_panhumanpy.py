# S1b: Biomni annotate_celltype_with_panhumanpy 的等价调用 (同一 panhumanpy_env, 同一 AzimuthNN 流程),
#      umap=False (不做新 embedding), refine=True
import os, sys, time, json, numpy as np, pandas as pd, scanpy as sc
import panhumanpy as ph
D=__import__("os").environ["ANNOTATION_WORKSPACE"]
OUT=f"{D}/work/panhumanpy"; os.makedirs(OUT,exist_ok=True)
L=open(f"{D}/logs/S1b_progress.txt","a",buffering=1)
def log(*a): L.write(time.strftime("[%H:%M:%S] ")+" ".join(map(str,a))+"\n")
log("panhumanpy", ph.get_version() if hasattr(ph,"get_version") else "?")
adata=sc.read_h5ad(f"{D}/data/sc_counts.h5ad")
log("loaded",adata.shape)
az=ph.AzimuthNN(adata)
meta=az.cells_meta
log("annotated; columns:", list(meta.columns))
try:
    az.azimuth_refine(); meta=az.cells_meta; log("refined; columns:", list(meta.columns))
except Exception as e: log("refine failed:", repr(e))
meta.to_csv(f"{OUT}/annotated_cell_metadata.csv")
log("S1b 完成")
