"""Portable paths shared by the final figure renderers."""
from pathlib import Path
import os
ROOT=Path(__file__).resolve().parents[2]
INPUT=ROOT/"data/figure_inputs"
INTEGRATED=ROOT/"data/integrated"
SPATIAL=ROOT/"data/spatial"
OUT=Path(os.environ.get("FIGURE_OUTPUT_DIR",str(ROOT/"figures/reproduced"))).resolve()
OUT.mkdir(parents=True,exist_ok=True)
(OUT/"source_data").mkdir(exist_ok=True)
FONT=ROOT/"environment/NotoSansCJKsc-Regular.otf"

# Optional package-closure audit: fail if a renderer reads the former workspace.
if os.environ.get("HANDOFF_STRICT_INPUTS")=="1":
    import sys,json,atexit
    _reads=set()
    def _audit(event,args):
        if event not in ("open","os.listdir","os.scandir") or not args:return
        value=args[0]
        if not isinstance(value,(str,bytes)):return
        try:p=Path(os.fsdecode(value)).absolute()
        except (ValueError,TypeError):return
        if "07-safeposter" in p.parts and not p.is_relative_to(ROOT):
            raise RuntimeError("Scientific input outside handoff package: "+str(p))
        if p.is_relative_to(ROOT) and event=="open":_reads.add(str(p.relative_to(ROOT)))
    sys.addaudithook(_audit)
    def _save_audit():
        path=OUT/(Path(sys.argv[0]).stem+"_access_audit.json")
        path.write_text(json.dumps({"package_closure_enforced":True,"accessed":sorted(_reads)},indent=2))
    atexit.register(_save_audit)
