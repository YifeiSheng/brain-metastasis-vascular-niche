"""Render the accepted final figure from package-contained frozen inputs."""
from figure_paths import ROOT,INPUT,INTEGRATED,SPATIAL,OUT,FONT
# Fig 2: NOTCH3+ 周细胞血管龛 / 脑血管单元 (Result 2). 一个脚本生成整张图.
import os, re, json, numpy as np, pandas as pd, scanpy as sc, scipy.sparse as sp
from scipy.cluster.hierarchy import linkage
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib import font_manager, gridspec, colors as mcolors
from matplotlib.lines import Line2D; from matplotlib.patches import Patch
from scipy.stats import mannwhitneyu

plt.rcParams.update({"text.color":"#000000","axes.labelcolor":"#000000","axes.titlecolor":"#000000","xtick.color":"#000000","ytick.color":"#000000","font.family":["DejaVu Sans"],"font.size":7,"axes.titlesize":7.5,"axes.labelsize":7,"xtick.labelsize":6.5,"ytick.labelsize":6.5,"legend.fontsize":6.5,
    "axes.linewidth":0.6,"xtick.major.width":0.5,"ytick.major.width":0.5,"xtick.major.size":2,"ytick.major.size":2,"axes.spines.top":False,"axes.spines.right":False,"pdf.fonttype":42,"savefig.dpi":300,"figure.dpi":110})
B=str(INPUT); DL=str(INTEGRATED); FIG=str(OUT); R13=f"{B}/tables"; R14=f"{B}/tables"; R15=f"{B}/tables"
ST=str(SPATIAL)
os.makedirs(f"{FIG}/source_data",exist_ok=True)
# Canonical paper identifiers are shared across all main figures.
PAPER_PATIENTS=pd.read_csv(f"{B}/metadata/paper_patient_mapping_v4.csv")
PAPER_ID=PAPER_PATIENTS.set_index("patient_id")["paper_patient_id"].to_dict()
PAPER_ORDER=PAPER_PATIENTS.set_index("patient_id")["paper_patient_order"].to_dict()
def paper_id(patient_id):
    return PAPER_ID[patient_id]

C=dict(met="#2a78d6",lym="#eb6834",gli="#1baf7a",ref="#898781",ink="#000000",sec="#52514e",grid="#e1e0d9",axis="#c3c2b7",red="#e34948",yellow="#eda100",violet="#4a3aa7",spot="#dededa")
def style(ax,grid="y"):
    if grid: ax.grid(axis=grid,color=C["grid"],lw=0.5); ax.set_axisbelow(True)
    for s in ["left","bottom"]: ax.spines[s].set_color(C["axis"])
    ax.tick_params(colors=C["sec"],labelcolor=C["ink"])
def label_panels(fig,groups):
    fig.canvas.draw(); fig.set_layout_engine(None); r=fig.canvas.get_renderer()
    for L,axs in groups.items():
        bbs=[a.get_tightbbox(r).transformed(fig.transFigure.inverted()) for a in axs]
        x0=max(min(b.x0 for b in bbs)-0.006,0.003); y1=min(max(b.y1 for b in bbs)+0.004,0.995)
        fig.text(x0,y1,f"{L}.",fontsize=11,fontweight="bold",fontfamily="DejaVu Sans",ha="left",va="bottom",color=C["ink"])
def strip(ax,vals,cols,labels,jitter=0.07,s=10):
    for i,(v,c) in enumerate(zip(vals,cols)):
        v=np.asarray(v,float); v=v[~np.isnan(v)]
        if len(v)==0: continue
        x=np.random.default_rng(i).normal(i,jitter,len(v)); ax.scatter(x,v,s=s,color=c,alpha=0.9,linewidths=0.4,edgecolors="white",zorder=3); ax.hlines(np.median(v),i-0.3,i+0.3,color=C["ink"],lw=1.1,zorder=4)
    ax.set_xticks(range(len(labels))); ax.set_xticklabels(labels)
def pstr(p): return "p<0.001" if p<0.001 else f"p={p:.3f}" if p<0.01 else f"p={p:.2f}"
# ---------------- A 内部 Visium: NOTCH3 检出 + 血管龛邻域 ----------------
SL=[("S1_T","batch_10562_2022_05_30",paper_id("P1")),("Toct6","batch_10562_2022_05_30",paper_id("P8")),("Toct5","batch_15551_2022_03_28",paper_id("P2")),("Toct4","batch_15551_2022_03_28",paper_id("P6"))]
cn=pd.read_csv(f"{B}/tables/M4_spot_CN_assignments.csv.gz",index_col=0,usecols=["Unnamed: 0","slide","band","CN"] if False else None,low_memory=False)[["slide","band","CN"]]
def load_slide(sl,batch):
    p=f"{ST}/{batch}/1.SpaceRanger/{sl}"; v=sc.read_10x_h5(f"{p}/filtered_feature_bc_matrix.h5"); v.var_names_make_unique()
    pos=pd.read_csv(f"{p}/spatial/tissue_positions_list.csv",header=None)
    if str(pos.iloc[0,0]).strip()=="barcode": pos=pd.read_csv(f"{p}/spatial/tissue_positions_list.csv")
    pos.columns=["barcode","in_tissue","row","col","py","px"]; pos=pos.set_index("barcode").reindex(v.obs_names); v=v[pos.in_tissue.fillna(0).astype(int)==1].copy(); pos=pos.reindex(v.obs_names)
    g=cn[cn.slide==sl]; g=g[~g.index.duplicated()]; v.obs["CN"]=g.CN.reindex(v.obs_names).values; v.obs["band"]=g.band.reindex(v.obs_names).values
    v.obs["px"]=pos.px.values.astype(float); v.obs["py"]=pos.py.values.astype(float); v.obs["NOTCH3"]=np.asarray(v[:,"NOTCH3"].X.todense()).ravel()>0
    return v
# ---------------- B 内部 sc: 间质/内皮子簇 ----------------
lab=pd.read_csv(f"{DL}/per_cell_labels.csv").set_index("cell")
a=sc.read_h5ad(f"{DL}/final_integrated_annotated.h5ad"); a.var_names_make_unique(); a=a[lab.index.intersection(a.obs_names)].copy(); lab=lab.loc[a.obs_names]
sub=a[lab.lineage_l1.isin(["基质","内皮"]).values].copy(); sc.pp.normalize_total(sub,target_sum=1e4); sc.pp.log1p(sub); sl_=lab.loc[sub.obs_names]
PERI=["NOTCH3","RGS5","PDGFRB","KCNJ8","HIGD1B","CSPG4"]; FIB=["DCN","LUM"]; ECG=["PECAM1","CLDN5","VWF"]; VEN=["ACKR1"]; BBB=["ABCB1","MFSD2A"]; ACT=["ANGPT2","PLVAP"]
GENES=PERI+FIB+ECG+VEN+BBB+ACT; gi=[g for g in GENES if g in sub.var_names]; X=pd.DataFrame(np.asarray(sub[:,gi].X.todense()),index=sub.obs_names,columns=gi)
sub.obs["sub05"]=sl_.sub05.fillna(sl_.atomic_cluster_id).values; sub.obs["lin"]=sl_.lineage_l1.values
mean=X.groupby(sub.obs.sub05.values).mean(); pct=(X>0).groupby(sub.obs.sub05.values).mean()
def typ(c):
    m=mean.loc[c]; lin=sub.obs.lin[sub.obs.sub05==c].mode().iloc[0]
    if lin=="基质": return "周细胞" if m[PERI].mean()>m[FIB].mean() else "成纤维细胞"
    sc_={"内皮·静脉（ACKR1+）":m[VEN].mean(),"内皮·屏障型（ABCB1/MFSD2A+）":m[BBB].mean(),"内皮·活化型（ANGPT2/PLVAP+）":m[ACT].mean()}
    return max(sc_,key=sc_.get)
TYPE={c:typ(c) for c in mean.index}; TCOL={"周细胞":C["met"],"成纤维细胞":C["ref"],"内皮·静脉（ACKR1+）":C["lym"],"内皮·屏障型（ABCB1/MFSD2A+）":C["gli"],"内皮·活化型（ANGPT2/PLVAP+）":C["yellow"]}
sub.obs["type"]=sub.obs.sub05.map(TYPE)
EN_TYPE={"周细胞":"Pericyte","成纤维细胞":"Fibroblast","内皮·静脉（ACKR1+）":"Venous EC","内皮·屏障型（ABCB1/MFSD2A+）":"Barrier EC","内皮·活化型（ANGPT2/PLVAP+）":"Activated EC"}
# ---------------- C 周细胞占间质 ----------------
d4=pd.read_csv(f"{R13}/D4_signature_frequency_by_sample.csv"); d4=d4[d4.signature.str.startswith("血管周细胞")&(d4.n_lineage_cells>=20)]
d8=pd.read_csv(f"{R13}/D8_signature_frequency_by_sample.csv"); d8=d8[d8.signature.str.startswith("血管周细胞")&(d8.n_lineage_cells>=20)]
v5=pd.read_csv(f"{R14}/V5_snrna_composition.csv"); v5=v5[v5.n_stroma>=20]
# ---------------- D 图谱模型 ----------------
v3=pd.read_csv(f"{R14}/V3_percell_predictions.csv.gz",low_memory=False); v3=v3[(v3.conf>=0.5)&v3.predicted_labels.isin(["周细胞_T型","周细胞_M型","平滑肌","血管周成纤维"])]
G=[("正常颞叶\n（Wälchli）",v3[(v3.source=="Wälchli_其他_正常颞叶")&(v3.sorted=="unsorted")]),("脑转移\n（Wälchli）",v3[(v3.source.str.contains("肺癌脑转移"))&(v3.sorted=="unsorted")]),
   ("脑转移\n（Kim）",v3[(v3.source=="Kim2020")&(v3.origin=="mBrain")&v3.author_subtype.isin(["Pericytes","Smooth muscle cells"])]),("我们\n（候选）",v3[(v3.source=="我们_sc")&(v3.peri_ndet>=4)]),
   ("肺原发\n（Kim）",v3[(v3.source=="Kim2020")&(v3.origin=="tLung")&v3.author_subtype.isin(["Pericytes","Smooth muscle cells"])]),("正常肺\n（Kim）",v3[(v3.source=="Kim2020")&(v3.origin=="nLung")&v3.author_subtype.isin(["Pericytes","Smooth muscle cells"])])]
# ---------------- E 内皮状态 ----------------
v2=pd.read_csv(f"{R14}/V2_ec_state_by_sample.csv"); d5=pd.read_csv(f"{R13}/D5_vascular_subtype.csv"); d5["group"]="肺癌脑转移"
ec=pd.concat([d5,v2]); ec=ec[(ec.sorted=="EC_sorted")&(ec.n_EC>=100)]
MET={"屏障型占比":"EC_毛细血管_血脑屏障_frac","新生型占比":"EC_尖端_血管新生_frac","ABCB1":"EC_ABCB1_det","MFSD2A":"EC_MFSD2A_det","ANGPT2":"EC_ANGPT2_det","PLVAP":"EC_PLVAP_det","ABCB1∧ANGPT2":"EC_ABCB1_and_ANGPT2"}
GORD=["正常颞叶","低级别胶质瘤","高级别胶质瘤","肺癌脑转移","脑膜瘤"]; H=ec.groupby("group")[list(MET.values())].median().reindex(GORD); H.columns=list(MET)
# ---------------- F 邻域富集随半径 ----------------
x4=pd.read_csv(f"{R14}/V4_xenium_neighbor.csv"); x4=x4[x4.pair=="EC-壁细胞"]
s1=pd.read_csv(f"{R14}/V1_slideseq_neighbor_enrichment.csv"); s1=s1[s1.pair=="EC-周细胞"]
# ---------------- G IMC ----------------
k6=pd.read_csv(f"{R14}/V6_imc_vessel_metrics_by_patient.csv")
# ---------------- H 血管覆盖 ----------------
s7=pd.read_csv(f"{R15}/S7_vessel_coverage_all.csv")
# ================= 画图（手工英寸布局，7.2 x 8.2） =================
FH=7.65; fig=plt.figure(figsize=(7.2,FH))
def Y(t,b): return 1-b/FH,1-t/FH
def AX(x0,t,x1,b,**kw): y0,y1=Y(t,b); return fig.add_axes([x0,y0,x1-x0,y1-y0],**kw)
def GRID(x0,t,x1,b,nr,nc,wg=0.006,hg=0.35):
    w=(x1-x0-(nc-1)*wg)/nc; h=((b-t)-(nr-1)*hg)/nr
    return [[AX(x0+j*(w+wg),t+i*(h+hg),x0+j*(w+wg)+w,t+i*(h+hg)+h) for j in range(nc)] for i in range(nr)]
X8=f"{B}/tables"
# A 内部 Visium: 内皮签名评分 / 周细胞签名评分 (连续), 共用色标
gA=GRID(0.04,0.44,0.46,2.08,2,4,hg=0.20); axA=[]; VMIN,VMAX=-0.1,0.6; ANN=[]
for j,(sl,batch,name) in enumerate(SL):
    d=pd.read_csv(f"{X8}/spot_scores_{sl}.csv",index_col=0); bd=pd.read_csv(f"{X8}/spot_bands_{sl}.csv",index_col=0).reindex(d.index)
    pos=pd.read_csv(f"{ST}/{batch}/1.SpaceRanger/{sl}/spatial/tissue_positions_list.csv",header=None); pos.columns=["barcode","in_tissue","row","col","py","px"]; pos=pos.set_index("barcode").reindex(d.index)
    pcol=[c for c in d.columns if c.startswith("血管周细胞") and not c.endswith("__pos")][0]; ecol=[c for c in d.columns if c.startswith("内皮细胞") and not c.endswith("__pos")][0]; tum=(bd.band=="tumor").values
    vv=load_slide(sl,batch); vv=vv[vv.obs_names.intersection(d.index)]; Xc=vv.X.tocsc(); gix={g:k for k,g in enumerate(vv.var_names)}
    ves=np.zeros(vv.n_obs,bool)
    for g_ in ["PECAM1","VWF","CLDN5"]:
        if g_ in gix: ves|=np.asarray(Xc[:,gix[g_]].todense()).ravel()>0
    n3=pd.Series(np.asarray(Xc[:,gix["NOTCH3"]].todense()).ravel()>0,index=vv.obs_names).reindex(d.index).fillna(False).values; ves=pd.Series(ves,index=vv.obs_names).reindex(d.index).fillna(False).values
    for i,(key,col) in enumerate([("内皮评分",ecol),("周细胞评分",pcol)]):
        ax=gA[i][j]; axA.append(ax); v=d[col].values; o=np.argsort(v)
        im=ax.scatter(pos.px.values[o],-pos.py.values[o],c=v[o],s=1.6,cmap="magma",vmin=VMIN,vmax=VMAX,linewidths=0,rasterized=True)
        ax.set_aspect("equal"); ax.set_anchor("S" if i==0 else "N"); ax.set_xticks([]); ax.set_yticks([]); [s_.set_visible(False) for s_ in ax.spines.values()]
        txt=(f"Vessel spots {ves.mean()*100:.0f}%" if i==0 else (f"Tumor NOTCH3 {n3[tum].mean()*100:.0f}%" if tum.sum()>=20 else f"All NOTCH3 {n3.mean()*100:.0f}%"))
        ANN.append((i,j,ax,name,key,txt))
# 标题 / 注释 / 行标签: 按行取实际绘制框的最高顶 / 最低底, 使同一行水平对齐
fig.canvas.draw()
for i in [0,1]:
    boxes=[ax.get_position(original=False) for (ii,jj,ax,_,_,_) in ANN if ii==i]; yt=max(b.y1 for b in boxes); yb=min(b.y0 for b in boxes)
    for (ii,jj,ax,name,key,txt) in ANN:
        if ii!=i: continue
        b=ax.get_position(original=False); xc=(b.x0+b.x1)/2
        fig.text(xc,yb-0.004,txt,fontsize=5.1,ha="center",va="top",color=C["sec"])
        if i==0: fig.text(xc,yt+0.004,name,fontsize=7,ha="center",va="bottom",color=C["ink"])
        if i==0 and jj==0: XC0=b.x0
        if i==0 and jj==3: fig.text((XC0+b.x1)/2,yt+0.024,"内部 Visium（8 张中的 4 张）",fontsize=6.5,ha="center",va="bottom",color=C["sec"])
        if jj==0: fig.text(b.x0-0.012,(yt+yb)/2,key,rotation=90,ha="right",va="center",fontsize=6.5)
caxA=AX(0.465,0.65,0.473,1.82); cb=fig.colorbar(im,cax=caxA); cb.ax.set_title("评分",fontsize=5.5,pad=2); cb.ax.tick_params(labelsize=5.5)
# B 内部 sc: 全图 UMAP 高亮 + 子簇 marker 点图
axB1=AX(0.53,0.44,0.66,1.98); axB1.scatter(lab.UMAP_1,lab.UMAP_2,s=0.2,c="#e6e6e2",linewidths=0,rasterized=True)
for t,c in TCOL.items():
    q=sub.obs[sub.obs.type==t]
    if len(q)==0: continue
    axB1.scatter(lab.loc[q.index,"UMAP_1"],lab.loc[q.index,"UMAP_2"],s=2.5,c=c,linewidths=0,rasterized=True,label=f"{EN_TYPE[t]} ({len(q)})")
axB1.set_xticks([]); axB1.set_yticks([]); axB1.set_aspect("equal"); axB1.set_anchor("N"); [axB1.spines[s].set_color(C["axis"]) for s in ["left","bottom"]]; axB1.set_title("内部单细胞：间质 / 内皮子簇",fontsize=6.5,loc="left")
axB1.legend(loc="upper center",bbox_to_anchor=(0.43,-0.005),frameon=False,markerscale=3,handletextpad=0.3,fontsize=5.6,labelspacing=0.25,ncol=1)
axB2=AX(0.775,0.44,0.977,1.69); gi=[g for g in gi if g not in ["CSPG4","VWF"]]; rows=sorted(mean.index,key=lambda c:(list(TCOL).index(TYPE[c]),c)); ys=np.arange(len(rows))[::-1]
Z=mean.loc[rows,gi]; Z=Z.div(Z.max(axis=0).replace(0,1),axis=1); P=pct.loc[rows,gi]
for yi,rw in zip(ys,rows):
    axB2.scatter(np.arange(len(gi)),[yi]*len(gi),s=P.loc[rw].values*30,c=Z.loc[rw].values,cmap=mcolors.LinearSegmentedColormap.from_list("b",["#cde2fb","#0d366b"]),vmin=0,vmax=1,linewidths=0.3,edgecolors="white")
axB2.set_yticks(ys); axB2.set_yticklabels([f"{EN_TYPE[TYPE[c]]} {c.split('_')[-1]}" for c in rows],fontsize=6)
axB2.set_xticks(range(len(gi))); axB2.set_xticklabels(gi,rotation=90,fontsize=5.5,style="italic"); axB2.set_xlim(-0.6,len(gi)-0.4); axB2.set_ylim(-0.7,len(rows)-0.3)
for xk in [4.5,6.5,8.5]: axB2.axvline(xk,color=C["grid"],lw=0.5)
style(axB2,grid=None); axB2.tick_params(length=0)
for s_,ms in [("10%",3),("50%",15),("100%",30)]: axB2.scatter([],[],s=ms,c="#5598e7",label=s_,linewidths=0.3,edgecolors="white")
axB2.legend(title="检出比例",loc="upper center",bbox_to_anchor=(0.43,-0.32),ncol=3,frameon=False,labelspacing=0.3,title_fontsize=5.5,handletextpad=0.2,fontsize=5.5)
caxB=AX(0.545,2.105,0.645,2.155); cbB=fig.colorbar(plt.cm.ScalarMappable(norm=mcolors.Normalize(0,1),cmap=mcolors.LinearSegmentedColormap.from_list("b2",["#cde2fb","#0d366b"])),cax=caxB,orientation="horizontal",ticks=[0,1]); cbB.ax.tick_params(labelsize=5,length=1); cbB.set_label("相对表达",fontsize=5.3,labelpad=1)
# C 周细胞占间质: x 轴只放部位, 数据集写在组标题
axC=AX(0.08,2.64,0.465,3.86); groups=[("正常肺",d4[d4.origin=="nLung"].frac_of_lineage,C["ref"]),("肺原发",d4[d4.origin=="tLung"].frac_of_lineage,C["ref"]),("脑转移",d4[d4.origin=="mBrain"].frac_of_lineage,C["met"]),
    ("肺原发",d8[d8.site=="PT"].frac_of_lineage,C["ref"]),("脑转移",d8[d8.site=="BM"].frac_of_lineage,C["met"]),("颅外",v5[v5.site=="ECM"].peri_over_peri_fib,C["ref"]),("脑内",v5[v5.site=="MBM"].peri_over_peri_fib,C["met"])]
strip(axC,[g[1].values for g in groups],[g[2] for g in groups],[g[0] for g in groups],s=9); axC.set_ylabel("周细胞占间质比例"); style(axC); axC.tick_params(axis="x",labelsize=6)
for (i,j) in [(1,2),(3,4),(5,6)]:
    pv=mannwhitneyu(groups[i][1].dropna(),groups[j][1].dropna()).pvalue; top=max(np.nanmax(groups[i][1]),np.nanmax(groups[j][1]))+0.05
    axC.plot([i,i,j,j],[top,top+0.02,top+0.02,top],color=C["sec"],lw=0.6); axC.text((i+j)/2,top+0.03,pstr(pv),ha="center",fontsize=6,color=C["sec"])
axC.axvline(2.5,color=C["grid"],lw=0.5); axC.axvline(4.5,color=C["grid"],lw=0.5); axC.set_ylim(0,1.18)
for x_,t_ in [(1,"Kim 2020\nscRNA"),(3.5,"GSE223499\nsnRNA"),(5.5,"Biermann 2022\nsnRNA")]: axC.text(x_,1.16,t_,ha="center",va="top",fontsize=5.6,color=C["sec"])
axC.set_title("公共队列 · 周细胞占间质",loc="left",fontsize=7)
# D 图谱模型壁细胞组成 (横向堆积条)
axD=AX(0.68,2.64,0.98,3.84); STK=[("周细胞_T型","T 型周细胞",C["met"]),("平滑肌","平滑肌",C["sec"]),("血管周成纤维","血管周成纤维",C["axis"])]
ys=np.arange(len(G))[::-1]; left=np.zeros(len(G))
for key,name,col in STK:
    vals=np.array([ (g.predicted_labels==key).mean() if len(g) else 0 for _,g in G]); axD.barh(ys,vals,left=left,height=0.7,color=col,edgecolor="white",linewidth=0.6,label=name); left+=vals
DL_=["Normal brain (Wälchli)","BrM (Wälchli)","BrM (Kim)","Internal candidates","Primary lung (Kim)","Normal lung (Kim)"]
axD.set_yticks(ys); axD.set_yticklabels([f"{n_}  {len(g):,}" for n_,(_,g) in zip(DL_,G)],fontsize=5.8); axD.set_xlim(0,1.0); axD.set_xlabel("预测壁细胞组成"); axD.set_title("内部 + 公共 · 脑血管图谱映射",loc="left",fontsize=7); style(axD,grid="x")
axD.legend(loc="upper center",bbox_to_anchor=(0.5,-0.22),ncol=3,frameon=False,handlelength=1,columnspacing=0.6,handletextpad=0.3,fontsize=5.8)
# E Endothelial marker medians: all five groups, no cell pooling or renormalisation.
axE1=AX(0.115,4.65,0.31,5.61); axE2=AX(0.36,4.65,0.475,5.61)
gmarkers=[("ABCB1","EC_ABCB1_det"),("MFSD2A","EC_MFSD2A_det"),("ANGPT2","EC_ANGPT2_det"),("PLVAP","EC_PLVAP_det")]
gstyles=[("正常颞叶",C["ref"],"o"),("低级别胶质瘤",C["gli"],"s"),("高级别胶质瘤",C["gli"],"^"),("肺癌脑转移",C["met"],"D"),("脑膜瘤",C["sec"],"x")]
for j,(group,col,mk) in enumerate(gstyles):
    values=ec[ec.group==group][[c for _,c in gmarkers]].median().values
    yy=np.arange(4)+(j-2)*.12
    axE1.scatter(values,yy,s=19,c=col,marker=mk,linewidths=.6,label=group,zorder=3)
axE1.set_yticks(range(4)); axE1.set_yticklabels([g for g,_ in gmarkers],fontstyle="italic",fontsize=6)
axE1.set_ylim(3.6,-.6); axE1.set_xlim(-.02,1.02); axE1.set_xticks([0,.5,1]); axE1.set_xlabel("内皮检出比例",fontsize=6)
style(axE1,grid="x"); axE1.set_title("公共 Wälchli · 样本中位",fontsize=6.5,loc="left")
axE1.axhline(1.5,color=C["grid"],lw=.6)
axE1.legend(loc="upper left",bbox_to_anchor=(-.35,-.24),ncol=3,frameon=False,fontsize=5.4,handletextpad=.2,columnspacing=.5)
v5e=pd.read_csv(f"{R14}/V5_snrna_composition.csv"); v5e=v5e[v5e.n_EC>=20]
for i,(nm,_) in enumerate(gmarkers):
    colm=nm+"_in_EC"
    for site,col,dy in [("ECM",C["ref"],-.15),("MBM",C["met"],.15)]:
        v=v5e[v5e.site==site][colm].dropna().values
        yy=np.random.default_rng(i).normal(i+dy,.025,len(v)); axE2.scatter(v,yy,s=7,color=col,alpha=.7,linewidths=.2,edgecolors="white",zorder=3)
        axE2.vlines(np.median(v),i+dy-.10,i+dy+.10,color=C["ink"],lw=1,zorder=4)
axE2.set_yticks(range(4)); axE2.set_yticklabels([]); axE2.set_ylim(3.6,-.6); axE2.set_xlim(-.02,1.02); axE2.set_xticks([0,.5,1]); axE2.set_xlabel("内皮检出比例",fontsize=6);style(axE2,grid="x")
axE2.set_title("公共 Biermann",fontsize=6.5,loc="left")
axE2.legend(handles=[Line2D([],[],marker="o",ls="",color=C["ref"],label="颅外"),Line2D([],[],marker="o",ls="",color=C["met"],label="脑内")],loc="upper left",bbox_to_anchor=(-.10,-.30),frameon=False,fontsize=5.5,handletextpad=.2,ncol=2,columnspacing=.4)
H.to_csv(f"{FIG}/source_data/Fig2_endothelial_all_seven_metrics.csv")
# F 邻域富集随半径衰减
axF1=AX(0.61,4.65,0.78,5.61); axF2=AX(0.81,4.65,0.98,5.61,sharey=axF1)
for smp,g in x4.groupby("sample"): g=g.sort_values("radius_um"); axF1.plot(g.radius_um,g.obs_over_null,"-o",color=C["met"],lw=1.2,ms=3.5,mec="white",mew=0.4,alpha=0.9)
axF1.axhline(1,color=C["axis"],lw=0.6); axF1.set_xticks([15,30,60]); axF1.set_xlabel("半径（µm）"); axF1.set_ylabel("邻域富集（obs/null）"); axF1.set_yscale("log"); style(axF1); axF1.set_title("公共 Xenium（4 张）",fontsize=6.5,loc="left")
for pid,g in s1.groupby("pid"): g=g.sort_values("radius_um"); axF2.plot(g.radius_um,g.obs_over_null,"-o",color=C["met"] if g.site.iloc[0]=="BM" else C["ref"],lw=1,ms=3,mec="white",mew=0.4,alpha=0.85)
axF2.axhline(1,color=C["axis"],lw=0.6); axF2.set_xticks([20,40,60,80]); axF2.set_xlabel("半径（µm）"); style(axF2); axF2.set_title("公共 Slide-seq（13 张）",fontsize=6.5,loc="left"); axF2.tick_params(labelleft=False)
axF2.legend(handles=[Line2D([],[],color=C["met"],label="脑转移"),Line2D([],[],color=C["ref"],label="肺原发")],loc="upper right",frameon=False,fontsize=5.8)
# G 成像质谱
k6["grp"]=k6["Tumor Type"].map({"Brain Metastasis":"BrM","Glioblastoma":"GBM","Astrocytoma":"Astro."}); GO=["BrM","GBM","Astro."]; GC=[C["met"],C["gli"],C["gli"]]
axG1=AX(0.08,6.39,0.245,7.29); axG2=AX(0.325,6.39,0.49,7.29)
for ax,(colm,yl) in zip([axG1,axG2],[("EC_per_mm2","CD31+ 细胞/mm²"),("cancer_median_dist_um","癌细胞–血管距离（µm）")]):
    vals=[k6[k6.grp==g][colm].dropna().values for g in GO]; strip(ax,vals,GC,GO,s=7); ax.set_ylabel(yl); style(ax); ax.set_ylim(0,max(np.concatenate(vals))*1.3); ax.tick_params(axis="x",labelsize=6)
    pv=mannwhitneyu(vals[0],np.concatenate(vals[1:])).pvalue; ax.text(0.03,0.98,f"vs 胶质瘤\n{pstr(pv)}",transform=ax.transAxes,ha="left",va="top",fontsize=5.8,color=C["sec"])
axG1.set_title("公共 IMC · 血管密度",fontsize=6.5,loc="left"); axG2.set_title("公共 IMC · 血管距离",fontsize=6.5,loc="left")
# H 血管 spot 比例 vs NOTCH3 覆盖
axH=AX(0.655,6.39,0.98,7.29); GR=[("脑转移",C["met"]),("PCNSL",C["lym"]),("泛癌原发(Yang)",C["ref"])]; NM={"脑转移":"脑转移（35）","PCNSL":"淋巴瘤（8）","泛癌原发(Yang)":"配对原发（4）"}
for g,col in GR:
    q=s7[s7.group2==g]; axH.scatter(q.all_vessel_frac,q.all_cov_NOTCH3,s=14,color=col,alpha=0.9,linewidths=0.4,edgecolors="white",label=NM[g],zorder=3)
axH.set_title("公共 Visium · 血管与 NOTCH3 覆盖",fontsize=6.5,loc="left"); axH.set_xlabel("血管 spot 比例"); axH.set_ylabel("血管 spot 内 NOTCH3 检出比例"); axH.set_xlim(0,1); axH.set_ylim(0,1.02); style(axH,grid="both"); axH.legend(loc="upper left",frameon=False,handletextpad=0.2,fontsize=5.6,labelspacing=0.2)
x=s7[s7.group2=="脑转移"].all_cov_NOTCH3.dropna(); y=s7[s7.group2=="PCNSL"].all_cov_NOTCH3.dropna()
for v_,col,lab_ in [(x.median(),C["met"],"脑转移中位"),(y.median(),C["lym"],"淋巴瘤中位")]:
    axH.axhline(v_,color=col,lw=0.9,ls=(0,(4,2)),zorder=1); axH.text(0.98,v_+0.015,f"{lab_} {v_:.2f}",transform=axH.get_yaxis_transform(),ha="right",va="bottom",fontsize=5.4,color=C["sec"])
axH.set_xlabel("血管 spot 比例\nNOTCH3 覆盖："+pstr(mannwhitneyu(x,y).pvalue),fontsize=5.7,labelpad=1)

pd.DataFrame({"subcluster":list(TYPE),"display_type":[TYPE[c] for c in TYPE]}).to_csv(f"{FIG}/source_data/Fig2_subcluster_display_types.csv",index=False)
mean.to_csv(f"{FIG}/source_data/Fig2_marker_mean_logCP10K.csv");pct.to_csv(f"{FIG}/source_data/Fig2_marker_detection.csv")
pd.DataFrame([{"group":nm,"n_cells":len(g),**{key:float((g.predicted_labels==key).mean()) for key,_,_ in STK}} for nm,g in G]).to_csv(f"{FIG}/source_data/Fig2_mural_model_composition.csv",index=False)
ec.to_csv(f"{FIG}/source_data/Fig2_endothelial_sample_metrics.csv",index=False)
s7.to_csv(f"{FIG}/source_data/Fig2_vessel_coverage.csv",index=False)


# Translate Text artists before measuring panel bounding boxes.
# Chinese lookup labels in source-data tables remain unchanged for traceability.
EN_TEXT={
"内皮评分":"EC score",
"周细胞评分":"Pericyte score",
"内部 Visium（8 张中的 4 张）":"Internal Visium (4 of 8 sections)",
"评分":"Score",
"内部单细胞：间质 / 内皮子簇":"Internal stromal / EC atlas",
"检出比例":"Detected (%)",
"相对表达":"Relative expression",
"正常肺":"Normal\nlung",
"肺原发":"Primary\nlung",
"脑转移":"BrM",
"颅外":"ECM",
"脑内":"MBM",
"周细胞占间质比例":"Pericyte fraction of stroma",
"公共队列 · 周细胞占间质":"Public cohorts · Stromal composition",
"T 型周细胞":"T-type pericyte",
"平滑肌":"Smooth muscle",
"血管周成纤维":"Perivascular fibroblast",
"预测壁细胞组成":"Predicted mural-cell composition",
"内部 + 公共 · 脑血管图谱映射":"Internal + public · Vascular atlas mapping",
"正常颞叶":"Normal brain",
"低级别胶质瘤":"LGG",
"高级别胶质瘤":"HGG",
"肺癌脑转移":"Lung BrM",
"脑膜瘤":"Meningioma",
"内皮检出比例":"Fraction of ECs",
"公共 Wälchli · 样本中位":"Public Wälchli · Sample medians",
"公共 Biermann":"Public Biermann",
"半径（µm）":"Radius (µm)",
"邻域富集（obs/null）":"Enrichment (obs/null)",
"公共 Xenium（4 张）":"Public Xenium (n = 4)",
"公共 Slide-seq（13 张）":"Public Slide-seq (n = 13)",
"CD31+ 细胞/mm²":"CD31+ cells/mm²",
"癌细胞–血管距离（µm）":"Cancer–vessel distance (µm)",
"公共 IMC · 血管密度":"Public IMC · Density",
"公共 IMC · 血管距离":"Public IMC · Distance",
"公共 Visium · 血管与 NOTCH3 覆盖":"Public Visium · Vascular NOTCH3",
"血管 spot 比例":"Vessel-positive spot fraction",
"血管 spot 内 NOTCH3 检出比例":"NOTCH3+ fraction of vessel spots",
"脑转移（35）":"BrM (35)",
"淋巴瘤（8）":"PCNSL (8)",
"配对原发（4）":"Matched primary (4)",
}
from matplotlib.text import Text as _Text
for _t in fig.findobj(match=_Text):
    _s=_t.get_text()
    if _s in EN_TEXT: _t.set_text(EN_TEXT[_s])
    elif _s.startswith("vs 胶质瘤"): _t.set_text(_s.replace("vs 胶质瘤","vs glioma"))
    elif _s.startswith("脑转移中位"): _t.set_text(_s.replace("脑转移中位","BrM median"))
    elif _s.startswith("淋巴瘤中位"): _t.set_text(_s.replace("淋巴瘤中位","PCNSL median"))
    elif _s.startswith("血管 spot 比例\nNOTCH3 覆盖："):
        _t.set_text(_s.replace("血管 spot 比例\nNOTCH3 覆盖：","Vessel-positive spot fraction\nNOTCH3 coverage: "))
axB1.set_title("Internal stromal / EC atlas",fontsize=6.5,loc="left")
axC.set_xticklabels(["Normal\nlung","Primary\nlung","BrM","Primary\nlung","BrM","ECM","MBM"])
axC.tick_params(axis="x",labelsize=5.6)
axD.set_title("Internal + public\nVascular atlas mapping",loc="left",fontsize=6.5)
axD.legend(loc="upper center",bbox_to_anchor=(.36,-.24),ncol=2,frameon=False,
    handlelength=1,columnspacing=.7,handletextpad=.3,fontsize=5.6)
for _t in axD.get_legend().get_texts():
    _t.set_text(EN_TEXT.get(_t.get_text(),_t.get_text()))
axE1.set_title("Public Wälchli\nSample medians",fontsize=6.5,loc="left")
axE2.set_title("Public\nBiermann",fontsize=6.5,loc="left")
axF1.set_title("Public Xenium\n4 sections",fontsize=6.5,loc="left")
axF2.set_title("Public Slide-seq\n13 sections",fontsize=6.5,loc="left")
axG1.set_title("Public IMC\nEC density",fontsize=6.5,loc="left")
axG2.set_title("Public IMC\nCancer–EC distance",fontsize=6.5,loc="left")
axH.set_title("Public Visium · Vascular NOTCH3",fontsize=6.5,loc="left")
axG2.set_ylabel("Nearest-EC distance (µm)",fontsize=6)
axH.set_ylabel("NOTCH3+ fraction of vessel spots",fontsize=6)

def label_panels2(fig,groups):
    fig.canvas.draw(); r=fig.canvas.get_renderer()
    for L,axs in groups.items():
        bbs=[a.get_tightbbox(r).transformed(fig.transFigure.inverted()) for a in axs]
        x0=max(min(b.x0 for b in bbs)-0.006,0.003); y1=min(max(b.y1 for b in bbs)+0.003,0.99)
        fig.text(x0,y1,f"{L}.",fontsize=11,fontweight="bold",fontfamily="DejaVu Sans",ha="left",va="bottom",color=C["ink"])

# Final display-only typography pass; source categories remain traceable.
from matplotlib.text import Text as _Text
fig.canvas.draw()
for _t in fig.findobj(match=_Text):
    _t.set_color("#000000")
    _t.set_text(_t.get_text().replace(" | ",", ").replace("｜",", ").replace("|",", "))
PANEL_X={"A":.015,"B":.510,"C":.015,"D":.510,"E":.015,"F":.510,"G":.015,"H":.510}
PANEL_ROWS=[["A","B"],["C","D"],["E","F"],["G","H"]]

def label_panels_rows(fig,groups,rows):
    # Column anchors do not depend on differing ylabel/tick widths.
    fig.canvas.draw(); r=fig.canvas.get_renderer(); pos={}
    for L,axs in groups.items():
        bbs=[a.get_tightbbox(r).transformed(fig.transFigure.inverted()) for a in axs]
        pos[L]=max(b.y1 for b in bbs)
    for row in rows:
        y=min(max(pos[L] for L in row)+0.003,0.99)
        for L in row:
            fig.text(PANEL_X[L],y,f"{L}.",fontsize=11,fontweight="bold",
                     fontfamily="DejaVu Sans",ha="left",va="bottom",color="#000000")
label_panels_rows(fig,{"A":axA+[caxA],"B":[axB1,axB2],"C":[axC],"D":[axD],"E":[axE1,axE2],"F":[axF1,axF2],"G":[axG1,axG2],"H":[axH]},PANEL_ROWS)
pd.DataFrame([{"slide":sl,"paper_patient_id":nm,"display_order":i+1} for i,(sl,_,nm) in enumerate(SL)]).to_csv(f"{FIG}/source_data/Fig2_panel_A_sample_order.csv",index=False)
fig.savefig(f"{FIG}/Fig2.png",dpi=300); fig.savefig(f"{FIG}/Fig2.pdf"); fig.savefig(f"{FIG}/Fig2_preview.jpg",dpi=170); print("Figure 2 rendered")


# Visible-artist validation checks the delivered figure, not source lookup strings.
from matplotlib.text import Text as _Text
import json as _json
from pathlib import Path as _Path
fig.canvas.draw(); _renderer=fig.canvas.get_renderer()
_outside=[]; _cjk=[]; _nonblack=[]; _bars=[]; _panel_positions={}; _visible_text=[]
for _t in fig.findobj(match=_Text):
    if not _t.get_visible() or not _t.get_text().strip(): continue
    _s=_t.get_text(); _visible_text.append(_s)
    if re.search(r"[\u3400-\u9fff]",_s): _cjk.append(_s)
    if "|" in _s or "｜" in _s: _bars.append(_s)
    if mcolors.to_rgba(_t.get_color()) != (0.,0.,0.,1.): _nonblack.append({"text":_s,"color":str(_t.get_color())})
    _bb=_t.get_window_extent(_renderer).transformed(fig.transFigure.inverted())
    if _bb.x0 < -.002 or _bb.y0 < -.002 or _bb.x1 > 1.002 or _bb.y1 > 1.002:
        _outside.append({"text":_s,"bbox":[float(v) for v in _bb.extents]})
    if re.fullmatch(r"[A-H]\.",_s): _panel_positions[_s.rstrip(".")]=[float(v) for v in _t.get_position()]
_row_qa=[{"panels":_row,"same_y":len({round(_panel_positions[_l][1],10) for _l in _row})==1} for _row in PANEL_ROWS]
_left_qa=all(abs(_panel_positions[_r[0]][0]-.015)<1e-10 for _r in PANEL_ROWS)
_qa={"cjk_text":_cjk,"nonblack_text":_nonblack,"vertical_bar_text":_bars,"outside_canvas_text":_outside,
     "axes_count":len(fig.axes),"canvas_inches":list(fig.get_size_inches()),"panel_label_positions":_panel_positions,
     "same_row_alignment":_row_qa,"left_column_x":.015,"left_column_alignment":_left_qa,
     "visible_text":_visible_text}
_Path(FIG,"Fig2_layout_qa.json").write_text(_json.dumps(_qa,ensure_ascii=False,indent=2))
assert not _cjk, _cjk
assert not _nonblack, _nonblack
assert not _bars, _bars
assert not _outside, _outside
assert all(_row["same_y"] for _row in _row_qa) and _left_qa, _row_qa


