"""Render the accepted final figure from package-contained frozen inputs."""
from figure_paths import ROOT,INPUT,INTEGRATED,SPATIAL,OUT,FONT
#!/usr/bin/env python
import hashlib, json, re
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.text import Text
from matplotlib.colors import to_rgba

B=INPUT
OLD=B/"compositions"
O=OUT
SD=O/"source_data"
SD.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({
    "font.family":["DejaVu Sans"],"font.size":7,"axes.titlesize":7.5,
    "axes.labelsize":7,"xtick.labelsize":6.2,"ytick.labelsize":6.2,
    "legend.fontsize":5.8,"axes.linewidth":.6,"xtick.major.width":.5,
    "ytick.major.width":.5,"xtick.major.size":2,"ytick.major.size":2,
    "axes.spines.top":False,"axes.spines.right":False,"pdf.fonttype":42,
    "savefig.dpi":300,"figure.dpi":110,"text.color":"black",
    "axes.labelcolor":"black","xtick.color":"black","ytick.color":"black",
})
LIN=["上皮/肺腺癌","上皮/神经内分泌","B细胞谱系","T/NK","髓系","胶质","基质","内皮","跨谱系"]
LN=["LUAD epithelial","NE epithelial","B cells","T / NK","Myeloid","Glial","Stromal","Endothelial","Unresolved"]
LC=dict(zip(LIN,["#2a78d6","#eb6834","#1baf7a","#eda100","#e87ba4","#008300","#4a3aa7","#e34948","#c3c2b7"]))
CNIDS=[0,2,1,5,3,4,6,7]
CNN={0:"CN0 Epithelial score",2:"CN2 B-cell score",1:"CN1 Fibroblast",5:"CN5 Mural / EC",3:"CN3 Microglia / astro.",4:"CN4 Oligo. / brain",6:"CN6 Reactive astro.",7:"CN7 Neutrophil"}
CNC={0:"#2a78d6",2:"#eb6834",1:"#8c78b8",5:"#4a3aa7",3:"#1baf7a",4:"#8b9a8f",6:"#80c7af",7:"#eda100"}
inputs=[]
def read(path,**kwargs):
    inputs.append(path)
    return pd.read_csv(path,**kwargs)
PM=read(B/"metadata/paper_patient_mapping_v4.csv").set_index("patient_id")
SM=read(B/"metadata/paper_sample_mapping_v4.csv").set_index(["assay","sample"])
sc_order=read(OLD/"Fig1_panel_D_sample_order.csv")
st_order=read(OLD/"Fig1_panel_G_sample_order.csv")
counts=read(OLD/"Fig1_lineage_counts_by_sample.csv",index_col=0).loc[sc_order["sample"],LIN]
fractions=read(OLD/"Fig1_lineage_fraction_by_sample.csv",index_col=0).loc[sc_order["sample"],LIN]
cncounts=read(OLD/"Fig1_CN_counts_by_slide.csv",index_col=0)
cnfractions=read(OLD/"Fig1_CN_fraction_by_slide.csv",index_col=0)
cncounts.columns=cncounts.columns.astype(int)
cnfractions.columns=cnfractions.columns.astype(int)
cncounts=cncounts.loc[st_order.slide,CNIDS]
cnfractions=cnfractions.loc[st_order.slide,CNIDS]
assert counts.to_numpy().sum()==90760
assert cncounts.to_numpy().sum()==16620
assert counts.shape==(12,9) and cncounts.shape==(5,8)
assert np.allclose(fractions.to_numpy(),counts.div(counts.sum(axis=1),axis=0).to_numpy(),atol=1e-15)
assert np.allclose(cnfractions.to_numpy(),cncounts.div(cncounts.sum(axis=1),axis=0).to_numpy(),atol=1e-15)
assert np.allclose(fractions.sum(axis=1),1) and np.allclose(cnfractions.sum(axis=1),1)
# Exact old numeric values are exported. Original keys are retained for traceability.
counts.to_csv(SD/"FigS2_lineage_counts_by_sample.csv")
fractions.to_csv(SD/"FigS2_lineage_fraction_by_sample.csv")
cncounts.to_csv(SD/"FigS2_CN_counts_by_slide.csv")
cnfractions.to_csv(SD/"FigS2_CN_fraction_by_slide.csv")
pd.DataFrame({"source_lineage":LIN,"display_lineage":LN,"color":[LC[x] for x in LIN]}).to_csv(SD/"FigS2_lineage_display_key.csv",index=False)
pd.DataFrame({"CN":CNIDS,"display_name":[CNN[x] for x in CNIDS],"color":[CNC[x] for x in CNIDS]}).to_csv(SD/"FigS2_CN_display_key.csv",index=False)
records=[]
for assay,df,key in [("scRNA-seq",sc_order,"sample"),("Visium",st_order,"slide")]:
    for _,row in df.iterrows():
        rec=SM.loc[(assay,row[key])].to_dict()
        rec.update({"sample":row[key],"assay":assay,"panel":"A" if assay=="scRNA-seq" else "B"})
        records.append(rec)
pd.DataFrame(records).to_csv(SD/"FigS2_sample_crosswalk.csv",index=False)

FH=4.25
fig=plt.figure(figsize=(7.2,FH))
def AX(x0,t,x1,b):
    return fig.add_axes([x0,1-b/FH,x1-x0,(b-t)/FH])
def style(ax):
    for side in ["left","bottom"]:
        ax.spines[side].set_color("#b9b9b9")
    ax.tick_params(colors="black")
axA=AX(.075,.67,.505,2.64)
bottom=np.zeros(len(counts))
for lin in LIN:
    axA.bar(range(len(counts)),fractions[lin]*100,bottom=bottom,color=LC[lin],width=.80,ec="white",lw=.24)
    bottom+=fractions[lin].to_numpy()*100
axA.set_xticks(range(len(counts)))
axA.set_xticklabels(sc_order.display_label,rotation=90,fontsize=6.2)
axA.set_ylim(0,100)
axA.set_xlim(-.6,len(counts)-.4)
axA.set_yticks([0,25,50,75,100])
axA.set_ylabel("Captured cells (%)",labelpad=3)
previous=None
for j,pt in enumerate(sc_order.patient_id):
    if previous is not None and previous!=pt:
        axA.axvline(j-.5,color="#e1e1e1",lw=.45,zorder=0)
    previous=pt
style(axA)
fig.text(.075,1-.30/FH,"Single-cell lineage composition",fontsize=7.5,va="baseline")
fig.text(.075,1-.49/FH,"12 specimens, 90,760 cells",fontsize=6.2,va="baseline")
sc_handles=[Patch(facecolor=LC[lin],edgecolor="none",label=nm) for lin,nm in zip(LIN,LN)]
fig.legend(handles=sc_handles,loc="upper left",bbox_to_anchor=(.064,1-3.48/FH),ncol=3,frameon=False,fontsize=5.7,handlelength=.95,handletextpad=.40,columnspacing=.8,borderaxespad=0,labelspacing=.55)

axB=AX(.663,.67,.983,2.64)
left=np.zeros(len(cncounts))
for k in CNIDS:
    axB.barh(range(len(cncounts)),cnfractions[k]*100,left=left,color=CNC[k],height=.71,ec="white",lw=.27)
    left+=cnfractions[k].to_numpy()*100
labels=[]
for _,row in st_order.iterrows():
    role=SM.loc[("Visium",row.slide),"tissue_role"]
    labels.append(PM.loc[row.patient_id,"paper_patient_id"]+(" T" if role=="tumor" else " A"))
axB.set_yticks(range(len(cncounts)))
axB.set_yticklabels(labels)
axB.invert_yaxis()
axB.set_xlim(0,100)
axB.set_xticks([0,25,50,75,100])
axB.set_xlabel("Neighborhood spots (%)",labelpad=3)
style(axB)
fig.text(.587,1-.30/FH,"Spatial neighborhood composition",fontsize=7.5,va="baseline")
fig.text(.587,1-.49/FH,"5 sections, 16,620 spots",fontsize=6.2,va="baseline")
cn_handles=[Patch(facecolor=CNC[k],edgecolor="none",label=CNN[k]) for k in CNIDS]
fig.legend(handles=cn_handles,loc="upper left",bbox_to_anchor=(.557,1-3.25/FH),ncol=2,frameon=False,fontsize=5.65,handlelength=.95,handletextpad=.4,columnspacing=.8,borderaxespad=0,labelspacing=.55)

panels={"A":[.015,1-.30/FH],"B":[.54,1-.30/FH]}
for label,(x,y) in panels.items():
    fig.text(x,y,label+".",fontsize=11,fontweight="bold",va="baseline")
fig.text(.075,1-4.10/FH,"T, tumor; A, adjacent / sampled tissue",fontsize=6.0)
fig.canvas.draw()
for t in fig.findobj(match=Text):
    t.set_color("black")
fig.canvas.draw()
renderer=fig.canvas.get_renderer()
outside=[];cjk=[];nonblack=[];vertical=[]
for t in fig.findobj(match=Text):
    if not t.get_visible() or not t.get_text().strip():
        continue
    s=t.get_text()
    if re.search(r"[\u3400-\u9fff]",s):cjk.append(s)
    if "|" in s:vertical.append(s)
    if to_rgba(t.get_color())[:3]!=(0.,0.,0.):nonblack.append(s)
    bb=t.get_window_extent(renderer).transformed(fig.transFigure.inverted())
    if bb.x0<-.002 or bb.y0<-.002 or bb.x1>1.002 or bb.y1>1.002:
        outside.append({"text":s,"bbox":[float(x) for x in bb.extents]})
qa={"canvas_inches":list(fig.get_size_inches()),"panel_positions":panels,"row_aligned":panels["A"][1]==panels["B"][1],"cjk_text":cjk,"nonblack_text":nonblack,"vertical_bar_text":vertical,"outside_canvas_text":outside}
(O/"FigS2_layout_qa.json").write_text(json.dumps(qa,indent=2))
assert not outside and not cjk and not nonblack and not vertical,qa
fig.savefig(O/"FigS2.png",dpi=300)
fig.savefig(O/"FigS2.pdf")
fig.savefig(O/"FigS2_preview.jpg",dpi=170)
validation={"cells":int(counts.to_numpy().sum()),"scRNA_samples":len(counts),"lineages":len(LIN),"CN_spots":int(cncounts.to_numpy().sum()),"CN_sections":len(cncounts),"CN_count":len(CNIDS),"all_fractions_sum_to_one":True,"scRNA_sample_order":sc_order["sample"].tolist(),"Visium_sample_order":st_order.slide.tolist()}
(O/"FigS2_validation.json").write_text(json.dumps(validation,indent=2))
manifest={str(path.relative_to(ROOT)):hashlib.sha256(path.read_bytes()).hexdigest() for path in dict.fromkeys(inputs)}
(O/"FigS2_input_manifest.json").write_text(json.dumps(manifest,indent=2))
print(json.dumps(validation,indent=2))
