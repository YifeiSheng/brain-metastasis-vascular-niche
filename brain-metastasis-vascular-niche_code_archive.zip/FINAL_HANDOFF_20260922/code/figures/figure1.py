"""Render the accepted final figure from package-contained frozen inputs."""
from figure_paths import ROOT,INPUT,INTEGRATED,SPATIAL,OUT,FONT
#!/usr/bin/env python
import json, hashlib, os
from pathlib import Path
import numpy as np, pandas as pd, anndata as ad
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager, colors as mc
from matplotlib.patches import Patch
from matplotlib.lines import Line2D
font_manager.fontManager.addfont(str(FONT))
plt.rcParams.update({"font.family":["DejaVu Sans"],"font.size":7,"axes.titlesize":7.5,"axes.labelsize":7,"xtick.labelsize":6.5,"ytick.labelsize":6.5,"legend.fontsize":6.5,
"axes.linewidth":0.6,"xtick.major.width":0.5,"ytick.major.width":0.5,"xtick.major.size":2,"ytick.major.size":2,"axes.spines.top":False,"axes.spines.right":False,"pdf.fonttype":42,"savefig.dpi":300,"figure.dpi":110})
B=INPUT
DL=INTEGRATED; O=OUT; O.mkdir(exist_ok=True)
SD=O/"source_data"; SD.mkdir(exist_ok=True)
ST=SPATIAL
C=dict(met="#2a78d6",lym="#eb6834",gli="#1baf7a",ref="#898781",ink="#000000",sec="#000000",grid="#e1e0d9",axis="#c3c2b7",red="#e34948",yellow="#eda100",violet="#4a3aa7",spot="#dededa")
LIN=["上皮/肺腺癌","上皮/神经内分泌","B细胞谱系","T/NK","髓系","胶质","基质","内皮","跨谱系"]
LN=["LUAD epithelial","NE epithelial","B cells","T / NK","Myeloid","Glial","Stromal","Endothelial","Unresolved"]
LC=dict(zip(LIN,["#2a78d6","#eb6834","#1baf7a","#eda100","#e87ba4","#008300","#4a3aa7","#e34948","#c3c2b7"]))
PT=["P1","P5","P8","P3","P2","P4","P6","P7"]
SAMPLES=[("C1_BRM01","P1","旁"),("T1_BRM01","P1","瘤"),("M_C","P5","旁"),("M_T","P5","瘤"),("M2_C","P3","旁"),("M2_T","P3","瘤"),("S2_T1","P2","瘤"),("S1_C1","P4","旁"),("S1_T1","P4","瘤"),("C8","P6","旁"),("T8","P6","瘤"),("S3_T3","P7","瘤")]
SLIDES=[
("S1_T","P1","LUAD BrM · Tumor","batch_10562_2022_05_30"),
("Toct6","P8","LUAD BrM · Tumor","batch_10562_2022_05_30"),
("Toct4","P6","PCNSL · Tumor","batch_15551_2022_03_28"),
("Toct5","P2","PCNSL · Tumor","batch_15551_2022_03_28"),
("Coct4","P6","PCNSL · Adjacent","batch_15551_2022_03_28")]
CNIDS=[0,2,1,5,3,4,6,7]
CNN={0:"CN0 Epithelial score",2:"CN2 B-cell score",1:"CN1 Fibroblast",5:"CN5 Mural / EC",3:"CN3 Microglia / astro.",4:"CN4 Oligo. / brain",6:"CN6 Reactive astro.",7:"CN7 Neutrophil"}
CNC={0:"#2a78d6",2:"#eb6834",1:"#8c78b8",5:"#4a3aa7",3:"#1baf7a",4:"#8b9a8f",6:"#80c7af",7:"#eda100"}
pmf=B/"metadata/paper_patient_mapping_v4.csv"
smf=B/"metadata/paper_sample_mapping_v4.csv"
PM=pd.read_csv(pmf).set_index("patient_id")
SM=pd.read_csv(smf).set_index(["assay","sample"])
PT=PM.sort_values("paper_patient_order").index.tolist()
SAMPLES=sorted(SAMPLES,key=lambda r:(PM.loc[r[1],"paper_patient_order"],0 if r[2]=="瘤" else 1))
SLIDES=sorted(SLIDES,key=lambda r:(PM.loc[r[1],"paper_patient_order"],1 if r[0].startswith("C") else 0))
DC={"LUAD":"#2a78d6","SCLC":"#75a8da","PCNSL":"#eb6834"}
inputs=[pmf,smf]
def csv(path,**kw):
    path=Path(path); inputs.append(path); return pd.read_csv(path,**kw)
p=csv(DL/"per_cell_labels.csv").set_index("cell")
assert len(p)==90760 and p.index.is_unique
cn=csv(B/"tables/M4_spot_CN_assignments.csv.gz",index_col=0)
cent=csv(B/"tables/M4_CN_centroids_z.csv",index_col=0)
assert set(cn.CN.unique())==set(CNIDS)
comp=pd.crosstab(p["sample"],p.lineage_l1).reindex(index=[s[0] for s in SAMPLES],columns=LIN,fill_value=0)
compn=comp.div(comp.sum(axis=1),axis=0)
comp.to_csv(SD/"Fig1_lineage_counts_by_sample.csv"); compn.to_csv(SD/"Fig1_lineage_fraction_by_sample.csv")
cncomp=pd.crosstab(cn.slide,cn.CN).reindex(index=[s[0] for s in SLIDES],columns=CNIDS,fill_value=0)
cnfrac=cncomp.div(cncomp.sum(axis=1),axis=0)
cncomp.to_csv(SD/"Fig1_CN_counts_by_slide.csv"); cnfrac.to_csv(SD/"Fig1_CN_fraction_by_slide.csv")
# Cached data are keyed to the h5ad and frozen labels, never to a mutable analysis.
genes=["EPCAM","KRT19","CHGA","INSM1","CD79A","MS4A1","CD3D","NKG7","LYZ","C1QA","PLP1","MOG","DCN","PDGFRB","PECAM1","VWF"]
hp=DL/"final_integrated_annotated.h5ad"; inputs.append(hp)
cache=SD/"Fig1_marker_matrix.npz"
key=str(hp.stat().st_mtime_ns)+":"+str((DL/"per_cell_labels.csv").stat().st_mtime_ns)
if cache.exists() and np.load(cache)["key"].item()==key:
    dat=np.load(cache); means=dat["means"]; det=dat["det"]
else:
    print("Reading sc counts for identity markers",flush=True)
    a=ad.read_h5ad(hp); a.var_names_make_unique()
    assert a.obs_names.equals(p.index)
    total=np.asarray(a.X.sum(axis=1)).ravel()
    xx=a[:,genes].X.toarray().astype(float)
    norm=np.log1p(xx / np.maximum(total[:,None],1) * 1e4)
    means=np.array([norm[p.lineage_l1.eq(l)].mean(axis=0) for l in LIN])
    det=np.array([(xx[p.lineage_l1.eq(l)]>0).mean(axis=0) for l in LIN])
    np.savez_compressed(cache,key=key,means=means,det=det)
    del a,xx,norm
pd.DataFrame(means,index=LIN,columns=genes).to_csv(SD/"Fig1_marker_mean_logCP10K.csv")
pd.DataFrame(det,index=LIN,columns=genes).to_csv(SD/"Fig1_marker_fraction_detected.csv")


# Reusable styling and manual inch-based layout.
from matplotlib.patches import Circle, Polygon, Rectangle, FancyArrowPatch
from matplotlib.text import Text as MText
import re
from matplotlib.colors import to_rgba
FH=7.3;fig=plt.figure(figsize=(7.2,FH))
plt.rcParams.update({"text.color":"black","axes.labelcolor":"black","xtick.color":"black","ytick.color":"black"})
def AX(x0,t,x1,b,**kw):return fig.add_axes([x0,1-b/FH,x1-x0,(b-t)/FH],**kw)
def off(ax):
    ax.set_xticks([]);ax.set_yticks([])
    for sp in ax.spines.values():sp.set_visible(False)
def title(ax,s):ax.set_title(s,loc="left",fontsize=7.1,pad=5,color="black")
def style(ax):
    for side in ["left","bottom"]:ax.spines[side].set_color("#b9b9b9")
    ax.tick_params(colors="black")
# Coverage retains all source IDs, including provisional mapping qualifications in metadata/caption.
coverage=pd.DataFrame(0,index=["scRNA tumor","scRNA adjacent","Visium tumor","Visium adjacent"],columns=PT)
for pt in PT:
    coverage.loc["scRNA tumor",pt]=int(((p.patient_id==pt)&(p.tissue_role=="tumor")).any())
    coverage.loc["scRNA adjacent",pt]=int(((p.patient_id==pt)&(p.tissue_role=="adjacent_or_field")).any())
for fp in sorted((B/"tables").glob("spot_bands_*.csv")):
    rr=csv(fp).iloc[0]
    coverage.loc["Visium tumor" if rr.role=="tumor" else "Visium adjacent",rr.patient]=1
assert list(coverage.sum(axis=1))==[7,5,4,4]
coverage.to_csv(SD/"Fig1_modality_coverage.csv")
p["paper_patient_id"]=p.patient_id.map(PM.paper_patient_id)
p["paper_disease"]=p.patient_id.map(PM.paper_disease)
# A: anatomy illustration plus actual donor-by-specimen glyphs.
# The AI illustration is conceptual, NOT a cohort image or inferred lesion location.
axA=AX(.04,.34,.985,1.77);off(axA);axA.set_xlim(0,6.80);axA.set_ylim(0,1.64)
asset=INPUT/"assets/brain_brm_pcnsL_coronal.png";inputs.append(asset)
art=plt.imread(asset)
axA.imshow(art,extent=(0,2.38,.275,1.64),aspect="auto",interpolation="lanczos")
axA.text(.59,.20,"Lung BrM",ha="center",fontsize=7,fontweight="bold")
axA.text(1.79,.20,"PCNSL",ha="center",fontsize=7,fontweight="bold")
axA.text(.59,.04,"LUAD / SCLC",ha="center",fontsize=5.8)
axA.text(1.79,.04,"DLBCL",ha="center",fontsize=5.8)
title(axA,"Study design and cohort coverage")
# Broad arrows denote assay branches, not confirmed specimen pairing.
def arr(x0,y0,x1,y1):
    axA.add_patch(FancyArrowPatch((x0,y0),(x1,y1),arrowstyle="-|>",mutation_scale=6,lw=.7,color="#77848b",shrinkA=2,shrinkB=2))
axA.plot([2.38,2.49,2.49,2.68],[.83,.83,1.25,1.25],color="#77848b",lw=.7)
axA.plot([2.49,2.49,2.68],[.83,.40,.40],color="#77848b",lw=.7)
arr(2.56,1.25,2.68,1.25);arr(2.56,.40,2.68,.40)
# Whole-cell suspension and generic RNA reads avoid unverified experimental hardware.
for j,(dx,dy,rr) in enumerate([(-.10,.09,.047),(.00,.12,.055),(.11,.06,.05),(-.12,-.02,.05),(0,-.02,.06),(.10,-.07,.046),(-.03,-.12,.05)]):
    axA.add_patch(Circle((2.86+dx,1.25+dy),rr,fc=["#bbd3df","#c6bfdc","#dbbdba","#b8d2c4","#ded1aa","#c3d4df","#cabdd5"][j],ec="#718796",lw=.4))
    axA.add_patch(Circle((2.86+dx+.005,1.25+dy),rr*.36,fc="#7a8e9e",ec="none"))
arr(3.07,1.25,3.37,1.25)
for j,col in enumerate(["#537c91","#839e90","#a58ab0"]):
    xx=np.linspace(3.44,3.79,40); yy=1.33-.08*j+.02*np.sin(np.linspace(0,3*np.pi,40)+j)
    axA.plot(xx,yy,color=col,lw=1)
    for xp in np.arange(3.46,3.80,.06):
        yp=np.interp(xp,xx,yy);axA.plot([xp,xp],[yp,yp-.035],color=col,lw=.6)
axA.text(3.33,1.56,"scRNA-seq",ha="center",fontsize=6.7,fontweight="bold")
axA.text(2.86,1.00,"Cells",ha="center",fontsize=5.6)
arr(3.89,1.25,4.11,1.25)
# Sections and a spatial capture slide.
tissue=np.array([[-.17,-.09],[-.20,.02],[-.11,.12],[.04,.10],[.17,.04],[.18,-.06],[.07,-.12],[-.06,-.08]])
for k in range(3):
    axA.add_patch(Polygon(tissue+[2.88-.025*k,.40+.033*k],closed=True,fc=["#e2c7c7","#ecd8d7","#f2e3e2"][k],ec="#a58485",lw=.4))
axA.text(2.86,.12,"Sections",ha="center",fontsize=5.6)
arr(3.08,.40,3.37,.40)
axA.add_patch(Rectangle((3.43,.23),.39,.31,fc="#eff4f5",ec="#7a95a1",lw=.65))
axA.add_patch(Rectangle((3.43,.23),.08,.31,fc="#cfdee4",ec="none"))
axA.add_patch(Polygon(tissue*.56+[3.66,.38],closed=True,fc="#e8cbd0",ec="#a58485",lw=.35))
for xx in np.arange(3.57,3.78,.042):
    for yy in np.arange(.29,.49,.042):axA.add_patch(Circle((xx,yy),.007,fc="#537c91",ec="none"))
axA.text(3.33,.77,"Visium",ha="center",fontsize=6.7,fontweight="bold")
arr(3.89,.40,4.11,.40)
# Every specimen symbol corresponds to one actual sample/section; aligned donors expose overlap.
xs=np.linspace(4.66,6.64,8)
for j,pt in enumerate(PT):
    dis=PM.loc[pt,"paper_disease"];col=DC[dis]
    axA.add_patch(Circle((xs[j],1.37),.035,fc=col,ec="none"))
    axA.add_patch(Polygon([[xs[j]-.045,1.22],[xs[j]-.045,1.30],[xs[j]+.045,1.30],[xs[j]+.045,1.22]],closed=True,fc=col,ec="none"))
    axA.text(xs[j],1.13,str(PM.loc[pt,"paper_patient_id"]).split("-")[-1],ha="center",va="center",fontsize=5.5)
    for row,yy in enumerate([.91,.72,.43,.24]):
        exists=bool(coverage.iloc[row,j])
        if not exists:
            axA.plot([xs[j]-.017,xs[j]+.017],[yy,yy],color="#d5d5d5",lw=.8);continue
        if row<2:
            axA.add_patch(Circle((xs[j],yy),.048,fc=col if row==0 else "white",ec=col,lw=.8))
            if row==0:axA.add_patch(Circle((xs[j]+.007,yy-.003),.013,fc="white",ec="none",alpha=.9))
        else:
            axA.add_patch(Rectangle((xs[j]-.052,yy-.035),.104,.07,fc=col if row==2 else "white",ec=col,lw=.7))
            axA.plot([xs[j]-.032,xs[j]-.032],[yy-.026,yy+.026],color="white" if row==2 else col,lw=.6)
for x0,x1,lab in [(xs[0]-.08,xs[2]+.08,"LUAD"),(xs[3]-.09,xs[3]+.09,"SCLC"),(xs[4]-.08,xs[7]+.08,"PCNSL")]:
    axA.text((x0+x1)/2,1.58,lab,fontsize=5.7,ha="center")
    axA.plot([x0,x1],[1.50,1.50],color="black",lw=.45)
for yy,txt in [(.91,"Tumor"),(.72,"Adjacent"),(.43,"Tumor"),(.24,"Adjacent")]:
    axA.text(4.40,yy,txt,ha="right",va="center",fontsize=5.5)
axA.text(5.65,.055,"One symbol per specimen",ha="center",fontsize=5.3)
pd.DataFrame([{"patient_id":pt,"paper_patient_id":PM.loc[pt,"paper_patient_id"],"row":row,"sample_present":int(coverage.loc[row,pt])} for pt in PT for row in coverage.index]).to_csv(SD/"Fig1_panel_A_specimen_glyphs.csv",index=False)

# B: coordinated frozen UMAPs with legends to the RIGHT of each plot.
umap_axes=[];umap_legends=[];rng=np.random.default_rng(17);ix=rng.permutation(len(p))
xlim=(p.UMAP_1.min()-1,p.UMAP_1.max()+1);ylim=(p.UMAP_2.min()-1,p.UMAP_2.max()+1)
fig.text(.055,1-1.99/FH,"Harmony-integrated single-cell atlas, 90,760 cells",fontsize=7.3,va="baseline",color="black")
donor_order=[pt for pt in PT if pt in set(p.patient_id)]
donor_colors=dict(zip(donor_order,["#2a78d6","#168f94","#7856a6","#eb6834","#c6a42d","#52944d","#be5484"]))
display_ln=["LUAD epith.","NE epith.","B cell","T / NK","Myeloid","Glial","Stromal","Endothelial","Unresolved"]
for k,(left,right,col,ttl) in enumerate([
(.045,.217,p.lineage_l1.map(LC),"Cell annotation"),
(.375,.547,p.patient_id.map(donor_colors),"Donor"),
(.705,.877,p.paper_disease.map(DC),"Disease")]):
    ax=AX(left,2.22,right,3.63);umap_axes.append(ax)
    ax.scatter(p.UMAP_1.values[ix],p.UMAP_2.values[ix],c=col.values[ix],s=.31,lw=0,rasterized=True)
    ax.set_xlim(xlim);ax.set_ylim(ylim);ax.set_aspect("equal");ax.set_anchor("NW");off(ax);title(ax,ttl)
    if k==0:
        handles=[Line2D([],[],marker="o",color="none",markerfacecolor=LC[lin],markeredgecolor="none",markersize=3,label=nm) for lin,nm in zip(LIN,display_ln)]
    elif k==1:
        handles=[Line2D([],[],marker="o",color="none",markerfacecolor=donor_colors[pt],markeredgecolor="none",markersize=3,label=PM.loc[pt,"paper_patient_id"]) for pt in donor_order]
    else:
        handles=[Line2D([],[],marker="o",color="none",markerfacecolor=DC[d],markeredgecolor="none",markersize=3,label=d+(" BrM" if d!="PCNSL" else "")) for d in ["LUAD","SCLC","PCNSL"]]
    umap_legends.append(ax.legend(handles=handles,loc="center left",bbox_to_anchor=(1.02,.5),ncol=1,frameon=False,fontsize=5.5,handlelength=.8,handletextpad=.32,borderaxespad=0,labelspacing=.35))
p[["sample","patient_id","paper_patient_id","paper_disease","lineage_l1","UMAP_1","UMAP_2"]].to_csv(SD/"Fig1_frozen_UMAP_views.csv.gz",compression="gzip")
# C: fixed lineage-marker evidence.
axC=AX(.160,4.02,.476,5.00);z=means/np.maximum(means.max(axis=0),1e-12)
for i in range(len(LIN)):
    axC.scatter(np.arange(len(genes)),np.full(len(genes),i),s=det[i]*29,c=z[i],cmap="Blues",vmin=0,vmax=1,lw=0)
axC.set_xlim(-.6,len(genes)-.4);axC.set_ylim(len(LIN)-.5,-.5)
axC.set_yticks(range(len(LIN)));axC.set_yticklabels(LN,fontsize=5.5)
axC.set_xticks(range(len(genes)));axC.set_xticklabels(genes,rotation=90,fontsize=5.3,fontstyle="italic");axC.tick_params(length=0)
for k in np.arange(1.5,15,2):axC.axvline(k,color="#e1e1e1",lw=.45,zorder=0)
for sp in axC.spines.values():sp.set_visible(False)
title(axC,"Lineage markers")
caxC=AX(.488,4.12,.495,4.93);cb=fig.colorbar(plt.cm.ScalarMappable(norm=mc.Normalize(0,1),cmap="Blues"),cax=caxC,ticks=[0,1]);cb.ax.tick_params(labelsize=5,length=1);cb.set_label("Relative mean",fontsize=5.1,labelpad=2)
leg=[axC.scatter([],[],s=v*29,c="#7b7b7b",label=f"{int(v*100)}%") for v in [.1,.5,1]]
fig.text(.160,1-5.53/FH,"Cells expressing (%)",fontsize=5.2,color="black")
axC.legend(handles=leg,loc="upper left",bbox_to_anchor=(.328,1-5.44/FH),bbox_transform=fig.transFigure,ncol=3,frameon=False,fontsize=5.3,handletextpad=.25,columnspacing=.6,borderaxespad=0)
# D: retain the eight CN identities that explain the spatial maps.
features=["肺腺癌上皮","淋巴瘤B","T细胞","干扰素反应巨噬","成纤维细胞","血管周细胞/平滑肌","内皮细胞","活化小胶质","星形胶质","少突胶质成熟","反应性星形胶质","中性粒"]
flabs=["LUAD epith.","B cell","T cell","IFN macroph.","Fibroblast","Mural","Endothelial","Act. microglia","Astrocyte","Oligodendro.","React. astro.","Neutrophil"]
axD=AX(.721,4.02,.958,5.00);hh=cent.loc[CNIDS,features]
im=axD.imshow(hh.values,aspect="auto",cmap="RdBu_r",vmin=-2,vmax=2,interpolation="nearest")
axD.set_yticks(range(8));axD.set_yticklabels([CNN[i] for i in CNIDS],fontsize=5.15)
for y,k in enumerate(CNIDS):axD.add_patch(Rectangle((-8.9,y-.46),.25,.92,color=CNC[k],clip_on=False,lw=0))
axD.set_xticks(range(len(features)));axD.set_xticklabels(flabs,rotation=90,fontsize=5.0);axD.tick_params(length=0)
for sp in axD.spines.values():sp.set_visible(False)
title(axD,"Spatial neighborhood signatures")
hh.to_csv(SD/"Fig1_CN_selected_centroids_z.csv")
caxD=AX(.965,4.16,.973,4.95);cb=fig.colorbar(im,cax=caxD,ticks=[-2,0,2],extend="both");cb.ax.tick_params(labelsize=5,length=1)
caxD.set_title("z",fontsize=5.5,pad=2,color="black")
# White gaps are controlled in inches, not equal-width subplot cells.
map_height=1.12; map_gap=.16; map_top=5.99
map_data=[]
for sl,pt,desc,batch in SLIDES:
    d=cn[cn.slide==sl];sfp=ST/batch/"1.SpaceRanger"/sl/"spatial/scalefactors_json.json";inputs.append(sfp)
    sf=json.loads(sfp.read_text());um_per_px=55/float(sf["spot_diameter_fullres"])
    x=d.px*um_per_px;y=-d.py*um_per_px
    xr=x.max()-x.min();yr=y.max()-y.min()
    map_data.append((sl,pt,d,x,y,xr,yr))
widths=[map_height*v[5]/v[6] for v in map_data]
total_width=sum(widths)+map_gap*(len(widths)-1)
left_in=(7.2-total_width)/2
axE=[];spatial_boxes=[]
for j,((sl,pt,d,x,y,xr,yr),width) in enumerate(zip(map_data,widths)):
    ax=AX(left_in/7.2,map_top,(left_in+width)/7.2,map_top+map_height);axE.append(ax)
    ax.scatter(x,y,c=d.CN.map(CNC),s=2.5,lw=0,rasterized=True)
    ax.set_xlim(x.min()-.025*xr,x.max()+.025*xr);ax.set_ylim(y.min()-.025*yr,y.max()+.025*yr)
    ax.set_aspect("equal");ax.set_anchor("N");off(ax)
    bx=x.min()+.025*xr;by=y.min()+.025*yr
    ax.plot([bx,bx+1000],[by,by],color="black",lw=1.1)
    ax.text(bx+500,by+.025*yr,"1 mm",ha="center",va="bottom",fontsize=5.0,bbox=dict(fc="white",ec="none",pad=.3,alpha=.9))
    ax.set_title(PM.loc[pt,"paper_patient_name"],loc="center",fontsize=6.0,pad=5,color="black")
    ax.text(.5,-.065,"Adjacent" if sl.startswith("C") else "Tumor",transform=ax.transAxes,ha="center",va="top",fontsize=5.4)
    spatial_boxes.append({"slide":sl,"paper_patient_id":PM.loc[pt,"paper_patient_id"],"left_in":left_in,"width_in":width,"height_in":map_height})
    left_in+=width+map_gap
pd.DataFrame([{"slide":sl,"patient_id":pt,"paper_patient_id":PM.loc[pt,"paper_patient_id"],"paper_sample_id":SM.loc[("Visium",sl),"paper_sample_id"]} for sl,pt,_,_ in SLIDES]).to_csv(SD/"Fig1_panel_E_sample_order.csv",index=False)
panel_positions={}
for key,x,top in [("A",.015,.18),("B",.015,1.94),("C",.015,3.82),("D",.552,3.82),("E",.015,5.78)]:
    fig.text(x,1-top/FH,key+".",fontfamily="DejaVu Sans",fontsize=11,fontweight="bold",va="baseline",color="black")
    panel_positions[key]=[x,1-top/FH]
# All text black, including colorbar/legend text; scientific data colors are preserved.
for t in fig.findobj(match=MText):
    t.set_color("#000000")
    if t.get_text():t.set_text(t.get_text().replace(" | "," · ").replace("|",""))
fig.canvas.draw()
for t in fig.findobj(match=MText):t.set_color("#000000")
fig.savefig(O/"Fig1.png",dpi=300);fig.savefig(O/"Fig1.pdf");fig.savefig(O/"Fig1_preview.jpg",dpi=170)
manifest={}
for path in dict.fromkeys(inputs):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""):h.update(chunk)
    manifest[str(path.relative_to(ROOT))]=h.hexdigest()
(O/"Fig1_input_manifest.json").write_text(json.dumps(manifest,indent=2))
summary={"cells":len(p),"donor_ids_sc":p.patient_id.nunique(),"samples_sc":p["sample"].nunique(),"CN_slides":len(cnfrac),"CN_spots":len(cn),"CN_count":8,"modality_matrix_counts":coverage.sum(axis=1).to_dict(),"patient_order":PT,"donor_linkage":"P8 provisional; P2 spatial linkage inferred; qualifications in metadata and caption","UMAP":"Three views of same frozen Harmony embedding; unchanged coordinates, limits and draw order"}
(O/"Fig1_validation.json").write_text(json.dumps(summary,indent=2))
fig.canvas.draw();renderer=fig.canvas.get_renderer();outside=[];cjk=[];nonblack=[];bars=[]
for t in fig.findobj(match=MText):
    if not t.get_visible() or not t.get_text().strip():continue
    txt=t.get_text()
    if re.search(r"[\u3400-\u9fff]",txt):cjk.append(txt)
    if "|" in txt:bars.append(txt)
    if to_rgba(t.get_color())[:3]!=(0.,0.,0.):nonblack.append(txt)
    bb=t.get_window_extent(renderer).transformed(fig.transFigure.inverted())
    if bb.x0<-.002 or bb.y0<-.002 or bb.x1>1.002 or bb.y1>1.002:outside.append({"text":txt,"bbox":[float(v) for v in bb.extents]})
qa={"cjk_text":cjk,"nonblack_text":nonblack,"vertical_bar_text":bars,"outside_canvas_text":outside,"panel_positions":panel_positions,"left_column_aligned":len({panel_positions[k][0] for k in ["A","B","C","E"]})==1,"row_aligned":panel_positions["C"][1]==panel_positions["D"][1],"umap_same_limits":all(np.array_equal(a.get_xlim(),umap_axes[0].get_xlim()) and np.array_equal(a.get_ylim(),umap_axes[0].get_ylim()) for a in umap_axes),"canvas_inches":list(fig.get_size_inches()),"spatial_boxes_inches":spatial_boxes,"spatial_map_height_gain":map_height/.56,"spatial_axes_gap_inches":map_gap,"legend_placement":"right of each UMAP","umap_legend_to_right":[bool(lg.get_window_extent(renderer).x0>=ax.get_window_extent(renderer).x1) for ax,lg in zip(umap_axes,umap_legends)]}
(O/"Fig1_layout_qa.json").write_text(json.dumps(qa,indent=2))
print(json.dumps(summary),flush=True)
assert not outside and not cjk and not nonblack and not bars,qa
