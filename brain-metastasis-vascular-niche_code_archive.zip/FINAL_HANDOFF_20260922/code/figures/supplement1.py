"""Render the accepted final figure from package-contained frozen inputs."""
from figure_paths import ROOT,INPUT,INTEGRATED,SPATIAL,OUT,FONT
# Fig 1: 队列、冻结图谱与恶性身份 (Result 1). 一个脚本生成整张图, 子图按英寸手工定位.
import os, re, numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib import font_manager, colors as mcolors
from matplotlib.patches import Patch
from scipy.cluster.hierarchy import linkage, leaves_list
font_manager.fontManager.addfont(str(FONT))
plt.rcParams.update({"font.family":["Noto Sans CJK SC","DejaVu Sans"],"font.size":7,"axes.titlesize":7.5,"axes.labelsize":7,"xtick.labelsize":6.5,"ytick.labelsize":6.5,"legend.fontsize":6.5,
    "axes.linewidth":0.6,"xtick.major.width":0.5,"ytick.major.width":0.5,"xtick.major.size":2,"ytick.major.size":2,"axes.spines.top":False,"axes.spines.right":False,"pdf.fonttype":42,"savefig.dpi":300})
B=str(INPUT); DL=str(INTEGRATED); FIG=str(OUT); os.makedirs(FIG,exist_ok=True)
C=dict(met="#2a78d6",lym="#eb6834",gli="#1baf7a",ref="#898781",ink="#0b0b0b",sec="#52514e",grid="#e1e0d9",axis="#c3c2b7",red="#e34948")
LIN_ORDER=["上皮/肺腺癌","上皮/神经内分泌","B细胞谱系","T/NK","髓系","胶质","基质","内皮","跨谱系"]
LIN_NAME={"上皮/肺腺癌":"肺腺癌上皮","上皮/神经内分泌":"神经内分泌肿瘤上皮","B细胞谱系":"B 细胞谱系","T/NK":"T/NK 细胞","髓系":"髓系","胶质":"胶质","基质":"基质","内皮":"内皮","跨谱系":"跨谱系/未定"}
LIN_COL=dict(zip(LIN_ORDER,["#2a78d6","#eb6834","#1baf7a","#eda100","#e87ba4","#008300","#4a3aa7","#e34948","#c3c2b7"]))
def style(ax,grid="y"):
    if grid: ax.grid(axis=grid,color=C["grid"],lw=0.5); ax.set_axisbelow(True)
    for s in ["left","bottom"]: ax.spines[s].set_color(C["axis"])
    ax.tick_params(colors=C["sec"],labelcolor=C["ink"])
FH=4.9; fig=plt.figure(figsize=(7.2,FH))
def Y(t,b): return 1-b/FH,1-t/FH
def AX(x0,t,x1,b,**kw): y0,y1=Y(t,b); return fig.add_axes([x0,y0,x1-x0,y1-y0],**kw)
def label_panels(fig,groups):
    fig.canvas.draw(); r=fig.canvas.get_renderer()
    for L,axs in groups.items():
        bbs=[a.get_tightbbox(r).transformed(fig.transFigure.inverted()) for a in axs]
        x0=max(min(b.x0 for b in bbs)-0.006,0.003); y1=min(max(b.y1 for b in bbs)+0.003,0.99)
        fig.text(x0,y1,f"{L}.",fontsize=11,fontweight="bold",fontfamily="DejaVu Sans",ha="left",va="bottom",color=C["ink"])
# ---------------- 数据 ----------------
p=pd.read_csv(f"{DL}/per_cell_labels.csv"); pm=pd.read_csv(f"{DL}/patient_metadata.csv")
DIS={"肺腺癌":"肺腺癌脑转移","A型小细胞肺癌":"小细胞肺癌脑转移","弥漫大B细胞淋巴瘤":"中枢神经系统淋巴瘤"}; pdis=dict(zip(pm.patient_id,pm["疾病"].map(DIS)))
d6=pd.read_csv(f"{B}/tables/D6_brain_vs_primary_fisher.csv")
CHRLEN={"chr1":248956422,"chr2":242193529,"chr3":198295559,"chr4":190214555,"chr5":181538259,"chr6":170805979,"chr7":159345973,"chr8":145138636,"chr9":138394717,"chr10":133797422,"chr11":135086622,"chr12":133275309,"chr13":114364328,"chr14":107043718,"chr15":101991189,"chr16":90338345,"chr17":83257441,"chr18":80373285,"chr19":58617616,"chr20":64444167,"chr21":46709983,"chr22":50818468,"chrX":156040895}
CHRS=list(CHRLEN); BIN=2e6; START={}; NBIN={}; off=0
for c in CHRS: START[c]=off; NBIN[c]=int(np.ceil(CHRLEN[c]/BIN)); off+=NBIN[c]
NB=off
calls=pd.read_csv(f"{B}/infercnv/M7c_luad_malignant_calls_hmm.csv")

# Show HMM output only: no synthetic reference profiles.
def cnv_rows(pt,max_rows=480):
    d=f"{B}/infercnv/{pt}"
    reg=pd.read_csv(f"{d}/infercnv_out/17_HMM_predHMMi6.leiden.hmm_mode-subclusters.pred_cnv_regions.dat",sep="\t")
    grp=pd.read_csv(f"{d}/infercnv_out/17_HMM_predHMMi6.leiden.hmm_mode-subclusters.cell_groupings",sep="\t")
    V={}
    for g,sub in reg.groupby("cell_group_name"):
        v=np.full(NB,3.)
        for _,r in sub.iterrows():
            if r.chr not in START: continue
            b0=START[r.chr]+int(r.start//BIN);b1=min(START[r.chr]+NBIN[r.chr],START[r.chr]+int(r.end//BIN)+1)
            v[b0:b1]=r.state
        V[g]=v
    mal=calls[calls.patient==pt].set_index("cell").malignant_hmm
    q=grp[grp.cell.isin(mal.index)].copy();q["mal"]=q.cell.map(mal).astype(bool)
    matrix=[];bounds=[];metadata=[]
    for m,label in [(False,"未过恶性阈值"),(True,"过恶性阈值")]:
        z=q[q.mal==m]
        if z.empty:continue
        cnt=z.groupby("cell_group_name").size()
        missing=[g for g in cnt.index if g not in V]
        if missing:raise RuntimeError(f"{pt}: no HMM profile for {missing}")
        vec=np.array([V[g] for g in cnt.index])
        order=leaves_list(linkage(vec,"average")) if len(cnt)>2 else np.arange(len(cnt))
        begin=len(matrix)
        for i in order: matrix.extend([vec[i]]*max(1,round(max_rows*cnt.iloc[i]/len(q))))
        bounds.append((begin,len(matrix),label,int(cnt.sum()),len(cnt)))
        metadata.append(dict(patient=pt,status=label,cells=int(cnt.sum()),HMM_groups=len(cnt)))
    ann=pd.read_csv(f"{d}/annotations.txt",sep="\t",header=None,names=["cell","group"])
    return np.array(matrix),bounds,metadata,int(ann.group.eq("LUAD_epithelial").sum())
cmap=mcolors.ListedColormap(["#2166ac","#92c5de","#f7f7f7","#f4a582","#d6604d","#8b0000"])
norm=mcolors.BoundaryNorm(np.arange(.5,7),6)
AXS=[];summary=[]
for pt,x0,x1 in [("P1",.06,.325),("P5",.365,.63)]:
    ax=AX(x0,.55,x1,4.10);M,bounds,info,denom=cnv_rows(pt);summary+=info
    im=ax.imshow(M,cmap=cmap,norm=norm,aspect="auto",interpolation="nearest",origin="upper",rasterized=True)
    for ch in CHRS[1:]:ax.axvline(START[ch]-.5,color="white",lw=.35)
    for start,end,label,n,ng in bounds:
        if start:ax.axhline(start-.5,color=C["ink"],lw=.7)
        # DATA coordinates share the image's top-origin direction.
        ax.text(NB*.98,(start+end)/2,label+f"\nn={n:,} / {ng} HMM 组",ha="right",va="center",fontsize=5.7,
            bbox=dict(fc="white",ec="none",alpha=.90,pad=1.5))
    show=[f"chr{i}" for i in [1,3,5,7,8,11,13,18]]+["chrX"]
    ax.set_xticks([START[c]+NBIN[c]/2 for c in show]);ax.set_xticklabels([c[3:] for c in show],fontsize=5)
    ax.set_yticks([]);ax.set_xlabel("染色体（2 Mb 窗口）",fontsize=6)
    ax.set_title(f"内部 {pt} · {sum(x['cells'] for x in info):,}/{denom:,} 细胞",loc="left",fontsize=7)
    for sp in ax.spines.values():sp.set_visible(False)
    AXS.append(ax)
cax=AX(.18,4.45,.53,4.54);cb=fig.colorbar(im,cax=cax,orientation="horizontal",ticks=[1,2,3,4,5,6]);cb.set_label("inferCNV i6 HMM 状态（3 = 二倍体基线；非实测拷贝数）",fontsize=5.7,labelpad=2)
# The same nominal-p-selected events are preserved, without arm/gene equivalence diamonds.
axE=AX(.80,.55,.985,4.10);nb,npr=174,2479;EV={"amp2":"扩增","deepdel":"深缺失"}
d=d6.copy();d["a"]=(d.brain_frac*nb).round();d["c"]=(d.primary_frac*npr).round();d["b"]=nb-d.a;d["d"]=npr-d.c
se=np.sqrt(1/np.maximum(d.a,.5)+1/np.maximum(d.b,.5)+1/np.maximum(d.c,.5)+1/np.maximum(d.d,.5))
d["lo"]=np.exp(np.log(d.OR.clip(lower=1e-3))-1.96*se);d["hi"]=np.exp(np.log(d.OR.clip(lower=1e-3))+1.96*se)
d=d[(d.fisher_p<.05)&np.isfinite(d.OR)&(d.OR>0)&(d.a>0)&(d.c>0)].sort_values("fisher_p").head(12).sort_values("OR")
for i,(_,r) in enumerate(d.iterrows()):
    axE.plot([r.lo,r.hi],[i,i],color=C["met"],lw=1)
    axE.scatter(r.OR,i,s=19,color=C["met"],edgecolors="white",lw=.5,zorder=3)
axE.axvline(1,color=C["axis"],lw=.6);axE.set_xscale("log");axE.set_xlim(.8,3000);axE.set_xticks([1,10,100,1000])
axE.set_yticks(range(len(d)));axE.set_yticklabels([f"{r.gene} {EV[r.event]}" for _,r in d.iterrows()],fontsize=6)
axE.set_title("公共 MSK-MET",loc="left",fontsize=7);axE.set_xlabel("OR：脑转移 vs 原发",fontsize=6);style(axE,"x")
axE.text(.5,-.16,"174 vs 2,479 例\n按名义 p<0.05 筛选",transform=axE.transAxes,ha="center",fontsize=5.6,color=C["sec"])
fig.canvas.draw();rr=fig.canvas.get_renderer()
for letter,axes in [("A",AXS),("B",[axE])]:
    bb=[a.get_tightbbox(rr).transformed(fig.transFigure.inverted()) for a in axes]
    fig.text(max(.006,min(z.x0 for z in bb)-.012),.964,letter+".",fontsize=11,fontweight="bold",fontfamily="DejaVu Sans")
pd.DataFrame(summary).to_csv(f"{FIG}/source_data/FigS1_HMM_coverage.csv",index=False)
d.to_csv(f"{FIG}/source_data/FigS1_MSK_selected_events.csv",index=False)
fig.savefig(f"{FIG}/FigS1.png",dpi=300);fig.savefig(f"{FIG}/FigS1.pdf");fig.savefig(f"{FIG}/FigS1_preview.jpg",dpi=170)
print("Supplement 1 rendered",summary)

# Reproducible visual bounds QA (in addition to human image inspection).
from matplotlib.text import Text as _Text
import json as _json
fig.canvas.draw(); _renderer=fig.canvas.get_renderer(); _outside=[]
for _t in fig.findobj(match=_Text):
    if not _t.get_visible() or not _t.get_text().strip(): continue
    _bb=_t.get_window_extent(_renderer).transformed(fig.transFigure.inverted())
    if _bb.x0 < -.002 or _bb.y0 < -.002 or _bb.x1 > 1.002 or _bb.y1 > 1.002:
        _outside.append({"text":_t.get_text(),"bbox":[float(v) for v in _bb.extents]})
(OUT/'FigS1_layout_qa.json').write_text(_json.dumps({"outside_canvas_text":_outside,"axes_count":len(fig.axes),"canvas_inches":list(fig.get_size_inches())},ensure_ascii=False,indent=2))
