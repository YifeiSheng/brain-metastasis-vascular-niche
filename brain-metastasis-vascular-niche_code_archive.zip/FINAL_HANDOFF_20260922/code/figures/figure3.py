"""Render the accepted final figure from package-contained frozen inputs."""
from figure_paths import ROOT,INPUT,INTEGRATED,SPATIAL,OUT,FONT
# Fig 3: 脑内肿瘤共同缺失外周招募的免疫层 (Result 3). 一个脚本生成整张图.
import os, re, numpy as np, pandas as pd, scanpy as sc, scipy.io
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib import font_manager, gridspec, colors as mcolors
from matplotlib.lines import Line2D
from scipy.stats import mannwhitneyu

plt.rcParams.update({"text.color":"#000000","axes.labelcolor":"#000000","axes.titlecolor":"#000000","xtick.color":"#000000","ytick.color":"#000000","font.family":["DejaVu Sans"],"font.size":7,"axes.titlesize":7.5,"axes.labelsize":7,"xtick.labelsize":6.5,"ytick.labelsize":6.5,"legend.fontsize":6.5,
    "axes.linewidth":0.6,"xtick.major.width":0.5,"ytick.major.width":0.5,"xtick.major.size":2,"ytick.major.size":2,"axes.spines.top":False,"axes.spines.right":False,"pdf.fonttype":42,"savefig.dpi":300,"figure.dpi":110})
B=str(INPUT); DL=str(INTEGRATED); FIG=str(OUT); R15=f"{B}/tables"
ST=str(SPATIAL)
os.makedirs(f"{FIG}/source_data",exist_ok=True)
# Canonical paper identifiers are shared across all main figures.
PAPER_PATIENTS=pd.read_csv(f"{B}/metadata/paper_patient_mapping_v4.csv")
PAPER_ID=PAPER_PATIENTS.set_index("patient_id")["paper_patient_id"].to_dict()
PAPER_ORDER=PAPER_PATIENTS.set_index("patient_id")["paper_patient_order"].to_dict()
def paper_id(patient_id):
    return PAPER_ID[patient_id]

C=dict(met="#2a78d6",lym="#eb6834",gli="#1baf7a",ref="#898781",ink="#000000",sec="#52514e",grid="#e1e0d9",axis="#c3c2b7",red="#e34948",yellow="#eda100",violet="#4a3aa7",magenta="#e87ba4",spot="#dededa")
def style(ax,grid="y"):
    if grid: ax.grid(axis=grid,color=C["grid"],lw=0.5); ax.set_axisbelow(True)
    for s in ["left","bottom"]: ax.spines[s].set_color(C["axis"])
    ax.tick_params(colors=C["sec"],labelcolor=C["ink"])
def label_panels(fig,groups):
    fig.canvas.draw(); fig.set_layout_engine(None); r=fig.canvas.get_renderer()
    for L,axs in groups.items():
        bbs=[a.get_tightbbox(r).transformed(fig.transFigure.inverted()) for a in axs]
        x0=max(min(b.x0 for b in bbs)-0.006,0.003); y1=min(max(b.y1 for b in bbs)+0.004,0.995)
        fig.text(x0,y1,f"{L}.",fontsize=11,fontweight="bold",fontfamily="DejaVu Sans",ha="left",va="bottom",color=C["ink"])
def strip(ax,vals,cols,labels,jitter=0.07,s=9,rot=0,fs=6.5):
    for i,(v,c) in enumerate(zip(vals,cols)):
        v=np.asarray(v,float); v=v[~np.isnan(v)]
        if len(v)==0: continue
        x=np.random.default_rng(i).normal(i,jitter,len(v)); ax.scatter(x,v,s=s,color=c,alpha=0.9,linewidths=0.4,edgecolors="white",zorder=3); ax.hlines(np.median(v),i-0.3,i+0.3,color=C["ink"],lw=1.1,zorder=4)
    ax.set_xticks(range(len(labels))); ax.set_xticklabels(labels,rotation=rot,fontsize=fs,ha="right" if rot else "center",rotation_mode="anchor" if rot else "default")
def pstr(p): return "p<0.001" if p<0.001 else f"p={p:.3f}" if p<0.01 else f"p={p:.2f}"
# ---------------- A: 内部 sc 肥大细胞 / DC ----------------
lab=pd.read_csv(f"{DL}/per_cell_labels.csv").set_index("cell")
a=sc.read_h5ad(f"{DL}/final_integrated_annotated.h5ad"); a.var_names_make_unique(); lab=lab.loc[lab.index.intersection(a.obs_names)]; a=a[lab.index].copy()
mix=lab.index[lab.atomic_cluster_id=="r4_053"]; pdc=lab.index[lab.atomic_cluster_id=="r4_055"]
G=["TPSAB1","CPA3","LAMP3","CCR7","CLEC9A","XCR1","CD1C","CLEC10A","LILRA4"]; g=[x for x in G if x in a.var_names]
X=pd.DataFrame(np.asarray(a[list(mix)+list(pdc),g].X.todense())>0,index=list(mix)+list(pdc),columns=g)
def cell_type(i):
    if i in set(pdc): return "pDC"
    r=X.loc[i]
    if r.get("TPSAB1",False) or r.get("CPA3",False): return "肥大细胞"
    if r.get("LAMP3",False) or r.get("CCR7",False): return "mregDC"
    if r.get("CLEC9A",False) or r.get("XCR1",False): return "cDC1"
    if r.get("CD1C",False) or r.get("CLEC10A",False): return "cDC2"
    return "其他髓系"
ct=pd.Series({i:cell_type(i) for i in X.index}); TCOL={"肥大细胞":C["red"],"pDC":C["violet"],"mregDC":C["yellow"],"cDC1":C["gli"],"cDC2":C["lym"]}
# ---------------- B: 内部 Visium 检出 ----------------
SL=[("S1_T","batch_10562_2022_05_30","P1 肺腺癌"),("Toct6","batch_10562_2022_05_30","P8 肺腺癌"),("Toct4","batch_15551_2022_03_28","P6 淋巴瘤"),("Toct5","batch_15551_2022_03_28","P2 淋巴瘤")]
BG=[("TPSAB1","肥大细胞"),("LILRA4","pDC"),("LAMP3","mregDC")]
def load_slide(sl,batch):
    p=f"{ST}/{batch}/1.SpaceRanger/{sl}"; v=sc.read_10x_h5(f"{p}/filtered_feature_bc_matrix.h5"); v.var_names_make_unique()
    pos=pd.read_csv(f"{p}/spatial/tissue_positions_list.csv",header=None)
    if str(pos.iloc[0,0]).strip()=="barcode": pos=pd.read_csv(f"{p}/spatial/tissue_positions_list.csv")
    pos.columns=["barcode","in_tissue","row","col","py","px"]; pos=pos.set_index("barcode").reindex(v.obs_names); v=v[pos.in_tissue.fillna(0).astype(int)==1].copy(); pos=pos.reindex(v.obs_names)
    v.obs["px"]=pos.px.values.astype(float); v.obs["py"]=pos.py.values.astype(float); return v
# ---------------- C/D: 跨队列 ----------------
S=pd.read_csv(f"{R15}/S1_all_signature_frequencies.csv")
COH=[("Kim2020_sc","正常肺","Kim | normal lung","out"),("Kim2020_sc","肺原发","Kim | primary lung","out"),("Izar2023_sn","肺原发","Tagore | primary lung","out"),("Biermann2022_sn","颅外转移","Biermann | ECM","out"),
     ("Gonzalez2022_sc","脑转移","Gonzalez | BrM","in"),("Kim2020_sc","脑转移","Kim | BrM","in"),("内部_sc","癌转移(内部)","Internal | BrM","in"),("Izar2023_sn","脑转移","Tagore | BrM","in"),("Biermann2022_sn","脑转移","Biermann | BrM","in"),("Duke2026_sn","脑转移","Duke | BrM","in"),("Simon2026_multiome","脑转移","Simon | BrM","in"),("Yang2026_sn","脑转移","Yang | BrM","in"),
     ("内部_sc","PCNSL(内部)","Internal | PCNSL","in"),("Heming2022_sc","PCNSL(外部)","Heming | PCNSL","in"),("GSE181304_sc","PCNSL(外部)","GSE181304 | PCNSL","in"),("Steen2021_sc","结内DLBCL","Steen | nodal DLBCL","out")]
COH=[(a,b,c.replace(" | ",", "),d) for a,b,c,d in COH]
def cohort_vals(sig_prefix):
    vals=[]; 
    for coh,grp,_,_ in COH:
        q=S[(S.cohort==coh)&(S.group==grp)&S.signature.str.startswith(sig_prefix)]; vals.append(q.frac_of_lineage.values)
    return vals
CCOL=[C["met"] if c[3]=="in" else C["ref"] for c in COH]; CLAB=[c[2] for c in COH]
# ---------------- E: IMC ----------------
M1=pd.read_csv(f"{R15}/M1_imc_immune_by_patient_region.csv"); M1=M1[M1.region=="Tumor Core"]
# ---------------- F: PCNSL vs 结内 ----------------
L2=pd.read_csv(f"{R15}/L2_patient_level_frequencies.csv")
# ================= 画图（7.2 x 7.4；面板顺序：内部数据 → 内部+公共合并 → 公共验证） =================
FH=7.4; fig=plt.figure(figsize=(7.2,FH))
def Y(t,b): return 1-b/FH,1-t/FH
def AX(x0,t,x1,b,**kw): y0,y1=Y(t,b); return fig.add_axes([x0,y0,x1-x0,y1-y0],**kw)
XR=R15; XC=dict(mast=C["red"],pDC=C["violet"],cDC1=C["gli"],mregDC=C["yellow"]); XN={"mast":"Mast","pDC":"pDC","cDC1":"cDC1","mregDC":"mregDC","T":"T cells","macro":"Macro."}
R1T,R1B=0.46,2.50; R2T,R2B=2.98,5.10; R3T,R3B=5.52,6.87
# ---------------- A 内部单细胞 ----------------
axA1=AX(0.045,R1T,0.25,R1B); axA1.scatter(lab.UMAP_1,lab.UMAP_2,s=0.2,c="#e6e6e2",linewidths=0,rasterized=True)
for t,col in TCOL.items():
    idx=ct.index[ct==t]; axA1.scatter(lab.loc[idx,"UMAP_1"],lab.loc[idx,"UMAP_2"],s=4,c=col,linewidths=0,rasterized=True,label="{} ({})".format("Mast" if t=="肥大细胞" else t,len(idx)))
axA1.set_xticks([]); axA1.set_yticks([]); axA1.set_aspect("equal"); axA1.set_anchor("N"); [axA1.spines[s_].set_color(C["axis"]) for s_ in ["left","bottom"]]
axA1.legend(loc="upper center",bbox_to_anchor=(0.5,-0.03),frameon=False,markerscale=3,handletextpad=0.3,fontsize=5.6,labelspacing=0.25,ncol=2,columnspacing=0.6)
axA1.set_title("Internal scRNA-seq: 90,760 cells",fontsize=6.5,loc="left")
axA2=AX(0.315,R1T,0.43,R1B-0.47); PT=sorted(lab.patient_id.unique(),key=lambda _p:PAPER_ORDER[_p]); tab=pd.crosstab(lab.loc[ct.index,"patient_id"],ct).reindex(PT).fillna(0).reindex(columns=list(TCOL)).fillna(0)
tab_count=tab.copy(); tab=tab.div(lab.groupby("patient_id").size().reindex(PT),axis=0)*100
bottom=np.zeros(len(PT))
for t,col in TCOL.items(): axA2.bar(range(len(PT)),tab[t].values,bottom=bottom,width=0.72,color=col,edgecolor="white",linewidth=0.5); bottom+=tab[t].values
axA2.set_xticks(range(len(PT))); axA2.set_xticklabels([paper_id(_p) for _p in PT],fontsize=5.5,rotation=90); axA2.set_ylabel("All cells (%)",fontsize=6); style(axA2,grid=None); axA2.set_title("7 patients",fontsize=6.5,loc="left")
# ---------------- B 内部 + 7 个公共队列 (合并分析) ----------------
SIGS=[("肥大细胞","Mast"),("浆细胞样树突状细胞 pDC","pDC"),("成熟调节型树突状细胞 mregDC","mregDC"),("经典 1 型树突状细胞 cDC1","cDC1"),("经典 2 型树突状细胞 cDC2","cDC2")]
Hm=np.full((len(COH),len(SIGS)),np.nan); NS=np.zeros(len(COH),int); Nmat=np.zeros_like(Hm,dtype=int)
for i,(coh,grp,_,_) in enumerate(COH):
    for j,(pre,_) in enumerate(SIGS):
        q=S[(S.cohort==coh)&(S.group==grp)&(S.signature.eq(pre) if pre=="肥大细胞" else S.signature.str.startswith(pre))]
        if len(q): Hm[i,j]=q.frac_of_lineage.median(); Nmat[i,j]=q["sample"].nunique(); NS[i]=max(NS[i],Nmat[i,j])
axB=AX(0.665,R1T,0.952,R1B); cm=mcolors.LinearSegmentedColormap.from_list("b",["#f7f9fc","#7cabd6"])
cm.set_bad("#e9e8e4"); imB=axB.imshow(np.ma.masked_invalid(Hm),cmap=cm,norm=mcolors.PowerNorm(gamma=.45,vmin=0,vmax=.30),aspect="auto")
for i in range(Hm.shape[0]):
    for j in range(Hm.shape[1]):
        if not np.isnan(Hm[i,j]):
            v=Hm[i,j]*100; txt="0" if v==0 else "<0.1" if v<.1 else "{:.1f}".format(v)
            axB.text(j,i,txt,ha="center",va="center",fontsize=5.3,color="white" if Hm[i,j]>.075 else C["ink"])
        else:
            axB.add_patch(plt.Rectangle((j-.5,i-.5),1,1,facecolor="none",edgecolor="#b9b8b2",hatch="////",lw=0))
            axB.text(j,i,"NA",ha="center",va="center",fontsize=5,color=C["sec"])
IS_IN=[("内部" in c[0]) for c in COH]
for i,isin in enumerate(IS_IN):
    if isin: axB.add_patch(plt.Rectangle((-0.5,i-0.5),len(SIGS),1,fill=False,ec=C["ink"],lw=1.1,zorder=5,clip_on=False))
axB.set_xticks(range(len(SIGS))); axB.set_xticklabels([n for _,n in SIGS],fontsize=6); axB.xaxis.tick_top()
axB.set_yticks(range(len(COH))); axB.set_yticklabels(["{} ({})".format(c[2],n_) for c,n_ in zip(COH,NS)],fontsize=5.5)
for tl,isin,c in zip(axB.get_yticklabels(),IS_IN,COH):
    tl.set_color(C["ink"]);  tl.set_fontweight("bold" if isin else "normal")
for yk in [3.5,11.5]: axB.axhline(yk,color=C["ink"],lw=0.8)
[s_.set_visible(False) for s_ in axB.spines.values()]; axB.tick_params(length=0)
axB.set_xlabel("Median % of myeloid cells; boxes: internal\n(n): maximum available samples; NA: not estimated",fontsize=5.8,labelpad=3)
axB.set_title("Internal + 10 public cohorts",fontsize=6.5,loc="left",pad=14)
caxB=AX(.962,.75,.971,2.23); cbB=fig.colorbar(imB,cax=caxB,ticks=[0,.001,.01,.05,.15,.30]); cbB.ax.set_yticklabels(["0","0.1","1","5","15","30"]); cbB.ax.tick_params(labelsize=5,length=1); cbB.ax.set_title("%",fontsize=5.5,pad=3)
for i,(_,grp,_,loc) in enumerate(COH):
    col=C["lym"] if "PCNSL" in grp else C["met"] if loc=="in" else C["ref"]
    pass  # Site identity is explicit in labels; avoid overlap with sample counts.
pd.DataFrame(Hm,index=[c[2] for c in COH],columns=[g[1] for g in SIGS]).to_csv(f"{FIG}/source_data/Fig3_heatmap_medians.csv")
pd.DataFrame(Nmat,index=[c[2] for c in COH],columns=[g[1] for g in SIGS]).to_csv(f"{FIG}/source_data/Fig3_heatmap_n_by_celltype.csv")
tab_count.to_csv(f"{FIG}/source_data/Fig3_internal_marker_defined_counts.csv");tab.to_csv(f"{FIG}/source_data/Fig3_internal_percent_all_cells.csv")
# ---------------- C 淋巴瘤: 内部 4 例 + 外部 3 例 vs 结内 (合并分析) ----------------
axC=AX(0.16,R2T,0.475,R2B-0.26); SIGD=[("浆细胞样树突状细胞 pDC","pDC"),("成熟调节型树突状细胞 mregDC","mregDC"),("经典 2 型树突状细胞 cDC2","cDC2"),("经典单核细胞","Classical mono."),("活化调节性 T 细胞","Activated Treg\n(T/NK)")]
ys=np.arange(len(SIGD))[::-1]
for y_,(pre,nm) in zip(ys,SIGD):
    q=L2[L2.signature.str.startswith(pre)]; a_in=q[q.group=="PCNSL(内部)"].frac_of_lineage; a_ex=q[q.group=="PCNSL(外部)"].frac_of_lineage; a_=pd.concat([a_in,a_ex]); b_=q[q.group=="结内DLBCL"].frac_of_lineage
    axC.plot([a_.median()*100,b_.median()*100],[y_,y_],color=C["axis"],lw=1.6,zorder=2)
    axC.scatter(a_ex*100,[y_+0.2]*len(a_ex),s=9,facecolors="none",edgecolors=C["lym"],linewidths=0.7,zorder=2)
    axC.scatter(a_in*100,[y_+0.2]*len(a_in),s=11,color=C["lym"],alpha=0.9,linewidths=0,zorder=3)
    axC.scatter(b_*100,[y_-0.2]*len(b_),s=9,color=C["ref"],alpha=0.6,linewidths=0,zorder=2)
    axC.scatter(a_.median()*100,y_,s=26,color=C["lym"],zorder=4,edgecolors="white",linewidths=0.5); axC.scatter(b_.median()*100,y_,s=26,color=C["ref"],zorder=4,edgecolors="white",linewidths=0.5)
    pv=mannwhitneyu(a_,b_).pvalue if len(a_)>=3 and len(b_)>=3 else np.nan; axC.text(41.5,y_,pstr(pv),va="center",ha="left",fontsize=5.8,color=C["sec"])
axC.set_yticks(ys); axC.set_yticklabels([n for _,n in SIGD],fontsize=6); axC.set_xlabel("Parent lineage (%); large dots: medians"); style(axC,grid="x"); axC.set_xlim(-1,50); axC.set_xticks([0,10,20,30,40]); axC.set_ylim(-0.7,len(SIGD)+.55)
axC.legend(handles=[Line2D([],[],marker="o",ls="",color=C["lym"],markersize=4,label="Internal PCNSL (4)"),Line2D([],[],marker="o",ls="",mfc="none",mec=C["lym"],markersize=4,label="Public PCNSL (3)"),Line2D([],[],marker="o",ls="",color=C["ref"],markersize=4,label="Nodal DLBCL (4)")],loc="upper left",bbox_to_anchor=(.43,1.04),ncol=1,frameon=False,fontsize=5.6,handletextpad=0.2,columnspacing=0.8)
axC.set_title("PCNSL vs nodal DLBCL",fontsize=6.5,loc="left")
# ---------------- D 公共 Xenium 单细胞空间图 ----------------
from sklearn.neighbors import KDTree
SLIDE="X_14_0024"; xs=pd.read_csv(f"{XR}/cells_{SLIDE}.csv.gz"); xs["x"]=xs.x-xs.x.min(); xs["y"]=xs.y-xs.y.min()
ECxy=xs.loc[xs.cls=="EC",["x","y"]].values; isDC=xs.cls.isin(["pDC","cDC1","mregDC"]).values
xs["nearEC"]=KDTree(ECxy).query(xs[["x","y"]].values,k=1)[0][:,0]<=15
BIN=25.0; NX=int(np.ceil(xs.x.max()/BIN))+1; NY=int(np.ceil(xs.y.max()/BIN))+1
xb=(xs.x.values/BIN).astype(int); yb=(xs.y.values/BIN).astype(int)
def integral(mask):
    Hh=np.zeros((NX,NY)); np.add.at(Hh,(xb[mask],yb[mask]),1); Sc=np.zeros((NX+1,NY+1)); Sc[1:,1:]=Hh.cumsum(0).cumsum(1); return Sc
I_all=integral(np.ones(len(xs),bool)); I_ec=integral((xs.cls=="EC").values); I_tu=integral((xs.cls=="tumor").values); I_dc=integral(isDC); I_dcv=integral(isDC&xs.nearEC.values)
def wsum(Sc,K): return Sc[K:,K:]-Sc[:-K,K:]-Sc[K:,:-K]+Sc[:-K,:-K]
F=4000.0; KF=int(F/BIN); Wall=wsum(I_all,KF); Wtu=wsum(I_tu,KF); Wdcv=wsum(I_dcv,KF); ftu=np.divide(Wtu,np.maximum(Wall,1))
sc_=np.where((Wall>=30000)&(ftu>=0.35)&(ftu<=0.75),Wdcv,-1); fi,fj=np.unravel_index(np.argmax(sc_),sc_.shape); FX,FY=fi*BIN,fj*BIN
fld=xs[(xs.x>=FX)&(xs.x<FX+F)&(xs.y>=FY)&(xs.y<FY+F)]
W=400.0; K=int(W/BIN); wall=wsum(I_all,K); wec=wsum(I_ec,K); wtu=wsum(I_tu,K); wdc=wsum(I_dc,K); wdcv=wsum(I_dcv,K); wf=np.divide(wtu,np.maximum(wall,1))
inside=np.zeros_like(wall,bool); inside[fi:fi+KF-K,fj:fj+KF-K]=True; dense=wall>=np.median(wall[inside])*0.8
ZW={}
for k_,scz in [("i",np.where(inside&dense&(wec>=60)&(wdcv>=3),wdcv+0.02*wec,-1)),("ii",np.where(inside&dense&(wf>=0.7)&(wec<=20)&(wdc<=1),wf*100,-1))]:
    i_,j_=np.unravel_index(np.argmax(scz),scz.shape); ZW[k_]=(i_*BIN,j_*BIN,int(wdc[i_,j_]),int(wec[i_,j_]),float(wf[i_,j_]))
axD1=AX(0.57,R2T,0.785,R2B); axD1.set_aspect("equal"); axD1.set_anchor("N")
for cls,col,sz in [("other","#f2f1ee",1.2),("T","#c9c8c0",1.6),("tumor","#dcdcd6",1.8),("EC","#2a78d6",2.6)]:
    q=fld[fld.cls==cls]; axD1.scatter(q.x,q.y,s=sz,c=col,linewidths=0,rasterized=True)
q=fld[fld.cls=="mast"]; axD1.scatter(q.x,q.y,s=7,c=XC["mast"],linewidths=0.25,edgecolors="white",zorder=3)
for cls in ["pDC","cDC1","mregDC"]:
    q=fld[fld.cls==cls]; axD1.scatter(q.x,q.y,s=13,c=XC[cls],linewidths=0.4,edgecolors="white",zorder=4)
axD1.set_xlim(FX,FX+F); axD1.set_ylim(FY,FY+F); axD1.set_xticks([]); axD1.set_yticks([]); [s_.set_visible(False) for s_ in axD1.spines.values()]
axD1.plot([FX+F-560,FX+F-60],[FY+70]*2,color=C["ink"],lw=1.5); axD1.text(FX+F-310,FY+110,"500 µm",ha="center",va="bottom",fontsize=5.6)
axD1.set_title("Public Xenium | breast BrM",fontsize=6.5,loc="left")
for k_,(cx,cy,ndc,nec,ft) in ZW.items():
    axD1.add_patch(plt.Rectangle((cx,cy),W,W,fill=False,ec=C["ink"],lw=1.2,zorder=5)); axD1.text(cx+W+70,cy+W/2,k_,ha="left",va="center",fontsize=8,color=C["ink"],fontfamily="DejaVu Sans",fontweight="bold")
NC={c_:int((fld.cls==c_).sum()) for c_ in ["EC","tumor","mast","pDC","cDC1","mregDC"]}
LEG=[("#2a78d6","EC",NC["EC"]),("#dcdcd6","Tumor",NC["tumor"]),(XC["mast"],"Mast",NC["mast"]),(XC["pDC"],"pDC",NC["pDC"]),(XC["cDC1"],"cDC1",NC["cDC1"]),(XC["mregDC"],"mregDC",NC["mregDC"])]
axD1.legend(handles=[Line2D([],[],marker="o",ls="",color=col,markersize=4,label="{} ({:,})".format(nm,nn)) for col,nm,nn in LEG],loc="upper center",bbox_to_anchor=(0.5,-0.01),ncol=2,frameon=False,fontsize=5.4,handletextpad=0.2,columnspacing=0.6)
axD=[axD1]; ZT={"i":"i  Vascular region","ii":"ii  Tumor nest"}
for n_,(k_,(cx,cy,ndc,nec,ft)) in enumerate(ZW.items()):
    ax=AX(0.85,R2T+n_*1.12,0.985,R2T+n_*1.12+.98); axD.append(ax); z=xs[(xs.x>=cx)&(xs.x<cx+W)&(xs.y>=cy)&(xs.y<cy+W)]
    for cls,col,sz in [("other","#f2f1ee",6),("T","#c9c8c0",6),("tumor","#dcdcd6",8),("EC","#2a78d6",14)]:
        q=z[z.cls==cls]; ax.scatter(q.x,q.y,s=sz,c=col,linewidths=0)
    q=z[z.cls=="mast"]; ax.scatter(q.x,q.y,s=16,c=XC["mast"],linewidths=0.3,edgecolors="white",zorder=3)
    for cls in ["pDC","cDC1","mregDC"]:
        q=z[z.cls==cls]; ax.scatter(q.x,q.y,s=36,c=XC[cls],linewidths=0.5,edgecolors="white",zorder=4)
    ax.set_xlim(cx,cx+W); ax.set_ylim(cy,cy+W); ax.set_aspect("equal"); ax.set_xticks([]); ax.set_yticks([]); [s_.set_color(C["ink"]) for s_ in ax.spines.values()]
    ax.set_title(ZT[k_],fontsize=6,loc="left",pad=2)
    ax.text(0.03,0.97,"EC {}\nDC {}\nTumor {:.0f}%".format(nec,ndc,ft*100),transform=ax.transAxes,ha="left",va="top",fontsize=5.2,color=C["sec"],linespacing=1.35,bbox=dict(boxstyle="round,pad=0.15",fc="white",ec="none",alpha=0.85))
    ax.plot([cx+W-120,cx+W-20],[cy+20]*2,color=C["ink"],lw=1.3); ax.text(cx+W-70,cy+30,"100 µm",ha="center",va="bottom",fontsize=5)
pd.DataFrame([{"window":k,"x_um":v[0],"y_um":v[1],"width_um":W,"n_DC":v[2],"n_EC":v[3],"tumor_fraction":v[4]} for k,v in ZW.items()]).to_csv(f"{FIG}/source_data/Fig3_Xenium_windows.csv",index=False)
# ---------------- E 公共 Xenium 定量 ----------------
cnts=pd.read_csv(f"{XR}/X_xenium_rare_counts.csv"); nbr=pd.read_csv(f"{XR}/X_xenium_rare_neighbor.csv"); order=["mast","pDC","cDC1","mregDC","T","macro"]
axE1=AX(0.085,R3T,0.215,R3B)
for i,c_ in enumerate(order):
    v=cnts[f"{c_}_per_10k"].values; axE1.scatter(np.random.default_rng(i).normal(i,0.06,len(v)),v,s=10,color=XC.get(c_,C["ref"]),linewidths=0.4,edgecolors="white",zorder=3); axE1.hlines(np.median(v),i-0.3,i+0.3,color=C["ink"],lw=1.1,zorder=4)
axE1.set_yscale("log"); axE1.set_xticks(range(len(order))); axE1.set_xticklabels([XN[c_] for c_ in order],fontsize=6,rotation=90); axE1.set_ylabel("Cells per 10,000 cells"); style(axE1); axE1.set_title("Xenium: 4 sections",fontsize=6.5,loc="left")
axE2=AX(0.30,R3T,0.49,R3B); ys=np.arange(len(order))[::-1]
for y_,c_ in zip(ys,order):
    for tgt,col,dy in [("EC","#5598e7",0.16),("tumor","#898781",-0.16)]:
        v=nbr[(nbr.cell==c_)&(nbr.target==tgt)&(nbr.radius_um==15)].enrich.values; v=np.log2(np.clip(v,0.05,None))
        for vv in v:
            axE2.scatter(vv,y_+dy,s=13,color=col,marker="<" if vv<=np.log2(.05)+1e-9 else "o",linewidths=.4,edgecolors="white",zorder=3)
        if len(v): axE2.plot([np.median(v)]*2,[y_+dy-0.12,y_+dy+0.12],color=C["ink"],lw=1.1,zorder=4)
axE2.axvline(0,color=C["axis"],lw=0.7); axE2.set_yticks(ys); axE2.set_yticklabels([XN[c_] for c_ in order],fontsize=6); axE2.set_xlabel("15-µm enrichment, log2(obs/null)",fontsize=6); style(axE2,grid="x")
axE2.legend(handles=[Line2D([],[],marker="o",ls="",color="#5598e7",label="Near EC"),Line2D([],[],marker="o",ls="",color="#898781",label="Near tumor")],loc="upper left",bbox_to_anchor=(-.15,-.23),frameon=False,fontsize=5.6,handletextpad=0.2,ncol=2); axE2.set_title("Neighborhood",fontsize=6.5,loc="left")
# ---------------- F 公共 Visium 配对 ----------------
PAIRS=[("B14","B14.Primary","B14T.update"),("B352","B352.Primary.update","B352T"),("B361","B361.Primary.update","B361T.update"),("B98","B98T.Primary","B98T")]
# Accepted source percentages are computed from CPA3/TPSAB1 spot detection.
_pairsource=pd.read_csv(INPUT/"tables/Fig3_public_Visium_pairs.csv").set_index("patient")
axF=AX(0.585,R3T,0.70,R3B)
_visium_pairs=[]
for pt,pr,bm in PAIRS:
    a_,b_=_pairsource.loc[pt,["primary_mast_positive_spots_percent","BrM_mast_positive_spots_percent"]]; axF.plot([0,1],[a_,b_],"-",color=C["ref"],lw=1,zorder=2); axF.scatter([0],[a_],s=16,color=C["ref"],zorder=3,edgecolors="white",linewidths=0.4); axF.scatter([1],[b_],s=16,color=C["met"],zorder=3,edgecolors="white",linewidths=0.4); axF.text(-0.08,a_,pt,ha="right",va="center",fontsize=5.4,color=C["sec"])
    _visium_pairs.append({"patient":pt,"primary_sample":pr,"BrM_sample":bm,"primary_mast_positive_spots_percent":a_,"BrM_mast_positive_spots_percent":b_})
axF.set_xticks([0,1]); axF.set_xticklabels(["Primary","BrM"],fontsize=5.5); axF.set_xlim(-0.55,1.3); axF.set_ylabel("Mast-marker-positive spots (%)"); style(axF); axF.set_title("Public Visium: 4 pairs",fontsize=6.5,loc="left")
# ---------------- G 公共成像质谱 ----------------
axG=AX(0.83,R3T,0.975,R3B); M1["grp"]=np.where(M1.group=="脑转移","脑转移","胶质瘤")
vals=[M1[M1.grp=="脑转移"]["dens_DCs cell"].dropna().values,M1[M1.grp=="胶质瘤"]["dens_DCs cell"].dropna().values,M1[M1.grp=="脑转移"]["dens_Mast cell"].dropna().values,M1[M1.grp=="胶质瘤"]["dens_Mast cell"].dropna().values]
strip(axG,vals,[C["met"],C["gli"],C["met"],C["gli"]],["BrM","Glioma","BrM","Glioma"],s=5,fs=5.8,jitter=0.09); axG.set_ylabel("Cell density (per mm²)"); style(axG); axG.set_yscale("symlog",linthresh=1); axG.set_ylim(-0.25,max(np.concatenate(vals))*2.5); axG.set_yticks([0,1,10,100]); axG.set_yticklabels(["0","1","10","100"])
for x_,t_,pv in [(0.5,"DCs",mannwhitneyu(vals[0],vals[1]).pvalue),(2.5,"Mast",mannwhitneyu(vals[2],vals[3]).pvalue)]: axG.text(x_,0.98,"{}\n{}".format(t_,pstr(pv)),transform=axG.get_xaxis_transform(),ha="center",va="top",fontsize=5.8,color=C["sec"])
axG.axvline(1.5,color=C["grid"],lw=0.6); axG.set_title("Public IMC: 41 vs 139",fontsize=6.5,loc="left"); axG.text(0,-.27,"ROI–patient mapping\nverified",transform=axG.transAxes,fontsize=5.1,color=C["sec"])

# Final display-only typography pass; source categories remain traceable.
from matplotlib.text import Text as _Text
fig.canvas.draw()
for _t in fig.findobj(match=_Text):
    _t.set_color("#000000")
    _t.set_text(_t.get_text().replace(" | ",", ").replace("｜",", ").replace("|",", "))
PANEL_X={"A":.015,"B":.510,"C":.015,"D":.555,"E":.015,"F":.530,"G":.765}
PANEL_ROWS=[["A","B"],["C","D"],["E","F","G"]]

def label_panels_rows(fig,groups,rows):
    # Column anchors do not depend on differing ylabel/tick widths.
    fig.canvas.draw(); r=fig.canvas.get_renderer(); pos={}
    for L,axs in groups.items():
        bbs=[a.get_tightbbox(r).transformed(fig.transFigure.inverted()) for a in axs]
        pos[L]=max(b.y1 for b in bbs)
    for row in rows:
        y=min(max(pos[L] for L in row)+0.003,0.99)
        for L in row:
            fig.text(PANEL_X[L],y,f"{L}.",fontsize=11,fontweight="bold",
                     fontfamily="DejaVu Sans",ha="left",va="bottom",color="#000000")
label_panels_rows(fig,{"A":[axA1,axA2],"B":[axB],"C":[axC],"D":axD,"E":[axE1,axE2],"F":[axF],"G":[axG]},PANEL_ROWS)
pd.DataFrame([{"patient_id":p,"paper_patient_id":paper_id(p),"display_order":i+1} for i,p in enumerate(PT)]).to_csv(f"{FIG}/source_data/Fig3_panel_A_patient_order.csv",index=False)
fig.savefig(f"{FIG}/Fig3.png",dpi=300); fig.savefig(f"{FIG}/Fig3.pdf"); fig.savefig(f"{FIG}/Fig3_preview.jpg",dpi=170); print("Figure 3 rendered")


# Visible-artist validation checks the delivered figure, not source lookup strings.
from matplotlib.text import Text as _Text
import json as _json
from pathlib import Path as _Path
fig.canvas.draw(); _renderer=fig.canvas.get_renderer()
_outside=[]; _cjk=[]; _nonblack=[]; _bars=[]; _panel_positions={}; _visible_text=[]
for _t in fig.findobj(match=_Text):
    if not _t.get_visible() or not _t.get_text().strip(): continue
    _s=_t.get_text(); _visible_text.append(_s)
    if re.search(r"[\u3400-\u9fff]",_s): _cjk.append(_s)
    if "|" in _s or "｜" in _s: _bars.append(_s)
    if mcolors.to_rgba(_t.get_color()) != (0.,0.,0.,1.): _nonblack.append({"text":_s,"color":str(_t.get_color())})
    _bb=_t.get_window_extent(_renderer).transformed(fig.transFigure.inverted())
    if _bb.x0 < -.002 or _bb.y0 < -.002 or _bb.x1 > 1.002 or _bb.y1 > 1.002:
        _outside.append({"text":_s,"bbox":[float(v) for v in _bb.extents]})
    if re.fullmatch(r"[A-H]\.",_s): _panel_positions[_s.rstrip(".")]=[float(v) for v in _t.get_position()]
_row_qa=[{"panels":_row,"same_y":len({round(_panel_positions[_l][1],10) for _l in _row})==1} for _row in PANEL_ROWS]
_left_qa=all(abs(_panel_positions[_r[0]][0]-.015)<1e-10 for _r in PANEL_ROWS)
_qa={"cjk_text":_cjk,"nonblack_text":_nonblack,"vertical_bar_text":_bars,"outside_canvas_text":_outside,
     "axes_count":len(fig.axes),"canvas_inches":list(fig.get_size_inches()),"panel_label_positions":_panel_positions,
     "same_row_alignment":_row_qa,"left_column_x":.015,"left_column_alignment":_left_qa,
     "visible_text":_visible_text}
_Path(FIG,"Fig3_layout_qa.json").write_text(_json.dumps(_qa,ensure_ascii=False,indent=2))
assert not _cjk, _cjk
assert not _nonblack, _nonblack
assert not _bars, _bars
assert not _outside, _outside
assert all(_row["same_y"] for _row in _row_qa) and _left_qa, _row_qa


from collections import Counter as _Counter
import hashlib as _hashlib
def _sha(p):
    h=_hashlib.sha256()
    with open(p,"rb") as f:
        for block in iter(lambda:f.read(4*1024*1024),b""): h.update(block)
    return h.hexdigest()
_extra={
    "Fig3_PCNSL_patient_level_frequencies.csv":L2,
    "Fig3_Xenium_rare_counts.csv":cnts,
    "Fig3_Xenium_rare_neighbor.csv":nbr,
    "Fig3_IMC_tumor_core.csv":M1,
    "Fig3_public_Visium_pairs.csv":pd.DataFrame(_visium_pairs),
    "Fig3_Xenium_field_counts.csv":pd.DataFrame([NC]),
    "Fig3_Xenium_field_extent.csv":pd.DataFrame([{"x_um":FX,"y_um":FY,"width_um":F,"total_cells":len(fld)}]),
}
for _name,_frame in _extra.items(): _frame.to_csv(_Path(FIG,"source_data",_name),index=False)
_highlights=lab.loc[ct.index,["UMAP_1","UMAP_2","patient_id"]].copy()
_highlights["marker_defined_cell_type"]=ct
_highlights.to_csv(_Path(FIG,"source_data","Fig3_internal_highlighted_cells.csv"))
