#!/usr/bin/env python3
"""Verify every delivered payload file against the final manifest."""
from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parents[1]
manifest=json.loads((root/'MANIFEST.json').read_text())
bad=[]
for i,x in enumerate(manifest['files'],1):
 p=root/x['path']
 if not p.is_file():bad.append([x['path'],'missing']);continue
 h=hashlib.sha256()
 with p.open('rb') as f:
  for c in iter(lambda:f.read(8*1024*1024),b''):h.update(c)
 if h.hexdigest()!=x['sha256'] or p.stat().st_size!=x['bytes']:bad.append([x['path'],'checksum/size mismatch'])
print(json.dumps({'files_checked':len(manifest['files']),'mismatches':bad},ensure_ascii=False,indent=2))
sys.exit(bool(bad))
