#!/usr/bin/env Rscript
# Package the selected frozen state. No integration, graph, UMAP or labels are recomputed.
Sys.setlocale("LC_CTYPE", "C.UTF-8")
args <- commandArgs(trailingOnly=TRUE)
stopifnot(length(args)==3)
B<-normalizePath(args[1]); H<-normalizePath(args[2]); P<-normalizePath(args[3])
Sys.setenv(OPENBLAS_NUM_THREADS="2",OMP_NUM_THREADS="2",MKL_NUM_THREADS="2")
suppressPackageStartupMessages({library(Seurat);library(Matrix);library(jsonlite)})
out<-file.path(P,"data/integrated"); dir.create(out,recursive=TRUE,showWarnings=FALSE)
tmp<-file.path(dirname(P),"HANDOFF_PREPARATION_20260922/frozen_bridge")
dir.create(tmp,recursive=TRUE,showWarnings=FALSE)
D<-file.path(B,"delivery/biomni_annotation_20260905")
x<-readRDS(file.path(D,"work/S2_seurat_frozen.rds"))
labels<-read.csv(file.path(D,"output/per_cell_labels.csv"),stringsAsFactors=FALSE,check.names=FALSE,fileEncoding="UTF-8")
stopifnot(!anyDuplicated(labels$cell),identical(colnames(x),labels$cell))
for(n in intersect(c("sample","patient_id","tissue_role","atomic_cluster_id"),colnames(x@meta.data)))
 stopifnot(identical(as.character(x@meta.data[[n]]),as.character(labels[[n]])))
lat<-readRDS(file.path(H,"integration/harmony_biology_preserving_hvg3000_theta0p5_seed41.latent.rds"))
s<-readRDS(file.path(H,"graph/v2_2_selected_graph_grid/snn_matrix_v2_2.rds"))
stopifnot(!anyDuplicated(lat$cell),!anyDuplicated(s$cell),setequal(colnames(x),s$cell),setequal(colnames(x),lat$cell))
hm<-lat$latent[match(colnames(x),lat$cell),,drop=FALSE]
stopifnot(identical(unname(Embeddings(x,"harmony")),unname(hm)))
sn<-s$snn[match(colnames(x),s$cell),match(colnames(x),s$cell)]
stopifnot(nrow(sn)==ncol(x),ncol(sn)==ncol(x))
rownames(sn)<-colnames(sn)<-colnames(x)
um<-Embeddings(x,"umap")
stopifnot(max(abs(um-as.matrix(labels[,c("UMAP_1","UMAP_2")])))<1e-14)
# Current labels keep all uncertainty; no recoding of labels or identities.
for(n in setdiff(colnames(labels),c("cell","UMAP_1","UMAP_2"))) x[[n]]<-labels[[n]]
ca<-read.csv(file.path(D,"output/cluster_annotation.csv"),stringsAsFactors=FALSE,check.names=FALSE,fileEncoding="UTF-8")
ci<-match(labels$atomic_cluster_id,ca$atomic_cluster_id);stopifnot(!anyNA(ci))
for(n in c("confidence","assignment_status","marker_identity_within_cluster"))x[[paste0("cluster_",n)]]<-ca[[n]][ci]
pm<-read.csv(file.path(B,"data/metadata/paper_sample_mapping_v4.csv"),stringsAsFactors=FALSE,check.names=FALSE,fileEncoding="UTF-8")
pm<-pm[pm$assay=="scRNA-seq",]; stopifnot(!anyDuplicated(pm$sample))
ix<-match(labels$sample,pm$sample); stopifnot(!anyNA(ix))
for(n in grep("^paper_",colnames(pm),value=TRUE))x[[n]]<-pm[[n]][ix]
x[["frozen_snn"]]<-as.Graph(sn);DefaultAssay(x[["frozen_snn"]])<-"RNA"
Idents(x)<-"atomic_cluster_id"
x@misc$final_handoff<-list(candidate_id=s$candidate_id,count_semantics="RNA counts are raw integer counts; RNA data retain the original Seurat LogNormalize values.",
 current_annotation_source="per_cell_labels.csv",integration_not_recomputed=TRUE,
 annotation_not_recomputed=TRUE,umap_not_recomputed=TRUE,graph_parameters=s$graph_parameters,
 integration_parameters=lat$params,original_count_object=file.path(D,"work/S2_seurat_frozen.rds"),
 label_scope="Current manuscript lineage_l1/proposed_label; uncertainty columns retained; not all labels are equally confident.")
# Small typed bridge lets Python import the identical double-precision coordinates and sparse graph.
writeBin(as.double(hm),file.path(tmp,"harmony.f64"),size=8,endian="little")
writeBin(as.double(um),file.path(tmp,"umap.f64"),size=8,endian="little")
writeBin(as.double(sn@x),file.path(tmp,"snn_x.f64"),size=8,endian="little")
writeBin(as.integer(sn@i),file.path(tmp,"snn_i.i32"),size=4,endian="little")
writeBin(as.integer(sn@p),file.path(tmp,"snn_p.i32"),size=4,endian="little")
writeLines(colnames(x),file.path(tmp,"cells.txt"),useBytes=TRUE)
write_json(list(n_cells=ncol(x),n_features=nrow(x),latent_dim=ncol(hm),snn_nnz=length(sn@x),
 candidate_id=s$candidate_id,graph_parameters=s$graph_parameters,integration_parameters=lat$params,
 R_version=R.version.string,Seurat_version=as.character(packageVersion("Seurat")),
 Matrix_version=as.character(packageVersion("Matrix"))),file.path(tmp,"bridge.json"),pretty=TRUE,auto_unbox=TRUE)
saveRDS(x,file.path(out,"final_integrated_annotated.rds"),compress=TRUE)
z<-readRDS(file.path(out,"final_integrated_annotated.rds"))
stopifnot(identical(colnames(z),colnames(x)),identical(z@meta.data,x@meta.data),
 identical(Embeddings(z,"harmony"),Embeddings(x,"harmony")),
 identical(Embeddings(z,"umap"),Embeddings(x,"umap")),
 identical(z@graphs$frozen_snn,x@graphs$frozen_snn),
 identical(GetAssayData(z,assay="RNA",layer="counts"),GetAssayData(x,assay="RNA",layer="counts")))
write_json(list(status="PASS",cells=ncol(z),features=nrow(z),reductions=names(z@reductions),
 graph="frozen_snn",graph_nnz=length(z@graphs$frozen_snn@x),
 RDS_roundtrip_exact=TRUE,source_Harmony_exact=TRUE,source_UMAP_max_abs_diff=max(abs(um-as.matrix(labels[,c("UMAP_1","UMAP_2")])))),
 file.path(out,"SEURAT_VALIDATION.json"),pretty=TRUE,auto_unbox=TRUE)
cat("Packaged annotated Seurat and exact sparse bridge\n")
