#!/usr/bin/env python3
"""Validate the final package; optional original sources allow exact value checks."""
import argparse, json, hashlib, platform
from pathlib import Path
import anndata as ad
import numpy as np
import pandas as pd
from scipy import sparse
p=argparse.ArgumentParser()
p.add_argument("--source-counts")
p.add_argument("--bridge")
p.add_argument("--write-report",help="Optional new output JSON path; validation is read-only by default.")
args=p.parse_args()
P=Path(__file__).resolve().parents[2]; out=P/"data/integrated"
a=ad.read_h5ad(out/"final_integrated_annotated.h5ad")
labels=pd.read_csv(out/"per_cell_labels.csv",index_col="cell")
checks={}
def digest_sparse(x):
    x=sparse.csr_matrix(x);h=hashlib.sha256()
    h.update(np.array(x.shape,dtype="<i8").tobytes())
    for arr in (x.indptr.astype("<i8"),x.indices.astype("<i8"),x.data.astype("<f8")):h.update(arr.tobytes())
    return h.hexdigest()
checks["shape_90760_by_49593"]=a.shape==(90760,49593)
checks["cell_order_exact"]=list(a.obs_names)==list(labels.index)
checks["current_labels_exact"]=all(np.array_equal(a.obs[c].astype(str).values,labels[c].fillna("").astype(str).values) for c in ["sub05","lineage_l1","proposed_label"])
checks["integer_nonnegative_counts"]=np.isfinite(a.X.data).all() and (a.X.data>=0).all() and (a.X.data==np.floor(a.X.data)).all()
checks["standard_UMAP_alias_exact"]=np.array_equal(a.obsm["X_umap"],a.obsm["X_umap_frozen"])
checks["finite_30D_Harmony"]=a.obsm["X_harmony"].shape==(a.n_obs,30) and np.isfinite(a.obsm["X_harmony"]).all()
checks["68_atomic_clusters"]=a.obs.atomic_cluster_id.nunique()==68
checks["12_samples_7_donors"]=a.obs["sample"].nunique()==12 and a.obs.patient_id.nunique()==7
checks["all_paper_aliases_present"]=a.obs.paper_sample_id.astype(str).str.len().min()>0
checks["SNN_shape_and_weights"]=a.obsp["frozen_snn"].shape==(a.n_obs,a.n_obs) and np.isfinite(a.obsp["frozen_snn"].data).all()
if args.source_counts:
    s=ad.read_h5ad(args.source_counts)
    checks["source_counts_csr_digest_exact"]=digest_sparse(a.X)==digest_sparse(s.X)
    checks["source_all_obs_columns_preserved"]=all(np.array_equal(s.obs[c].astype(str).values,a.obs[c].astype(str).values) for c in s.obs)
    checks["source_features_preserved"]=a.var.equals(s.var)
    checks["original_frozen_UMAP_exact"]=np.array_equal(a.obsm["X_umap_frozen"],s.obsm["X_umap_frozen"])
if args.bridge:
    b=Path(args.bridge);bm=json.loads((b/"bridge.json").read_text())
    hm=np.fromfile(b/"harmony.f64",dtype="<f8").reshape((a.n_obs,bm["latent_dim"]),order="F")
    graph=sparse.csc_matrix((np.fromfile(b/"snn_x.f64",dtype="<f8"),np.fromfile(b/"snn_i.i32",dtype="<i4"),np.fromfile(b/"snn_p.i32",dtype="<i4")),shape=(a.n_obs,a.n_obs))
    checks["source_Harmony_exact"]=np.array_equal(a.obsm["X_harmony"],hm)
    checks["source_SNN_exact"]=digest_sparse(a.obsp["frozen_snn"])==digest_sparse(graph)
if (out/"SEURAT_COUNTS_HASH.json").exists():
    rc=json.loads((out/"SEURAT_COUNTS_HASH.json").read_text())
    for name,arr in [("indptr",a.X.indptr),("indices",a.X.indices),("values",a.X.data)]:
        checks["Seurat_AnnData_counts_"+name+"_exact"]=hashlib.sha256(np.asarray(arr,dtype="<f8").tobytes()).hexdigest()==rc[name+"_sha256"]
    checks["Seurat_AnnData_features_exact"]=hashlib.sha256(("\n".join(a.var_names)+"\n").encode()).hexdigest()==rc["feature_names_sha256"]
    checks["Seurat_AnnData_cells_exact"]=hashlib.sha256(("\n".join(a.obs_names)+"\n").encode()).hexdigest()==rc["cell_names_sha256"]
checks["Seurat_validation_PASS"]=json.loads((out/"SEURAT_VALIDATION.json").read_text())["status"]=="PASS"
slides=pd.read_csv(P/"data/spatial/SLIDE_MANIFEST.csv")
checks["8_spatial_slides_validated"]=len(slides)==8 and slides.matrix_barcodes_in_tissue_positions.all()
checks={k:bool(v) for k,v in checks.items()}
assert all(checks.values()),checks
result=dict(status="PASS",checks=checks,shape=list(a.shape),nnz=int(a.X.nnz),
 count_matrix_digest=digest_sparse(a.X),graph_nnz=int(a.obsp["frozen_snn"].nnz),
 spatial_tissue_spots=int(slides.tissue_spots.sum()),spatial_slides=slides.to_dict("records"),
 python_version=platform.python_version(),annotation_chain_reexecuted=False,analysis_recomputed=False)
if args.write_report:
    Path(args.write_report).write_text(json.dumps(result,indent=2))
print(json.dumps(dict(status="PASS",n_checks=len(checks),shape=list(a.shape),nnz=int(a.X.nnz),
 graph_nnz=int(a.obsp["frozen_snn"].nnz),spatial_tissue_spots=int(slides.tissue_spots.sum()))))
