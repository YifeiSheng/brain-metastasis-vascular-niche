#!/usr/bin/env python3
"""Assemble the final frozen data products without re-analysis.
Run package_frozen_seurat.R first. Inputs are immutable project source assets.
No expression normalization, integration, graph calculation or relabeling occurs here.
"""
import argparse, hashlib, json, shutil, platform
from pathlib import Path
import anndata as ad
import numpy as np
import pandas as pd
import scipy
from scipy import sparse
import h5py

parser=argparse.ArgumentParser()
parser.add_argument("--project",required=True)
parser.add_argument("--upstream",required=True)
parser.add_argument("--package",required=True)
args=parser.parse_args()
B=Path(args.project); U=Path(args.upstream); P=Path(args.package)
D=B/"delivery/biomni_annotation_20260905"; out=P/"data/integrated"
H=U/"trials/biological_analysis/M1_sc_atlas/results/HM03_CANONICAL_HANDOFF_V1"
bridge=P.parent/"HANDOFF_PREPARATION_20260922/frozen_bridge"
out.mkdir(parents=True,exist_ok=True)
manifest=[]; checks={}
def sha(p):
    h=hashlib.sha256()
    with Path(p).open("rb") as f:
        for block in iter(lambda:f.read(16*1024*1024),b""):h.update(block)
    return h.hexdigest()
def copy(src,dst,role):
    src=Path(src);dst=Path(dst);dst.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(src,dst)
    s=sha(src); assert s==sha(dst)
    manifest.append(dict(source=str(src),packaged=str(dst.relative_to(P)),bytes=dst.stat().st_size,sha256=s,role=role))
def digest_sparse(x):
    x=sparse.csr_matrix(x)
    h=hashlib.sha256()
    h.update(np.array(x.shape,dtype="<i8").tobytes())
    for arr in (x.indptr.astype("<i8"),x.indices.astype("<i8"),x.data.astype("<f8")):
        h.update(arr.tobytes())
    return h.hexdigest()

source=D/"data/sc_counts.h5ad"; a=ad.read_h5ad(source)
labels=pd.read_csv(D/"output/per_cell_labels.csv",index_col="cell")
assert a.obs_names.is_unique and labels.index.is_unique
assert list(a.obs_names)==list(labels.index)
for col in ["sample","patient_id","tissue_role","atomic_cluster_id"]:
    assert np.array_equal(a.obs[col].astype(str).values,labels[col].astype(str).values)
for col in ["UMAP_1","UMAP_2"]:
    assert np.allclose(a.obs[col].values,labels[col].values,rtol=0,atol=1e-14)
original_obs=a.obs.copy(); original_var=a.var.copy()
original_X=digest_sparse(a.X)
original_umap=a.obsm["X_umap_frozen"].copy()
assert sparse.issparse(a.X) and np.isfinite(a.X.data).all()
assert (a.X.data>=0).all() and (a.X.data==np.floor(a.X.data)).all()
for col in ["sub05","lineage_l1","proposed_label"]:
    a.obs[col]=labels[col].fillna("").astype(str)
ca=pd.read_csv(D/"output/cluster_annotation.csv",index_col="atomic_cluster_id")
assert ca.index.is_unique
for col in ["confidence","assignment_status","marker_identity_within_cluster"]:
    a.obs["cluster_"+col]=a.obs.atomic_cluster_id.astype(str).map(ca[col]).fillna("").astype(str)
pm=pd.read_csv(B/"data/metadata/paper_sample_mapping_v4.csv")
pm=pm.loc[pm.assay.eq("scRNA-seq")].set_index("sample")
assert pm.index.is_unique and a.obs["sample"].isin(pm.index).all()
assert np.array_equal(a.obs["patient_id"].astype(str).values,a.obs["sample"].astype(str).map(pm["patient_id"]).values)
for col in pm.columns:
    if col.startswith("paper_"):
        vals=a.obs["sample"].astype(str).map(pm[col])
        a.obs[col]=vals.astype(int) if col.endswith("_order") else vals.fillna("").astype(str)

bm=json.loads((bridge/"bridge.json").read_text())
cells=(bridge/"cells.txt").read_text().splitlines()
assert cells==list(a.obs_names)
hm=np.fromfile(bridge/"harmony.f64",dtype="<f8").reshape((a.n_obs,bm["latent_dim"]),order="F")
um=np.fromfile(bridge/"umap.f64",dtype="<f8").reshape((a.n_obs,2),order="F")
graph=sparse.csc_matrix((np.fromfile(bridge/"snn_x.f64",dtype="<f8"),
                        np.fromfile(bridge/"snn_i.i32",dtype="<i4"),
                        np.fromfile(bridge/"snn_p.i32",dtype="<i4")),shape=(a.n_obs,a.n_obs)).tocsr()
assert np.isfinite(hm).all() and np.isfinite(graph.data).all() and (graph.data>=0).all()
assert np.allclose(original_umap,um,rtol=0,atol=1e-14)
a.obsm["X_harmony"]=hm
# Keep the original obsm key and exact bytes; X_umap is a standard alias.
a.obsm["X_umap"]=original_umap.copy()
a.obsp["frozen_snn"]=graph
input_paths=[source,D/"output/per_cell_labels.csv",D/"work/S2_seurat_frozen.rds",
 H/"integration/harmony_biology_preserving_hvg3000_theta0p5_seed41.latent.rds",
 H/"graph/v2_2_selected_graph_grid/snn_matrix_v2_2.rds",
 B/"data/metadata/paper_sample_mapping_v4.csv"]
source_inputs=[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)) for p in input_paths]
a.uns["final_handoff"]={
 "candidate_id":bm["candidate_id"],
 "count_semantics":"X contains the original nonnegative integer raw RNA counts; no batch-corrected expression matrix is implied.",
 "integration_method":"Harmony; frozen biology_preserving_hvg3000; batch=sample; 30 latent dimensions.",
 "integration_parameters_json":json.dumps(bm["integration_parameters"],ensure_ascii=False),
 "graph_parameters_json":json.dumps(bm["graph_parameters"],ensure_ascii=False),
 "frozen_operating_point":"Euclidean k=30 weighted SNN; Leiden seed 42; resolution 4; 68 atomic clusters.",
 "current_annotation_source":"per_cell_labels.csv",
 "annotation_uncertainty":"lineage_l1/proposed_label are current manuscript labels; cluster_confidence and assignment_status retain uncertainty.",
 "source_inputs_json":json.dumps(source_inputs,ensure_ascii=False),
 "integration_recomputed":False,"umap_recomputed":False,"graph_recomputed":False,"labels_recomputed":False,
 "SNN_storage":"obsp/frozen_snn; original weights, no rescaling.",
 "identity_qualifications":"P8 is spatial-only provisional and not a verified extra donor; Toct5/Coct5-P2 linkage remains inferred.",
}
dest=out/"final_integrated_annotated.h5ad"
a.write_h5ad(dest,compression="gzip")
r=ad.read_h5ad(dest)
checks["shape_90760_by_49593"]=r.shape==(90760,49593)
checks["source_counts_csr_digest_exact"]=digest_sparse(r.X)==original_X
checks["source_all_obs_columns_preserved"]=all(np.array_equal(original_obs[c].astype(str).values,r.obs[c].astype(str).values) for c in original_obs)
checks["source_features_preserved"]=r.var.equals(original_var)
checks["cell_order_exact"]=list(r.obs_names)==list(labels.index)
checks["current_labels_exact"]=all(np.array_equal(r.obs[c].astype(str).values,labels[c].fillna("").astype(str).values) for c in ["sub05","lineage_l1","proposed_label"])
checks["original_frozen_UMAP_exact"]=np.array_equal(r.obsm["X_umap_frozen"],original_umap)
checks["standard_UMAP_alias_exact"]=np.array_equal(r.obsm["X_umap"],original_umap)
checks["Harmony_exact"]=np.array_equal(r.obsm["X_harmony"],hm)
checks["SNN_exact"]=digest_sparse(r.obsp["frozen_snn"])==digest_sparse(graph)
checks["68_atomic_clusters"]=r.obs.atomic_cluster_id.nunique()==68
checks["12_samples_7_donors"]=r.obs["sample"].nunique()==12 and r.obs.patient_id.nunique()==7
checks["all_paper_aliases_present"]=r.obs.paper_sample_id.astype(str).str.len().min()>0
checks={k:bool(v) for k,v in checks.items()}
assert all(checks.values()),checks
manifest.append(dict(source="derived from frozen inputs listed in DATA_PROVENANCE.json",packaged=str(dest.relative_to(P)),bytes=dest.stat().st_size,sha256=sha(dest),role="Primary final integrated and annotated AnnData"))

for name in ["per_cell_labels.csv","cluster_annotation.csv","marker_evidence.csv","rare_cell_candidates.csv","rare_cell_markers.csv"]:
    copy(D/"output"/name,(out/name if name in ["per_cell_labels.csv","cluster_annotation.csv"] else out/"annotation_evidence"/name),"Current annotation and evidence")
for name in ["patient_metadata.csv","gene_absent_per_sample.csv"]:
    copy(D/"data"/name,out/name,"Source sample and assay coverage metadata")
for name in ["paper_patient_mapping_v4.csv","paper_sample_mapping_v4.csv"]:
    copy(B/"data/metadata"/name,P/"data/metadata"/name,"Current publication aliases; original join keys preserved")
for name in ["patient_registry_verified.csv","molecular_verification.csv","sc_sample_meta.csv","st_sample_meta.csv",
             "sc_st_patient_match.csv","sc_st_correspondence_evidence.csv","P8_provenance_memo.md","lymphoma_subtype_comparison.csv"]:
    copy(U/"data/meta"/name,P/"data/metadata"/name,"Verified source metadata or explicit remaining identity uncertainty")
for rel in ["integration/harmony_biology_preserving_hvg3000_theta0p5_seed41.latent.rds",
            "graph/v2_2_selected_graph_grid/snn_matrix_v2_2.rds",
            "umap/harmony_biology_preserving_hvg3000_theta0p5_seed41.euclidean_k30_umap.rds",
            ]:
    copy(H/rel,out/"frozen_reference"/rel,"Selected frozen source state; no alternative candidate")
features=pd.read_csv(H/"inputs/v5_frozen_feature_sets.csv")
features=features.loc[features.feature_set_id.eq("biology_preserving_hvg3000")]
assert len(features)==3000 and features.gene.is_unique
selected=out/"frozen_reference/inputs/selected_hvg3000.csv"
selected.parent.mkdir(parents=True,exist_ok=True)
features.to_csv(selected,index=False)
manifest.append(dict(source=str(H/"inputs/v5_frozen_feature_sets.csv"),packaged=str(selected.relative_to(P)),bytes=selected.stat().st_size,sha256=sha(selected),role="Exact selected biology-preserving 3000-feature subset"))
spatial=[]
for src in sorted((U/"data/ST").rglob("*")):
    if src.is_file() and src.name!=".DS_Store":
        copy(src,P/"data/spatial"/src.relative_to(U/"data/ST"),"Final internal Visium source matrix, spatial coordinates or histology")
for h5 in sorted((P/"data/spatial").rglob("filtered_feature_bc_matrix.h5")):
    with h5py.File(h5,"r") as f:
        barcodes=[x.decode() for x in f["matrix/barcodes"][:]]
        dims=f["matrix/shape"][:].tolist()
    positions=pd.read_csv(h5.parent/"spatial/tissue_positions_list.csv",header=None,
                          names=["barcode","in_tissue","array_row","array_col","pxl_row","pxl_col"])
    assert len(barcodes)==len(set(barcodes))
    assert set(barcodes).issubset(set(positions.loc[positions.in_tissue.eq(1),"barcode"]))
    spatial.append(dict(slide=h5.parent.name,relative_dir=str(h5.parent.relative_to(P)),
                        features=dims[0],filtered_spots=dims[1],tissue_spots=int(positions.in_tissue.eq(1).sum()),
                        matrix_barcodes_in_tissue_positions=True))
assert len(spatial)==8
pd.DataFrame(spatial).to_csv(P/"data/spatial/SLIDE_MANIFEST.csv",index=False)
rds=out/"final_integrated_annotated.rds"
assert rds.exists()
manifest.append(dict(source="derived frozen Seurat; see package_frozen_seurat.R",packaged=str(rds.relative_to(P)),bytes=rds.stat().st_size,sha256=sha(rds),role="Final annotated Seurat with RNA counts/data, frozen Harmony/UMAP/SNN"))
pd.DataFrame(manifest).to_csv(P/"data/DATA_FILE_MANIFEST.csv",index=False)
(out/"DATA_VALIDATION.json").write_text(json.dumps(dict(status="PASS",checks=checks,
 shape=list(r.shape),nnz=int(r.X.nnz),count_matrix_digest=original_X,graph_nnz=int(graph.nnz),
 source_Harmony_UMAP_max_abs_difference=float(np.max(np.abs(original_umap-um))),
 spatial_slides=spatial,versions=dict(python=platform.python_version(),anndata=ad.__version__,numpy=np.__version__,scipy=scipy.__version__)),indent=2))
(out/"DATA_PROVENANCE.json").write_text(json.dumps(dict(source_inputs=source_inputs,bridge_parameters=bm,
 packaging_only=True,recomputed_analysis=False,files=manifest),indent=2))
print(json.dumps(dict(status="PASS",checks=len(checks),files=len(manifest),H5AD_bytes=dest.stat().st_size,RDS_bytes=rds.stat().st_size,spatial_slides=8)))
