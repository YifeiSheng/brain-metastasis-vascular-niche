atomic_v1_root <- function(root = normalizePath(getwd(), mustWork = TRUE)) {
  file.path(
    root,
    "trials/biological_analysis/M1_sc_atlas/results/revision_work",
    "integration_annotation_rebuild_clean"
  )
}

atomic_v1_output <- function(root = normalizePath(getwd(), mustWork = TRUE)) {
  file.path(atomic_v1_root(root), "atomic_annotation_v1")
}

atomic_v1_resolutions <- c(0.4, 0.8, 1.2, 1.6, 2.0, 3.0, 4.0)
atomic_v1_atomic_resolution <- 4.0
atomic_v1_graph_k <- 30L
atomic_v1_dims <- 30L
atomic_v1_seed <- 42L

atomic_v1_resolution_tag <- function(x) {
  vapply(x, function(value) {
    paste0("r", gsub("\\.", "p", format(value, trim = TRUE, scientific = FALSE)))
  }, character(1))
}

atomic_v1_normalized_entropy <- function(x, n_possible_levels) {
  tab <- table(x, useNA = "no")
  if (length(tab) <= 1L) return(0)
  if (length(n_possible_levels) != 1L || is.na(n_possible_levels) ||
      n_possible_levels < length(tab) || n_possible_levels <= 1L) {
    stop("Invalid frozen category count for normalized entropy")
  }
  p <- as.numeric(tab) / sum(tab)
  -sum(p * log(p)) / log(n_possible_levels)
}

atomic_v1_relabel_partition <- function(membership, prefix) {
  cells <- names(membership)
  membership <- as.character(membership)
  if (is.null(cells)) stop("Partition membership has no cell names")
  names(membership) <- cells
  size <- table(membership)
  first_cell <- tapply(cells, membership, min)
  ordering <- order(-as.integer(size), first_cell[names(size)])
  old <- names(size)[ordering]
  width <- max(3L, nchar(length(old)))
  new <- sprintf(paste0(prefix, "_%0", width, "d"), seq_along(old))
  map <- stats::setNames(new, old)
  unname(map[membership])
}

atomic_v1_load_context <- function(root = normalizePath(getwd(), mustWork = TRUE)) {
  clean <- atomic_v1_root(root)
  registry <- data.table::fread(file.path(clean, "unsupervised_candidate_registry.csv"))
  metadata <- readRDS(file.path(clean, "inputs", "all_cells_design_qc_provenance.rds"))
  metadata <- data.table::as.data.table(metadata)[analysis_singlets == TRUE]
  if (nrow(metadata) != 90760L || anyDuplicated(metadata$cell)) {
    stop("Frozen 90,760-singlet membership is invalid")
  }
  list(clean = clean, registry = registry, metadata = metadata, cells = metadata$cell)
}

atomic_v1_load_latent <- function(candidate_id, context, root = normalizePath(getwd(), mustWork = TRUE),
                                  allow_control = FALSE) {
  target_id <- candidate_id
  row <- context$registry[context$registry$candidate_id == target_id]
  if (nrow(row) != 1L) stop("Candidate is absent or duplicated: ", candidate_id)
  if (length(row$supervised) != 1L || is.na(row$supervised) || row$supervised != FALSE) {
    stop("Candidate must explicitly declare supervised == FALSE: ", candidate_id)
  }
  if (length(row$fit_status) != 1L || is.na(row$fit_status) ||
      row$fit_status != "COMPLETE") {
    stop("Candidate fit_status is not COMPLETE: ", candidate_id)
  }
  eligible <- row$method %chin% c("Harmony", "Seurat_RPCA", "scVI")
  if (!eligible && !allow_control) {
    stop("Only integrated Harmony/RPCA/scVI candidates are eligible: ", candidate_id)
  }
  if (!file.exists(row$path)) stop("Latent file does not exist: ", row$path)
  observed_md5 <- unname(tools::md5sum(row$path))
  if (!identical(observed_md5, row$md5)) stop("Latent MD5 mismatch: ", candidate_id)

  if (grepl("\\.rds$", row$path, ignore.case = TRUE)) {
    object <- readRDS(row$path)
    if (is.null(object$latent)) stop("RDS candidate has no explicit $latent matrix")
    latent <- object$latent
  } else if (grepl("\\.npz$", row$path, ignore.case = TRUE)) {
    helper <- file.path(
      root, "trials/biological_analysis/M1_sc_atlas/scripts/export_npz_latent_sidecar_v5.py"
    )
    prefix <- tempfile(pattern = "atomic_v1_npz_")
    sidecars <- paste0(prefix, c(".latent.f32", ".cells.txt", ".shape.tsv"))
    on.exit(unlink(sidecars), add = TRUE)
    status <- system2("python3", c(shQuote(helper), shQuote(row$path), shQuote(prefix)))
    if (!identical(status, 0L)) stop("NPZ sidecar export failed: ", candidate_id)
    shape <- data.table::fread(paste0(prefix, ".shape.tsv"), header = FALSE)
    nr <- as.integer(shape[[1]][1]); nc <- as.integer(shape[[2]][1])
    con <- file(paste0(prefix, ".latent.f32"), open = "rb")
    values <- readBin(con, numeric(), n = nr * nc, size = 4L, endian = "little")
    close(con)
    if (length(values) != nr * nc) stop("NPZ latent sidecar is truncated: ", candidate_id)
    latent <- matrix(values, nrow = nr, ncol = nc, byrow = TRUE)
    rownames(latent) <- readLines(paste0(prefix, ".cells.txt"), warn = FALSE)
  } else {
    stop("Unsupported latent format: ", row$path)
  }

  if (nrow(latent) != length(context$cells) || ncol(latent) < atomic_v1_dims) {
    stop("Latent shape mismatch: ", candidate_id)
  }
  original_cells <- rownames(latent)
  if (is.null(original_cells) || anyDuplicated(original_cells) ||
      !setequal(original_cells, context$cells)) {
    stop("Latent cell-name membership mismatch: ", candidate_id)
  }
  if (!identical(original_cells, context$cells)) {
    stop("Latent original cell order differs from the frozen order: ", candidate_id)
  }
  latent <- latent[, seq_len(atomic_v1_dims), drop = FALSE]
  if (anyNA(latent) || any(!is.finite(latent))) {
    stop("Latent order/finiteness mismatch: ", candidate_id)
  }
  storage.mode(latent) <- "double"
  list(
    latent = latent, registry_row = row, eligible = eligible,
    observed_md5 = observed_md5, original_cell_order_exact = TRUE
  )
}

atomic_v1_write_manifest <- function(paths, output_path, role,
                                     base_dir = dirname(output_path)) {
  paths <- normalizePath(paths, mustWork = TRUE)
  base_dir <- normalizePath(base_dir, mustWork = TRUE)
  prefix <- paste0(base_dir, .Platform$file.sep)
  if (!all(startsWith(paths, prefix))) stop("Manifest path is outside base_dir")
  manifest <- data.table::data.table(
    role = role,
    relative_path = substring(paths, nchar(prefix) + 1L),
    bytes = file.info(paths)$size,
    md5 = unname(tools::md5sum(paths))
  )
  data.table::fwrite(manifest, output_path)
  invisible(manifest)
}
