atomic_v2_2_version <- "atomic_resolution_grid_v2_2_2026-08-07"
atomic_v2_2_resolutions <- seq(4, 10, by = 0.5)
atomic_v2_2_leiden_seed <- 42L
atomic_v2_2_leiden_iterations <- 4L
atomic_v2_2_max_workers <- 2L

atomic_v2_2_output <- function(root = normalizePath(getwd(), mustWork = TRUE)) {
  file.path(
    atomic_v1_root(root),
    "atomic_annotation_v2_2_annotation_optimized"
  )
}

atomic_v2_2_candidate_parent <- function(
    root = normalizePath(getwd(), mustWork = TRUE)) {
  file.path(atomic_v2_2_output(root), "candidate_graph_grids")
}

atomic_v2_2_batch_dir <- function(
    root = normalizePath(getwd(), mustWork = TRUE)) {
  file.path(atomic_v2_2_output(root), "graph_grid_batch_v2_2")
}

atomic_v2_2_resolution_tag <- function(x) {
  atomic_v1_resolution_tag(x)
}

atomic_v2_2_partition_id <- function(candidate_id, resolution_tag) {
  paste(candidate_id, resolution_tag, sep = "__")
}

atomic_v2_2_effective_counts <- function(sizes) {
  sizes <- as.numeric(sizes)
  if (!length(sizes) || anyNA(sizes) || any(!is.finite(sizes)) ||
      any(sizes <= 0)) {
    stop("Cluster sizes are invalid")
  }
  p <- sizes / sum(sizes)
  list(
    hill = exp(-sum(p * log(p))),
    inverse_simpson = 1 / sum(p^2),
    effective_to_raw = exp(-sum(p * log(p))) / length(sizes)
  )
}

atomic_v2_2_scalar_true <- function(x) {
  length(x) == 1L && !is.na(x) &&
    toupper(trimws(as.character(x))) == "TRUE"
}

atomic_v2_2_scalar_false <- function(x) {
  length(x) == 1L && !is.na(x) &&
    toupper(trimws(as.character(x))) == "FALSE"
}

atomic_v2_2_md5_one <- function(path) {
  if (!file.exists(path) || dir.exists(path)) {
    stop("Required file is missing: ", path)
  }
  unname(tools::md5sum(path))
}

atomic_v2_2_relative_path <- function(path, base_dir) {
  path <- normalizePath(path, mustWork = TRUE)
  base_dir <- normalizePath(base_dir, mustWork = TRUE)
  prefix <- paste0(base_dir, .Platform$file.sep)
  if (!startsWith(path, prefix)) stop("Path is outside base directory: ", path)
  substring(path, nchar(prefix) + 1L)
}

atomic_v2_2_write_manifest <- function(paths, roles, output_path, base_dir) {
  if (length(paths) != length(roles) || !length(paths)) {
    stop("Manifest paths and roles must have equal positive length")
  }
  paths <- normalizePath(paths, mustWork = TRUE)
  base_dir <- normalizePath(base_dir, mustWork = TRUE)
  prefix <- paste0(base_dir, .Platform$file.sep)
  if (!all(startsWith(paths, prefix))) {
    stop("Manifest payload is outside base directory")
  }
  manifest <- data.table::data.table(
    role = roles,
    relative_path = substring(paths, nchar(prefix) + 1L),
    bytes = as.numeric(file.info(paths)$size),
    md5 = unname(tools::md5sum(paths))
  )
  if (anyNA(manifest$md5) || anyDuplicated(manifest$relative_path)) {
    stop("Manifest payload is invalid")
  }
  data.table::fwrite(manifest, output_path)
  invisible(manifest)
}

atomic_v2_2_verify_manifest_row <- function(
    manifest_path, payload_path, role_expected = NULL) {
  manifest <- data.table::fread(manifest_path)
  required <- c("role", "relative_path", "bytes", "md5")
  if (!setequal(names(manifest), required) ||
      anyDuplicated(manifest$relative_path)) {
    stop("Manifest schema is invalid: ", manifest_path)
  }
  row <- manifest[relative_path == basename(payload_path)]
  if (nrow(row) != 1L) {
    stop("Manifest does not uniquely pin payload: ", payload_path)
  }
  if (!is.null(role_expected) && !identical(as.character(row$role), role_expected)) {
    stop("Manifest role mismatch for payload: ", payload_path)
  }
  observed_bytes <- as.numeric(file.info(payload_path)$size)
  observed_md5 <- atomic_v2_2_md5_one(payload_path)
  if (!identical(as.numeric(row$bytes), observed_bytes) ||
      !identical(as.character(row$md5), observed_md5)) {
    stop("Manifest bytes/MD5 mismatch for payload: ", payload_path)
  }
  invisible(row)
}
