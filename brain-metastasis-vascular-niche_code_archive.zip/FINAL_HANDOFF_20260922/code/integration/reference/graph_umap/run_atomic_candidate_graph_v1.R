#!/usr/bin/env Rscript

# Build one global Euclidean weighted-SNN graph from an eligible integrated
# latent and derive the frozen resolution ladder. No expression, annotation,
# reference, malignancy, region, or CNV evidence enters this script.

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 1L) stop("Usage: run_atomic_candidate_graph_v1.R candidate_id")
candidate_id <- args[1]

root <- normalizePath(getwd(), mustWork = TRUE)
.libPaths(c(file.path(root, "Rlib"), .libPaths()))
suppressPackageStartupMessages({
  library(data.table)
  library(digest)
  library(igraph)
  library(Matrix)
  library(Seurat)
})
source(file.path(
  root, "trials/biological_analysis/M1_sc_atlas/scripts/atomic_annotation_v1_helpers.R"
))

main <- function(candidate_id, root) {
context <- atomic_v1_load_context(root)
loaded <- atomic_v1_load_latent(candidate_id, context, root, allow_control = FALSE)
latent <- loaded$latent
metadata <- copy(context$metadata)
script_path <- file.path(
  root, "trials/biological_analysis/M1_sc_atlas/scripts/run_atomic_candidate_graph_v1.R"
)
helper_path <- file.path(
  root, "trials/biological_analysis/M1_sc_atlas/scripts/atomic_annotation_v1_helpers.R"
)
protocol_path <- file.path(
  context$clean, "ATOMIC_INTEGRATION_ANNOTATION_PROTOCOL_V1.md"
)
registry_path <- file.path(context$clean, "unsupervised_candidate_registry.csv")
metadata_path <- file.path(context$clean, "inputs", "all_cells_design_qc_provenance.rds")
candidate_parent <- file.path(atomic_v1_output(root), "candidate_graphs")
output_dir <- file.path(candidate_parent, candidate_id)
stage_dir <- file.path(candidate_parent, paste0(".", candidate_id, ".staging-", Sys.getpid()))
dir.create(candidate_parent, recursive = TRUE, showWarnings = FALSE)
if (dir.exists(output_dir) || file.exists(output_dir)) {
  stop("Overwrite protection: candidate output already exists: ", candidate_id)
}
if (dir.exists(stage_dir) || file.exists(stage_dir)) {
  stop("Staging path already exists: ", stage_dir)
}
dir.create(stage_dir, recursive = FALSE, showWarnings = FALSE)
committed <- FALSE
on.exit({
  if (!committed && dir.exists(stage_dir)) {
    unlink(stage_dir, recursive = TRUE, force = TRUE)
  }
}, add = TRUE)

immutable_outputs <- c(
  "resolution_membership.csv.gz", "resolution_summary.csv",
  "resolution_transition_audit.csv", "atomic_cluster_composition.csv",
  "graph_summary.csv", "graph_object_without_edges.rds", "acceptance_checks.csv",
  "sessionInfo.txt", "delivery_manifest.csv"
)
present <- file.exists(file.path(stage_dir, immutable_outputs))
if (any(present)) {
  stop("Unexpected output collision in staging directory: ", candidate_id)
}

message("Building weighted SNN for ", candidate_id)
started <- Sys.time()
set.seed(atomic_v1_seed)
neighbor_started <- proc.time()[3]
neighbors <- FindNeighbors(
  latent,
  k.param = atomic_v1_graph_k,
  return.neighbor = FALSE,
  compute.SNN = TRUE,
  prune.SNN = 1 / 15,
  nn.method = "annoy",
  n.trees = 50,
  annoy.metric = "euclidean",
  l2.norm = FALSE,
  verbose = FALSE
)
neighbor_seconds <- unname(proc.time()[3] - neighbor_started)
snn <- neighbors$snn
if (!identical(rownames(snn), context$cells) || !identical(colnames(snn), context$cells)) {
  stop("SNN cell order mismatch")
}

graph_started <- proc.time()[3]
graph <- graph_from_adjacency_matrix(
  snn, mode = "undirected", weighted = TRUE, diag = FALSE
)
graph_seconds <- unname(proc.time()[3] - graph_started)
if (vcount(graph) != length(context$cells)) stop("Graph vertex count mismatch")
if (!identical(V(graph)$name, context$cells)) stop("Graph vertex order mismatch")
component_result <- components(graph)

membership <- data.table(cell = context$cells)
resolution_summary <- list()
for (resolution in atomic_v1_resolutions) {
  tag <- atomic_v1_resolution_tag(resolution)
  message("Leiden ", candidate_id, " resolution ", resolution)
  cluster_started <- proc.time()[3]
  set.seed(atomic_v1_seed)
  partition <- cluster_leiden(
    graph,
    objective_function = "modularity",
    weights = E(graph)$weight,
    resolution_parameter = resolution,
    n_iterations = 4L
  )
  raw_membership <- membership(partition)
  names(raw_membership) <- V(graph)$name
  relabelled <- atomic_v1_relabel_partition(raw_membership, tag)
  membership[, (tag) := relabelled]
  sizes <- sort(table(relabelled))
  resolution_summary[[tag]] <- data.table(
    candidate_id = candidate_id,
    resolution = resolution,
    resolution_tag = tag,
    n_clusters = length(sizes),
    min_cluster_size = min(sizes),
    p10_cluster_size = as.numeric(quantile(sizes, 0.10, names = FALSE)),
    median_cluster_size = median(sizes),
    max_cluster_size = max(sizes),
    n_clusters_lt20 = sum(sizes < 20L),
    n_clusters_lt50 = sum(sizes < 50L),
    n_clusters_lt100 = sum(sizes < 100L),
    leiden_seconds = unname(proc.time()[3] - cluster_started),
    production_seed = atomic_v1_seed,
    is_atomic_partition = resolution == atomic_v1_atomic_resolution
  )
}
resolution_summary <- rbindlist(resolution_summary)
atomic_tag <- atomic_v1_resolution_tag(atomic_v1_atomic_resolution)
setnames(membership, atomic_tag, "atomic_cluster_id")

# Resolution changes are diagnostic only. Higher-resolution partitions are not
# assumed to be strict subclusters of the preceding resolution.
transition_audit <- list()
tags <- atomic_v1_resolution_tag(atomic_v1_resolutions)
tags[tags == atomic_tag] <- "atomic_cluster_id"
for (i in seq_len(length(tags) - 1L)) {
  coarse_tag <- tags[i]; fine_tag <- tags[i + 1L]
  tab <- membership[, .N, by = c(coarse_tag, fine_tag)]
  fine_sizes <- tab[, .(fine_n = sum(N), parent_n = .N, max_parent_n = max(N)), by = fine_tag]
  fine_sizes[, parent_containment := max_parent_n / fine_n]
  transition_audit[[i]] <- data.table(
    candidate_id = candidate_id,
    coarse_resolution = atomic_v1_resolutions[i],
    fine_resolution = atomic_v1_resolutions[i + 1L],
    n_fine_clusters = nrow(fine_sizes),
    cell_weighted_parent_containment = weighted.mean(
      fine_sizes$parent_containment, fine_sizes$fine_n
    ),
    fraction_fine_clusters_strictly_nested = mean(fine_sizes$parent_containment == 1),
    fraction_fine_clusters_parent_containment_ge_0p95 = mean(
      fine_sizes$parent_containment >= 0.95
    ),
    n_fine_clusters_with_multiple_parents = sum(fine_sizes$parent_n > 1L)
  )
}
transition_audit <- rbindlist(transition_audit)

metadata[, atomic_cluster_id := membership$atomic_cluster_id]
atomic_composition <- metadata[, .(
  n_cells = .N,
  n_samples = uniqueN(sample),
  n_patients = uniqueN(patient_id),
  n_disease_groups = uniqueN(disease_group),
  dominant_sample_fraction = max(table(sample)) / .N,
  dominant_patient_fraction = max(table(patient_id)) / .N,
  sample_entropy = atomic_v1_normalized_entropy(sample, uniqueN(metadata$sample)),
  patient_entropy = atomic_v1_normalized_entropy(patient_id, uniqueN(metadata$patient_id)),
  disease_entropy = atomic_v1_normalized_entropy(
    disease_group, uniqueN(metadata$disease_group)
  )
), by = atomic_cluster_id]
atomic_composition[, candidate_id := candidate_id]
setcolorder(atomic_composition, c("candidate_id", "atomic_cluster_id", setdiff(
  names(atomic_composition), c("candidate_id", "atomic_cluster_id")
)))

degree_values <- degree(graph)
weight_values <- E(graph)$weight
component_sizes <- component_result$csize
graph_summary <- data.table(
  candidate_id = candidate_id,
  method = loaded$registry_row$method,
  feature_set_id = loaded$registry_row$feature_set_id,
  latent_md5 = loaded$observed_md5,
  n_cells = nrow(latent),
  n_dimensions = ncol(latent),
  metric = "euclidean",
  graph_k = atomic_v1_graph_k,
  annoy_trees = 50L,
  prune_snn = 1 / 15,
  n_edges = ecount(graph),
  n_components = component_result$no,
  largest_component_fraction = max(component_sizes) / vcount(graph),
  n_isolated_cells = sum(degree_values == 0L),
  n_components_lt20 = sum(component_sizes < 20L),
  n_cells_in_components_lt20 = sum(component_sizes[component_sizes < 20L]),
  median_degree = median(degree_values),
  p10_degree = as.numeric(quantile(degree_values, 0.10, names = FALSE)),
  p90_degree = as.numeric(quantile(degree_values, 0.90, names = FALSE)),
  mean_edge_weight = mean(weight_values),
  median_edge_weight = median(weight_values),
  neighbor_seconds = neighbor_seconds,
  graph_conversion_seconds = graph_seconds,
  total_seconds = as.numeric(difftime(Sys.time(), started, units = "secs")),
  leiden_seed = atomic_v1_seed,
  annoy_seed_contract = "RcppAnnoy deterministic package-default seed",
  resolution_ladder = paste(atomic_v1_resolutions, collapse = ";"),
  atomic_resolution = atomic_v1_atomic_resolution,
  umap_generated = FALSE,
  expression_or_annotation_label_used_for_graph = FALSE,
  cnv_used_for_graph = FALSE,
  script_md5 = unname(tools::md5sum(script_path)),
  helper_md5 = unname(tools::md5sum(helper_path)),
  protocol_md5 = unname(tools::md5sum(protocol_path)),
  registry_md5 = unname(tools::md5sum(registry_path)),
  metadata_md5 = unname(tools::md5sum(metadata_path))
)

membership_path <- file.path(stage_dir, "resolution_membership.csv.gz")
resolution_path <- file.path(stage_dir, "resolution_summary.csv")
transition_path <- file.path(stage_dir, "resolution_transition_audit.csv")
composition_path <- file.path(stage_dir, "atomic_cluster_composition.csv")
summary_path <- file.path(stage_dir, "graph_summary.csv")
object_path <- file.path(stage_dir, "graph_object_without_edges.rds")
checks_path <- file.path(stage_dir, "acceptance_checks.csv")
session_path <- file.path(stage_dir, "sessionInfo.txt")

fwrite(membership, membership_path, compress = "gzip")
fwrite(resolution_summary, resolution_path)
fwrite(transition_audit, transition_path)
fwrite(atomic_composition, composition_path)
fwrite(graph_summary, summary_path)
saveRDS(list(
  candidate_id = candidate_id,
  cell = context$cells,
  atomic_cluster_id = membership$atomic_cluster_id,
  resolution_summary = resolution_summary,
  transition_audit = transition_audit,
  graph_parameters = list(
    dimensions = seq_len(atomic_v1_dims), metric = "euclidean",
    k = atomic_v1_graph_k, annoy_trees = 50L,
    annoy_seed_contract = "RcppAnnoy deterministic package-default seed",
    prune_snn = 1 / 15,
    graph = "weighted_SNN", leiden = "igraph_cluster_leiden_modularity",
    leiden_iterations = 4L, seed = atomic_v1_seed,
    resolution_ladder = atomic_v1_resolutions,
    atomic_resolution = atomic_v1_atomic_resolution
  ),
  latent_md5 = loaded$observed_md5,
  full_graph_saved = FALSE
), object_path, compress = TRUE)

checks <- data.table(
  check = c(
    "eligible_integrated_candidate", "cell_count_90760", "cell_order_exact",
    "latent_finite", "latent_md5_exact", "graph_all_vertices_present",
    "resolution_ladder_complete", "atomic_resolution_exact",
    "graph_scope_excludes_expression_and_annotation_labels",
    "graph_scope_excludes_cnv", "no_umap_generated"
  ),
  pass = c(
    loaded$eligible, nrow(latent) == 90760L,
    loaded$original_cell_order_exact && identical(membership$cell, context$cells),
    !anyNA(latent) && all(is.finite(latent)),
    identical(loaded$observed_md5, loaded$registry_row$md5),
    sum(component_sizes) == length(context$cells),
    identical(resolution_summary$resolution, atomic_v1_resolutions),
    resolution_summary[is_atomic_partition == TRUE, resolution] == atomic_v1_atomic_resolution,
    TRUE, TRUE, TRUE
  )
)
fwrite(checks, checks_path)
writeLines(capture.output(sessionInfo()), session_path)
if (!all(checks$pass)) stop("Candidate graph acceptance check failed")

generated <- c(
  membership_path, resolution_path, transition_path, composition_path,
  summary_path, object_path, checks_path, session_path
)
manifest_path <- file.path(stage_dir, "delivery_manifest.csv")
atomic_v1_write_manifest(
  generated, manifest_path,
  c("membership", "resolution_summary", "transition_audit", "composition",
    "graph_summary", "graph_object_without_edges", "acceptance", "session"),
  base_dir = stage_dir
)
if (!file.rename(stage_dir, output_dir)) {
  stop("Failed to atomically commit candidate output: ", candidate_id)
}
committed <- TRUE
message("Atomic graph complete: ", candidate_id)
invisible(output_dir)
}

main(candidate_id, root)
