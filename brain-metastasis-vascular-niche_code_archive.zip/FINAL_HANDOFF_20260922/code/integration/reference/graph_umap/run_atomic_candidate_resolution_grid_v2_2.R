#!/usr/bin/env Rscript

# Reconstruct one candidate's frozen Euclidean k30 weighted-SNN, prove exact
# historical resolution-4 reproduction, and derive the common v2.2 Leiden grid.
# No expression, marker, reference, annotation, CNV, region, or UMAP data enter.

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 1L) {
  stop("Usage: run_atomic_candidate_resolution_grid_v2_2.R candidate_id")
}
candidate_id <- args[[1L]]
if (!grepl("^[A-Za-z0-9][A-Za-z0-9._-]*$", candidate_id)) {
  stop("Unsafe candidate_id: ", candidate_id)
}

root <- normalizePath(getwd(), mustWork = TRUE)
.libPaths(c(file.path(root, "Rlib"), .libPaths()))
suppressPackageStartupMessages({
  library(data.table)
  library(digest)
  library(igraph)
  library(Matrix)
  library(Seurat)
})
source(file.path(
  root, "trials/biological_analysis/M1_sc_atlas/scripts",
  "atomic_annotation_v1_helpers.R"
))
source(file.path(
  root, "trials/biological_analysis/M1_sc_atlas/scripts",
  "atomic_resolution_grid_v2_2_helpers.R"
))

main <- function(candidate_id, root) {
  started <- Sys.time()
  context <- atomic_v1_load_context(root)
  loaded <- atomic_v1_load_latent(
    candidate_id, context, root, allow_control = FALSE
  )
  latent <- loaded$latent
  metadata <- copy(context$metadata)

  script_path <- file.path(
    root, "trials/biological_analysis/M1_sc_atlas/scripts",
    "run_atomic_candidate_resolution_grid_v2_2.R"
  )
  helper_v1_path <- file.path(
    root, "trials/biological_analysis/M1_sc_atlas/scripts",
    "atomic_annotation_v1_helpers.R"
  )
  helper_v2_2_path <- file.path(
    root, "trials/biological_analysis/M1_sc_atlas/scripts",
    "atomic_resolution_grid_v2_2_helpers.R"
  )
  protocol_path <- file.path(
    atomic_v2_2_output(root), "contracts", "GRAPH_RESOLUTION_GRID_PROTOCOL_V2_2.md"
  )
  registry_path <- file.path(context$clean, "unsupervised_candidate_registry.csv")
  metadata_path <- file.path(
    context$clean, "inputs", "all_cells_design_qc_provenance.rds"
  )
  historical_dir <- file.path(
    atomic_v1_output(root), "candidate_graphs", candidate_id
  )
  historical_membership_path <- file.path(
    historical_dir, "resolution_membership.csv.gz"
  )
  historical_graph_summary_path <- file.path(
    historical_dir, "graph_summary.csv"
  )
  historical_resolution_summary_path <- file.path(
    historical_dir, "resolution_summary.csv"
  )
  historical_manifest_path <- file.path(historical_dir, "delivery_manifest.csv")

  required_inputs <- c(
    script_path, helper_v1_path, helper_v2_2_path, protocol_path,
    registry_path, metadata_path, historical_membership_path,
    historical_graph_summary_path, historical_resolution_summary_path,
    historical_manifest_path, loaded$registry_row$path
  )
  if (any(!file.exists(required_inputs)) || any(dir.exists(required_inputs))) {
    stop("A required v2.2 graph-grid input is missing or not a regular file")
  }
  atomic_v2_2_verify_manifest_row(
    historical_manifest_path, historical_membership_path, "membership"
  )
  atomic_v2_2_verify_manifest_row(
    historical_manifest_path, historical_graph_summary_path, "graph_summary"
  )
  atomic_v2_2_verify_manifest_row(
    historical_manifest_path, historical_resolution_summary_path,
    "resolution_summary"
  )

  historical_membership <- fread(
    historical_membership_path,
    select = c("cell", "atomic_cluster_id"),
    colClasses = list(character = c("cell", "atomic_cluster_id"))
  )
  if (nrow(historical_membership) != 90760L ||
      anyDuplicated(historical_membership$cell) ||
      anyNA(historical_membership$atomic_cluster_id) ||
      !identical(historical_membership$cell, context$cells)) {
    stop("Historical r4 membership is invalid")
  }
  historical_graph_summary <- fread(historical_graph_summary_path)
  historical_resolution_summary <- fread(historical_resolution_summary_path)
  if (nrow(historical_graph_summary) != 1L ||
      nrow(historical_resolution_summary[resolution == 4]) != 1L ||
      historical_graph_summary$candidate_id[[1L]] != candidate_id ||
      historical_graph_summary$latent_md5[[1L]] != loaded$observed_md5 ||
      historical_graph_summary$n_cells[[1L]] != 90760L ||
      historical_graph_summary$n_dimensions[[1L]] != atomic_v1_dims ||
      historical_graph_summary$metric[[1L]] != "euclidean" ||
      historical_graph_summary$graph_k[[1L]] != atomic_v1_graph_k ||
      !isTRUE(all.equal(
        as.numeric(historical_graph_summary$prune_snn[[1L]]), 1 / 15,
        tolerance = 1e-15
      ))) {
    stop("Historical graph contract is stale or incompatible")
  }

  output_parent <- atomic_v2_2_candidate_parent(root)
  output_dir <- file.path(output_parent, candidate_id)
  stage_dir <- file.path(
    output_parent, paste0(".", candidate_id, ".staging-", Sys.getpid())
  )
  dir.create(output_parent, recursive = TRUE, showWarnings = FALSE)
  if (file.exists(output_dir) || dir.exists(output_dir)) {
    stop("Overwrite protection: v2.2 candidate output exists: ", output_dir)
  }
  if (file.exists(stage_dir) || dir.exists(stage_dir)) {
    stop("Staging output already exists: ", stage_dir)
  }
  dir.create(stage_dir, recursive = FALSE, showWarnings = FALSE)
  committed <- FALSE
  on.exit({
    if (!committed && dir.exists(stage_dir)) {
      unlink(stage_dir, recursive = TRUE, force = TRUE)
    }
  }, add = TRUE)

  message("Reconstructing frozen weighted SNN: ", candidate_id)
  set.seed(atomic_v2_2_leiden_seed)
  neighbor_started <- proc.time()[[3L]]
  neighbors <- FindNeighbors(
    latent,
    k.param = atomic_v1_graph_k,
    return.neighbor = FALSE,
    compute.SNN = TRUE,
    prune.SNN = 1 / 15,
    nn.method = "annoy",
    n.trees = 50L,
    annoy.metric = "euclidean",
    l2.norm = FALSE,
    verbose = FALSE
  )
  neighbor_seconds <- unname(proc.time()[[3L]] - neighbor_started)
  snn <- methods::as(neighbors$snn, "dgCMatrix")
  rm(neighbors)
  if (!identical(rownames(snn), context$cells) ||
      !identical(colnames(snn), context$cells) ||
      !identical(dim(snn), c(90760L, 90760L)) ||
      !isTRUE(Matrix::isSymmetric(snn))) {
    stop("Reconstructed SNN shape/order/symmetry mismatch")
  }
  snn_serialized_md5 <- digest::digest(
    list(
      i = snn@i, p = snn@p, x = snn@x, Dim = snn@Dim,
      Dimnames = snn@Dimnames
    ),
    algo = "md5", serialize = TRUE
  )

  graph_started <- proc.time()[[3L]]
  graph <- graph_from_adjacency_matrix(
    snn, mode = "undirected", weighted = TRUE, diag = FALSE
  )
  graph_seconds <- unname(proc.time()[[3L]] - graph_started)
  if (vcount(graph) != 90760L || !identical(V(graph)$name, context$cells)) {
    stop("Reconstructed graph vertex order mismatch")
  }
  component_result <- components(graph)
  component_sizes <- component_result$csize
  degree_values <- degree(graph)
  weight_values <- E(graph)$weight

  reconstructed_graph_values <- list(
    n_edges = ecount(graph),
    n_components = component_result$no,
    largest_component_fraction = max(component_sizes) / vcount(graph),
    n_isolated_cells = sum(degree_values == 0L),
    n_components_lt20 = sum(component_sizes < 20L),
    n_cells_in_components_lt20 = sum(component_sizes[component_sizes < 20L]),
    median_degree = median(degree_values),
    p10_degree = as.numeric(quantile(degree_values, 0.10, names = FALSE)),
    p90_degree = as.numeric(quantile(degree_values, 0.90, names = FALSE)),
    mean_edge_weight = mean(weight_values),
    median_edge_weight = median(weight_values)
  )
  integer_graph_fields <- c(
    "n_edges", "n_components", "n_isolated_cells", "n_components_lt20",
    "n_cells_in_components_lt20", "median_degree", "p10_degree", "p90_degree"
  )
  numeric_graph_fields <- c(
    "largest_component_fraction", "mean_edge_weight", "median_edge_weight"
  )
  graph_audit <- rbindlist(c(
    lapply(integer_graph_fields, function(field) {
      expected <- as.numeric(historical_graph_summary[[field]][[1L]])
      observed <- as.numeric(reconstructed_graph_values[[field]])
      data.table(
        candidate_id = candidate_id, audit_type = "historical_graph_integer",
        metric = field, expected = format(expected, scientific = FALSE),
        observed = format(observed, scientific = FALSE), tolerance = "0",
        pass = identical(expected, observed)
      )
    }),
    lapply(numeric_graph_fields, function(field) {
      expected <- as.numeric(historical_graph_summary[[field]][[1L]])
      observed <- as.numeric(reconstructed_graph_values[[field]])
      data.table(
        candidate_id = candidate_id, audit_type = "historical_graph_numeric",
        metric = field, expected = format(expected, digits = 17),
        observed = format(observed, digits = 17), tolerance = "1e-12",
        pass = isTRUE(all.equal(expected, observed, tolerance = 1e-12))
      )
    })
  ))
  if (!all(graph_audit$pass)) {
    stop("Reconstructed SNN graph statistics do not reproduce history")
  }

  message("Running 13-resolution Leiden grid: ", candidate_id)
  membership <- data.table(cell = context$cells)
  resolution_rows <- vector("list", length(atomic_v2_2_resolutions))
  composition_rows <- vector("list", length(atomic_v2_2_resolutions))
  for (index in seq_along(atomic_v2_2_resolutions)) {
    resolution <- atomic_v2_2_resolutions[[index]]
    tag <- atomic_v2_2_resolution_tag(resolution)
    cluster_started <- proc.time()[[3L]]
    set.seed(atomic_v2_2_leiden_seed)
    partition <- cluster_leiden(
      graph,
      objective_function = "modularity",
      weights = E(graph)$weight,
      resolution_parameter = resolution,
      n_iterations = atomic_v2_2_leiden_iterations
    )
    raw_membership <- igraph::membership(partition)
    names(raw_membership) <- V(graph)$name
    labels <- atomic_v1_relabel_partition(raw_membership, tag)
    membership[, (tag) := labels]
    sizes <- table(labels)
    effective <- atomic_v2_2_effective_counts(sizes)
    resolution_rows[[index]] <- data.table(
      candidate_id = candidate_id,
      method = as.character(loaded$registry_row$method),
      feature_set_id = as.character(loaded$registry_row$feature_set_id),
      latent_md5 = loaded$observed_md5,
      resolution = resolution,
      resolution_tag = tag,
      partition_id = atomic_v2_2_partition_id(candidate_id, tag),
      n_cells = sum(sizes),
      n_clusters = length(sizes),
      hill_effective_cluster_count = effective$hill,
      inverse_simpson_effective_cluster_count = effective$inverse_simpson,
      effective_to_raw_cluster_ratio = effective$effective_to_raw,
      min_cluster_size = min(sizes),
      p10_cluster_size = as.numeric(quantile(sizes, 0.10, names = FALSE)),
      median_cluster_size = median(sizes),
      max_cluster_size = max(sizes),
      n_clusters_lt20 = sum(sizes < 20L),
      n_clusters_lt50 = sum(sizes < 50L),
      n_clusters_lt100 = sum(sizes < 100L),
      n_cells_in_clusters_lt20 = sum(sizes[sizes < 20L]),
      n_cells_in_clusters_lt50 = sum(sizes[sizes < 50L]),
      n_cells_in_clusters_lt100 = sum(sizes[sizes < 100L]),
      leiden_seconds = unname(proc.time()[[3L]] - cluster_started),
      production_seed = atomic_v2_2_leiden_seed,
      leiden_iterations = atomic_v2_2_leiden_iterations
    )

    composition <- copy(metadata)
    composition[, cluster_id := labels]
    composition <- composition[, .(
      n_cells = .N,
      n_samples = uniqueN(sample),
      n_patients = uniqueN(patient_id),
      n_disease_groups = uniqueN(disease_group),
      dominant_sample_fraction = max(table(sample)) / .N,
      dominant_patient_fraction = max(table(patient_id)) / .N,
      sample_entropy = atomic_v1_normalized_entropy(
        sample, uniqueN(metadata$sample)
      ),
      patient_entropy = atomic_v1_normalized_entropy(
        patient_id, uniqueN(metadata$patient_id)
      ),
      disease_entropy = atomic_v1_normalized_entropy(
        disease_group, uniqueN(metadata$disease_group)
      )
    ), by = cluster_id]
    composition[, `:=`(
      candidate_id = candidate_id,
      resolution = resolution,
      resolution_tag = tag,
      partition_id = atomic_v2_2_partition_id(candidate_id, tag),
      sample_dominant_ge_0p90 = dominant_sample_fraction >= 0.90,
      patient_dominant_ge_0p90 = dominant_patient_fraction >= 0.90
    )]
    setcolorder(composition, c(
      "candidate_id", "resolution", "resolution_tag", "partition_id",
      "cluster_id", setdiff(
        names(composition),
        c("candidate_id", "resolution", "resolution_tag", "partition_id", "cluster_id")
      )
    ))
    setorder(composition, cluster_id)
    composition_rows[[index]] <- composition
    rm(partition, raw_membership, labels, composition)
  }
  resolution_summary <- rbindlist(resolution_rows)
  cluster_composition <- rbindlist(composition_rows)
  expected_tags <- atomic_v2_2_resolution_tag(atomic_v2_2_resolutions)
  if (!identical(names(membership), c("cell", expected_tags)) ||
      !identical(resolution_summary$resolution, atomic_v2_2_resolutions) ||
      nrow(membership) != 90760L || anyNA(membership)) {
    stop("Resolution-grid membership schema/content mismatch")
  }

  r4_membership_exact <- identical(
    membership$r4, historical_membership$atomic_cluster_id
  )
  r4_reproduction <- data.table(
    candidate_id = candidate_id,
    n_cells = 90760L,
    historical_membership_md5 = atomic_v2_2_md5_one(historical_membership_path),
    historical_n_clusters = uniqueN(historical_membership$atomic_cluster_id),
    reconstructed_n_clusters = uniqueN(membership$r4),
    n_exact_cell_matches = sum(
      membership$r4 == historical_membership$atomic_cluster_id
    ),
    exact_cell_order = identical(membership$cell, historical_membership$cell),
    exact_membership = r4_membership_exact,
    pass = r4_membership_exact &&
      identical(membership$cell, historical_membership$cell)
  )
  if (!r4_reproduction$pass[[1L]]) {
    stop("Historical r4 cell-level membership was not reproduced exactly")
  }

  transition_rows <- vector("list", length(expected_tags) - 1L)
  for (index in seq_len(length(expected_tags) - 1L)) {
    coarse_tag <- expected_tags[[index]]
    fine_tag <- expected_tags[[index + 1L]]
    tab <- membership[, .N, by = c(coarse_tag, fine_tag)]
    fine_sizes <- tab[, .(
      fine_n = sum(N), parent_n = .N, max_parent_n = max(N)
    ), by = fine_tag]
    fine_sizes[, parent_containment := max_parent_n / fine_n]
    transition_rows[[index]] <- data.table(
      candidate_id = candidate_id,
      coarse_resolution = atomic_v2_2_resolutions[[index]],
      fine_resolution = atomic_v2_2_resolutions[[index + 1L]],
      coarse_resolution_tag = coarse_tag,
      fine_resolution_tag = fine_tag,
      n_fine_clusters = nrow(fine_sizes),
      cell_weighted_parent_containment = weighted.mean(
        fine_sizes$parent_containment, fine_sizes$fine_n
      ),
      fraction_fine_clusters_strictly_nested = mean(
        fine_sizes$parent_containment == 1
      ),
      fraction_fine_clusters_parent_containment_ge_0p95 = mean(
        fine_sizes$parent_containment >= 0.95
      ),
      n_fine_clusters_with_multiple_parents = sum(fine_sizes$parent_n > 1L)
    )
  }
  transition_audit <- rbindlist(transition_rows)

  membership_path <- file.path(
    stage_dir, "resolution_grid_membership_v2_2.csv.gz"
  )
  resolution_path <- file.path(stage_dir, "resolution_summary_v2_2.csv")
  transition_path <- file.path(
    stage_dir, "resolution_transition_audit_v2_2.csv"
  )
  composition_path <- file.path(stage_dir, "cluster_composition_v2_2.csv.gz")
  r4_audit_path <- file.path(
    stage_dir, "historical_r4_reproduction_audit_v2_2.csv"
  )
  snn_path <- file.path(stage_dir, "snn_matrix_v2_2.rds")
  edge_audit_path <- file.path(stage_dir, "snn_edge_audit_v2_2.csv")
  graph_summary_path <- file.path(stage_dir, "graph_summary_v2_2.csv")
  partition_registry_path <- file.path(
    stage_dir, "partition_registry_candidate_v2_2.csv"
  )
  input_pins_path <- file.path(stage_dir, "input_provenance_v2_2.csv")
  checks_path <- file.path(stage_dir, "acceptance_checks_v2_2.csv")
  session_path <- file.path(stage_dir, "sessionInfo.txt")

  fwrite(membership, membership_path, compress = "gzip")
  fwrite(resolution_summary, resolution_path)
  fwrite(transition_audit, transition_path)
  fwrite(cluster_composition, composition_path, compress = "gzip")
  fwrite(r4_reproduction, r4_audit_path)

  message("Saving one complete sparse SNN: ", candidate_id)
  snn_save_started <- proc.time()[[3L]]
  saveRDS(list(
    version = atomic_v2_2_version,
    candidate_id = candidate_id,
    cell = context$cells,
    snn = snn,
    sparse_payload_md5 = snn_serialized_md5,
    graph_parameters = list(
      dimensions = seq_len(atomic_v1_dims), metric = "euclidean",
      k = atomic_v1_graph_k, annoy_trees = 50L, prune_snn = 1 / 15,
      graph = "weighted_SNN", seed = atomic_v2_2_leiden_seed
    )
  ), snn_path, compress = TRUE)
  snn_save_seconds <- unname(proc.time()[[3L]] - snn_save_started)
  snn_file_md5 <- atomic_v2_2_md5_one(snn_path)
  snn_file_bytes <- as.numeric(file.info(snn_path)$size)

  edge_quantiles <- as.numeric(quantile(
    weight_values, c(0, 0.01, 0.10, 0.25, 0.50, 0.75, 0.90, 0.99, 1),
    names = FALSE
  ))
  edge_audit <- data.table(
    candidate_id = candidate_id,
    matrix_class = class(snn)[[1L]],
    n_rows = nrow(snn),
    n_cols = ncol(snn),
    sparse_nnz = Matrix::nnzero(snn),
    diagonal_nnz = sum(diag(snn) != 0),
    symmetric = Matrix::isSymmetric(snn),
    sparse_payload_md5 = snn_serialized_md5,
    graph_n_edges = ecount(graph),
    edge_weight_min = edge_quantiles[[1L]],
    edge_weight_p01 = edge_quantiles[[2L]],
    edge_weight_p10 = edge_quantiles[[3L]],
    edge_weight_p25 = edge_quantiles[[4L]],
    edge_weight_p50 = edge_quantiles[[5L]],
    edge_weight_p75 = edge_quantiles[[6L]],
    edge_weight_p90 = edge_quantiles[[7L]],
    edge_weight_p99 = edge_quantiles[[8L]],
    edge_weight_max = edge_quantiles[[9L]],
    edge_weight_sum = sum(weight_values),
    edge_weight_sum_squares = sum(weight_values^2),
    snn_file_bytes = snn_file_bytes,
    snn_file_md5 = snn_file_md5
  )
  fwrite(edge_audit, edge_audit_path)

  membership_bytes <- as.numeric(file.info(membership_path)$size)
  membership_md5 <- atomic_v2_2_md5_one(membership_path)
  final_membership_path <- file.path(
    output_dir, "resolution_grid_membership_v2_2.csv.gz"
  )
  final_graph_path <- file.path(output_dir, "snn_matrix_v2_2.rds")
  partition_registry <- resolution_summary[, .(
    partition_id,
    candidate_id,
    resolution,
    resolution_tag,
    membership_path = final_membership_path,
    membership_column = resolution_tag,
    n_cells = as.integer(n_cells),
    n_clusters = as.integer(n_clusters),
    k_hill = hill_effective_cluster_count,
    k_hill_over_k_raw = effective_to_raw_cluster_ratio,
    membership_bytes = membership_bytes,
    membership_md5 = membership_md5,
    graph_path = final_graph_path,
    graph_md5 = snn_file_md5,
    graph_protocol_version = atomic_v2_2_version,
    r4_reproduction_status = "EXACT_CELL_LEVEL_MATCH",
    is_historical_r4 = FALSE
  )]
  fwrite(partition_registry, partition_registry_path)

  input_pins <- data.table(
    input_role = c(
      "executed_candidate_script", "historical_v1_helper",
      "v2_2_helper", "frozen_v2_2_protocol", "candidate_registry",
      "singlet_metadata", "latent", "historical_membership",
      "historical_graph_summary", "historical_resolution_summary",
      "historical_delivery_manifest"
    ),
    absolute_path = normalizePath(c(
      script_path, helper_v1_path, helper_v2_2_path, protocol_path,
      registry_path, metadata_path, loaded$registry_row$path,
      historical_membership_path, historical_graph_summary_path,
      historical_resolution_summary_path, historical_manifest_path
    ), mustWork = TRUE)
  )
  input_pins[, `:=`(
    bytes = as.numeric(file.info(absolute_path)$size),
    md5 = unname(tools::md5sum(absolute_path))
  )]
  fwrite(input_pins, input_pins_path)

  graph_summary <- data.table(
    version = atomic_v2_2_version,
    candidate_id = candidate_id,
    method = as.character(loaded$registry_row$method),
    feature_set_id = as.character(loaded$registry_row$feature_set_id),
    latent_md5 = loaded$observed_md5,
    n_cells = nrow(latent),
    n_dimensions = ncol(latent),
    metric = "euclidean",
    graph_k = atomic_v1_graph_k,
    annoy_trees = 50L,
    prune_snn = 1 / 15,
    n_edges = reconstructed_graph_values$n_edges,
    n_components = reconstructed_graph_values$n_components,
    largest_component_fraction = reconstructed_graph_values$largest_component_fraction,
    n_isolated_cells = reconstructed_graph_values$n_isolated_cells,
    n_components_lt20 = reconstructed_graph_values$n_components_lt20,
    n_cells_in_components_lt20 = reconstructed_graph_values$n_cells_in_components_lt20,
    median_degree = reconstructed_graph_values$median_degree,
    p10_degree = reconstructed_graph_values$p10_degree,
    p90_degree = reconstructed_graph_values$p90_degree,
    mean_edge_weight = reconstructed_graph_values$mean_edge_weight,
    median_edge_weight = reconstructed_graph_values$median_edge_weight,
    neighbor_seconds = neighbor_seconds,
    graph_conversion_seconds = graph_seconds,
    snn_save_seconds = snn_save_seconds,
    total_seconds = as.numeric(difftime(Sys.time(), started, units = "secs")),
    leiden_seed = atomic_v2_2_leiden_seed,
    leiden_iterations = atomic_v2_2_leiden_iterations,
    resolution_ladder = paste(atomic_v2_2_resolutions, collapse = ";"),
    n_resolutions = length(atomic_v2_2_resolutions),
    historical_r4_membership_exact = r4_membership_exact,
    historical_graph_statistics_exact = all(graph_audit$pass),
    full_sparse_snn_saved = TRUE,
    sparse_snn_payload_md5 = snn_serialized_md5,
    sparse_snn_file_bytes = snn_file_bytes,
    sparse_snn_file_md5 = snn_file_md5,
    expression_or_annotation_label_used_for_graph = FALSE,
    cnv_used_for_graph = FALSE,
    umap_generated = FALSE,
    script_md5 = atomic_v2_2_md5_one(script_path),
    helper_v1_md5 = atomic_v2_2_md5_one(helper_v1_path),
    helper_v2_2_md5 = atomic_v2_2_md5_one(helper_v2_2_path),
    protocol_md5 = atomic_v2_2_md5_one(protocol_path),
    registry_md5 = atomic_v2_2_md5_one(registry_path),
    metadata_md5 = atomic_v2_2_md5_one(metadata_path),
    historical_membership_md5 = atomic_v2_2_md5_one(historical_membership_path),
    historical_graph_summary_md5 = atomic_v2_2_md5_one(
      historical_graph_summary_path
    )
  )
  fwrite(graph_summary, graph_summary_path)

  check_ids <- c(
    "eligible_integrated_candidate", "cell_count_90760",
    "latent_cell_order_exact", "latent_finite", "latent_md5_exact",
    "historical_inputs_manifest_verified", "graph_vertex_order_exact",
    "historical_graph_statistics_exact", "historical_r4_membership_exact",
    "resolution_grid_exact_13", "resolution_grid_values_exact",
    "membership_schema_exact", "all_partitions_cover_90760",
    "all_partition_ids_unique", "full_sparse_snn_saved",
    "snn_shape_order_symmetry_exact", "snn_file_md5_recorded",
    "graph_scope_excludes_expression_annotation_cnv_region_umap",
    "no_umap_generated"
  )
  checks <- data.table(
    check_id = check_ids,
    pass = c(
      loaded$eligible,
      nrow(latent) == 90760L,
      loaded$original_cell_order_exact,
      !anyNA(latent) && all(is.finite(latent)),
      identical(loaded$observed_md5, loaded$registry_row$md5),
      TRUE,
      identical(V(graph)$name, context$cells),
      all(graph_audit$pass),
      r4_membership_exact,
      nrow(resolution_summary) == 13L,
      identical(resolution_summary$resolution, atomic_v2_2_resolutions),
      identical(names(membership), c("cell", expected_tags)),
      all(resolution_summary$n_cells == 90760L),
      uniqueN(resolution_summary$partition_id) == 13L,
      file.exists(snn_path) && snn_file_bytes > 0,
      identical(dim(snn), c(90760L, 90760L)) &&
        identical(rownames(snn), context$cells) &&
        identical(colnames(snn), context$cells) && Matrix::isSymmetric(snn),
      identical(atomic_v2_2_md5_one(snn_path), snn_file_md5),
      TRUE,
      TRUE
    )
  )
  fwrite(checks, checks_path)
  writeLines(capture.output(sessionInfo()), session_path)
  if (!all(checks$pass)) stop("v2.2 candidate acceptance check failed")

  payload <- c(
    membership_path, resolution_path, transition_path, composition_path,
    partition_registry_path, graph_summary_path,
    edge_audit_path, snn_path, r4_audit_path, input_pins_path,
    checks_path, session_path
  )
  roles <- c(
    "membership", "resolution_summary", "transition_audit", "composition",
    "partition_registry", "graph_summary",
    "snn_edge_audit", "full_sparse_snn", "historical_r4_reproduction",
    "input_provenance", "acceptance", "session"
  )
  manifest_path <- file.path(stage_dir, "delivery_manifest_v2_2.csv")
  atomic_v2_2_write_manifest(
    payload, roles, manifest_path, base_dir = stage_dir
  )

  if (!file.rename(stage_dir, output_dir)) {
    stop("Failed to atomically commit v2.2 candidate output: ", candidate_id)
  }
  committed <- TRUE
  message(
    "v2.2 candidate graph grid complete: ", candidate_id,
    " (", round(graph_summary$total_seconds[[1L]], 1), " seconds)"
  )
  invisible(output_dir)
}

main(candidate_id, root)
