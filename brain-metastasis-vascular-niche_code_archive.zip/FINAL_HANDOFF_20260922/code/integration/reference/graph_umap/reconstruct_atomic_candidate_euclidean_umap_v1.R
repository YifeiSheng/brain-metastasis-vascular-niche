#!/usr/bin/env Rscript

# Reconstruct one protocol-aligned candidate-review UMAP from the same frozen
# integrated latent and Euclidean k=30 Annoy neighbor recipe used before the
# weighted-SNN/Leiden step. The archived SNN edges were not retained, so this is
# a deterministic reconstruction under the frozen recipe, not reuse of an
# archived graph.

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 1L) {
  stop("Usage: reconstruct_atomic_candidate_euclidean_umap_v1.R candidate_id")
}
candidate_id <- args[[1]]

root <- normalizePath(getwd(), mustWork = TRUE)
.libPaths(c(file.path(root, "Rlib"), .libPaths()))
suppressPackageStartupMessages({
  library(data.table)
  library(digest)
  library(Seurat)
  library(uwot)
})
source(file.path(
  root,
  "trials/biological_analysis/M1_sc_atlas/scripts/atomic_annotation_v1_helpers.R"
))

context <- atomic_v1_load_context(root)
loaded <- atomic_v1_load_latent(candidate_id, context, root, allow_control = FALSE)
latent <- loaded$latent

graph_dir <- file.path(
  atomic_v1_output(root), "candidate_graphs", candidate_id
)
graph_object_path <- file.path(graph_dir, "graph_object_without_edges.rds")
graph_summary_path <- file.path(graph_dir, "graph_summary.csv")
if (!file.exists(graph_object_path) || !file.exists(graph_summary_path)) {
  stop("Missing accepted atomic graph provenance for ", candidate_id)
}
graph_object <- readRDS(graph_object_path)
graph_summary <- fread(graph_summary_path)
if (nrow(graph_summary) != 1L ||
    !identical(graph_object$candidate_id, candidate_id) ||
    !identical(graph_object$cell, context$cells) ||
    !identical(graph_object$latent_md5, loaded$observed_md5) ||
    graph_object$full_graph_saved != FALSE ||
    graph_summary$metric != "euclidean" ||
    graph_summary$graph_k != atomic_v1_graph_k ||
    graph_summary$annoy_trees != 50L ||
    abs(graph_summary$prune_snn - 1 / 15) > 1e-12) {
  stop("Archived graph provenance does not match the frozen protocol")
}

output_parent <- file.path(
  atomic_v1_output(root),
  "candidate_review_umap_euclidean_v1",
  "coordinates"
)
dir.create(output_parent, recursive = TRUE, showWarnings = FALSE)
output_path <- file.path(
  output_parent,
  paste0(candidate_id, ".euclidean_k30_umap.rds")
)
stage_path <- file.path(
  output_parent,
  paste0(".", candidate_id, ".staging-", Sys.getpid(), ".rds")
)
if (file.exists(output_path) || dir.exists(output_path)) {
  stop("Overwrite protection: coordinate output already exists: ", candidate_id)
}
if (file.exists(stage_path) || dir.exists(stage_path)) {
  stop("Staging collision: ", stage_path)
}
committed <- FALSE
on.exit({
  if (!committed && file.exists(stage_path)) unlink(stage_path, force = TRUE)
}, add = TRUE)

message("Reconstructing Euclidean Annoy kNN: ", candidate_id)
set.seed(atomic_v1_seed)
neighbor_started <- proc.time()[[3]]
neighbor <- FindNeighbors(
  latent,
  k.param = atomic_v1_graph_k,
  return.neighbor = TRUE,
  compute.SNN = FALSE,
  nn.method = "annoy",
  n.trees = 50L,
  annoy.metric = "euclidean",
  l2.norm = FALSE,
  verbose = FALSE
)
neighbor_seconds <- unname(proc.time()[[3]] - neighbor_started)
nn_idx <- SeuratObject::Indices(neighbor)
nn_dist <- SeuratObject::Distances(neighbor)
storage.mode(nn_idx) <- "integer"
storage.mode(nn_dist) <- "double"
if (!identical(dim(nn_idx), c(90760L, 30L)) ||
    !identical(dim(nn_dist), c(90760L, 30L)) ||
    !identical(as.integer(nn_idx[, 1]), seq_len(90760L)) ||
    anyNA(nn_idx) || anyNA(nn_dist) || any(!is.finite(nn_dist)) ||
    any(nn_dist < 0) || max(abs(nn_dist[, 1])) > 1e-12) {
  stop("Reconstructed nearest-neighbor audit failed: ", candidate_id)
}

message("Optimizing UMAP from reconstructed Euclidean kNN: ", candidate_id)
set.seed(atomic_v1_seed)
umap_started <- proc.time()[[3]]
umap <- uwot::umap(
  X = NULL,
  n_neighbors = atomic_v1_graph_k,
  n_components = 2L,
  metric = "euclidean",
  n_epochs = 200L,
  min_dist = 0.3,
  spread = 1,
  init = "spectral",
  nn_method = list(idx = nn_idx, dist = nn_dist),
  fast_sgd = FALSE,
  n_threads = 1L,
  n_sgd_threads = 1L,
  ret_model = FALSE,
  verbose = FALSE
)
umap_seconds <- unname(proc.time()[[3]] - umap_started)
if (!identical(dim(umap), c(90760L, 2L)) ||
    anyNA(umap) || any(!is.finite(umap))) {
  stop("UMAP coordinate audit failed: ", candidate_id)
}
rownames(umap) <- context$cells
colnames(umap) <- c("UMAP_1", "UMAP_2")

coordinate_object <- list(
  candidate_id = candidate_id,
  cell = context$cells,
  umap = umap,
  candidate_latent_md5 = loaded$observed_md5,
  archived_graph_object_md5 = unname(tools::md5sum(graph_object_path)),
  archived_graph_edges_available = FALSE,
  exact_archived_graph_reused = FALSE,
  reconstructed_neighbor_index_md5 = digest(nn_idx, algo = "md5"),
  reconstructed_neighbor_distance_md5 = digest(nn_dist, algo = "md5"),
  reconstruction_parameters = list(
    latent_dimensions = seq_len(atomic_v1_dims),
    latent_scaling = "none",
    cell_order = "frozen_90760_analysis_singlets",
    neighbor_implementation = "Seurat::FindNeighbors",
    neighbor_method = "annoy",
    neighbor_metric = "euclidean",
    n_neighbors = atomic_v1_graph_k,
    annoy_trees = 50L,
    l2_norm = FALSE,
    archived_snn_prune_for_leiden = 1 / 15,
    umap_implementation = "uwot::umap",
    umap_input = "reconstructed_precomputed_euclidean_knn",
    umap_min_dist = 0.3,
    umap_spread = 1,
    umap_init = "spectral",
    umap_epochs = 200L,
    umap_seed = atomic_v1_seed,
    umap_fast_sgd = FALSE,
    umap_sgd_threads = 1L,
    annotation_or_label_used = FALSE
  ),
  timing_seconds = list(
    neighbor = neighbor_seconds,
    umap = umap_seconds,
    total = neighbor_seconds + umap_seconds
  ),
  software_versions = list(
    R = as.character(getRversion()),
    Seurat = as.character(packageVersion("Seurat")),
    SeuratObject = as.character(packageVersion("SeuratObject")),
    RcppAnnoy = as.character(packageVersion("RcppAnnoy")),
    uwot = as.character(packageVersion("uwot"))
  ),
  interpretation = paste0(
    "UMAP reconstructed from the same frozen integrated latent using ",
    "Euclidean distance and 30 neighbours. The UMAP neighbourhood was ",
    "rebuilt for visualization and is not an archived weighted-SNN edge list."
  )
)
saveRDS(coordinate_object, stage_path, compress = TRUE)
roundtrip <- readRDS(stage_path)
if (!identical(roundtrip$candidate_id, candidate_id) ||
    !identical(roundtrip$cell, context$cells) ||
    !identical(roundtrip$candidate_latent_md5, loaded$observed_md5) ||
    !identical(roundtrip$umap, umap)) {
  stop("Coordinate RDS round-trip audit failed: ", candidate_id)
}
if (!file.rename(stage_path, output_path)) {
  stop("Failed to commit coordinate output: ", candidate_id)
}
committed <- TRUE
message(
  "Completed ", candidate_id,
  " | kNN ", round(neighbor_seconds, 1), " s",
  " | UMAP ", round(umap_seconds, 1), " s"
)
