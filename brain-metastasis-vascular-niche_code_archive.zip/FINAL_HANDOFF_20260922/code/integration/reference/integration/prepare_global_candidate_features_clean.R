#!/usr/bin/env Rscript

root <- normalizePath(getwd(), mustWork = TRUE)
.libPaths(c(file.path(root, "Rlib"), .libPaths()))
suppressPackageStartupMessages({
  library(data.table)
  library(Seurat)
})
options(future.globals.maxSize = 24 * 1024^3)
set.seed(42)

out <- file.path(
  root,
  "trials/biological_analysis/M1_sc_atlas/results/revision_work/integration_annotation_rebuild_clean"
)
input_dir <- file.path(out, "inputs")
provenance_dir <- file.path(out, "provenance")
dir.create(input_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(provenance_dir, recursive = TRUE, showWarnings = FALSE)
a <- readRDS(file.path(input_dir, "all_cells_design_qc_provenance.rds"))[analysis_singlets == TRUE]
cells <- a$cell
if (length(cells) != 90760L || anyDuplicated(cells)) stop("Frozen singlet membership mismatch")
source_paths <- unique(a$source_object_path)
if (length(source_paths) != 12L || any(!file.exists(source_paths))) stop("Expected 12 source objects")

objects <- lapply(source_paths, function(path) {
  message("Preparing per-library HVGs: ", basename(path))
  object <- readRDS(path)
  use <- intersect(colnames(object), cells)
  object <- subset(object, cells = use)
  DefaultAssay(object) <- "RNA"
  object <- NormalizeData(object, normalization.method = "LogNormalize", scale.factor = 10000, verbose = FALSE)
  FindVariableFeatures(object, selection.method = "vst", nfeatures = 5000, verbose = FALSE)
})
if (sum(vapply(objects, ncol, integer(1))) != 90760L) stop("Prepared-object membership mismatch")
gene_sets <- lapply(objects, rownames)
if (length(Reduce(intersect, gene_sets)) < 30000L) stop("Unexpectedly small common gene universe")

ranked <- SelectIntegrationFeatures(object.list = objects, nfeatures = 5000)
if (length(ranked) < 4000L) stop("Insufficient ranked integration features")

cc <- unique(c(Seurat::cc.genes.updated.2019$s.genes, Seurat::cc.genes.updated.2019$g2m.genes))
sex_linked <- c("XIST", "TSIX", "RPS4Y1", "DDX3Y", "KDM5D", "EIF1AY", "UTY", "ZFY", "TMSB4Y", "USP9Y")
is_mito <- grepl("^MT-", ranked, ignore.case = TRUE)
is_ribo <- grepl("^RP[SL][0-9]", ranked, ignore.case = TRUE)
is_cycle <- toupper(ranked) %chin% toupper(cc)
is_sex <- toupper(ranked) %chin% toupper(sex_linked)
is_ig_tcr <- grepl(
  "^(IGH[VDJCMEGA]|IGK[VDJC]|IGL[VDJC]|TR[ABDG][VJC])",
  ranked, ignore.case = TRUE
) | toupper(ranked) %chin% c("IGKC", "JCHAIN")

base_keep <- !(is_mito | is_ribo | is_cycle | is_sex)
biology <- ranked[base_keep][seq_len(3000L)]
identity <- ranked[base_keep & !is_ig_tcr][seq_len(3000L)]
if (length(biology) != 3000L || length(identity) != 3000L || anyDuplicated(biology) || anyDuplicated(identity)) {
  stop("Frozen feature construction failed to produce two unique 3,000-gene sets")
}

feature_table <- rbindlist(list(
  data.table(feature_set_id = "identity_oriented_hvg3000", rank = seq_along(identity), gene = identity),
  data.table(feature_set_id = "biology_preserving_hvg3000", rank = seq_along(biology), gene = biology)
))
feature_table[, `:=`(
  excluded_mito = grepl("^MT-", gene, ignore.case = TRUE),
  excluded_ribosomal = grepl("^RP[SL][0-9]", gene, ignore.case = TRUE),
  excluded_cell_cycle = toupper(gene) %chin% toupper(cc),
  excluded_sex_linked = toupper(gene) %chin% toupper(sex_linked),
  is_ig_tcr = grepl("^(IGH[VDJCMEGA]|IGK[VDJC]|IGL[VDJC]|TR[ABDG][VJC])", gene, ignore.case = TRUE) |
    toupper(gene) %chin% c("IGKC", "JCHAIN")
)]
fwrite(feature_table, file.path(input_dir, "v5_frozen_feature_sets.csv"))

rank_audit <- data.table(
  rank = seq_along(ranked), gene = ranked, is_mito, is_ribo, is_cycle, is_sex, is_ig_tcr,
  identity_selected = ranked %chin% identity,
  biology_selected = ranked %chin% biology
)
fwrite(rank_audit, file.path(input_dir, "v5_feature_filter_audit.csv.gz"))

object_audit <- rbindlist(lapply(seq_along(objects), function(i) data.table(
  source_object_path = normalizePath(source_paths[i]),
  source_md5 = unname(tools::md5sum(source_paths[i])),
  n_cells = ncol(objects[[i]]),
  n_genes = nrow(objects[[i]]),
  n_variable_features = length(VariableFeatures(objects[[i]])),
  cell_membership_md5 = digest::digest(sort(colnames(objects[[i]])), algo = "md5")
)))
fwrite(object_audit, file.path(provenance_dir, "candidate_source_object_audit.csv"))

feature_manifest <- feature_table[, .(
  n_features = .N,
  gene_order_md5 = digest::digest(gene, algo = "md5"),
  n_ig_tcr = sum(is_ig_tcr),
  first_gene = first(gene),
  last_gene = last(gene)
), by = feature_set_id]
feature_manifest[, `:=`(
  selection_seed = 42L,
  selection_method = "per-library_vst5000_SelectIntegrationFeatures_rank_filter_first3000",
  membership = "90760_analysis_singlets",
  frozen_before_candidate_fit = TRUE
)]
fwrite(feature_manifest, file.path(input_dir, "v5_frozen_feature_set_manifest.csv"))

saveRDS(
  list(
    feature_sets = list(
      identity_oriented_hvg3000 = identity,
      biology_preserving_hvg3000 = biology
    ),
    ranked_features = ranked,
    parameters = list(
      per_library_vst_nfeatures = 5000L,
      selected_features_target = 3000L,
      seed = 42L,
      membership = "90760_analysis_singlets"
    )
  ),
  file.path(input_dir, "v5_frozen_feature_sets.rds"),
  compress = TRUE
)

generated <- file.path(input_dir, c(
  "v5_frozen_feature_sets.csv", "v5_feature_filter_audit.csv.gz",
  "v5_frozen_feature_set_manifest.csv",
  "v5_frozen_feature_sets.rds"
))
fwrite(data.table(
  path = normalizePath(generated), bytes = file.info(generated)$size,
  md5 = unname(tools::md5sum(generated)), freeze_phase = "LABEL_FREE_FEATURE_FREEZE_BEFORE_CANDIDATE_FIT",
  immutable_after_freeze = TRUE
), file.path(provenance_dir, "feature_freeze_md5.csv"))
writeLines(capture.output(sessionInfo()), file.path(provenance_dir, "feature_preparation_sessionInfo.txt"))
message("Feature-set freeze complete")
