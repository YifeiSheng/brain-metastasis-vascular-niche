#!/usr/bin/env Rscript

args <- commandArgs(trailingOnly = TRUE)
valid_features <- c("identity_oriented_hvg3000", "biology_preserving_hvg3000")
if (length(args) != 1L || !args[1] %in% valid_features) {
  stop("Usage: build_baseline_harmony_candidates_clean.R identity_oriented_hvg3000|biology_preserving_hvg3000")
}
feature_id <- args[1]

root <- normalizePath(getwd(), mustWork = TRUE)
.libPaths(c(file.path(root, "Rlib"), .libPaths()))
suppressPackageStartupMessages({
  library(data.table)
  library(Matrix)
  library(irlba)
  library(Seurat)
  library(harmony)
})
options(future.globals.maxSize = 32 * 1024^3)

out <- file.path(
  root,
  "trials/biological_analysis/M1_sc_atlas/results/revision_work/integration_annotation_rebuild_clean"
)
input_dir <- file.path(out, "inputs")
provenance_dir <- file.path(out, "provenance")
latent_dir <- file.path(out, "embeddings")
dir.create(latent_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(provenance_dir, recursive = TRUE, showWarnings = FALSE)
features_obj <- readRDS(file.path(input_dir, "v5_frozen_feature_sets.rds"))
features <- features_obj$feature_sets[[feature_id]]
if (length(features) != 3000L || anyDuplicated(features)) stop("Invalid frozen feature set")
a <- readRDS(file.path(input_dir, "all_cells_design_qc_provenance.rds"))[analysis_singlets == TRUE]
cells <- a$cell
source_paths <- unique(a$source_object_path)
counts_list <- lapply(source_paths, function(path) {
  object <- readRDS(path)
  use <- a[source_object_path == path, cell]
  if (!all(features %in% rownames(object)) || !all(use %in% colnames(object))) {
    stop("Frozen genes/cells missing from source object")
  }
  GetAssayData(object, assay = "RNA", slot = "counts")[features, use, drop = FALSE]
})
if (sum(vapply(counts_list, ncol, integer(1))) != 90760L) stop("Candidate membership mismatch")

message("Combining frozen-feature sparse counts for ", feature_id)
counts <- do.call(cbind, counts_list)
rm(counts_list)
gc()
if (!identical(colnames(counts), cells) || ncol(counts) != 90760L) stop("Combined membership/order mismatch")

# Memory-bounded algebraic equivalent of LogNormalize -> ScaleData ->
# truncated PCA.  Zero entries remain implicit; centering/scaling vectors are
# passed directly to irlba.  Positive scaled values are capped at Seurat's
# default scale.max=10 before PCA.
libsize <- Matrix::colSums(counts)
if (any(libsize <= 0)) stop("Zero-library cell in analysis membership")
norm <- counts %*% Diagonal(x = 10000 / libsize)
norm@x <- log1p(norm@x)
gene_mean <- Matrix::rowMeans(norm)
gene_ss <- Matrix::rowSums(norm ^ 2)
gene_sd <- sqrt(pmax((gene_ss - ncol(norm) * gene_mean ^ 2) / (ncol(norm) - 1), 1e-12))
upper <- gene_mean[norm@i + 1L] + 10 * gene_sd[norm@i + 1L]
norm@x <- pmin(norm@x, upper)
set.seed(42)
pca_fit <- irlba::prcomp_irlba(
  Matrix::t(norm), n = 50L, center = gene_mean, scale. = gene_sd,
  maxit = 1000L, tol = 1e-5
)
pc <- pca_fit$x
rownames(pc) <- cells
if (nrow(pc) != 90760L || anyNA(pc) || !identical(rownames(pc), cells)) stop("PCA membership/order mismatch")
rm(counts, norm, pca_fit)
gc()

save_latent <- function(candidate_id, latent, method, seed, theta = NA_real_) {
  latent <- latent[cells, seq_len(30L), drop = FALSE]
  if (!identical(rownames(latent), cells) || anyNA(latent)) stop("Latent membership/order mismatch")
  path <- file.path(latent_dir, paste0(candidate_id, ".latent.rds"))
  if (file.exists(path)) stop("Refusing to overwrite retained candidate: ", path)
  saveRDS(list(
    latent = latent,
    pca = latent,
    cell = cells,
    feature_set_id = feature_id,
    hvg = features,
    params = list(
      candidate_id = candidate_id, method = method, batch_key = if (method == "Harmony") "sample" else "none",
      batch_key_status = if (method == "Harmony") "CONFOUNDED_LIBRARY_PROXY_TEST_ONLY" else "NOT_APPLICABLE",
      input_dimensions = "1:30", theta = theta, sigma = if (method == "Harmony") 0.1 else NA_real_,
      max_iter_harmony = if (method == "Harmony") 20L else NA_integer_,
      max_iter_kmeans = if (method == "Harmony") 20L else NA_integer_,
      normalization = "LogNormalize_10000", scaling = "center_unit_variance_scale_max_10",
      pca_engine = "sparse_irlba",
      seed = seed, membership = "90760_analysis_singlets_only"
    )
  ), path, compress = TRUE)
  data.table(
    candidate_id = candidate_id, method = method, feature_set_id = feature_id,
    random_seed = seed, theta = theta, path = normalizePath(path),
    bytes = file.info(path)$size, md5 = unname(tools::md5sum(path)),
    n_cells = nrow(latent), n_dimensions = ncol(latent),
    cell_order_md5 = digest::digest(rownames(latent), algo = "md5"),
    fit_status = "COMPLETE", fit_membership = "90760_analysis_singlets_only"
  )
}

rows <- list()
baseline_id <- paste0("baseline_", feature_id, "_seed42")
rows[[length(rows) + 1L]] <- save_latent(baseline_id, pc, "unintegrated_PCA", 42L)

meta <- data.frame(sample = a$sample, row.names = cells)
for (theta in c(0.5, 1, 2)) for (seed in c(41L, 42L)) {
  set.seed(seed)
  candidate_id <- paste0(
    "harmony_", feature_id, "_theta", gsub("\\.", "p", as.character(theta)), "_seed", seed
  )
  message("Fitting ", candidate_id)
  hm <- harmony::RunHarmony(
    pc[, 1:30, drop = FALSE], meta, vars_use = "sample",
    theta = theta, sigma = 0.1, max_iter = 20L, early_stop = TRUE,
    ncores = 4L, return_object = FALSE, verbose = FALSE,
    .options = harmony::harmony_options(max.iter.cluster = 20L)
  )
  rownames(hm) <- cells
  rows[[length(rows) + 1L]] <- save_latent(candidate_id, hm, "Harmony", seed, theta)
  rm(hm)
  gc()
}

manifest <- rbindlist(rows, use.names = TRUE, fill = TRUE)
fwrite(manifest, file.path(provenance_dir, paste0("baseline_harmony_manifest_", feature_id, ".csv")))
writeLines(capture.output(sessionInfo()), file.path(provenance_dir, paste0("baseline_harmony_", feature_id, "_sessionInfo.txt")))
message("Baseline/Harmony candidates complete for ", feature_id)
