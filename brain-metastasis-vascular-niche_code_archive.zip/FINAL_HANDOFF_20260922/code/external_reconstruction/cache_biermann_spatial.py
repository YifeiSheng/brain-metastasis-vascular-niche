"""Bounded 2-worker streaming cache for 96b_L17_nutrition_spatial.py; all files remain on server."""
import os
for k in ["OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"]:os.environ[k]="2"
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import gzip,json,time,subprocess,sys
import numpy as np
B=Path(os.environ.get("SAFEPOSTER_HANDOFF_ROOT",str(Path(__file__).resolve().parents[2])));O=B/"results/nutrition";E=B/"data/external/scrna/GSE185386/raw"
S=json.load(open(O/"gene_sets.json"))["sets"];GENES=sorted(set(sum(S.values(),[])));ALIASES={"ATP5A1":"ATP5F1A","ATP5B":"ATP5F1B"}
def cache_one(path):
 f=Path(path);name=f.name.split("_",1)[1].replace("_slide_raw_counts.csv.gz","");out=O/(name+"_selected_counts.npz")
 if out.exists():
  z=np.load(out)
  if "format_version" in z and int(z["format_version"][0])==2:return name+" reused"
 print("START",name,flush=True);start=time.time()
 with gzip.open(f,"rt") as h:
  head=h.readline().rstrip().split(",");bc=np.array([x.strip('"') for x in head[1:]]);tot=np.zeros(len(bc),float);select={}
  for j,line in enumerate(h):
   sep=line.find(",");g=line[:sep].strip('"');v=np.fromstring(line[sep+1:],sep=",",dtype=np.float32)
   if len(v)!=len(bc):raise ValueError(str(f)+" malformed "+g)
   tot+=v;cg=ALIASES.get(g,g)
   if cg in GENES:select[cg]=v
   if j%10000==0:print("PROGRESS",name,j,"genes",round(time.time()-start,1),"sec",flush=True)
 present=[g for g in GENES if g in select];c=np.column_stack([select[g] for g in present])
 tmp=O/(name+"_selected_counts.partial.npz")
 np.savez_compressed(tmp,barcodes=bc,counts=c,total=tot,genes=np.array(present),format_version=np.array([2]))
 tmp.replace(out)
 return name+" cached "+str(len(bc))+" beads "+str(len(present))+" genes "+str(round(time.time()-start,1))+" sec"
if __name__=="__main__":
 files=sorted(E.glob("*_slide_raw_counts.csv.gz"))
 with ProcessPoolExecutor(max_workers=2) as pool:
  fs=[pool.submit(cache_one,str(f)) for f in files]
  for fu in as_completed(fs):print(fu.result(),flush=True)
 print("CACHES COMPLETE; run code/analysis/96b_L17_nutrition_spatial.py separately.",flush=True)
