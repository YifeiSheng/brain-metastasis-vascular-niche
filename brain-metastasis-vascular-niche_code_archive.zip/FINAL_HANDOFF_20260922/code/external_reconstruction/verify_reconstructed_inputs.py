"""Check reconstructed external inputs against the frozen exclusion manifest.
Absent files are expected if only some datasets were restored. --require-all is
appropriate only after rebuilding the selected full scope. Exit 1 on mismatch.
"""
import argparse,hashlib,json
from pathlib import Path
P=Path(__file__).resolve().parents[2]
a=argparse.ArgumentParser(description=__doc__)
a.add_argument("--root",type=Path,default=P)
a.add_argument("--dataset",help="Optional dataset_id filter")
a.add_argument("--prefix",help="Optional package relative path prefix")
a.add_argument("--require-all",action="store_true")
a.add_argument("--report",type=Path)
s=a.parse_args()
rows=json.loads((P/"provenance/external_inputs_excluded.json").read_text())["files"];out=[]
for r in rows:
    if s.dataset and r["dataset_id"]!=s.dataset:continue
    if s.prefix and not r["path"].startswith(s.prefix):continue
    f=s.root/r["path"];d={"path":r["path"],"status":"missing","expected_sha256":r["sha256"]}
    if f.exists():
        h=hashlib.sha256()
        with f.open("rb") as x:
            for b in iter(lambda:x.read(8<<20),b""):h.update(b)
        d.update(actual_sha256=h.hexdigest(),bytes=f.stat().st_size,status="identical" if h.hexdigest()==r["sha256"] else "different")
    out.append(d)
if not out:a.error("No manifest entries match the requested dataset/prefix; nothing was verified.")
counts={x:sum(r["status"]==x for r in out) for x in ["identical","different","missing"]}
report={"scope":"Byte comparison only; different compression/serialization can require a separate semantic comparison.","counts":counts,"files":out}
if s.report:s.report.parent.mkdir(parents=True,exist_ok=True);s.report.write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps(counts))
raise SystemExit(1 if counts["different"] or (s.require_all and counts["missing"]) else 0)
