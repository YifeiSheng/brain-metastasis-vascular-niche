"""Prepare author archive layouts without changing gene/cell IDs or measurements.
Run in a working copy. Existing files are compared and never silently replaced.
"""
import argparse,gzip,hashlib,json,shutil,tarfile,zipfile
from pathlib import Path
P=Path(__file__).resolve().parents[2]
def copy_stream(inp,dst):
    dst.parent.mkdir(parents=True,exist_ok=True)
    temp=dst.with_name(dst.name+".partial")
    with temp.open("wb") as out: shutil.copyfileobj(inp,out,8<<20)
    if dst.exists():
        def sha(p):
            h=hashlib.sha256()
            with p.open("rb") as f:
                for b in iter(lambda:f.read(8<<20),b""):h.update(b)
            return h.digest()
        if sha(temp)!=sha(dst): raise ValueError("Refusing different existing file: "+str(dst))
        temp.unlink()
    else:temp.replace(dst)
def untar(archive,dest):
    with tarfile.open(archive) as t:
        for m in t.getmembers():
            if not m.isfile() or "__MACOSX" in m.name or Path(m.name).name.startswith("._"):continue
            dst=(dest/m.name).resolve()
            if not dst.is_relative_to(dest.resolve()):raise ValueError("Unsafe archive path "+m.name)
            with t.extractfile(m) as inp:copy_stream(inp,dst)
def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root",type=Path,default=P)
    ap.add_argument("--mode",required=True,choices=["raw-tar","vine-seq","visium179572","xenium","imc-updated"])
    ap.add_argument("--archive",type=Path,help="For raw-tar or imc-updated")
    ap.add_argument("--destination",type=Path,help="For raw-tar only")
    a=ap.parse_args();root=a.root.resolve()
    if a.mode=="raw-tar":
        if not a.archive or not a.destination:ap.error("raw-tar requires --archive and --destination")
        untar(a.archive,a.destination)
    elif a.mode=="vine-seq":
        d=root/"data/external/scrna/GSE163577/raw"
        fs=sorted(d.glob("*filtered_feature_bc_matrix.tar.gz"))
        if not fs:raise FileNotFoundError("Download GSE163577 sample tar.gz files first")
        for f in fs:untar(f,d)
    elif a.mode=="visium179572":
        d=root/"data/external/spatial/GSE179572/raw"
        fs=sorted(d.glob("GSM*_spatial.tar.gz"))
        if len(fs)!=6:raise ValueError("Expected six GSM spatial archives, found "+str(len(fs)))
        for f in fs:untar(f,d/f.name.split("_")[0])
    elif a.mode=="xenium":
        d=root/"data/external/spatial/GSE325935/raw"
        fs=sorted(d.glob("*cells.parquet.gz"))
        if len(fs)!=4:raise ValueError("Expected four cells.parquet.gz files")
        for f in fs:
            with gzip.open(f,"rb") as inp:copy_stream(inp,f.with_suffix(""))
    elif a.mode=="imc-updated":
        if not a.archive:ap.error("imc-updated requires --archive BrainData.zip from Zenodo 7884599")
        d=root/"results/verified_vascular_geometry/official_updated"
        count=0
        with zipfile.ZipFile(a.archive) as z:
            for m in z.infolist():
                if m.is_dir() or "__MACOSX" in m.filename or Path(m.filename).name.startswith(("._","~$")):continue
                name=m.filename
                targets=[("BRAIN_IMC_CellType/","CellType/"),("BRAIN_IMC_Segmentation/","Segmentation/")]
                rel=None
                for old,new in targets:
                    if old in name:rel=new+name.split(old,1)[1];break
                if Path(name).name=="Clinical Data GBM BrM.xlsx":rel="Clinical Data GBM BrM.xlsx"
                if rel is None:continue
                dst=(d/rel).resolve()
                if not dst.is_relative_to(d.resolve()):raise ValueError("Unsafe ZIP path")
                with z.open(m) as inp:copy_stream(inp,dst)
                count+=1
        mp=root/"results/verified_vascular_geometry/ALL_ROI_MAPPING_OFFICIAL_VERIFIED.csv"
        import csv
        with mp.open(newline="") as f:rows=list(csv.DictReader(f))
        missing=[]
        for r in rows:
            roi=r["official_roi"]
            for f in [d/"CellType"/(roi+".mat"),d/"Segmentation"/roi/"allRegionIndices.mat",d/"Segmentation"/roi/"nuclei_multiscale.mat"]:
                if not f.exists():missing.append(str(f.relative_to(root)))
        if missing:raise ValueError("Missing official ROI files: "+str(missing[:10]))
        print("Official named ROI layout ready:",len(rows),"ROIs;",count,"files. No order-based identity remapping.")
if __name__=="__main__":main()
