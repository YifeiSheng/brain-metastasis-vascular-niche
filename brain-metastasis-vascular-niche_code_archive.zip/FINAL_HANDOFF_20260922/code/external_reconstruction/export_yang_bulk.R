# Author bulk RDS objects -> CSV expected by scripts 50 and 84; no normalization.
args=commandArgs(trailingOnly=TRUE)
if(length(args)!=1) stop("Usage: Rscript export_yang_bulk.R DATA_EXTERNAL/bulk/Yang2026_BrM_zenodo")
d=args[[1]]
for(pair in list(c("discovery.counts.rds","discovery.counts.csv"),c("inhouse.validation.counts.rds","validation.counts.csv"))) {
  x=readRDS(file.path(d,pair[[1]]))
  if(is.null(dim(x))||is.null(rownames(x))||is.null(colnames(x))) stop("Missing named matrix axes")
  out=file.path(d,pair[[2]])
  if(file.exists(out)) stop(paste("Refusing overwrite",out))
  write.csv(x,out)
  cat(pair[[2]],nrow(x),ncol(x),"rows/columns; no normalization or sorting\n")
}
