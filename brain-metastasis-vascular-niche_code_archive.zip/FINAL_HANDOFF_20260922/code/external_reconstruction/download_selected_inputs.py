"""Download only a selected frozen source roster. No downloads without --download.
Default root is this package; set --root to a working copy before reconstruction.
"""
import argparse, hashlib, json, shutil, urllib.request
from pathlib import Path
P=Path(__file__).resolve().parents[2]
def sha(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(8<<20),b""): h.update(b)
    return h.hexdigest()
def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root",type=Path,default=P)
    ap.add_argument("--dataset",required=True,help="One dataset ID from source_downloads.json")
    ap.add_argument("--download",action="store_true",help="Without this flag, print the exact download plan only.")
    a=ap.parse_args()
    records=json.loads((Path(__file__).parent/"specifications/source_downloads.json").read_text())["files"]
    chosen=[r for r in records if r["dataset"]==a.dataset]
    if not chosen: raise SystemExit("Unknown dataset. Choices: "+", ".join(sorted({r["dataset"] for r in records})))
    for r in chosen:
        f=a.root/r["path"]
        print(r["url"],"->",f,flush=True)
        if not a.download: continue
        if f.exists():
            if r.get("sha256") and sha(f)!=r["sha256"]: raise ValueError("Existing checksum mismatch: "+str(f))
            if r.get("bytes") and f.stat().st_size!=r["bytes"]: raise ValueError("Existing size mismatch: "+str(f))
            continue
        f.parent.mkdir(parents=True,exist_ok=True)
        tmp=f.with_name(f.name+".partial")
        req=urllib.request.Request(r["url"],headers={"User-Agent":"Safeposter-reconstruction/1.0"})
        with urllib.request.urlopen(req,timeout=120) as response, tmp.open("wb") as out: shutil.copyfileobj(response,out,8<<20)
        if r.get("bytes") and tmp.stat().st_size!=r["bytes"]: raise ValueError("Downloaded size mismatch: "+str(tmp))
        if r.get("sha256") and sha(tmp)!=r["sha256"]: raise ValueError("Downloaded checksum mismatch: "+str(tmp))
        tmp.replace(f)
if __name__=="__main__": main()
