#!/usr/bin/env Rscript
# Reproduce the frozen Kim2020 D4 raw-UMI export; no normalization or cell QC here.
Sys.setenv(OPENBLAS_NUM_THREADS="2",OMP_NUM_THREADS="2",MKL_NUM_THREADS="2")
suppressPackageStartupMessages({library(Matrix);library(jsonlite)})
args<-commandArgs(TRUE)
if(length(args)!=2)stop("Usage: Rscript export_kim_D4.R SOURCE_DIRECTORY OUTPUT_DIRECTORY")
E<-normalizePath(args[1],mustWork=TRUE);O<-args[2]
dir.create(O,recursive=TRUE,showWarnings=FALSE)
outfiles<-file.path(O,c("matrix.mtx","features.tsv","barcodes.tsv","cell_annotation_subset.csv"))
if(any(file.exists(outfiles)))stop("Output payload exists; use a new reconstruction directory")
rds<-file.path(E,"GSE131907_raw_UMI_matrix.rds")
if(!file.exists(rds)){
    outer<-file.path(E,"GSE131907_Lung_Cancer_raw_UMI_matrix.rds.gz")
    if(!file.exists(outer))stop("Missing GEO raw RDS archive")
    # GEO file has an outer gzip wrapped around an already gz-compressed RDS.
    # Strip exactly one outer layer; readRDS handles the inner RDS compression.
    inp<-gzfile(outer,"rb");out<-file(rds,"wb")
    repeat {chunk<-readBin(inp,"raw",n=4*1024*1024);if(!length(chunk))break;writeBin(chunk,out)}
    close(inp);close(out)
}
ann<-read.delim(gzfile(file.path(E,"GSE131907_Lung_Cancer_cell_annotation.txt.gz")),stringsAsFactors=FALSE)
stopifnot(!anyDuplicated(ann$Index))
keep<-ann[ann$Sample_Origin %in% c("mBrain","tLung","nLung"),]
m<-readRDS(rds);input_dim<-dim(m)
stopifnot(!anyDuplicated(colnames(m)),!anyDuplicated(rownames(m)))
selected<-intersect(colnames(m),keep$Index)
m<-m[,selected,drop=FALSE]
if(!inherits(m,"sparseMatrix"))m<-Matrix(as.matrix(m),sparse=TRUE)
annotation<-keep[match(colnames(m),keep$Index),]
stopifnot(identical(as.character(annotation$Index),colnames(m)))
stopifnot(all(is.finite(m@x)),all(m@x>=0),all(m@x==round(m@x)))
writeMM(m,file.path(O,"matrix.mtx"))
writeLines(rownames(m),file.path(O,"features.tsv"))
writeLines(colnames(m),file.path(O,"barcodes.tsv"))
write.csv(annotation,file.path(O,"cell_annotation_subset.csv"),row.names=FALSE)
write_json(list(input_dim=input_dim,output_dim=dim(m),nnz=length(m@x),sum_UMI=sum(m@x),
 sample_origins=as.list(table(annotation$Sample_Origin)),n_samples=length(unique(annotation$Sample)),
 selection=c("mBrain","tLung","nLung"),matrix_orientation="genes x cells",
 cell_order="source RDS columns, retained by intersect; not sorted by annotation",
 gene_order="original RDS row order; all genes retained",normalization="none",
 R=R.version.string,Matrix=as.character(packageVersion("Matrix"))),
 file.path(O,"KIM_EXPORT_REPORT.json"),auto_unbox=TRUE,pretty=TRUE)
cat("EXPORTED",nrow(m),ncol(m),length(m@x),"\n")
