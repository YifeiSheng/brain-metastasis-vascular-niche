"""Restore frozen sample-selection parameters, never expression measurements."""
import argparse,hashlib,json,shutil
from pathlib import Path
P=Path(__file__).resolve().parents[2]
a=argparse.ArgumentParser(description=__doc__)
a.add_argument("--root",type=Path,default=P)
args=a.parse_args()
spec=Path(__file__).parent/"specifications"
for r in json.loads((spec/"sample_rosters.json").read_text())["files"]:
    src=spec/r["file"]; dst=args.root/r["restore_path"]
    assert hashlib.sha256(src.read_bytes()).hexdigest()==r["sha256"]
    if dst.exists():
        if hashlib.sha256(dst.read_bytes()).hexdigest()!=r["sha256"]: raise ValueError("Refusing different existing roster: "+str(dst))
    else:
        dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
    print(dst)
